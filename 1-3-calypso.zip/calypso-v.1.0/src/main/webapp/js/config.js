var hostname = "localhost";
var port = "8080";
var schoolId = "";  // do not assign a value for this, as the value is taken from the parameter passed in URL, at later point of script
var protocol = "http";
var mainRoute = "api/v1";
var project = "calypso"