package com.calypso.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.calypso.json.request.NewAdmissionRequest;
import com.calypso.manager.AdmissionManager;



@RestController
@RequestMapping("api/v1/")
public class AdmissionController {

		//private Logger logger = Logger.getLogger(AdmissionController.class);

		@Autowired
		AdmissionManager admissionManager;
		
		  @RequestMapping(value = "newStudent/{schoolId}", method = RequestMethod.POST, produces = "application/json")
		 @ResponseBody
		  public ResponseEntity<NewAdmissionRequest> addNewAdmission(
				  @PathVariable(value = "schoolId") String schoolId,
				  @RequestBody NewAdmissionRequest newAdmissionRequest)
		      throws Exception {
			 // logger.debug("Inside Controller");

			 NewAdmissionRequest response = admissionManager.insertNewAdmissionData(schoolId, newAdmissionRequest);
		    return new ResponseEntity<NewAdmissionRequest>(response, HttpStatus.CREATED);
		  }

		 
	

}
