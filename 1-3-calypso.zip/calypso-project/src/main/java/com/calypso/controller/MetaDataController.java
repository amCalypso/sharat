package com.calypso.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.calypso.common.LoginRequest;
import com.calypso.common.LoginResponse;
import com.calypso.json.request.MetaDataRequestMessage;
import com.calypso.json.response.MetaDataResponseMessage;
import com.calypso.manager.LoginManager;
import com.calypso.manager.MetaDataManager;

@RestController
@RequestMapping("calypso/api/v1/")
public class MetaDataController {

	private Logger logger = Logger.getLogger(MetaDataController.class);
	
	@Autowired
	MetaDataManager metaDataManager;

	@RequestMapping(value = "/sendmessage/{SCHOOL_ID}", method = RequestMethod.POST)
	@ResponseBody
	
	public ResponseEntity<?> metaDataPost(	
			@Validated @RequestBody(required = true) MetaDataRequestMessage metaDataRequest) {
		MetaDataResponseMessage response = new MetaDataResponseMessage();
		logger.debug("Debug- > Controller Logging for calypso ************** ");
		try {			
			response = metaDataManager.postMessage(metaDataRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<MetaDataResponseMessage>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<MetaDataResponseMessage>(response, HttpStatus.OK);
	}
	
}
