package com.calypso.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("calypso/api/v1/sendMessage")
public class AdminController {/*

	private Logger logger = Logger.getLogger(AdminController.class);

	@Autowired
	AdminManager adminManager;

	@RequestMapping(value = "/{schoolID}", method = RequestMethod.GET)

	public ResponseEntity<?> getschoolById(@PathVariable("schoolID") String schoolID) {
		AdminResponse response = new AdminResponse();
		logger.debug("Debug- > Admin Logging for calypso ************** ");
		try {			
			response = adminManager.getschoolById(schoolID);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<AdminResponse>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<AdminResponse>(response, HttpStatus.OK);
	}

*/}
