package com.calypso.mongo.core;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.calypso.config.SpringMongoConfig;
import com.calypso.mongo.model.User;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.ServerAddress;

public class MongoCRUD {
	
	private static ApplicationContext ctx;
	
	public static void main(String[] args) {

		ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");

		//User user = new User("mkyong", "password123");
		
		//User user = new User("mkyong", "password123");
		User user = new User("sharat", "rumjack");
		
		Builder o = MongoClientOptions.builder().connectTimeout(3000);  
		MongoClient mongo = new MongoClient(new ServerAddress("127.0.0.1"), o.build());    

		try {
		  mongo.getAddress();
		  System.out.println("Mongo is UP");
		} catch (Exception e) {
		  System.out.println("Mongo is down");
		  mongo.close();
		  return;
		}
		
	/*	DBCollection collection = db.getCollection("users");

		// convert JSON to DBObject directly
		DBObject dbObject = (DBObject) JSON
				.parse("{'name':'mkyong', 'age':30}");*/

		
		
		
		// save
		mongoOperation.save(user);

		// now user object got the created id.
		System.out.println("1. user : " + user);

		// query to search user
		Query searchUserQuery = new Query(Criteria.where("username").is("sharat"));

		// find the saved user again.
		User savedUser = mongoOperation.findOne(searchUserQuery, User.class);
		System.out.println("2. find - savedUser : " + savedUser);

		// update password
		mongoOperation.updateFirst(searchUserQuery,
				Update.update("password", "Idagunji20"),User.class);

		// find the updated user object
		User updatedUser = mongoOperation.findOne(searchUserQuery, User.class);

		System.out.println("3. updatedUser : " + updatedUser);

		// List, it should be empty now.
		List<User> listUser = mongoOperation.findAll(User.class);
		System.out.println("4. Number of user = " + listUser.size());
		
	}
}
