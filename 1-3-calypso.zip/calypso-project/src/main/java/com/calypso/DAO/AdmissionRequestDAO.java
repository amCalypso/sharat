package com.calypso.DAO;

import com.calypso.json.request.NewAdmissionRequest;

public interface AdmissionRequestDAO {

	NewAdmissionRequest addNewAdmissionData(NewAdmissionRequest newAdmissionRequest);
	

}
