package com.calypso.DAO;

import javax.persistence.PersistenceContext;

import com.calypso.json.request.NewAdmissionRequest;

public class AdmissionRequestDAOImpl implements  AdmissionRequestDAO{
	
	
/*	  @PersistenceContext(unitName = "eventPersistenceUnit")
	  EntityManager entityManager;
	 
	 
	  public NewAdmissionRequest addNewAdmissionData(EventTopicORM eventTopic) throws SQLException {
		    entityManager.persist(eventTopic);
		    return eventTopic;
		  }*/

	@Override
	public NewAdmissionRequest addNewAdmissionData(NewAdmissionRequest newAdmissionRequest) {

		
		
		return newAdmissionRequest;
	}

}
