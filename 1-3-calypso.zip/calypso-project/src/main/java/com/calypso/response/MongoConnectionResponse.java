package com.calypso.response;

public class MongoConnectionResponse {
	
	private String connectionResponse;

	public String getConnectionResponse() {
		return connectionResponse;
	}

	public void setConnectionResponse(String connectionResponse) {
		this.connectionResponse = connectionResponse;
	}

	

}
