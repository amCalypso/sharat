package com.calypso.response;

public class MongoUpdateResponse {

}
