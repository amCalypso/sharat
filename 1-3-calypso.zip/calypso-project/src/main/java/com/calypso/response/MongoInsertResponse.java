package com.calypso.response;

public class MongoInsertResponse {

}
