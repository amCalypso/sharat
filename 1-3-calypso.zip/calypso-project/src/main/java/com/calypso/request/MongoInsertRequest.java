package com.calypso.request;


public class MongoInsertRequest {
	
	
}

