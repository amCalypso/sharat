package com.calypso.pojobean;

public class Admin {


	private String AllInClass;
	private String AllInSchool;
	private String AllInSection;
	private String Body;
	private String From;
	private String SingleStudent;
	private String Title;
	private String selectedYear;
	private String selectedClass;
	private String selectedSection;
	private String selectedStudent;
	
	
	public String getAllInClass() {
		return AllInClass;
	}
	public void setAllInClass(String allInClass) {
		AllInClass = allInClass;
	}
	public String getAllInSchool() {
		return AllInSchool;
	}
	public void setAllInSchool(String allInSchool) {
		AllInSchool = allInSchool;
	}
	public String getAllInSection() {
		return AllInSection;
	}
	public void setAllInSection(String allInSection) {
		AllInSection = allInSection;
	}
	public String getBody() {
		return Body;
	}
	public void setBody(String body) {
		Body = body;
	}
	public String getFrom() {
		return From;
	}
	public void setFrom(String from) {
		From = from;
	}
	public String getSingleStudent() {
		return SingleStudent;
	}
	public void setSingleStudent(String singleStudent) {
		SingleStudent = singleStudent;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getSelectedYear() {
		return selectedYear;
	}
	public void setSelectedYear(String selectedYear) {
		this.selectedYear = selectedYear;
	}
	public String getSelectedClass() {
		return selectedClass;
	}
	public void setSelectedClass(String selectedClass) {
		this.selectedClass = selectedClass;
	}
	public String getSelectedSection() {
		return selectedSection;
	}
	public void setSelectedSection(String selectedSection) {
		this.selectedSection = selectedSection;
	}
	public String getSelectedStudent() {
		return selectedStudent;
	}
	public void setSelectedStudent(String selectedStudent) {
		this.selectedStudent = selectedStudent;
	}


}

