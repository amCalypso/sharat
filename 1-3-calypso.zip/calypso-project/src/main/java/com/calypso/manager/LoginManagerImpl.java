package com.calypso.manager;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.calypso.common.LoginRequest;
import com.calypso.common.LoginResponse;

@Service
public class LoginManagerImpl implements LoginManager {
	
	private Logger logger = Logger.getLogger(LoginManagerImpl.class);

	LoginResponse response = new LoginResponse();
	
	@Override
	public LoginResponse authenticateUser(LoginRequest loginRequest) throws Exception {
		
		logger.debug("Debug- > Manager Logging for calypso ************** ");
		
		response.setRole("ADMIN");
		response.setStatus("SUCCECSS");
		
		return response;
	}

}
