package com.calypso.manager;

import com.calypso.json.request.MetaDataRequestMessage;
import com.calypso.json.response.MetaDataResponseMessage;

public interface MetaDataManager {

	MetaDataResponseMessage postMessage(MetaDataRequestMessage metaDataRequest);

}
