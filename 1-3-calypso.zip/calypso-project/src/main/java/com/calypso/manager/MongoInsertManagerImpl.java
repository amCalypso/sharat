package com.calypso.manager;

import com.calypso.request.MongoInsertRequest;
import com.calypso.response.MongoInsertResponse;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class MongoInsertManagerImpl implements MongoInsertManager {

	MongoInsertResponse response = new MongoInsertResponse();
	private Logger logger = Logger.getLogger(MongoInsertManagerImpl.class);

	
	
	@Override
	public MongoInsertResponse insertResponse(MongoInsertRequest mongoInsertRequest) throws Exception {
		
		logger.debug("Debug- > Insert Record starting now ************** ");
		
		
		return null;
	}

}
