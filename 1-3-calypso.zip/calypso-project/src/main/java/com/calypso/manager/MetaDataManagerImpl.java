package com.calypso.manager;

import org.springframework.stereotype.Service;

import com.calypso.json.request.MetaDataRequestMessage;
import com.calypso.json.response.MetaDataResponseMessage;

@Service
public class MetaDataManagerImpl implements MetaDataManager{

	@Override
	public MetaDataResponseMessage postMessage(MetaDataRequestMessage metaDataRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}
