package com.calypso.manager;

import com.calypso.request.MongoInsertRequest;
import com.calypso.request.MongoUpdateRequest;
import com.calypso.response.MongoInsertResponse;
import com.calypso.response.MongoUpdateResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class MongoUpdateManagerImpl implements MongoUpdateManager {

	MongoUpdateResponse response = new MongoUpdateResponse();
	private Logger logger = Logger.getLogger(MongoUpdateManagerImpl.class);

	
	
	@Override
	public MongoUpdateResponse updateResponse(MongoUpdateRequest mongoUpdateRequest) throws Exception {
		
		logger.debug("Debug- > Insert Record starting now ************** ");
		
		
		return null;
	}

}
