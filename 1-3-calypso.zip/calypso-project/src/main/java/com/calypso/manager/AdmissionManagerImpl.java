package com.calypso.manager;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.calypso.json.request.NewAdmissionRequest;
import com.mongodb.MongoClient;

@Service
public class AdmissionManagerImpl implements AdmissionManager{
		
		@Override
		public NewAdmissionRequest insertNewAdmissionData(String schoolId, NewAdmissionRequest newAdmissionRequest) {
			
			final String DB_NAME = schoolId;
			final String STUDENT_COLLECTION = "Student";
			final String MONGO_HOST = "localhost";
			final int MONGO_PORT = 27017;
			
			MongoClient mongo = new MongoClient(
					MONGO_HOST, MONGO_PORT);
			MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);
			
			mongoOps.insert(newAdmissionRequest, STUDENT_COLLECTION);

		
			mongo.close();
			
			return null;
		}
		
	}
