package com.calypso.manager;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Service;

import com.calypso.config.SpringMongoConfig;
import com.calypso.request.MongoConnectionRequest;
import com.calypso.response.MongoConnectionResponse;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.ServerAddress;

@Service
public class MongoConnectManagerImpl implements MongoConnectManager {

	MongoConnectionResponse response = new MongoConnectionResponse();

	@Override
	public MongoConnectionResponse connectionResponse(MongoConnectionRequest mongoConnectionResponse) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");

		MongoConnectionRequest user = new MongoConnectionRequest("mkyong", "password123");

		System.out.println("userName  " +user.getUsername());
		System.out.println("userPassword "+user.getPassword());

		Builder o = MongoClientOptions.builder().connectTimeout(3000);  
		MongoClient mongo = new MongoClient(new ServerAddress("127.0.0.1"), o.build());    
		try {
			mongo.getAddress();
			System.out.println(mongo.getAddress());
			System.out.println("Mongo is UP");
			response.setConnectionResponse("SUCCESS");
			return response;
		}  catch (Exception e) {
			System.out.println("Mongo is down");
			response.setConnectionResponse("FAILURE");
			mongo.close();
			return response;
		}
	}
}
