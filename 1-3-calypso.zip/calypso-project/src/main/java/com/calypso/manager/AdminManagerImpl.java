package com.calypso.manager;

import org.springframework.stereotype.Service;

import com.calypso.json.response.AdminResponse;

@Service
public class AdminManagerImpl  implements AdminManager{

	@Override
	public AdminResponse getschoolById(String schoolID) throws Exception {

		
		return null;
	}

}
