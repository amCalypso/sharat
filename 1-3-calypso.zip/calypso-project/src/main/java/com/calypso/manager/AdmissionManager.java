package com.calypso.manager;

import org.springframework.stereotype.Component;

import com.calypso.json.request.NewAdmissionRequest;

@Component
public interface AdmissionManager {

	NewAdmissionRequest insertNewAdmissionData(String schoolId, NewAdmissionRequest newAdmissionRequest);

}
