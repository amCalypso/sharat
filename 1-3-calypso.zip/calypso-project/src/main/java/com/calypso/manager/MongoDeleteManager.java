package com.calypso.manager;

import com.calypso.request.MongoDeleteRequest;
import com.calypso.response.MongoDeleteResponse;

public interface MongoDeleteManager {

	MongoDeleteResponse deleteResponse(MongoDeleteRequest mongoDeleteRequest) throws Exception;

}
