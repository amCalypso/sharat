package com.calypso.manager;

import com.calypso.json.response.AdminResponse;

public interface AdminManager {
	
	AdminResponse getschoolById(String schoolID) throws  Exception;

}
