package com.calypso.manager;

import com.calypso.request.MongoInsertRequest;
import com.calypso.response.MongoInsertResponse;

public interface MongoInsertManager {

	MongoInsertResponse insertResponse (MongoInsertRequest mongoInsertRequest) throws   Exception ;
	
}
