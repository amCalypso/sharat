package com.calypso;

import com.calypso.json.request.MetaDataRequestMessage;
import com.calypso.json.response.MetaDataResponseMessage;
import com.calypso.manager.MetaDataManager;

public class MetaDataManagerImpl implements MetaDataManager{

	@Override
	public MetaDataResponseMessage postMessage(MetaDataRequestMessage metaDataRequest) {

		
		
		
		return null;
	}

}
