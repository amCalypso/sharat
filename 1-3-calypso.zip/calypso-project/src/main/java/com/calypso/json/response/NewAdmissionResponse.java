package com.calypso.json.response;

public class NewAdmissionResponse {

}
