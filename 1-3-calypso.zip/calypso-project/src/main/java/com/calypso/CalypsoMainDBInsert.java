package com.calypso;

import java.net.UnknownHostException;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.calypso.json.request.NewAdmissionRequest;
import com.mongodb.MongoClient;

public class CalypsoMainDBInsert {
	
	public static final String DB_NAME = "calypso-db";
	public static final String STUDENT_COLLECTION = "Student";
	public static final String MONGO_HOST = "localhost";
	public static final int MONGO_PORT = 27017;

	public static void main(String[] args) {
		MongoClient mongo = new MongoClient(
				MONGO_HOST, MONGO_PORT);
		MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);
		NewAdmissionRequest p = new NewAdmissionRequest();
		p.setAddress("Bangalore");
		p.setAlternatePhoneNumber(null);
		mongoOps.insert(p, STUDENT_COLLECTION);

	/*	NewAdmissionRequest p1 = mongoOps.findOne(
				new Query(Criteria.where("name").is("sharat")),
				NewAdmissionRequest.class, STUDENT_COLLECTION);*/

		//System.out.println(p1);
		
		//mongoOps.dropCollection(PERSON_COLLECTION);
		mongo.close();
	}

}
