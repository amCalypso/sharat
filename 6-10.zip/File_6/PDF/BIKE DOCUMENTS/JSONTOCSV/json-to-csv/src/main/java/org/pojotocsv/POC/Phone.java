package org.pojotocsv.POC;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Phone {

	@JsonProperty("ProfileId")
	private String ProfileId;
	
	@JsonProperty("PhoneId")
	private String PhoneId;
	
	@JsonProperty("PhoneNumber")
	private String PhoneNumber;
	
	@JsonProperty("SourcePhoneNumber")
	private String SourcePhoneNumber;
	
	@JsonProperty("PhoneCountryCode")
	private String PhoneCountryCode;
	
	@JsonProperty("AcceptsText")
	private boolean AcceptsText;
	
	@JsonProperty("Frequency")
	private long Frequency;
	
	@JsonProperty("NeverBefore")
	private Date NeverBefore;
	
	@JsonProperty("NeverAfter")
	private Date NeverAfter;
	
	@JsonProperty("ChannelCode")
	private String ChannelCode;
	
	@JsonProperty("LocationCode")
	private String LocationCode;
	
	@JsonProperty("IsPreferred")
	private boolean IsPreferred;
	
	@JsonProperty("DeliveryStatus")
	private String DeliveryStatus;
	
	@JsonProperty("AccountSourceCode")
	private String AccountSourceCode;
	
	@JsonProperty("SourceAccountNumber")
	private String SourceAccountNumber;
	
	@JsonProperty("BrandOrgCode")
	private String BrandOrgCode;
	
	@JsonProperty("ActivityDate")
	private Date ActivityDate;
	
	@JsonProperty("CreateFileId")
	private long CreateFileId;
	
	@JsonProperty("CreateRecordNumber")
	private long CreateRecordNumber;
	
	@JsonProperty("UpdateFileId")
	private long UpdateFileId;
	
	@JsonProperty("UpdateRecordNumber")
	private long UpdateRecordNumber;
	
	@JsonProperty("ContactPointId")
	private String ContactPointId;
	
	@JsonProperty("OriginalContactPoint")
	private OriginalContactPoint OriginalContactPoint;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("CreateUser")
	private String CreateUser;
	
	@JsonProperty("CreateDate")
	private Date CreateDate;
	
	@JsonProperty("UpdateUser")
	private String UpdateUser;
	
	@JsonProperty("UpdateDate")
	private Date UpdateDate;
	
	public String getProfileId() {
		return ProfileId;
	}
	public void setProfileId(String profileId) {
		ProfileId = profileId;
	}
	public String getPhoneId() {
		return PhoneId;
	}
	public void setPhoneId(String phoneId) {
		PhoneId = phoneId;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getSourcePhoneNumber() {
		return SourcePhoneNumber;
	}
	public void setSourcePhoneNumber(String sourcePhoneNumber) {
		SourcePhoneNumber = sourcePhoneNumber;
	}
	public String getPhoneCountryCode() {
		return PhoneCountryCode;
	}
	public void setPhoneCountryCode(String phoneCountryCode) {
		PhoneCountryCode = phoneCountryCode;
	}
	public boolean isAcceptsText() {
		return AcceptsText;
	}
	public void setAcceptsText(boolean acceptsText) {
		AcceptsText = acceptsText;
	}
	public long getFrequency() {
		return Frequency;
	}
	public void setFrequency(long frequency) {
		Frequency = frequency;
	}
	public Date getNeverBefore() {
		return NeverBefore;
	}
	public void setNeverBefore(Date neverBefore) {
		NeverBefore = neverBefore;
	}
	public Date getNeverAfter() {
		return NeverAfter;
	}
	public void setNeverAfter(Date neverAfter) {
		NeverAfter = neverAfter;
	}
	public String getChannelCode() {
		return ChannelCode;
	}
	public void setChannelCode(String channelCode) {
		ChannelCode = channelCode;
	}
	public String getLocationCode() {
		return LocationCode;
	}
	public void setLocationCode(String locationCode) {
		LocationCode = locationCode;
	}
	public boolean isIsPreferred() {
		return IsPreferred;
	}
	public void setIsPreferred(boolean isPreferred) {
		IsPreferred = isPreferred;
	}
	public String getDeliveryStatus() {
		return DeliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		DeliveryStatus = deliveryStatus;
	}
	public String getAccountSourceCode() {
		return AccountSourceCode;
	}
	public void setAccountSourceCode(String accountSourceCode) {
		AccountSourceCode = accountSourceCode;
	}
	public String getSourceAccountNumber() {
		return SourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		SourceAccountNumber = sourceAccountNumber;
	}
	public String getBrandOrgCode() {
		return BrandOrgCode;
	}
	public void setBrandOrgCode(String brandOrgCode) {
		BrandOrgCode = brandOrgCode;
	}
	public Date getActivityDate() {
		return ActivityDate;
	}
	public void setActivityDate(Date activityDate) {
		ActivityDate = activityDate;
	}
	public long getCreateFileId() {
		return CreateFileId;
	}
	public void setCreateFileId(long createFileId) {
		CreateFileId = createFileId;
	}
	public long getCreateRecordNumber() {
		return CreateRecordNumber;
	}
	public void setCreateRecordNumber(long createRecordNumber) {
		CreateRecordNumber = createRecordNumber;
	}
	public long getUpdateFileId() {
		return UpdateFileId;
	}
	public void setUpdateFileId(long updateFileId) {
		UpdateFileId = updateFileId;
	}
	public long getUpdateRecordNumber() {
		return UpdateRecordNumber;
	}
	public void setUpdateRecordNumber(long updateRecordNumber) {
		UpdateRecordNumber = updateRecordNumber;
	}
	public String getContactPointId() {
		return ContactPointId;
	}
	public void setContactPointId(String contactPointId) {
		ContactPointId = contactPointId;
	}
	public OriginalContactPoint getOriginalContactPoint() {
		return OriginalContactPoint;
	}
	public void setOriginalContactPoint(OriginalContactPoint originalContactPoint) {
		OriginalContactPoint = originalContactPoint;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getCreateUser() {
		return CreateUser;
	}
	public void setCreateUser(String createUser) {
		CreateUser = createUser;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public String getUpdateUser() {
		return UpdateUser;
	}
	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}
	public Date getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}
	
	
}
