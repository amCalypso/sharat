package org.pojotocsv.POC;

public class SocialAccount {

}
