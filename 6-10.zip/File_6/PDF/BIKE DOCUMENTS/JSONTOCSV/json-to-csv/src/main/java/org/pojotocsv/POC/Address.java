package org.pojotocsv.POC;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Address {

	@JsonProperty("ProfileId")
	private String ProfileId;
	
	@JsonProperty("AddressId")
	private String AddressId;
	
	@JsonProperty("AddressLine1")
	private String AddressLine1;
	
	@JsonProperty("SourceAddressLine1")
	private String SourceAddressLine1;
	
	@JsonProperty("AddressLine2")
	private String AddressLine2;
	
	@JsonProperty("SourceAddressLine2")
	private String SourceAddressLine2;
	
	@JsonProperty("AddressLine3")
	private String AddressLine3;
	
	@JsonProperty("SourceAddressLine3")
	private String SourceAddressLine3;
	
	@JsonProperty("City")
	private String City;
	
	@JsonProperty("SourceCity")
	private String SourceCity;
	
	@JsonProperty("StateCode")
	private String StateCode;
	
	@JsonProperty("SourceStateCode")
	private String SourceStateCode;
	
	@JsonProperty("CountryCode")
	private String CountryCode;
	
	@JsonProperty("SourceCountryCode")
	private String SourceCountryCode;
	
	@JsonProperty("PostalCode")
	private String PostalCode;
	
	@JsonProperty("SourcePostalCode")
	private String SourcePostalCode;
	
	@JsonProperty("ChannelCode")
	private String ChannelCode;
	
	@JsonProperty("LocationCode")
	private String LocationCode;
	
	@JsonProperty("IsPreferred")
	private boolean IsPreferred;
	
	@JsonProperty("DeliveryStatus")
	private String DeliveryStatus;
	
	@JsonProperty("DoNotStandardize")
	private boolean DoNotStandardize;
	
	@JsonProperty("AccountSourceCode")
	private String AccountSourceCode;
	
	@JsonProperty("SourceAccountNumber")
	private String SourceAccountNumber;
	
	@JsonProperty("BrandOrgCode")
	private String BrandOrgCode;
	
	@JsonProperty("ActivityDate")
	private Date ActivityDate;
	
	@JsonProperty("CreateFileId")
	private long CreateFileId;
	
	@JsonProperty("CreateRecordNumber")
	private long CreateRecordNumber;
	
	@JsonProperty("UpdateFileId")
	private long UpdateFileId;
	
	@JsonProperty("UpdateRecordNumber")
	private long UpdateRecordNumber;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("CreateUser")
	private String CreateUser;
	
	@JsonProperty("CreateDate")
	private Date CreateDate;
	
	@JsonProperty("UpdateUser")
	private String UpdateUser;
	
	@JsonProperty("UpdateDate")
	private String UpdateDate;
	
	
	
	public String getProfileId() {
		return ProfileId;
	}
	public void setProfileId(String profileId) {
		ProfileId = profileId;
	}
	public String getAddressId() {
		return AddressId;
	}
	public void setAddressId(String addressId) {
		AddressId = addressId;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getSourceAddressLine1() {
		return SourceAddressLine1;
	}
	public void setSourceAddressLine1(String sourceAddressLine1) {
		SourceAddressLine1 = sourceAddressLine1;
	}
	public String getAddressLine2() {
		return AddressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public String getSourceAddressLine2() {
		return SourceAddressLine2;
	}
	public void setSourceAddressLine2(String sourceAddressLine2) {
		SourceAddressLine2 = sourceAddressLine2;
	}
	public String getAddressLine3() {
		return AddressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		AddressLine3 = addressLine3;
	}
	public String getSourceAddressLine3() {
		return SourceAddressLine3;
	}
	public void setSourceAddressLine3(String sourceAddressLine3) {
		SourceAddressLine3 = sourceAddressLine3;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getSourceCity() {
		return SourceCity;
	}
	public void setSourceCity(String sourceCity) {
		SourceCity = sourceCity;
	}
	public String getStateCode() {
		return StateCode;
	}
	public void setStateCode(String stateCode) {
		StateCode = stateCode;
	}
	public String getSourceStateCode() {
		return SourceStateCode;
	}
	public void setSourceStateCode(String sourceStateCode) {
		SourceStateCode = sourceStateCode;
	}
	public String getCountryCode() {
		return CountryCode;
	}
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}
	public String getSourceCountryCode() {
		return SourceCountryCode;
	}
	public void setSourceCountryCode(String sourceCountryCode) {
		SourceCountryCode = sourceCountryCode;
	}
	public String getChannelCode() {
		return ChannelCode;
	}
	public void setChannelCode(String channelCode) {
		ChannelCode = channelCode;
	}
	public String getLocationCode() {
		return LocationCode;
	}
	public void setLocationCode(String locationCode) {
		LocationCode = locationCode;
	}
	public boolean isIsPreferred() {
		return IsPreferred;
	}
	public void setIsPreferred(boolean isPreferred) {
		IsPreferred = isPreferred;
	}
	public String getDeliveryStatus() {
		return DeliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		DeliveryStatus = deliveryStatus;
	}
	public boolean isDoNotStandardize() {
		return DoNotStandardize;
	}
	public void setDoNotStandardize(boolean doNotStandardize) {
		DoNotStandardize = doNotStandardize;
	}
	public String getAccountSourceCode() {
		return AccountSourceCode;
	}
	public void setAccountSourceCode(String accountSourceCode) {
		AccountSourceCode = accountSourceCode;
	}
	public String getSourceAccountNumber() {
		return SourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		SourceAccountNumber = sourceAccountNumber;
	}
	public String getBrandOrgCode() {
		return BrandOrgCode;
	}
	public void setBrandOrgCode(String brandOrgCode) {
		BrandOrgCode = brandOrgCode;
	}
	public Date getActivityDate() {
		return ActivityDate;
	}
	public void setActivityDate(Date activityDate) {
		ActivityDate = activityDate;
	}
	public long getCreateFileId() {
		return CreateFileId;
	}
	public void setCreateFileId(long createFileId) {
		CreateFileId = createFileId;
	}
	public long getCreateRecordNumber() {
		return CreateRecordNumber;
	}
	public void setCreateRecordNumber(long createRecordNumber) {
		CreateRecordNumber = createRecordNumber;
	}
	public long getUpdateFileId() {
		return UpdateFileId;
	}
	public void setUpdateFileId(long updateFileId) {
		UpdateFileId = updateFileId;
	}
	public long getUpdateRecordNumber() {
		return UpdateRecordNumber;
	}
	public void setUpdateRecordNumber(long updateRecordNumber) {
		UpdateRecordNumber = updateRecordNumber;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getCreateUser() {
		return CreateUser;
	}
	public void setCreateUser(String createUser) {
		CreateUser = createUser;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public String getUpdateUser() {
		return UpdateUser;
	}
	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	public String getSourcePostalCode() {
		return SourcePostalCode;
	}
	public void setSourcePostalCode(String sourcePostalCode) {
		SourcePostalCode = sourcePostalCode;
	}
	public String getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(String updateDate) {
		UpdateDate = updateDate;
	}
	
	
	
	
	
	
}
