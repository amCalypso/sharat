package SampleDemo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import org.supercsv.cellprocessor.ParseBool;
import org.supercsv.cellprocessor.ParseDate;
import org.supercsv.cellprocessor.ParseDouble;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.prefs.CsvPreference;

public class BeanReader {


	public static void main(String[] args) {


		//String csvFileName = "isbn";
		
		String csv = "0321356683,Effective Java,Joshua Bloch,Addision-Wesley,05/08/2008,38";

		//readCSVFile(csvFileName);
		
		readCSVFile(csv);

	}

	private static void readCSVFile(String csvFileName) {

		//System.out.println("csvFileName " +csvFileName);

		ICsvBeanReader beanReader = null;
		CellProcessor[] processors = new CellProcessor[] {
				new NotNull(), // ISBN
				new NotNull(), // title
				new NotNull(), // author
				new NotNull(), // publisher
				//new ParseDate("MM/dd/yyyy"), // published date
				new ParseBool(),
				new ParseDouble() // price
		};

		try {
			beanReader = new CsvBeanReader(new StringReader(csvFileName),CsvPreference.STANDARD_PREFERENCE);
			//String[] header = beanReader.getHeader(false);
			String[] header = {"isbn", "title", "author", "publisher", "published", "price"};
			/*for(String a : header){
				System.out.println("******** "+a);
				
			}*/
			Book bookBean = null;
			System.out.printf("**********" );
			while ((bookBean = beanReader.read(Book.class, header, processors)) != null) {
				System.out.printf("#########" +bookBean.getIsbn());
				System.out.println();
			}
		}  catch (IOException ex) {
			System.err.println("Error reading the CSV file: " + ex);
		} finally {
			if (beanReader != null) {
				try {
					beanReader.close();
				} catch (IOException ex) {
					System.err.println("Error closing the reader: " + ex);
				}
			}
		}

	}
}
