package org.pojotocsv.POC;


import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Jackson2Example2 {

	public static void main(String[] args) {
		Jackson2Example2 obj = new Jackson2Example2();
		obj.run();
	}

	private void run() {
		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonInString = "{\r\n\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\"ClientAccountId\": \"\",\r\n\t\"Prefix\": \"\",\r\n\t\"SourcePrefix\": \"\",\r\n\t\"FirstName\": \"Angie\",\r\n\t\"SourceFirstName\": \"Angie\",\r\n\t\"MiddleInit\": \"\",\r\n\t\"SourceMiddleInit\": \"\",\r\n\t\"LastName\": \"Potter\",\r\n\t\"SourceLastName\": \"Potter\",\r\n\t\"Suffix\": \"\",\r\n\t\"SourceSuffix\": \"\",\r\n\t\"GlobalOptOut\": false,\r\n\t\"GlobalOptDate\": \"2017-10-26T13:29:25.501684Z\",\r\n\t\"GlobalOptSource\": \"\",\r\n\t\"LanguageCode\": \"EN\",\r\n\t\"MaritalStatus\": \"S\",\r\n\t\"Gender\": \"M\",\r\n\t\"SourceGender\": \"M\",\r\n\t\"BirthDate\": \"1989-06-05T00:00:00.000000Z\",\r\n\t\"CompanyName\": \"Epsilon\",\r\n\t\"Addresses\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"AddressId\": \"ea2d8fee-3521-4028-ad82-87e37dd4d694\",\r\n\t\t\t\"AddressLine1\": \"123 THE RD\",\r\n\t\t\t\"SourceAddressLine1\": \"123 THE RD\",\r\n\t\t\t\"AddressLine2\": \"#3333\",\r\n\t\t\t\"SourceAddressLine2\": \"#3333\",\r\n\t\t\t\"AddressLine3\": \"\",\r\n\t\t\t\"SourceAddressLine3\": \"\",\r\n\t\t\t\"City\": \"IRVING\",\r\n\t\t\t\"SourceCity\": \"IRVING\",\r\n\t\t\t\"StateCode\": \"TX\",\r\n\t\t\t\"SourceStateCode\": \"TX\",\r\n\t\t\t\"CountryCode\": \"USA\",\r\n\t\t\t\"SourceCountryCode\": \"USA\",\r\n\t\t\t\"PostalCode\": \"75080\",\r\n\t\t\t\"SourcePostalCode\": \"75080\",\r\n\t\t\t\"ChannelCode\": \"DM\",\r\n\t\t\t\"LocationCode\": \"H\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"DoNotStandardize\": false,\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.907201Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.907201Z\"\r\n\t\t}\r\n\t],\r\n\t\"Emails\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"EmailId\": \"53720199-f3db-461a-bf4d-9dabde29f4a4\",\r\n\t\t\t\"EmailAddress\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\"SourceEmailAddress\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\"ChannelCode\": \"EM\",\r\n\t\t\t\"LocationCode\": \"B\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"ContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\"OriginalContactPoint\": {\r\n\t\t\t\t\"ContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\t\"ActiveContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\t\"ContactPointTypeCode\": \"EM\",\r\n\t\t\t\t\"ContactPointStatusCode\": \"A\",\r\n\t\t\t\t\"ContactPointValue\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\t\"ValidFlag\": \"Y\",\r\n\t\t\t\t\"CorrectedFlag\": \"N\",\r\n\t\t\t\t\"UndeliverableFlag\": \"N\",\r\n\t\t\t\t\"EmailDomain\": \"epsilon.com\",\r\n\t\t\t\t\"ContactPointSequenceNumber\": 42,\r\n\t\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\t\"Status\": \"A\",\r\n\t\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\t\"CreateDate\": \"2017-08-24T18:05:44.029089Z\",\r\n\t\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\t\"UpdateDate\": \"2017-08-24T18:05:44.029089Z\"\r\n\t\t\t},\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n\t\t}\r\n\t],\r\n\t\"Phones\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"PhoneId\": \"36fb45ba-2ac1-4577-b5b2-9b8c463ec863\",\r\n\t\t\t\"PhoneNumber\": \"1232343456\",\r\n\t\t\t\"SourcePhoneNumber\": \"1232343456\",\r\n\t\t\t\"PhoneCountryCode\": \"USA\",\r\n\t\t\t\"AcceptsText\": true,\r\n\t\t\t\"Frequency\": 7,\r\n\t\t\t\"NeverBefore\": \"0001-01-01T08:00:00.000000Z\",\r\n\t\t\t\"NeverAfter\": \"0001-01-01T23:00:00.000000Z\",\r\n\t\t\t\"ChannelCode\": \"SM\",\r\n\t\t\t\"LocationCode\": \"H\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\"OriginalContactPoint\": {\r\n\t\t\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\t\"ActiveContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\t\"ContactPointTypeCode\": \"PH\",\r\n\t\t\t\t\"ContactPointStatusCode\": \"A\",\r\n\t\t\t\t\"ContactPointValue\": \"1232343456\",\r\n\t\t\t\t\"ValidFlag\": \"Y\",\r\n\t\t\t\t\"CorrectedFlag\": \"N\",\r\n\t\t\t\t\"UndeliverableFlag\": \"N\",\r\n\t\t\t\t\"ContactPointSequenceNumber\": 41,\r\n\t\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\t\"Status\": \"A\",\r\n\t\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\t\"CreateDate\": \"2017-08-24T18:05:44.033089Z\",\r\n\t\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\t\"UpdateDate\": \"2017-08-24T18:05:44.033089Z\"\r\n\t\t\t},\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n\t\t}\r\n\t],\r\n\t\"SocialNetworks\": [],\r\n\t\"SocialAccounts\": [],\r\n\t\"ProgramCode\": \"PP\",\r\n\t\"SourceCode\": \"PP_CALL_IN\",\r\n\t\"EnrollmentStatus\": \"A\",\r\n\t\"JoinDate\": \"2017-10-26T13:29:25.501684Z\",\r\n\t\"EnrollChannelCode\": \"WEB\",\r\n\t\"TierCode\": \"BARN\",\r\n\t\"Username\": \"ANGIEPOTTER\",\r\n\t\"CardNumber\": \"456\",\r\n\t\"Status\": \"A\",\r\n\t\"TermsConditionsAcceptedInd\": false,\r\n\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\"CreateFileId\": 987654321,\r\n\t\"CreateRecordNumber\": 987654322,\r\n\t\"UpdateFileId\": 987654323,\r\n\t\"UpdateRecordNumber\": 987654324,\r\n\t\"AutoRewardOptInInd\": true,\r\n\t\"GamerAlias\": \"AP\",\r\n\t\"GamerAvatar\": \"angie.png\",\r\n\t\"IsTestProfile\": false,\r\n\t\"PostingKeys\": [],\r\n\t\"CreateUser\": \"CFROSONI\",\r\n\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\"UpdateUser\": \"CFROSONI\",\r\n\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n}";
			AddProfileResponse profile = mapper.readValue(jsonInString, AddProfileResponse.class);
			System.out.println(profile);

			//String prettyStaff1 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(profile);
			getStandardLayout(profile);

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static ProfileStandardLayout getStandardLayout(AddProfileResponse profileResponse){

		ProfileStandardLayout profileStandardLayout = new ProfileStandardLayout();

		profileStandardLayout.setPrefix(profileResponse.getPrefix());
		profileStandardLayout.setFirst_nm(profileResponse.getFirstName());
		profileStandardLayout.setMiddle_nm(profileResponse.getMiddleInit());
		profileStandardLayout.setLast_nm(profileResponse.getLastName());
		profileStandardLayout.setSuffix(profileResponse.getSuffix());
		profileStandardLayout.setLanguage_cd(profileResponse.getLanguageCode());
		profileStandardLayout.setMarital_status(profileResponse.getMaritalStatus());
		profileStandardLayout.setGender_cd(profileResponse.getGender());
		profileStandardLayout.setDate_of_birth(profileResponse.getBirthDate().toString());
		profileStandardLayout.setBusiness_nm(profileResponse.getCompanyName());
		if(!profileResponse.getAddresses().isEmpty()){
			Address addr = new Address();
			addr=profileResponse.getAddresses().get(0);
			profileStandardLayout.setAddr_line_1(addr.getAddressLine1());
			profileStandardLayout.setAddr_line_2(addr.getAddressLine2());
			profileStandardLayout.setAddr_line_3(addr.getAddressLine3());
			profileStandardLayout.setCity(addr.getCity());
			profileStandardLayout.setState(addr.getSourceStateCode());
			profileStandardLayout.setCountry(addr.getCountryCode());
			profileStandardLayout.setPostal_cd(addr.getPostalCode());


		}
		if(!profileResponse.getEmails().isEmpty()){

			Email email = new Email();
			email=profileResponse.getEmails().get(0);
			profileStandardLayout.setEmail_addr_1(email.getEmailAddress());



		}

		if(!profileResponse.getPhones().isEmpty()){

			Phone phone = new Phone();
			phone=profileResponse.getPhones().get(0);

			profileStandardLayout.setCell_phone_nbr(phone.getPhoneNumber());
			profileStandardLayout.setCell_phone_country_cd(phone.getPhoneCountryCode());
			if(phone.isAcceptsText()){
				profileStandardLayout.setDo_not_sms_ind("Y");
			}
			else{
				profileStandardLayout.setDo_not_sms_ind("N");
			}



		}

		profileStandardLayout.setAcct_src_cd(profileResponse.getAccountSourceCode());
		profileStandardLayout.setAcct_src_nbr(profileResponse.getSourceAccountNumber());
		profileStandardLayout.setBrand_cd(profileResponse.getBrandOrgCode());
		profileStandardLayout.setActivity_dt(profileResponse.getActivityDate());	

		writeCSVFile(profileStandardLayout);

		return profileStandardLayout;

	}

	static void writeCSVFile( ProfileStandardLayout profileStandardLayout) {
		System.out.println(profileStandardLayout);
		ICsvBeanWriter beanWriter = null;
		StringWriter writer = new StringWriter();
		final CellProcessor[] processors = getProcessors();
		try {
			beanWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);
			//String[] header = {"brand_cd", "acct_src_cd", "acct_src_nbr", "status", "status_change_dt","preferred_channel_cd","gender_cd","prefix","first_nm","middle_nm","last_nm","suffix","unparsed_nm","business_nm","title","addr_line_1","addr_line_2","addr_line_3","addr_line_4","city","state","postal_cd","country","iso_country_cd","date_of_birth","month_of_birth","year_of_birth","language_cd","marital_status","email_addr_1","email_addr_2","home_phone_nbr","home_phone_country_cd","work_phone_nbr","work_phone_country_cd","cell_phone_nbr","cell_phone_country_cd","pager_phone_nbr","pager_phone_country_cd","fax_phone_nbr","fax_phone_country_cd","other_phone_nbr","other_phone_country_cd","social_media_type_1","social_media_id_1","social_media_type_2","social_media_id_2","hardkey_1","hardkey_2","hardkey_3","hardkey_4","hardkey_5","hardkey_6","hardkey_7","hardkey_8","hardkey_9","hardkey_10","do_not_promote_ind","do_not_call_ind","do_not_mail_ind","do_not_sms_ind","do_not_email_ind","do_not_rent_ind","orig_dt","activity_dt"};
			//String[] header = {"brand_cd", "acct_src_cd" };
			
			List<String> list = new ArrayList<String>();
			list.add("brand_cd");
			list.add("acct_Src_cd");
			list.add("src_nbr");
			
			String[] header = new String[list.size()];
			header = list.toArray(header);
			
			
			
			
			beanWriter.writeHeader(header);
			beanWriter.write(profileStandardLayout, header, processors);
			//beanWriter.write(profileStandardLayout);


		} catch (IOException ex) {
			System.err.println("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();
				} catch (IOException ex) {
					System.err.println("Error closing the writer: " + ex);
				}
			}
		}

		System.out.println("CSV Data\n"+writer.toString());
	}

	private static CellProcessor[] getProcessors() {

		final CellProcessor[] processors = new CellProcessor[] { 

				new Optional(), // Role
				new Optional(), // Role
				/*new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(),*/ // Role

		};
		return processors;
	}


}