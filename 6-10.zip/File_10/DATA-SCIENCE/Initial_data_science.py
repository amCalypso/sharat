# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#importing libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#import the dataset

dataset = pd.read_csv('Social_Network_Ads.csv')