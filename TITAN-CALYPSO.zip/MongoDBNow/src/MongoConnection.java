import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;

import com.calypso.config.SpringMongoConfig;
import com.calypso.mongo.model.User;

public class MongoConnection {

	private static ApplicationContext ctx;
	
	public static void main(String[] args) {
		
		
		ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");
		
		User user = new User("mkyong", "password123");
		
		
		Builder o = MongoClientOptions.builder().connectTimeout(3000);  
		MongoClient mongo = new MongoClient(new ServerAddress("192.168.0.1", 3001), o.build());    

		try {
		  mongo.getAddress();
		} catch (Exception e) {
		  System.out.println("Mongo is down");
		  mongo.close();
		  return;
		}
	}
}
