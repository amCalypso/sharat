package com.calypso.manager;

import com.calypso.common.RegistrationRequest;
import com.calypso.common.RegistrationResponse;

public interface RegistrationManager {
	

	RegistrationResponse register(RegistrationRequest registrationRequest);

	

}
