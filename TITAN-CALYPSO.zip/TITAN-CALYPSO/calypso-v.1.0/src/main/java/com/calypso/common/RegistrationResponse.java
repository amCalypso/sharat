package com.calypso.common;

public class RegistrationResponse {
	
	private String firstName;
	private String middleName;
	private String LastName;
	private String address;
	private String sex;
	private String fathersName;
	private String mothersName;
	private Long phoneNumber;
	private long yoj;
	private String dob;

}
