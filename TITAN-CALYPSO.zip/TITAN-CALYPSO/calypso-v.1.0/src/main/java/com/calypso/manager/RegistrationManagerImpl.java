package com.calypso.manager;

import com.calypso.common.RegistrationRequest;
import com.calypso.common.RegistrationResponse;

public class RegistrationManagerImpl implements RegistrationManager {

	@Override
	public RegistrationResponse register(RegistrationRequest registrationRequest) {
		return null;
	}


}
