package mongoDbConnect;

public class mongoDbInsertion {
	
	public static void main(String[] args) {
		
		
		
		
		
		
	}

}
