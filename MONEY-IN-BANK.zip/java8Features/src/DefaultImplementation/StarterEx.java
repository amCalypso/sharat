package DefaultImplementation;

public interface StarterEx {

	void method1(String str);

	default void log(String str){
		System.out.println("logging::"+str); 		
	}
	//Class when implements interface, not necessary to provide implementation

	public interface StarterEx2 {

		void method2(String str);

		default void log(String str){
			System.out.println("logging::"+str); 
			//Class when implements interface, not necessary to provide implementation
		}
		
		/*
		 * 
		 *  Provide implementation for log() method if class impleents both interfaces else error - compiletime
		 * 
		 */
		
		/*
		 * 
		 * Static method is similar to default method except that we can�t override them in the implementation classes.
		 * Compile TIme error 
		 */

	}
}
