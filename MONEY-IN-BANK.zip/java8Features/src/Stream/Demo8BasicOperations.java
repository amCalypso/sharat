package Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lambda.expressions.Product;

public class Demo8BasicOperations {

	public static void main(String[] args) {  

		List<Product> list = new ArrayList<Product>();  
		list.add(new Product(1,"iPhone X",80));  
		list.add(new Product(2,"iPhone 7",49));  
		list.add(new Product(3,"1+3T",30)); 

		/*
		 * Collectors's method to sum the prices
		 * It provides reduction operations, such as accumulating elements into collections, summarizing elements 
		 * 
		 */
		Integer totalPrice1 = list.stream()  
				.collect(Collectors.summingInt(p -> p.price));  

		System.out.println(totalPrice1);  

		/*
		 * Reduce Method to sum the prices
		 * 
		 */

		Integer totalPrice2 = list.stream()  
				.map(p -> p.price)  
				.reduce(0 ,Integer::sum);     
		System.out.println(totalPrice2); 


		/*
		 * Max
		 * 
		 */
		Product productA = list.stream()  
				.max((p1, p2) ->   
				p1.price > p2.price ? 1: -1).get();
		System.out.println(productA.price);  



		/*
		 * Count
		 * 
		 */

		long count = list.stream()  
				.filter(p -> p.price < 100)  
				.count();  
		System.out.println(count);
	}

}
