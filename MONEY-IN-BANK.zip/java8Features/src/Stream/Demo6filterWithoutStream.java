package Stream;

import java.util.ArrayList;
import java.util.List;

import lambda.expressions.Product;

public class Demo6filterWithoutStream {
	
	 public static void main(String[] args) {  
	       
		 List<Product> productsList = new ArrayList<Product>();  

	        List<Product> list = new ArrayList<Product>();  
	        list.add(new Product(1,"iPhone X",80));  
	        list.add(new Product(2,"iPhone 7",49));  
	        list.add(new Product(3,"1+3T",30)); 
	        
	        
	        List<Integer> productPrice = new ArrayList<Integer>(); 
	        
	        for(Product product: list){  
	              
	            if(product.price < 100 ){  
	            	productPrice.add(product.price);    
	            }  
	        }  
	        System.out.println(productPrice);     
	    }  

}
