package Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import lambda.expressions.Product;

public class Demo9Conversion {

	public static void main(String[] args) {  



		List<Product> list = new ArrayList<Product>();  
		list.add(new Product(1,"iPhone X",80));  
		list.add(new Product(2,"iPhone 7",49));  
		list.add(new Product(3,"1+3T",30)); 


		/*
		 * List to Map
		 */
		Map<Integer,String> productPriceMap1 =   
				list.stream()  
				.collect(Collectors.toMap( p -> p.id, p -> p.name ));  

		System.out.println(productPriceMap1);  

		/*
		 * List to Set
		 */
		Set<Integer> productPriceMap2 =   
				list.stream() 
				.map( p -> p.price)  
				.collect(Collectors.toSet());  

		System.out.println(productPriceMap2);  
	}


}
