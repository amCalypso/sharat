package Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lambda.expressions.Product;

public class Demo7filterWithStream {

	public static void main(String[] args) {  


        List<Product> list = new ArrayList<Product>();  
        list.add(new Product(1,"iPhone X",80));  
        list.add(new Product(2,"iPhone 7",49));  
        list.add(new Product(3,"1+3T",30)); 

		List<Integer> productPrice = list.stream().filter(p -> p.price < 100 )        // filtering data  
									.map( p -> p.price)                   // fetching price  
									.collect(Collectors.toList());    // collecting as list  

		System.out.println(productPrice);  
	}
}  
