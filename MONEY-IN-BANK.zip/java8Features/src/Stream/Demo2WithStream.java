package Stream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Demo2WithStream {
	
	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		
		Integer a = sumIterator(list);
		System.out.println(a);
		
		
	}
	
	
	private static int sumIterator(List<Integer> list) {
		/*Iterator<Integer> it = list.iterator();
		int sum = 0;
		while (it.hasNext()) {
			int num = it.next();
				sum += num;
		}
		return sum;*/
		
		//return list.stream().filter(i -> i > 10).mapToInt(i -> i).sum();
		
		return list.stream().mapToInt(i -> i).sum();
	}
	
	

}


















/*
 *  1. Lot of Code
 *  2. Sequential 
 *  3. We need to know how the itearation will take place: External Iteration
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
