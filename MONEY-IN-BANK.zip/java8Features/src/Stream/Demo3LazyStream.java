package Stream;

import java.util.ArrayList;
import java.util.List;

public class Demo3LazyStream {

	public static void main(String[] args) {
		
		
		List<Integer> values = new ArrayList<Integer>();
		values.add(1);
		values.add(2);
		values.add(3);
		
	  values.stream().filter( i ->  {
			System.out.println("hi");
			return true;
		});
	  
	 values.stream().filter( i ->  {
			System.out.println("hi");
			return true;
		}).findFirst();
		
	}
}
