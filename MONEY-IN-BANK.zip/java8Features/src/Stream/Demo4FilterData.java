package Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import lambda.expressions.Product;

public class Demo4FilterData {
	
	public static void main(String[] args) {  
		List<Product> list = new ArrayList<Product>();  
		list.add(new Product(1,"iPhone X",80));  
		list.add(new Product(2,"iPhone 7",49));  
		list.add(new Product(3,"1+3T",30)); 
      
        Stream<Product> filtered_data = list.stream().filter(p -> p.price > 20);  
        
        filtered_data.forEach(  
                product -> System.out.println(product.name+ ": "+product.price)  
        );  
        
	}
}
