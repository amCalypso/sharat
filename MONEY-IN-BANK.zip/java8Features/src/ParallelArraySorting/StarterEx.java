package ParallelArraySorting;

import java.util.Arrays;

public class StarterEx {
	
	 public static void main(String[] args) {  
	        int[] arr1 = {5,8,1,0,6,9}; 

	        for (int i : arr1) {  
	            System.out.print(i+" ");  
	        }  
	        
	        Arrays.parallelSort(arr1);
	        System.out.println("\nAfter sorting");  
	        for (int i : arr1) {  
	            System.out.print(i+" ");  
	        }  
	        
	      
	    }  

}
