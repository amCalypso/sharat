package Optional;

public class Demo1WithoutOptional {
 
	    public static void main(String[] args) {  
	        String[] str = new String[10];  
	        String l = str[5].toLowerCase();  
	        System.out.print(l);  
	    }  
	}  

