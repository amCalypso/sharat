package MethodReferenceStarter;

import methodReferences.Voice;

public class Demo4ReferStaticReferences  {

	
	public static void saySomething() {
		System.out.println("Hello, this is static method.");  
		
	}

	
	public static void main(String[] args) {  
        
		// Referring static method  
		Voice sayable = Demo4ReferStaticReferences::saySomething;  
       
		// Calling interface method  
        sayable.say();  
    }  
	
	
	
}
