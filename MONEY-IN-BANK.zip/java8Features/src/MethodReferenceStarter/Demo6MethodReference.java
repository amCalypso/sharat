package MethodReferenceStarter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Demo6MethodReference {

	public static void main(String args[]){

		List<OrderBook> orderBook = new ArrayList<>(); 
		orderBook.add(new OrderBook(110, "MATHS",10)); 
		orderBook.add(new OrderBook(44, "ENGLISH",20)); 
		System.out.println("Before sorting : " +orderBook); 
		System.out.println("\n");

		// Sort all orders on price, using lambda expression 
		Collections.sort(orderBook, (a, b) -> a.getQuantity() - b.getQuantity()); 
		Collections.sort(orderBook, (a, b) -> OrderBook.compareByQuantity(a, b)); 

		System.out.println("After sorting by order quantity : " + orderBook); 
		
		
		//Method Reference. 
		Collections.sort(orderBook, OrderBook::compareByQuantity); 
		//System.out.println("After sorting by order quantity : " + orderBook); 
	}	
}


