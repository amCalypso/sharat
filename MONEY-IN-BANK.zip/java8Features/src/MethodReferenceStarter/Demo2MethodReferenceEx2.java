package MethodReferenceStarter;

/*
 * Call by Method
 * 
 */
interface Parser {
	String parse (String str);
	
	default void show(){
		System.out.println("HELLO mr X");
	}
}

class StringParser{
	public static String convert(String s){
		if(s.length() > 3 ){
			s = s.toUpperCase();
		} else {
			s= s.toLowerCase();
		}
		return s;
	}
}

class MyPrinter{
	public void print(String str , Parser p){
		str = p.parse(str);
		System.out.println(str);
	}
}

public class Demo2MethodReferenceEx2 {

	public static void main(String[] args) {

		String str = "Sharat";
		MyPrinter mp = new MyPrinter();
		mp.print( str, new Parser() {
			@Override
			public String parse(String x) {
				// TODO Auto-generated method stub
				return StringParser.convert(x);
			}
		}
				);

		//lambda

		mp.print(str, (String s ) -> StringParser.convert(s));
		mp.print(str, s -> StringParser.convert(s));

		//method Reference

		mp.print(str, StringParser::convert);

	}
}
