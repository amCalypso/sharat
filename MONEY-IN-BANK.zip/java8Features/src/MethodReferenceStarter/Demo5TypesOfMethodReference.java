package MethodReferenceStarter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Demo5TypesOfMethodReference {

	public static void main(String[] args) {
		
		/*
		 * Math.max()  is static method.
		 * Math::max equivalent to Math.max(x,y)
		 */
		List<Integer> integers = Arrays.asList(1,12,433,5);
		Optional<Integer> max = integers.stream().reduce( Math::max ); //method reference
		max.ifPresent(value -> System.out.println(value)); //Lambda
		max.ifPresent( System.out :: println ); //method Reference
		
		
		/*
		 * 
		 * ClassInstance::instanceMethodName
		 * 
		 */
		
		List<String> strings = Arrays.asList("a", "b", "c", "d");
		List<String> sorted = strings
		        .stream()
		        .sorted((s1, s2) -> s1.compareTo(s2)) //Lambda
		        .collect(Collectors.toList());		 
		System.out.println(sorted);
		 
		List<String> sortedAlt = strings
		        .stream()
		        .sorted( String :: compareTo) // s1.compareTo(s2) Method refrence
		        .collect(Collectors.toList());
		System.out.println(sortedAlt);
		
	
	
	
	/*
	 * 
	 * 
	 * Constructor
	 * 
	 */
	
	List<Integer> integers1 = IntStream
            .range(1, 100)
            .boxed()
            .collect(Collectors.toCollection( ArrayList::new )); //Constructor

     Optional<Integer> max1 = integers1.stream().reduce(Math::max);
     max1.ifPresent(System.out::println);
}
	
}
