package MethodReferenceStarter;

public class Demo3StarterEx {
	
	public static void main(String[] args) {
		
		Thread t1 = new Thread( ()->printMessage() );
		t1.start();
		
		Thread t2 = new Thread(Demo3StarterEx :: printMessage );
		t2.start();
	}

	private static void printMessage() {
      System.out.println("Hello");		
	}

}
