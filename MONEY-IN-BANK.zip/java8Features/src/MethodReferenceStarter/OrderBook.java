package MethodReferenceStarter;

public class OrderBook {

	private final int quantity; 
	private final String symbol;
	private final int price; 

	public OrderBook(int quantity, String symbol, int price) 

	{ 
		this.quantity = quantity; this.symbol = symbol;  this.price = price; 

	} 


	public int getQuantity() {
		return quantity;
	}

	public String getSymbol() {
		return symbol;
	}

	public int getPrice() {
		return price;
	}


	@Override
	public String toString() {
		return "OrderBook [quantity=" + quantity + ", symbol=" + symbol + ", price=" + price + "]";
	}


	public static int compareByQuantity(OrderBook a, OrderBook b){ return a.quantity - b.quantity; } 


}


