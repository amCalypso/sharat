package MethodReferenceStarter;

import java.util.Arrays;
import java.util.List;

/*
 * Call by Method
 * 
 */

public class Demo1MethodReferenceEx1 {
	
	public static void main(String[] args) {
		
		List<String> list = Arrays.asList("a","b","c");
		
		list.forEach(x -> System.out.println(x));
		
		list.forEach(System.out :: println);
		
		/*
		 * println method belongs to System.out
		 * 
		 */
		
	}

}
