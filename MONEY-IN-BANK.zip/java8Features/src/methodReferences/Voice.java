package methodReferences;

public interface Voice {
	
	void say();

}
