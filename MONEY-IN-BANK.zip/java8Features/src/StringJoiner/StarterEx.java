package StringJoiner;

import java.util.StringJoiner;

public class StarterEx {


	public static void main(String[] args) {  
		StringJoiner joinNames1 = new StringJoiner(",");
		joinNames1.add("1");  
		joinNames1.add("2");  
		joinNames1.add("3");  
		joinNames1.add("4");  
		System.out.println(joinNames1); 

		StringJoiner joinNames2 = new StringJoiner(",", "[", "}"); //delimiter,prefix,suffix
		joinNames2.add("30");  
		joinNames2.add("40"); 
		System.out.println(joinNames2);          

		StringJoiner merge = joinNames1.merge(joinNames2);   
		 System.out.println(merge);  
	}  
}
