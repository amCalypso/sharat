package MoreMethodReference;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

//http://javarevisited.blogspot.in/2017/03/what-is-method-references-in-java-8-example.html

public class StarterEx4 {
	
	public static void main(String args[]){
		
		List<Order> orderBook = new ArrayList<>(); 
		orderBook.add(new Order(1000, "MATHS", 10, Order.Side.BUY)); 
		orderBook.add(new Order(4000, "ENGLISH", 20, Order.Side.SELL)); 
		
		// Sort all orders on price, using lambda expression 
		
		System.out.println("Before sorting : " + orderBook); 
		Collections.sort(orderBook, (a, b) -> a.getQuantity() - b.getQuantity()); 
		
		
		//Method Reference. 
		
		
		Collections.sort(orderBook, (a, b) -> Order.compareByQuantity(a, b)); 
		Collections.sort(orderBook, Order::compareByQuantity); 
		System.out.println("After sorting by order quantity : " + orderBook); 
		

		Collections.sort(orderBook, Order::compareByValue); 
		System.out.println("After sorting by trade value : " + orderBook); 
		

		Order order = orderBook.get(0);
		Collections.sort(orderBook, order::compareByPrice); 
		System.out.println("Order book after sorting by price : " + orderBook); 
		
		
		String[] symbols = { "GOOG.NS", "APPL.NS", "MSFT.NS", "AMZN.NS"}; 
		Arrays.sort(symbols, String::compareToIgnoreCase); }
	}

		
