package lambda.expressions;


interface Add {
	int add (int  a, int  b );
}

public class LambdaDemo5MutipleParameters {
	public static void main(String[] args) {
		Add addObj = (a,b) -> (a+b);
		System.out.println(addObj.add(1, 2));
	}
}


