package lambda.expressions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Comparator {
	
	public static void main(String[] args) {  
        List<Product> list=new ArrayList<Product>();  
          
        list.add(new Product(1,"iPhone X",80));  
        list.add(new Product(2,"iPhone 5s",20));  
        list.add(new Product(3,"One+ 3T",30)); 
          
  
        Collections.sort(list, (p1,p2) ->  {  
                return p1.price.compareTo(p2.price);  
            } 
        
       );  
        
        for(Product p:list){  
            System.out.println(p.name + " " + p.price);  
        }  
  
    }  

}
