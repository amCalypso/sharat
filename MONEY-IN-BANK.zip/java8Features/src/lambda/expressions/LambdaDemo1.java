package lambda.expressions;

interface A{
	void show();
	default void doNotShow() {
		System.out.println("Do Not show");
	}
}

//External Class
/*class B implements A{
	public void show(){
		System.out.println("hello");
	}	
}
*/
public class LambdaDemo1 {
	public static void main(String[] args) {
		
		A obj2;
		A obj;
		A obj1;
		obj2 = new A() {   //Annonymous Inner class
			public void show(){
				System.out.println("AnonyMous Inner Class");
				System.out.println("Hello");
			}
		};
		obj2.show();
		
		//Lambda Expression
		System.out.println("\nLambda");
		obj = () -> {
			System.out.println("Hello");
		};
		
		obj1 = () -> System.out.println("Hello");
		
		
		obj.show();
		obj1.show();
		
	}
	
}
