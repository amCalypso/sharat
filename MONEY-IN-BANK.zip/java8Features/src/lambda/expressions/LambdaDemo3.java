package lambda.expressions;

import java.util.ArrayList;
import java.util.List;

public class LambdaDemo3 {
	
	public static void main(String[] args) {
		
		List<Integer> values = new ArrayList<Integer>();
		values.add(1);
		values.add(2);
		values.add(3);
		
		for(int i = 0 ; i< values.size(); i++){
			System.out.println(values.get(i));
		}
		
		System.out.println("\n");
		for(Integer a : values){
			System.out.println(a);
		}
		
		System.out.println("\n");
		values.forEach( i -> System.out.println(i) );
		
		
	}

}
