package lambda.expressions;

interface Say{
	public String say(String name);
}


public class SingleParameter {

	public static void main(String[] args) {

		Say s1 = (name) -> {
			return "Hello " + name;
		};
		System.out.println(s1.say("Sharat"));


		Say s2 = name -> {
			return "Hello " + name;
		};
		System.out.println(s2.say("Sharat"));

	}
}
