package lambda.expressions;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;


class ConsImpl implements Consumer<Integer>{

	@Override
	public void accept(Integer arg0) {
		// TODO Auto-generated method stub
		
	}

}

public class LambdaDemo4 {
	
	public static void main(String[] args) {
		
		List<Integer> values = new ArrayList<Integer>();
		values.add(1);
		values.add(2);
		values.add(3);
		
		
	//Without Lambda
		Consumer<Integer> c = new Consumer<Integer>(){
			@Override
			public void accept(Integer i) {
				//System.out.println(i);
			}
		};
		values.forEach(c);
		
		
		Consumer<Integer> c1 = i -> System.out.println(i);
		 values.forEach(c1);
		
		
		values.forEach( i -> System.out.println(i) ); //internal implementation
		
		
	}
}
