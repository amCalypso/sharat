package lambda.expressions;

import java.util.ArrayList;
import java.util.List;

public class ForEachLoop {

	public static void main(String[] args) {

		List<Integer> a = new ArrayList<Integer>();

		a.add(1);
		a.add(2);
		a.add(3);
		a.forEach( (s) -> System.out.println(s));
	}

}
