package lambda.expressions;

interface X{
	void show(int i);
}

/*class B implements A{
	
	public void show(int i){
		System.out.println("hello");
	}	
}
*/
public class LambdaDemo2 {
	
	public static void main(String[] args) {
		
		X obj;
		X obj1;
		/*obj = new A() {   //Annonymous Inner class
			public void show(){
				System.out.println("Hello" +i);
			}
			
		};*/
		
		obj = (int i) -> {
			System.out.println("Hello "  +i);
		};
		
		obj1 = (i) -> System.out.println("Hello " +i); 
		
		
		obj.show(2);
		obj1.show(0);
		
	}
	
}
