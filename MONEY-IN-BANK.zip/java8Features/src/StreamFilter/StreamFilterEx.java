package StreamFilter;

import java.util.ArrayList;
import java.util.List;

import lambda.expressions.Product;

public class StreamFilterEx {

	public static void main(String[] args) {



		List<Product> list = new ArrayList<Product>();  
		list.add(new Product(1,"iPhone X",80));  
		list.add(new Product(2,"iPhone 5s",20));  
		list.add(new Product(3,"1+ 3T",30)); 


		list.stream()  
		.filter(p ->p.price> 30000)     // filtering price  
		.map(pm ->pm.price)             // fetching price  
		.forEach(System.out::println);  // iterating price 
	}

}
