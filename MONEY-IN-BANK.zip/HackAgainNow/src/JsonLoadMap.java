import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonLoadMap {
	
	
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
		//String JSON_SOURCE = "{\n\t\"1\": {\n\t\t\"csv_header\": \"fname\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"2\": {\n\t\t\"csv_header\": \"mname\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"3\": {\n\t\t\"csv_header\": \"lname\",\n\t\t\"from_json_node\": \"firstname\"\n\t}\n}\n \n \n\t  ";
		
		String  JSON_SOURCE= "{\n\t\"1\": {\n\t\t\"csv_header\": \"fname\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"2\": {\n\t\t\"csv_header\": \"mname\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"3\": {\n\t\t\"csv_header\": \"lname\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"4\": {\n\t\t\"csv_header\": \"profileId\",\n\t\t\"from_json_node\": \"Addresses[].ProfileId\"\n\t},\n\t\"5\": {\n\t\t\"csv_header\": \"ValidFlag\",\n\t\t\"from_json_node\": \"Emails[].OriginalContactPoint.ValidFlag\"\n\t}\n}\n ";
		//HashMap<String,JsonNodeAttributes> result =   new ObjectMapper().readValue(JSON_SOURCE, HashMap.class);
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String,JsonNodeAttributes> result =
				  mapper.readValue(JSON_SOURCE, new TypeReference<Map<String,JsonNodeAttributes>>() {});
		
		for (Entry<String, JsonNodeAttributes> entry : result.entrySet()) {
		    System.out.println(entry.getKey()+" : "+entry.getValue());
		    
		}
		
		/*for(Map.Entry<String, JsonNode> s : result.entrySet()){
			
			System.out.print(String.valueOf(s.getValue().getCsv_header()));
		    //System.out.print(s.getKey()+" "+s.getValue().getFrom_json_node());
		
		}*/
		//result.forEach((key, value) -> System.out.println(key + ":" + value));
		
		/*final ObjectMapper mapper = new ObjectMapper(); // jackson's objectmapper
		final JsonRoot pojo = mapper.convertValue(result, JsonRoot.class);*/
		
		/*ObjectMapper m = new ObjectMapper();
		Map<String,Object> mapPojo = m.convertValue(jsonNode, Map.class);
		JsonNode anotherBean = m.convertValue(mapPojo, JsonNode.class);
		*/
		//System.out.println(Arrays.asList(result));
	}

}
