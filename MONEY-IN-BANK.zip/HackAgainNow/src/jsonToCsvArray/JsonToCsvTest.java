package jsonToCsvArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

public class JsonToCsvTest {

	private static ObjectMapper mapper = new ObjectMapper () ;

	private static CsvMapper csvMapper = new CsvMapper();

	public static void main(String[] args) throws IOException {
		
		String  JSON_SOURCE= "{\n\t\"1\": {\n\t\t\"csv_header\": \"fname\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"2\": {\n\t\t\"csv_header\": \"mname\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"3\": {\n\t\t\"csv_header\": \"lname\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"4\": {\n\t\t\"csv_header\": \"profileId\",\n\t\t\"from_json_node\": \"Addresses[].ProfileId\"\n\t},\n\t\"5\": {\n\t\t\"csv_header\": \"ValidFlag\",\n\t\t\"from_json_node\": \"Emails[].OriginalContactPoint.ValidFlag\"\n\t}\n}\n ";
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String,JsonNodeAttributes> result =
				  mapper.readValue(JSON_SOURCE, new TypeReference<Map<String,JsonNodeAttributes>>() {});
		
		for (Entry<String, JsonNodeAttributes> entry : result.entrySet()) {
		   // System.out.println(entry.getKey()+" : "+entry.getValue());
		    
		}
		
			List<FlatHeader> simpleList = new ArrayList<>();
			simpleList.add(new FlatHeader("hello", "world", "helloagain","hello", "world", "helloagain","hello", "world", "helloagain"));

			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(simpleList);

			//System.out.println(json);

			System.out.println("Now as CSV: ");
			CsvSchema schema = csvMapper.schemaFor(FlatHeader.class).withHeader();
			
			String a = csvMapper.writer(schema).writeValueAsString(simpleList);
			
			System.out.println(a);
			//System.out.println(csvMapper.writer(schema).writeValueAsString(simpleList));
		}
		
	}
	

