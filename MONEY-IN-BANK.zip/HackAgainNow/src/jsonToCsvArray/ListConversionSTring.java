package jsonToCsvArray;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class ListConversionSTring {

	
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		list.add("sharat");
		list.add("kaul");
		list.add("Naik");
		
		System.out.println(list.toString());
		
		String listNew = StringUtils.join(list, ',');
		
		System.out.println(listNew);
		
	}
}
