package jsonToCsvArrayActualImplementation;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SocialAccount {
	

	@JsonProperty("SocialAccountId")
	private String SocialAccountId;
	

	@JsonProperty("SocialAccountType")
	private String SocialAccountType;
	

	@JsonProperty("SocialToken")
	private String SocialToken;
	
	
	public String getSocialAccountId() {
		return SocialAccountId;
	}
	public void setSocialAccountId(String socialAccountId) {
		SocialAccountId = socialAccountId;
	}
	public String getSocialAccountType() {
		return SocialAccountType;
	}
	public void setSocialAccountType(String socialAccountType) {
		SocialAccountType = socialAccountType;
	}
	public String getSocialToken() {
		return SocialToken;
	}
	public void setSocialToken(String socialToken) {
		SocialToken = socialToken;
	}
	
	
	

}
