package jsonToCsvArrayActualImplementation;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PostingKey {
	
	
	@JsonProperty("PostingKeyId")
	private String PostingKeyId;
	
	@JsonProperty("PostingKeyCode")
	private String PostingKeyCode;
	
	@JsonProperty("PostingKeyValue")
	private String PostingKeyValue;

	public String getPostingKeyId() {
		return PostingKeyId;
	}

	public void setPostingKeyId(String postingKeyId) {
		PostingKeyId = postingKeyId;
	}

	public String getPostingKeyCode() {
		return PostingKeyCode;
	}

	public void setPostingKeyCode(String postingKeyCode) {
		PostingKeyCode = postingKeyCode;
	}

	public String getPostingKeyValue() {
		return PostingKeyValue;
	}

	public void setPostingKeyValue(String postingKeyValue) {
		PostingKeyValue = postingKeyValue;
	}

	@Override
	public String toString() {
		return "PostingKey [PostingKeyId=" + PostingKeyId + ", PostingKeyCode=" + PostingKeyCode + ", PostingKeyValue="
				+ PostingKeyValue + "]";
	}
	
	

}
