package jsonToCsvArrayActualImplementation;

public class splitData {

	
	public static void main(String[] args) {
		
		String a = "1989-06-05T00:00:00.000000Z";
		
		String[] data = a.split("\\-");
		
		System.out.println(data[2]);
		System.out.println(data.toString());
		
		for(String b : data){
			
			System.out.println(b);
		}
		
		String c =  "05T00:00:00.000000Z";
				
				
		    String d =  c.length() < 2 ? c : c.substring(0, 2);
		    
		    System.out.println(d);
		}
		
	
}
