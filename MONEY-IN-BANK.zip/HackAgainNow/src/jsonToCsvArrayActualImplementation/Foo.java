package jsonToCsvArrayActualImplementation;


import org.json.JSONArray;
import org.json.JSONObject;


public class Foo
{
  public static void main(String[] args) throws Exception
  {
    String jsonInput = "{\n\t\"ProfileId\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\"JArray1\": [{\n\t\t\"A\": \"a\",\n\t\t\"B\": \"b\",\n\t\t\"C\": \"c\"\n\t}, {\n\t\t\"A\": \"a1\",\n\t\t\"B\": \"b2\",\n\t\t\"C\": \"c3\",\n\t\t\"D\": \"d4\",\n\t\t\"E\": \"e5\"\n\t}, {\n\t\t\"A\": \"aa\",\n\t\t\"B\": \"bb\",\n\t\t\"C\": \"cc\",\n\t\t\"D\": \"dd\"\n\t}]\n}";
    // "I want to iterate though the objects in the array..."
    JSONObject outerObject = new JSONObject(jsonInput);
    //JSONObject innerObject = outerObject.getJSONObject("JObjects");
    JSONArray jsonArray = outerObject.getJSONArray("JArray1");
    
    
    for (int i = 0, size = jsonArray.length(); i < size; i++)
    {
      JSONObject objectInArray = jsonArray.getJSONObject(i);

      // "...and get thier component and thier value."
      String[] elementNames = JSONObject.getNames(objectInArray);
     // System.out.printf("%d ELEMENTS IN CURRENT OBJECT:\n", elementNames.length);
      for (String elementName : elementNames)
      {
        String value = objectInArray.getString(elementName);
        System.out.printf("name=%s, value=%s\n", elementName, value);
      }
      System.out.println();
    }
  }
}