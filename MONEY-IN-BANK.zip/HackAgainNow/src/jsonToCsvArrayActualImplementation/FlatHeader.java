package jsonToCsvArrayActualImplementation;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"ProfileId","ClientAccountId","Prefix","AddressLine1","AddressLine2","EmailId","EmailAddress","EmailDomain","ContactPointId"})
//@JsonPropertyOrder({"ProfileId", "ClientAccountId", "Prefix"})
public class FlatHeader {
	private String ProfileId;
	private String ClientAccountId;
	private String Prefix;
	private String AddressLine1;
	private String AddressLine2;
	private String EmailId;
	private String EmailAddress;
	private String EmailDomain;
	private String ContactPointId;

	public FlatHeader(){
	}


	public FlatHeader(String ProfileId, String ClientAccountId, String Prefix,String AddressLine1, String AddressLine2, String EmailId,String EmailAddress, String EmailDomain, String ContactPointId) {
		super();
		this.ProfileId = ProfileId;
		this.ClientAccountId = ClientAccountId;
		this.Prefix = Prefix;
		this.AddressLine1 = AddressLine1;
		this.AddressLine2 = AddressLine2;
		this.EmailId = EmailId;
		this.EmailAddress = EmailAddress;
		this.EmailDomain = EmailDomain;
		this.ContactPointId = ContactPointId;
	}

	public String getProfileId() {
		return ProfileId;
	}
	public void setProfileId(String profileId) {
		ProfileId = profileId;
	}
	public String getClientAccountId() {
		return ClientAccountId;
	}
	public void setClientAccountId(String clientAccountId) {
		ClientAccountId = clientAccountId;
	}
	public String getPrefix() {
		return Prefix;
	}
	public void setPrefix(String prefix) {
		Prefix = prefix;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return AddressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public String getEmailAddress() {
		return EmailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}
	public String getEmailDomain() {
		return EmailDomain;
	}
	public void setEmailDomain(String emailDomain) {
		EmailDomain = emailDomain;
	}
	public String getContactPointId() {
		return ContactPointId;
	}
	public void setContactPointId(String contactPointId) {
		ContactPointId = contactPointId;
	}

}

