package jsonToCsvArrayActualImplementation;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AddProfileResponse {
	
	@JsonProperty("ProfileId")
	private String ProfileId;
	
	@JsonProperty("ClientAccountId")
	private String ClientAccountId;
	
	@JsonProperty("Prefix")
	private String Prefix;
	
	@JsonProperty("SourcePrefix")
	private String SourcePrefix;
	
	@JsonProperty("FirstName")
	private String FirstName;
	
	@JsonProperty("SourceFirstName")
	private String SourceFirstName;
	
	@JsonProperty("MiddleInit")
	private String MiddleInit;
	
	@JsonProperty("SourceMiddleInit")
	private String SourceMiddleInit;
	
	@JsonProperty("LastName")
	private String LastName;
	
	@JsonProperty("SourceLastName")
	private String SourceLastName;
	
	@JsonProperty("Suffix")
	private String Suffix;
	
	@JsonProperty("SourceSuffix")
	private String SourceSuffix;
	
	@JsonProperty("GlobalOptOut")
	private boolean GlobalOptOut;
	
	@JsonProperty("GlobalOptDate")
	private String GlobalOptDate;
	
	@JsonProperty("GlobalOptSource")
	private String GlobalOptSource;
	
	@JsonProperty("LanguageCode")
	private String LanguageCode;
	
	@JsonProperty("MaritalStatus")
	private String MaritalStatus;
	
	@JsonProperty("Gender")
	private String Gender;
	
	@JsonProperty("SourceGender")
	private String SourceGender;
	
	@JsonProperty("BirthDate")
	private Date BirthDate;
	
	@JsonProperty("CompanyName")
	private String CompanyName;
	
	@JsonProperty("Addresses")
	private List<Address> Addresses;
	
	@JsonProperty("Emails")
	private List<Email> Emails;
	
	@JsonProperty("Phones")
	private List<Phone> Phones;
	
	@JsonProperty("SocialNetworks")
	private List<SocialNetwork> SocialNetworks;
	
	@JsonProperty("SocialAccounts")
	private List<SocialAccount> SocialAccounts;
	
	@JsonProperty("ProgramCode")
	private String ProgramCode;
	
	@JsonProperty("SourceCode")
	private String SourceCode;
	
	@JsonProperty("EnrollmentStatus")
	private String EnrollmentStatus;
	
	@JsonProperty("JoinDate")
	private Date JoinDate;
	
	@JsonProperty("EnrollChannelCode")
	private String EnrollChannelCode;
	
	@JsonProperty("TierCode")
	private String TierCode;
	
	@JsonProperty("Username")
	private String Username;
	
	@JsonProperty("CardNumber")
	private String CardNumber;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("TermsConditionsAcceptedInd")
	private boolean TermsConditionsAcceptedInd;
	
	@JsonProperty("AccountSourceCode")
	private String AccountSourceCode;
	
	@JsonProperty("SourceAccountNumber")
	private String SourceAccountNumber;
	
	@JsonProperty("BrandOrgCode")
	private String BrandOrgCode;
	
	@JsonProperty("ActivityDate")
	private Date ActivityDate;
	
	@JsonProperty("CreateFileId")
	private long CreateFileId;
	
	@JsonProperty("CreateRecordNumber")
	private long CreateRecordNumber;
	
	@JsonProperty("UpdateFileId")
	private long UpdateFileId;
	
	@JsonProperty("UpdateRecordNumber")
	private long UpdateRecordNumber;
	
	@JsonProperty("AutoRewardOptInInd")
	private boolean AutoRewardOptInInd;
	
	@JsonProperty("GamerAlias")
	private String GamerAlias;
	
	@JsonProperty("GamerAvatar")
	private String GamerAvatar;
	
	@JsonProperty("IsTestProfile")
	private boolean IsTestProfile;
	
	@JsonProperty("PostingKeys")
	private List<PostingKey> PostingKeys;
	
	@JsonProperty("CreateUser")
	private String CreateUser;
	
	@JsonProperty("CreateDate")
	private Date CreateDate;
	
	@JsonProperty("UpdateUser")
	private String UpdateUser;
	
	@JsonProperty("UpdateDate")
	private Date UpdateDate;
	
	public String getProfileId() {
		return ProfileId;
	}
	public void setProfileId(String profileId) {
		ProfileId = profileId;
	}
	public String getClientAccountId() {
		return ClientAccountId;
	}
	public void setClientAccountId(String clientAccountId) {
		ClientAccountId = clientAccountId;
	}
	public String getPrefix() {
		return Prefix;
	}
	public void setPrefix(String prefix) {
		Prefix = prefix;
	}
	public String getSourceFirstName() {
		return SourceFirstName;
	}
	public void setSourceFirstName(String sourceFirstName) {
		SourceFirstName = sourceFirstName;
	}
	public String getMiddleInit() {
		return MiddleInit;
	}
	public void setMiddleInit(String middleInit) {
		MiddleInit = middleInit;
	}
	public String getSourceMiddleInit() {
		return SourceMiddleInit;
	}
	public void setSourceMiddleInit(String sourceMiddleInit) {
		SourceMiddleInit = sourceMiddleInit;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getSourceLastName() {
		return SourceLastName;
	}
	public void setSourceLastName(String sourceLastName) {
		SourceLastName = sourceLastName;
	}
	public String getSuffix() {
		return Suffix;
	}
	public void setSuffix(String suffix) {
		Suffix = suffix;
	}
	public String getSourceSuffix() {
		return SourceSuffix;
	}
	public void setSourceSuffix(String sourceSuffix) {
		SourceSuffix = sourceSuffix;
	}
	public boolean getGlobalOptOut() {
		return GlobalOptOut;
	}
	public void setGlobalOptOut(boolean globalOptOut) {
		GlobalOptOut = globalOptOut;
	}
	public String getGlobalOptDate() {
		return GlobalOptDate;
	}
	public void setGlobalOptDate(String globalOptDate) {
		GlobalOptDate = globalOptDate;
	}
	public String getGlobalOptSource() {
		return GlobalOptSource;
	}
	public void setGlobalOptSource(String globalOptSource) {
		GlobalOptSource = globalOptSource;
	}
	public String getLanguageCode() {
		return LanguageCode;
	}
	public void setLanguageCode(String languageCode) {
		LanguageCode = languageCode;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getSourceGender() {
		return SourceGender;
	}
	public void setSourceGender(String sourceGender) {
		SourceGender = sourceGender;
	}
	public Date getBirthDate() {
		return BirthDate;
	}
	public void setBirthDate(Date birthDate) {
		BirthDate = birthDate;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public List<Address> getAddresses() {
		return Addresses;
	}
	public void setAddresses(List<Address> addresses) {
		Addresses = addresses;
	}
	public List<Email> getEmails() {
		return Emails;
	}
	public void setEmails(List<Email> emails) {
		Emails = emails;
	}
	public List<Phone> getPhones() {
		return Phones;
	}
	public void setPhones(List<Phone> phones) {
		Phones = phones;
	}
	public List<SocialNetwork> getSocialNetworks() {
		return SocialNetworks;
	}
	public void setSocialNetworks(List<SocialNetwork> socialNetworks) {
		SocialNetworks = socialNetworks;
	}
	public List<SocialAccount> getSocialAccounts() {
		return SocialAccounts;
	}
	public void setSocialAccounts(List<SocialAccount> socialAccounts) {
		SocialAccounts = socialAccounts;
	}
	public String getProgramCode() {
		return ProgramCode;
	}
	public void setProgramCode(String programCode) {
		ProgramCode = programCode;
	}
	public String getSourceCode() {
		return SourceCode;
	}
	public void setSourceCode(String sourceCode) {
		SourceCode = sourceCode;
	}
	public String getEnrollmentStatus() {
		return EnrollmentStatus;
	}
	public void setEnrollmentStatus(String enrollmentStatus) {
		EnrollmentStatus = enrollmentStatus;
	}
	public Date getJoinDate() {
		return JoinDate;
	}
	public void setJoinDate(Date joinDate) {
		JoinDate = joinDate;
	}
	public String getEnrollChannelCode() {
		return EnrollChannelCode;
	}
	public void setEnrollChannelCode(String enrollChannelCode) {
		EnrollChannelCode = enrollChannelCode;
	}
	public String getTierCode() {
		return TierCode;
	}
	public void setTierCode(String tierCode) {
		TierCode = tierCode;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getCardNumber() {
		return CardNumber;
	}
	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public boolean isTermsConditionsAcceptedInd() {
		return TermsConditionsAcceptedInd;
	}
	public void setTermsConditionsAcceptedInd(boolean termsConditionsAcceptedInd) {
		TermsConditionsAcceptedInd = termsConditionsAcceptedInd;
	}
	public String getAccountSourceCode() {
		return AccountSourceCode;
	}
	public void setAccountSourceCode(String accountSourceCode) {
		AccountSourceCode = accountSourceCode;
	}
	public String getSourceAccountNumber() {
		return SourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		SourceAccountNumber = sourceAccountNumber;
	}
	public String getBrandOrgCode() {
		return BrandOrgCode;
	}
	public void setBrandOrgCode(String brandOrgCode) {
		BrandOrgCode = brandOrgCode;
	}
	public Date getActivityDate() {
		return ActivityDate;
	}
	public void setActivityDate(Date activityDate) {
		ActivityDate = activityDate;
	}
	public long getCreateFileId() {
		return CreateFileId;
	}
	public void setCreateFileId(long createFileId) {
		CreateFileId = createFileId;
	}
	public long getCreateRecordNumber() {
		return CreateRecordNumber;
	}
	public void setCreateRecordNumber(long createRecordNumber) {
		CreateRecordNumber = createRecordNumber;
	}
	public long getUpdateFileId() {
		return UpdateFileId;
	}
	public void setUpdateFileId(long updateFileId) {
		UpdateFileId = updateFileId;
	}
	public long getUpdateRecordNumber() {
		return UpdateRecordNumber;
	}
	public void setUpdateRecordNumber(long updateRecordNumber) {
		UpdateRecordNumber = updateRecordNumber;
	}
	public boolean isAutoRewardOptInInd() {
		return AutoRewardOptInInd;
	}
	public void setAutoRewardOptInInd(boolean autoRewardOptInInd) {
		AutoRewardOptInInd = autoRewardOptInInd;
	}
	public String getGamerAlias() {
		return GamerAlias;
	}
	public void setGamerAlias(String gamerAlias) {
		GamerAlias = gamerAlias;
	}
	public String getGamerAvatar() {
		return GamerAvatar;
	}
	public void setGamerAvatar(String gamerAvatar) {
		GamerAvatar = gamerAvatar;
	}
	public boolean isIsTestProfile() {
		return IsTestProfile;
	}
	public void setIsTestProfile(boolean isTestProfile) {
		IsTestProfile = isTestProfile;
	}
	public List<PostingKey> getPostingKeys() {
		return PostingKeys;
	}
	public void setPostingKeys(List<PostingKey> postingKeys) {
		PostingKeys = postingKeys;
	}
	public String getCreateUser() {
		return CreateUser;
	}
	public void setCreateUser(String createUser) {
		CreateUser = createUser;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public String getUpdateUser() {
		return UpdateUser;
	}
	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}
	public Date getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}
	public String getSourcePrefix() {
		return SourcePrefix;
	}
	public void setSourcePrefix(String sourcePrefix) {
		SourcePrefix = sourcePrefix;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		MaritalStatus = maritalStatus;
	}
	
	
	
	

	
}
