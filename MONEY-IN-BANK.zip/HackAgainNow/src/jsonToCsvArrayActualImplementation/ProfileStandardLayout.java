package jsonToCsvArrayActualImplementation;

import java.util.Date;

public class ProfileStandardLayout {

	private String brand_cd;
	private String acct_src_cd;
	private String acct_src_nbr;
	private String status;
	private Date status_change_dt;
	private String preferred_channel_cd;
	private String gender_cd;
	private String prefix;
	private String first_nm;
	private String middle_nm;
	private String last_nm;
	private String suffix;
	private String unparsed_nm;
	private String business_nm;
	private String title;
	private String addr_line_1;
	private String addr_line_2;
	private String addr_line_3;
	private String addr_line_4;
	private String city;
	private String state;
	private String postal_cd;
	private String country;
	private String iso_country_cd;
	private String date_of_birth;
	private String month_of_birth;
	private String year_of_birth;
	private String language_cd;
	private String marital_status;
	private String email_addr_1;
	private String email_addr_2;
	private String home_phone_nbr;
	private String home_phone_country_cd;
	private String work_phone_nbr;
	private String work_phone_country_cd;
	private String cell_phone_nbr;
	private String cell_phone_country_cd;
	private String pager_phone_nbr;
	private String pager_phone_country_cd;
	private String fax_phone_nbr;
	private String fax_phone_country_cd;
	private String other_phone_nbr;
	private String other_phone_country_cd;
	private String social_media_type_1;
	private String social_media_id_1;
	private String social_media_type_2;
	private String social_media_id_2;
	private String hardkey_1;
	private String hardkey_2;
	private String hardkey_3;
	private String hardkey_4;
	private String hardkey_5;
	private String hardkey_6;
	private String hardkey_7;
	private String hardkey_8;
	private String hardkey_9;
	private String hardkey_10;
	private String do_not_promote_ind;
	private String do_not_call_ind;
	private String do_not_mail_ind;
	private String do_not_sms_ind;
	private String do_not_email_ind;
	private String do_not_rent_ind;
	private Date orig_dt;
	private Date activity_dt;
	public String getBrand_cd() {
		return brand_cd;
	}
	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}
	public String getAcct_src_cd() {
		return acct_src_cd;
	}
	public void setAcct_src_cd(String acct_src_cd) {
		this.acct_src_cd = acct_src_cd;
	}
	public String getAcct_src_nbr() {
		return acct_src_nbr;
	}
	public void setAcct_src_nbr(String acct_src_nbr) {
		this.acct_src_nbr = acct_src_nbr;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getStatus_change_dt() {
		return status_change_dt;
	}
	public void setStatus_change_dt(Date status_change_dt) {
		this.status_change_dt = status_change_dt;
	}
	public String getPreferred_channel_cd() {
		return preferred_channel_cd;
	}
	public void setPreferred_channel_cd(String preferred_channel_cd) {
		this.preferred_channel_cd = preferred_channel_cd;
	}
	public String getGender_cd() {
		return gender_cd;
	}
	public void setGender_cd(String gender_cd) {
		this.gender_cd = gender_cd;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getFirst_nm() {
		return first_nm;
	}
	public void setFirst_nm(String first_nm) {
		this.first_nm = first_nm;
	}
	public String getMiddle_nm() {
		return middle_nm;
	}
	public void setMiddle_nm(String middle_nm) {
		this.middle_nm = middle_nm;
	}
	public String getLast_nm() {
		return last_nm;
	}
	public void setLast_nm(String last_nm) {
		this.last_nm = last_nm;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getUnparsed_nm() {
		return unparsed_nm;
	}
	public void setUnparsed_nm(String unparsed_nm) {
		this.unparsed_nm = unparsed_nm;
	}
	public String getBusiness_nm() {
		return business_nm;
	}
	public void setBusiness_nm(String business_nm) {
		this.business_nm = business_nm;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAddr_line_1() {
		return addr_line_1;
	}
	public void setAddr_line_1(String addr_line_1) {
		this.addr_line_1 = addr_line_1;
	}
	public String getAddr_line_2() {
		return addr_line_2;
	}
	public void setAddr_line_2(String addr_line_2) {
		this.addr_line_2 = addr_line_2;
	}
	public String getAddr_line_3() {
		return addr_line_3;
	}
	public void setAddr_line_3(String addr_line_3) {
		this.addr_line_3 = addr_line_3;
	}
	public String getAddr_line_4() {
		return addr_line_4;
	}
	public void setAddr_line_4(String addr_line_4) {
		this.addr_line_4 = addr_line_4;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPostal_cd() {
		return postal_cd;
	}
	public void setPostal_cd(String postal_cd) {
		this.postal_cd = postal_cd;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getIso_country_cd() {
		return iso_country_cd;
	}
	public void setIso_country_cd(String iso_country_cd) {
		this.iso_country_cd = iso_country_cd;
	}
	public String getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getMonth_of_birth() {
		return month_of_birth;
	}
	public void setMonth_of_birth(String month_of_birth) {
		this.month_of_birth = month_of_birth;
	}
	public String getYear_of_birth() {
		return year_of_birth;
	}
	public void setYear_of_birth(String year_of_birth) {
		this.year_of_birth = year_of_birth;
	}
	public String getLanguage_cd() {
		return language_cd;
	}
	public void setLanguage_cd(String language_cd) {
		this.language_cd = language_cd;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	public String getEmail_addr_1() {
		return email_addr_1;
	}
	public void setEmail_addr_1(String email_addr_1) {
		this.email_addr_1 = email_addr_1;
	}
	public String getEmail_addr_2() {
		return email_addr_2;
	}
	public void setEmail_addr_2(String email_addr_2) {
		this.email_addr_2 = email_addr_2;
	}
	public String getHome_phone_nbr() {
		return home_phone_nbr;
	}
	public void setHome_phone_nbr(String home_phone_nbr) {
		this.home_phone_nbr = home_phone_nbr;
	}
	public String getHome_phone_country_cd() {
		return home_phone_country_cd;
	}
	public void setHome_phone_country_cd(String home_phone_country_cd) {
		this.home_phone_country_cd = home_phone_country_cd;
	}
	public String getWork_phone_nbr() {
		return work_phone_nbr;
	}
	public void setWork_phone_nbr(String work_phone_nbr) {
		this.work_phone_nbr = work_phone_nbr;
	}
	public String getWork_phone_country_cd() {
		return work_phone_country_cd;
	}
	public void setWork_phone_country_cd(String work_phone_country_cd) {
		this.work_phone_country_cd = work_phone_country_cd;
	}
	public String getCell_phone_nbr() {
		return cell_phone_nbr;
	}
	public void setCell_phone_nbr(String cell_phone_nbr) {
		this.cell_phone_nbr = cell_phone_nbr;
	}
	public String getCell_phone_country_cd() {
		return cell_phone_country_cd;
	}
	public void setCell_phone_country_cd(String cell_phone_country_cd) {
		this.cell_phone_country_cd = cell_phone_country_cd;
	}
	public String getPager_phone_nbr() {
		return pager_phone_nbr;
	}
	public void setPager_phone_nbr(String pager_phone_nbr) {
		this.pager_phone_nbr = pager_phone_nbr;
	}
	public String getPager_phone_country_cd() {
		return pager_phone_country_cd;
	}
	public void setPager_phone_country_cd(String pager_phone_country_cd) {
		this.pager_phone_country_cd = pager_phone_country_cd;
	}
	public String getFax_phone_nbr() {
		return fax_phone_nbr;
	}
	public void setFax_phone_nbr(String fax_phone_nbr) {
		this.fax_phone_nbr = fax_phone_nbr;
	}
	public String getFax_phone_country_cd() {
		return fax_phone_country_cd;
	}
	public void setFax_phone_country_cd(String fax_phone_country_cd) {
		this.fax_phone_country_cd = fax_phone_country_cd;
	}
	public String getOther_phone_nbr() {
		return other_phone_nbr;
	}
	public void setOther_phone_nbr(String other_phone_nbr) {
		this.other_phone_nbr = other_phone_nbr;
	}
	public String getOther_phone_country_cd() {
		return other_phone_country_cd;
	}
	public void setOther_phone_country_cd(String other_phone_country_cd) {
		this.other_phone_country_cd = other_phone_country_cd;
	}
	public String getSocial_media_type_1() {
		return social_media_type_1;
	}
	public void setSocial_media_type_1(String social_media_type_1) {
		this.social_media_type_1 = social_media_type_1;
	}
	public String getSocial_media_id_1() {
		return social_media_id_1;
	}
	public void setSocial_media_id_1(String social_media_id_1) {
		this.social_media_id_1 = social_media_id_1;
	}
	public String getSocial_media_type_2() {
		return social_media_type_2;
	}
	public void setSocial_media_type_2(String social_media_type_2) {
		this.social_media_type_2 = social_media_type_2;
	}
	public String getSocial_media_id_2() {
		return social_media_id_2;
	}
	public void setSocial_media_id_2(String social_media_id_2) {
		this.social_media_id_2 = social_media_id_2;
	}
	public String getHardkey_1() {
		return hardkey_1;
	}
	public void setHardkey_1(String hardkey_1) {
		this.hardkey_1 = hardkey_1;
	}
	public String getHardkey_2() {
		return hardkey_2;
	}
	public void setHardkey_2(String hardkey_2) {
		this.hardkey_2 = hardkey_2;
	}
	public String getHardkey_3() {
		return hardkey_3;
	}
	public void setHardkey_3(String hardkey_3) {
		this.hardkey_3 = hardkey_3;
	}
	public String getHardkey_4() {
		return hardkey_4;
	}
	public void setHardkey_4(String hardkey_4) {
		this.hardkey_4 = hardkey_4;
	}
	public String getHardkey_5() {
		return hardkey_5;
	}
	public void setHardkey_5(String hardkey_5) {
		this.hardkey_5 = hardkey_5;
	}
	public String getHardkey_6() {
		return hardkey_6;
	}
	public void setHardkey_6(String hardkey_6) {
		this.hardkey_6 = hardkey_6;
	}
	public String getHardkey_7() {
		return hardkey_7;
	}
	public void setHardkey_7(String hardkey_7) {
		this.hardkey_7 = hardkey_7;
	}
	public String getHardkey_8() {
		return hardkey_8;
	}
	public void setHardkey_8(String hardkey_8) {
		this.hardkey_8 = hardkey_8;
	}
	public String getHardkey_9() {
		return hardkey_9;
	}
	public void setHardkey_9(String hardkey_9) {
		this.hardkey_9 = hardkey_9;
	}
	public String getHardkey_10() {
		return hardkey_10;
	}
	public void setHardkey_10(String hardkey_10) {
		this.hardkey_10 = hardkey_10;
	}
	public String getDo_not_promote_ind() {
		return do_not_promote_ind;
	}
	public void setDo_not_promote_ind(String do_not_promote_ind) {
		this.do_not_promote_ind = do_not_promote_ind;
	}
	public String getDo_not_call_ind() {
		return do_not_call_ind;
	}
	public void setDo_not_call_ind(String do_not_call_ind) {
		this.do_not_call_ind = do_not_call_ind;
	}
	public String getDo_not_mail_ind() {
		return do_not_mail_ind;
	}
	public void setDo_not_mail_ind(String do_not_mail_ind) {
		this.do_not_mail_ind = do_not_mail_ind;
	}
	public String getDo_not_sms_ind() {
		return do_not_sms_ind;
	}
	public void setDo_not_sms_ind(String do_not_sms_ind) {
		this.do_not_sms_ind = do_not_sms_ind;
	}
	public String getDo_not_email_ind() {
		return do_not_email_ind;
	}
	public void setDo_not_email_ind(String do_not_email_ind) {
		this.do_not_email_ind = do_not_email_ind;
	}
	public String getDo_not_rent_ind() {
		return do_not_rent_ind;
	}
	public void setDo_not_rent_ind(String do_not_rent_ind) {
		this.do_not_rent_ind = do_not_rent_ind;
	}
	public Date getOrig_dt() {
		return orig_dt;
	}
	public void setOrig_dt(Date orig_dt) {
		this.orig_dt = orig_dt;
	}
	public Date getActivity_dt() {
		return activity_dt;
	}
	public void setActivity_dt(Date activity_dt) {
		this.activity_dt = activity_dt;
	}
	
	
	
	
	
	
	
}
