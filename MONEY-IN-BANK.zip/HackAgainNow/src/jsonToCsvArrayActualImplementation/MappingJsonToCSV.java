package jsonToCsvArrayActualImplementation;

import java.util.Date;

public class MappingJsonToCSV
{
    private String ProfileId;

    private String ClientAccountId;

    private String Prefix;

    private String FirstName;

    private String MiddleInit;

    private String LastName;

    private String Suffix;

    private boolean GlobalOptOut;

    private String GlobalOptDate;

    private String GlobalOptSource;

    private String LanguageCode;

    private String MaritalStatus;

    private String Gender;

    private Date BirthDate;

    private String day_of_birth;

    private String month_of_birth;

    private String year_of_birth;

    private String CompanyName;

    private String Addresses_H_AddressId;

    private String Addresses_H_AddressLine1;

    private String Addresses_H_SourceAddressLine1;

    private String Addresses_H_AddressLine2;

    private String Addresses_H_SourceAddressLine2;

    private String Addresses_H_AddressLine3;

    private String Addresses_H_SourceAddressLine3;

    private String Addresses_H_AddressLine4;

    private String Addresses_H_City;

    private String Addresses_H_SourceCity;

    private String Addresses_H_StateCode;

    private String Addresses_H_SourceStateCode;

    private String Addresses_H_CountryCode;

    private String Addresses_H_SourceCountryCode;

    private String Addresses_H_PostalCode;

    private String Addresses_H_SourcePostalCode;

    private String Addresses_H_ChannelCode;

    private String Addresses_H_LocationCode;

    private boolean Addresses_H_IsPreferred;

    private String Addresses_H_DeliveryStatus;

    private boolean Addresses_H_DoNotStandardize;

    private String Addresses_W_AddressId;

    private String Addresses_W_AddressLine1;

    private String Addresses_W_SourceAddressLine1;

    private String Addresses_W_AddressLine2;

    private String Addresses_W_SourceAddressLine2;

    private String Addresses_W_AddressLine3;

    private String Addresses_W_SourceAddressLine3;

    private String Addresses_W_AddressLine4;

    private String Addresses_W_City;

    private String Addresses_W_SourceCity;

    private String Addresses_W_StateCode;

    private String Addresses_W_SourceStateCode;

    private String Addresses_W_CountryCode;

    private String Addresses_W_SourceCountryCode;

    private String Addresses_W_PostalCode;

    private String Addresses_W_SourcePostalCode;

    private String Addresses_W_ChannelCode;

    private String Addresses_W_LocationCode;

    private boolean Addresses_W_IsPreferred;

    private String Addresses_W_DeliveryStatus;

    private boolean Addresses_W_DoNotStandardize;

    private String Emails_B_EmailId;

    private String Emails_B_EmailAddress;

    private String Emails_B_SourceEmailAddress;

    private String Emails_B_ChannelCode;

    private String Emails_B_LocationCode;

    private boolean Emails_B_IsPreferred;

    private String Emails_B_DeliveryStatus;

    private String Emails_B_ContactPointId;

    private String Emails_B_OriginalContactPoint_ContactPointId;

    private String Emails_B_OriginalContactPoint_ActiveContactPointId;

    private String Emails_B_OriginalContactPoint_ContactPointTypeCode;

    private String Emails_B_OriginalContactPoint_ContactPointStatusCode;

    private String Emails_B_OriginalContactPoint_ContactPointValue;

    private String Emails_B_OriginalContactPoint_ValidFlag;

    private String Emails_B_OriginalContactPoint_CorrectedFlag;

    private String Emails_B_OriginalContactPoint_UndeliverableFlag;

    private String Emails_B_OriginalContactPoint_EmailDomain;

    private String Emails_B_OriginalContactPoint_ContactPointSequenceNumber;

    private String Emails_B_OriginalContactPoint_Status;

    private String Emails_B_OriginalContactPoint_CreateUser;

    private Date Emails_B_OriginalContactPoint_CreateDate;

    private String Emails_B_OriginalContactPoint_UpdateUser;

    private Date Emails_B_OriginalContactPoint_UpdateDate;

    private String Emails_B_Status;

    private String Emails_H_EmailId;

    private String Emails_H_EmailAddress;

    private String Emails_H_SourceEmailAddress;

    private String Emails_H_ChannelCode;

    private String Emails_H_LocationCode;

    private boolean Emails_H_IsPreferred;

    private String Emails_H_DeliveryStatus;

    private String Emails_H_ContactPointId;

    private String Emails_H_OriginalContactPoint_ContactPointId;

    private String Emails_H_OriginalContactPoint_ActiveContactPointId;

    private String Emails_H_OriginalContactPoint_ContactPointTypeCode;

    private String Emails_H_OriginalContactPoint_ContactPointStatusCode;

    private String Emails_H_OriginalContactPoint_ContactPointValue;

    private String Emails_H_OriginalContactPoint_ValidFlag;

    private String Emails_H_OriginalContactPoint_CorrectedFlag;

    private String Emails_H_OriginalContactPoint_UndeliverableFlag;

    private String Emails_H_OriginalContactPoint_EmailDomain;

    private String Emails_H_OriginalContactPoint_ContactPointSequenceNumber;

    private String Emails_H_OriginalContactPoint_Status;

    private String Emails_H_OriginalContactPoint_CreateUser;

    private Date Emails_H_OriginalContactPoint_CreateDate;

    private String Emails_H_OriginalContactPoint_UpdateUser;

    private Date Emails_H_OriginalContactPoint_UpdateDate;

    private String Emails_H_Status;

    private String Emails_O_EmailId;

    private String Emails_O_EmailAddress;

    private String Emails_O_SourceEmailAddress;

    private String Emails_O_ChannelCode;

    private String Emails_O_LocationCode;

    private boolean Emails_O_IsPreferred;

    private String Emails_O_DeliveryStatus;

    private String Emails_O_ContactPointId;

    private String Emails_O_OriginalContactPoint_ContactPointId;

    private String Emails_O_OriginalContactPoint_ActiveContactPointId;

    private String Emails_O_OriginalContactPoint_ContactPointTypeCode;

    private String Emails_O_OriginalContactPoint_ContactPointStatusCode;

    private String Emails_O_OriginalContactPoint_ContactPointValue;

    private String Emails_O_OriginalContactPoint_ValidFlag;

    private String Emails_O_OriginalContactPoint_CorrectedFlag;

    private String Emails_O_OriginalContactPoint_UndeliverableFlag;

    private String Emails_O_OriginalContactPoint_EmailDomain;

    private String Emails_O_OriginalContactPoint_ContactPointSequenceNumber;

    private String Emails_O_OriginalContactPoint_Status;

    private String Emails_O_OriginalContactPoint_CreateUser;

    private Date Emails_O_OriginalContactPoint_CreateDate;

    private String Emails_O_OriginalContactPoint_UpdateUser;

    private Date Emails_O_OriginalContactPoint_UpdateDate;

    private String Emails_O_Status;

    private String Phones_W_PhoneId;

    private String Phones_W_PhoneNumber;

    private String Phones_W_SourcePhoneNumber;

    private String Phones_W_PhoneCountryCode;

    private boolean Phones_W_AcceptsText;

    private long Phones_W_Frequency;

    private Date Phones_W_NeverBefore;

    private Date Phones_W_NeverAfter;

    private String Phones_W_ChannelCode;

    private String Phones_W_LocationCode;

    private boolean Phones_W_IsPreferred;

    private String Phones_W_DeliveryStatus;

    private String Phones_W_ContactPointId;

    private String Phones_W_OriginalContactPoint_ContactPointId;

    private String Phones_W_OriginalContactPoint_ActiveContactPointId;

    private String Phones_W_OriginalContactPoint_ContactPointTypeCode;

    private String Phones_W_OriginalContactPoint_ContactPointStatusCode;

    private String Phones_W_OriginalContactPoint_ContactPointValue;

    private String Phones_W_OriginalContactPoint_ValidFlag;

    private String Phones_W_OriginalContactPoint_CorrectedFlag;

    private String Phones_W_OriginalContactPoint_UndeliverableFlag;

    private String Phones_W_OriginalContactPoint_ContactPointSequenceNumber;

    private String Phones_W_OriginalContactPoint_Status;

    private String Phones_W_OriginalContactPoint_CreateUser;

    private Date Phones_W_OriginalContactPoint_CreateDate;

    private String Phones_W_OriginalContactPoint_UpdateUser;

    private Date Phones_W_OriginalContactPoint_UpdateDate;

    private String Phones_W_Status;

    private String Phones_C_PhoneId;

    private String Phones_C_PhoneNumber;

    private String Phones_C_SourcePhoneNumber;

    private String Phones_C_PhoneCountryCode;

    private boolean Phones_C_AcceptsText;

    private long Phones_C_Frequency;

    private Date Phones_C_NeverBefore;

    private Date Phones_C_NeverAfter;

    private String Phones_C_ChannelCode;

    private String Phones_C_LocationCode;

    private boolean Phones_C_IsPreferred;

    private String Phones_C_DeliveryStatus;

    private String Phones_C_ContactPointId;

    private String Phones_C_OriginalContactPoint_ContactPointId;

    private String Phones_C_OriginalContactPoint_ActiveContactPointId;

    private String Phones_C_OriginalContactPoint_ContactPointTypeCode;

    private String Phones_C_OriginalContactPoint_ContactPointStatusCode;

    private String Phones_C_OriginalContactPoint_ContactPointValue;

    private String Phones_C_OriginalContactPoint_ValidFlag;

    private String Phones_C_OriginalContactPoint_CorrectedFlag;

    private String Phones_C_OriginalContactPoint_UndeliverableFlag;

    private String Phones_C_OriginalContactPoint_ContactPointSequenceNumber;

    private String Phones_C_OriginalContactPoint_Status;

    private String Phones_C_OriginalContactPoint_CreateUser;

    private Date Phones_C_OriginalContactPoint_CreateDate;

    private String Phones_C_OriginalContactPoint_UpdateUser;

    private Date Phones_C_OriginalContactPoint_UpdateDate;

    private String Phones_C_Status;

    private String Phones_P_PhoneId;

    private String Phones_P_PhoneNumber;

    private String Phones_P_SourcePhoneNumber;

    private String Phones_P_PhoneCountryCode;

    private boolean Phones_P_AcceptsText;

    private long Phones_P_Frequency;

    private Date Phones_P_NeverBefore;

    private Date Phones_P_NeverAfter;

    private String Phones_P_ChannelCode;

    private String Phones_P_LocationCode;

    private boolean Phones_P_IsPreferred;

    private String Phones_P_DeliveryStatus;

    private String Phones_P_ContactPointId;

    private String Phones_P_OriginalContactPoint_ContactPointId;

    private String Phones_P_OriginalContactPoint_ActiveContactPointId;

    private String Phones_P_OriginalContactPoint_ContactPointTypeCode;

    private String Phones_P_OriginalContactPoint_ContactPointStatusCode;

    private String Phones_P_OriginalContactPoint_ContactPointValue;

    private String Phones_P_OriginalContactPoint_ValidFlag;

    private String Phones_P_OriginalContactPoint_CorrectedFlag;

    private String Phones_P_OriginalContactPoint_UndeliverableFlag;

    private String Phones_P_OriginalContactPoint_ContactPointSequenceNumber;

    private String Phones_P_OriginalContactPoint_Status;

    private String Phones_P_OriginalContactPoint_CreateUser;

    private Date Phones_P_OriginalContactPoint_CreateDate;

    private String Phones_P_OriginalContactPoint_UpdateUser;

    private Date Phones_P_OriginalContactPoint_UpdateDate;

    private String Phones_P_Status;

    private String Phones_F_PhoneId;

    private String Phones_F_PhoneNumber;

    private String Phones_F_SourcePhoneNumber;

    private String Phones_F_PhoneCountryCode;

    private boolean Phones_F_AcceptsText;

    private int Phones_F_Frequency;

    private String Phones_F_NeverBefore;

    private String Phones_F_NeverAfter;

    private String Phones_F_ChannelCode;

    private String Phones_F_LocationCode;

    private boolean Phones_F_IsPreferred;

    private String Phones_F_DeliveryStatus;

    private String Phones_F_ContactPointId;

    private String Phones_F_OriginalContactPoint_ContactPointId;

    private String Phones_F_OriginalContactPoint_ActiveContactPointId;

    private String Phones_F_OriginalContactPoint_ContactPointTypeCode;

    private String Phones_F_OriginalContactPoint_ContactPointStatusCode;

    private String Phones_F_OriginalContactPoint_ContactPointValue;

    private String Phones_F_OriginalContactPoint_ValidFlag;

    private String Phones_F_OriginalContactPoint_CorrectedFlag;

    private String Phones_F_OriginalContactPoint_UndeliverableFlag;

    private int Phones_F_OriginalContactPoint_ContactPointSequenceNumber;

    private String Phones_F_OriginalContactPoint_Status;

    private String Phones_F_OriginalContactPoint_CreateUser;

    private String Phones_F_OriginalContactPoint_CreateDate;

    private String Phones_F_OriginalContactPoint_UpdateUser;

    private String Phones_F_OriginalContactPoint_UpdateDate;

    private String Phones_F_Status;

    private String Phones_O_PhoneId;

    private String Phones_O_PhoneNumber;

    private String Phones_O_SourcePhoneNumber;

    private String Phones_O_PhoneCountryCode;

    private boolean Phones_O_AcceptsText;

    private int Phones_O_Frequency;

    private String Phones_O_NeverBefore;

    private String Phones_O_NeverAfter;

    private String Phones_O_ChannelCode;

    private String Phones_O_LocationCode;

    private boolean Phones_O_IsPreferred;

    private String Phones_O_DeliveryStatus;

    private String Phones_O_ContactPointId;

    private String Phones_O_OriginalContactPoint_ContactPointId;

    private String Phones_O_OriginalContactPoint_ActiveContactPointId;

    private String Phones_O_OriginalContactPoint_ContactPointTypeCode;

    private String Phones_O_OriginalContactPoint_ContactPointStatusCode;

    private String Phones_O_OriginalContactPoint_ContactPointValue;

    private String Phones_O_OriginalContactPoint_ValidFlag;

    private String Phones_O_OriginalContactPoint_CorrectedFlag;

    private String Phones_O_OriginalContactPoint_UndeliverableFlag;

    private int Phones_O_OriginalContactPoint_ContactPointSequenceNumber;

    private String Phones_O_OriginalContactPoint_Status;

    private String Phones_O_OriginalContactPoint_CreateUser;

    private String Phones_O_OriginalContactPoint_CreateDate;

    private String Phones_O_OriginalContactPoint_UpdateUser;

    private String Phones_O_OriginalContactPoint_UpdateDate;

    private String Phones_O_Status;

    private String SocialAccounts_0_SocialAccountId;

    private String SocialAccounts_0_SocialAccountType;

    private String SocialAccounts_0_SocialToken;

    private String SocialAccounts_1_SocialAccountId;

    private String SocialAccounts_1_SocialAccountType;

    private String SocialAccounts_1_SocialToken;

    private String SocialNetworks_0_SocialNetworkCode;

    private String SocialNetworks_0_SocialNetworkUserName;

    private String SocialNetworks_1_SocialNetworkCode;

    private String SocialNetworks_1_SocialNetworkUserName;

    private String ProgramCode;

    private String SourceCode;

    private String EnrollmentStatus;

    private Date JoinDate;

    private String EnrollChannelCode;

    private String TierCode;

    private String Username;

    private String CardNumber;

    private String Status;

    private boolean TermsConditionsAcceptedInd;

    private String AccountSourceCode;

    private String SourceAccountNumber;

    private String BrandOrgCode;

    private Date ActivityDate;

    private long CreateFileId;

    private long CreateRecordNumber;

    private long UpdateFileId;

    private long UpdateRecordNumber;

    private boolean AutoRewardOptInInd;

    private String GamerAlias;

    private String GamerAvatar;

    private boolean IsTestProfile;

    private String PostingKeys_0_PostingKeyId;

    private String PostingKeys_0_PostingKeyCode;

    private String PostingKeys_0_PostingKeyValue;

    private String PostingKeys_1_PostingKeyId;

    private String PostingKeys_1_PostingKeyCode;

    private String PostingKeys_1_PostingKeyValue;

    private String CreateUser;

    private Date CreateDate;

    private String UpdateUser;

    private Date UpdateDate;

    private String Status_change_dt;

    private String preferred_channel_cd;

    private String unparsed_nm;

    private String title;

    private String orig_dt;

    private String hardkey_1;

    private String hardkey_2;

    private String hardkey_3;

    private String hardkey_4;

    private String hardkey_5;

    private String hardkey_6;

    private String hardkey_7;

    private String hardkey_8;

    private String hardkey_9;

    private String hardkey_10;

    private String do_not_promote_ind;

    private String do_not_call_ind;

    private String do_not_mail_ind;

    private String do_not_sms_ind;

    private String do_not_email_ind;

    private String do_not_rent_ind;

    public void setProfileId(String ProfileId){
        this.ProfileId = ProfileId;
    }
    public String getProfileId(){
        return this.ProfileId;
    }
    public void setClientAccountId(String ClientAccountId){
        this.ClientAccountId = ClientAccountId;
    }
    public String getClientAccountId(){
        return this.ClientAccountId;
    }
    public void setPrefix(String Prefix){
        this.Prefix = Prefix;
    }
    public String getPrefix(){
        return this.Prefix;
    }
    public void setFirstName(String FirstName){
        this.FirstName = FirstName;
    }
    public String getFirstName(){
        return this.FirstName;
    }
    public void setMiddleInit(String MiddleInit){
        this.MiddleInit = MiddleInit;
    }
    public String getMiddleInit(){
        return this.MiddleInit;
    }
    public void setLastName(String LastName){
        this.LastName = LastName;
    }
    public String getLastName(){
        return this.LastName;
    }
    public void setSuffix(String Suffix){
        this.Suffix = Suffix;
    }
    public String getSuffix(){
        return this.Suffix;
    }
    public void setGlobalOptOut(boolean GlobalOptOut){
        this.GlobalOptOut = GlobalOptOut;
    }
    public boolean getGlobalOptOut(){
        return this.GlobalOptOut;
    }
    public void setGlobalOptDate(String GlobalOptDate){
        this.GlobalOptDate = GlobalOptDate;
    }
    public String getGlobalOptDate(){
        return this.GlobalOptDate;
    }
    public void setGlobalOptSource(String GlobalOptSource){
        this.GlobalOptSource = GlobalOptSource;
    }
    public String getGlobalOptSource(){
        return this.GlobalOptSource;
    }
    public void setLanguageCode(String LanguageCode){
        this.LanguageCode = LanguageCode;
    }
    public String getLanguageCode(){
        return this.LanguageCode;
    }
    public void setMaritalStatus(String MaritalStatus){
        this.MaritalStatus = MaritalStatus;
    }
    public String getMaritalStatus(){
        return this.MaritalStatus;
    }
    public void setGender(String Gender){
        this.Gender = Gender;
    }
    public String getGender(){
        return this.Gender;
    }
    public void setBirthDate(Date date){
        this.BirthDate = date;
    }
    public Date getBirthDate(){
        return this.BirthDate;
    }
    public void setDay_of_birth(String day_of_birth){
        this.day_of_birth = day_of_birth;
    }
    public String getDay_of_birth(){
        return this.day_of_birth;
    }
    public void setMonth_of_birth(String month_of_birth){
        this.month_of_birth = month_of_birth;
    }
    public String getMonth_of_birth(){
        return this.month_of_birth;
    }
    public void setYear_of_birth(String year_of_birth){
        this.year_of_birth = year_of_birth;
    }
    public String getYear_of_birth(){
        return this.year_of_birth;
    }
    public void setCompanyName(String CompanyName){
        this.CompanyName = CompanyName;
    }
    public String getCompanyName(){
        return this.CompanyName;
    }
    public void setAddresses_H_AddressId(String Addresses_H_AddressId){
        this.Addresses_H_AddressId = Addresses_H_AddressId;
    }
    public String getAddresses_H_AddressId(){
        return this.Addresses_H_AddressId;
    }
    public void setAddresses_H_AddressLine1(String Addresses_H_AddressLine1){
        this.Addresses_H_AddressLine1 = Addresses_H_AddressLine1;
    }
    public String getAddresses_H_AddressLine1(){
        return this.Addresses_H_AddressLine1;
    }
    public void setAddresses_H_SourceAddressLine1(String Addresses_H_SourceAddressLine1){
        this.Addresses_H_SourceAddressLine1 = Addresses_H_SourceAddressLine1;
    }
    public String getAddresses_H_SourceAddressLine1(){
        return this.Addresses_H_SourceAddressLine1;
    }
    public void setAddresses_H_AddressLine2(String Addresses_H_AddressLine2){
        this.Addresses_H_AddressLine2 = Addresses_H_AddressLine2;
    }
    public String getAddresses_H_AddressLine2(){
        return this.Addresses_H_AddressLine2;
    }
    public void setAddresses_H_SourceAddressLine2(String Addresses_H_SourceAddressLine2){
        this.Addresses_H_SourceAddressLine2 = Addresses_H_SourceAddressLine2;
    }
    public String getAddresses_H_SourceAddressLine2(){
        return this.Addresses_H_SourceAddressLine2;
    }
    public void setAddresses_H_AddressLine3(String Addresses_H_AddressLine3){
        this.Addresses_H_AddressLine3 = Addresses_H_AddressLine3;
    }
    public String getAddresses_H_AddressLine3(){
        return this.Addresses_H_AddressLine3;
    }
    public void setAddresses_H_SourceAddressLine3(String Addresses_H_SourceAddressLine3){
        this.Addresses_H_SourceAddressLine3 = Addresses_H_SourceAddressLine3;
    }
    public String getAddresses_H_SourceAddressLine3(){
        return this.Addresses_H_SourceAddressLine3;
    }
    public void setAddresses_H_AddressLine4(String Addresses_H_AddressLine4){
        this.Addresses_H_AddressLine4 = Addresses_H_AddressLine4;
    }
    public String getAddresses_H_AddressLine4(){
        return this.Addresses_H_AddressLine4;
    }
    public void setAddresses_H_City(String Addresses_H_City){
        this.Addresses_H_City = Addresses_H_City;
    }
    public String getAddresses_H_City(){
        return this.Addresses_H_City;
    }
    public void setAddresses_H_SourceCity(String Addresses_H_SourceCity){
        this.Addresses_H_SourceCity = Addresses_H_SourceCity;
    }
    public String getAddresses_H_SourceCity(){
        return this.Addresses_H_SourceCity;
    }
    public void setAddresses_H_StateCode(String Addresses_H_StateCode){
        this.Addresses_H_StateCode = Addresses_H_StateCode;
    }
    public String getAddresses_H_StateCode(){
        return this.Addresses_H_StateCode;
    }
    public void setAddresses_H_SourceStateCode(String Addresses_H_SourceStateCode){
        this.Addresses_H_SourceStateCode = Addresses_H_SourceStateCode;
    }
    public String getAddresses_H_SourceStateCode(){
        return this.Addresses_H_SourceStateCode;
    }
    public void setAddresses_H_CountryCode(String Addresses_H_CountryCode){
        this.Addresses_H_CountryCode = Addresses_H_CountryCode;
    }
    public String getAddresses_H_CountryCode(){
        return this.Addresses_H_CountryCode;
    }
    public void setAddresses_H_SourceCountryCode(String Addresses_H_SourceCountryCode){
        this.Addresses_H_SourceCountryCode = Addresses_H_SourceCountryCode;
    }
    public String getAddresses_H_SourceCountryCode(){
        return this.Addresses_H_SourceCountryCode;
    }
    public void setAddresses_H_PostalCode(String Addresses_H_PostalCode){
        this.Addresses_H_PostalCode = Addresses_H_PostalCode;
    }
    public String getAddresses_H_PostalCode(){
        return this.Addresses_H_PostalCode;
    }
    public void setAddresses_H_SourcePostalCode(String Addresses_H_SourcePostalCode){
        this.Addresses_H_SourcePostalCode = Addresses_H_SourcePostalCode;
    }
    public String getAddresses_H_SourcePostalCode(){
        return this.Addresses_H_SourcePostalCode;
    }
    public void setAddresses_H_ChannelCode(String Addresses_H_ChannelCode){
        this.Addresses_H_ChannelCode = Addresses_H_ChannelCode;
    }
    public String getAddresses_H_ChannelCode(){
        return this.Addresses_H_ChannelCode;
    }
    public void setAddresses_H_LocationCode(String Addresses_H_LocationCode){
        this.Addresses_H_LocationCode = Addresses_H_LocationCode;
    }
    public String getAddresses_H_LocationCode(){
        return this.Addresses_H_LocationCode;
    }
    public void setAddresses_H_IsPreferred(boolean Addresses_H_IsPreferred){
        this.Addresses_H_IsPreferred = Addresses_H_IsPreferred;
    }
    public boolean getAddresses_H_IsPreferred(){
        return this.Addresses_H_IsPreferred;
    }
    public void setAddresses_H_DeliveryStatus(String Addresses_H_DeliveryStatus){
        this.Addresses_H_DeliveryStatus = Addresses_H_DeliveryStatus;
    }
    public String getAddresses_H_DeliveryStatus(){
        return this.Addresses_H_DeliveryStatus;
    }
    public void setAddresses_H_DoNotStandardize(boolean Addresses_H_DoNotStandardize){
        this.Addresses_H_DoNotStandardize = Addresses_H_DoNotStandardize;
    }
    public boolean getAddresses_H_DoNotStandardize(){
        return this.Addresses_H_DoNotStandardize;
    }
    public void setAddresses_W_AddressId(String Addresses_W_AddressId){
        this.Addresses_W_AddressId = Addresses_W_AddressId;
    }
    public String getAddresses_W_AddressId(){
        return this.Addresses_W_AddressId;
    }
    public void setAddresses_W_AddressLine1(String Addresses_W_AddressLine1){
        this.Addresses_W_AddressLine1 = Addresses_W_AddressLine1;
    }
    public String getAddresses_W_AddressLine1(){
        return this.Addresses_W_AddressLine1;
    }
    public void setAddresses_W_SourceAddressLine1(String Addresses_W_SourceAddressLine1){
        this.Addresses_W_SourceAddressLine1 = Addresses_W_SourceAddressLine1;
    }
    public String getAddresses_W_SourceAddressLine1(){
        return this.Addresses_W_SourceAddressLine1;
    }
    public void setAddresses_W_AddressLine2(String Addresses_W_AddressLine2){
        this.Addresses_W_AddressLine2 = Addresses_W_AddressLine2;
    }
    public String getAddresses_W_AddressLine2(){
        return this.Addresses_W_AddressLine2;
    }
    public void setAddresses_W_SourceAddressLine2(String Addresses_W_SourceAddressLine2){
        this.Addresses_W_SourceAddressLine2 = Addresses_W_SourceAddressLine2;
    }
    public String getAddresses_W_SourceAddressLine2(){
        return this.Addresses_W_SourceAddressLine2;
    }
    public void setAddresses_W_AddressLine3(String Addresses_W_AddressLine3){
        this.Addresses_W_AddressLine3 = Addresses_W_AddressLine3;
    }
    public String getAddresses_W_AddressLine3(){
        return this.Addresses_W_AddressLine3;
    }
    public void setAddresses_W_SourceAddressLine3(String Addresses_W_SourceAddressLine3){
        this.Addresses_W_SourceAddressLine3 = Addresses_W_SourceAddressLine3;
    }
    public String getAddresses_W_SourceAddressLine3(){
        return this.Addresses_W_SourceAddressLine3;
    }
    public void setAddresses_W_AddressLine4(String Addresses_W_AddressLine4){
        this.Addresses_W_AddressLine4 = Addresses_W_AddressLine4;
    }
    public String getAddresses_W_AddressLine4(){
        return this.Addresses_W_AddressLine4;
    }
    public void setAddresses_W_City(String Addresses_W_City){
        this.Addresses_W_City = Addresses_W_City;
    }
    public String getAddresses_W_City(){
        return this.Addresses_W_City;
    }
    public void setAddresses_W_SourceCity(String Addresses_W_SourceCity){
        this.Addresses_W_SourceCity = Addresses_W_SourceCity;
    }
    public String getAddresses_W_SourceCity(){
        return this.Addresses_W_SourceCity;
    }
    public void setAddresses_W_StateCode(String Addresses_W_StateCode){
        this.Addresses_W_StateCode = Addresses_W_StateCode;
    }
    public String getAddresses_W_StateCode(){
        return this.Addresses_W_StateCode;
    }
    public void setAddresses_W_SourceStateCode(String Addresses_W_SourceStateCode){
        this.Addresses_W_SourceStateCode = Addresses_W_SourceStateCode;
    }
    public String getAddresses_W_SourceStateCode(){
        return this.Addresses_W_SourceStateCode;
    }
    public void setAddresses_W_CountryCode(String Addresses_W_CountryCode){
        this.Addresses_W_CountryCode = Addresses_W_CountryCode;
    }
    public String getAddresses_W_CountryCode(){
        return this.Addresses_W_CountryCode;
    }
    public void setAddresses_W_SourceCountryCode(String Addresses_W_SourceCountryCode){
        this.Addresses_W_SourceCountryCode = Addresses_W_SourceCountryCode;
    }
    public String getAddresses_W_SourceCountryCode(){
        return this.Addresses_W_SourceCountryCode;
    }
    public void setAddresses_W_PostalCode(String Addresses_W_PostalCode){
        this.Addresses_W_PostalCode = Addresses_W_PostalCode;
    }
    public String getAddresses_W_PostalCode(){
        return this.Addresses_W_PostalCode;
    }
    public void setAddresses_W_SourcePostalCode(String Addresses_W_SourcePostalCode){
        this.Addresses_W_SourcePostalCode = Addresses_W_SourcePostalCode;
    }
    public String getAddresses_W_SourcePostalCode(){
        return this.Addresses_W_SourcePostalCode;
    }
    public void setAddresses_W_ChannelCode(String Addresses_W_ChannelCode){
        this.Addresses_W_ChannelCode = Addresses_W_ChannelCode;
    }
    public String getAddresses_W_ChannelCode(){
        return this.Addresses_W_ChannelCode;
    }
    public void setAddresses_W_LocationCode(String Addresses_W_LocationCode){
        this.Addresses_W_LocationCode = Addresses_W_LocationCode;
    }
    public String getAddresses_W_LocationCode(){
        return this.Addresses_W_LocationCode;
    }
    public void setAddresses_W_IsPreferred(boolean Addresses_W_IsPreferred){
        this.Addresses_W_IsPreferred = Addresses_W_IsPreferred;
    }
    public boolean getAddresses_W_IsPreferred(){
        return this.Addresses_W_IsPreferred;
    }
    public void setAddresses_W_DeliveryStatus(String Addresses_W_DeliveryStatus){
        this.Addresses_W_DeliveryStatus = Addresses_W_DeliveryStatus;
    }
    public String getAddresses_W_DeliveryStatus(){
        return this.Addresses_W_DeliveryStatus;
    }
    public void setAddresses_W_DoNotStandardize(boolean Addresses_W_DoNotStandardize){
        this.Addresses_W_DoNotStandardize = Addresses_W_DoNotStandardize;
    }
    public boolean getAddresses_W_DoNotStandardize(){
        return this.Addresses_W_DoNotStandardize;
    }
    public void setEmails_B_EmailId(String Emails_B_EmailId){
        this.Emails_B_EmailId = Emails_B_EmailId;
    }
    public String getEmails_B_EmailId(){
        return this.Emails_B_EmailId;
    }
    public void setEmails_B_EmailAddress(String Emails_B_EmailAddress){
        this.Emails_B_EmailAddress = Emails_B_EmailAddress;
    }
    public String getEmails_B_EmailAddress(){
        return this.Emails_B_EmailAddress;
    }
    public void setEmails_B_SourceEmailAddress(String Emails_B_SourceEmailAddress){
        this.Emails_B_SourceEmailAddress = Emails_B_SourceEmailAddress;
    }
    public String getEmails_B_SourceEmailAddress(){
        return this.Emails_B_SourceEmailAddress;
    }
    public void setEmails_B_ChannelCode(String Emails_B_ChannelCode){
        this.Emails_B_ChannelCode = Emails_B_ChannelCode;
    }
    public String getEmails_B_ChannelCode(){
        return this.Emails_B_ChannelCode;
    }
    public void setEmails_B_LocationCode(String Emails_B_LocationCode){
        this.Emails_B_LocationCode = Emails_B_LocationCode;
    }
    public String getEmails_B_LocationCode(){
        return this.Emails_B_LocationCode;
    }
    public void setEmails_B_IsPreferred(boolean Emails_B_IsPreferred){
        this.Emails_B_IsPreferred = Emails_B_IsPreferred;
    }
    public boolean getEmails_B_IsPreferred(){
        return this.Emails_B_IsPreferred;
    }
    public void setEmails_B_DeliveryStatus(String Emails_B_DeliveryStatus){
        this.Emails_B_DeliveryStatus = Emails_B_DeliveryStatus;
    }
    public String getEmails_B_DeliveryStatus(){
        return this.Emails_B_DeliveryStatus;
    }
    public void setEmails_B_ContactPointId(String Emails_B_ContactPointId){
        this.Emails_B_ContactPointId = Emails_B_ContactPointId;
    }
    public String getEmails_B_ContactPointId(){
        return this.Emails_B_ContactPointId;
    }
    public void setEmails_B_OriginalContactPoint_ContactPointId(String Emails_B_OriginalContactPoint_ContactPointId){
        this.Emails_B_OriginalContactPoint_ContactPointId = Emails_B_OriginalContactPoint_ContactPointId;
    }
    public String getEmails_B_OriginalContactPoint_ContactPointId(){
        return this.Emails_B_OriginalContactPoint_ContactPointId;
    }
    public void setEmails_B_OriginalContactPoint_ActiveContactPointId(String Emails_B_OriginalContactPoint_ActiveContactPointId){
        this.Emails_B_OriginalContactPoint_ActiveContactPointId = Emails_B_OriginalContactPoint_ActiveContactPointId;
    }
    public String getEmails_B_OriginalContactPoint_ActiveContactPointId(){
        return this.Emails_B_OriginalContactPoint_ActiveContactPointId;
    }
    public void setEmails_B_OriginalContactPoint_ContactPointTypeCode(String Emails_B_OriginalContactPoint_ContactPointTypeCode){
        this.Emails_B_OriginalContactPoint_ContactPointTypeCode = Emails_B_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getEmails_B_OriginalContactPoint_ContactPointTypeCode(){
        return this.Emails_B_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setEmails_B_OriginalContactPoint_ContactPointStatusCode(String Emails_B_OriginalContactPoint_ContactPointStatusCode){
        this.Emails_B_OriginalContactPoint_ContactPointStatusCode = Emails_B_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getEmails_B_OriginalContactPoint_ContactPointStatusCode(){
        return this.Emails_B_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setEmails_B_OriginalContactPoint_ContactPointValue(String Emails_B_OriginalContactPoint_ContactPointValue){
        this.Emails_B_OriginalContactPoint_ContactPointValue = Emails_B_OriginalContactPoint_ContactPointValue;
    }
    public String getEmails_B_OriginalContactPoint_ContactPointValue(){
        return this.Emails_B_OriginalContactPoint_ContactPointValue;
    }
    public void setEmails_B_OriginalContactPoint_ValidFlag(String Emails_B_OriginalContactPoint_ValidFlag){
        this.Emails_B_OriginalContactPoint_ValidFlag = Emails_B_OriginalContactPoint_ValidFlag;
    }
    public String getEmails_B_OriginalContactPoint_ValidFlag(){
        return this.Emails_B_OriginalContactPoint_ValidFlag;
    }
    public void setEmails_B_OriginalContactPoint_CorrectedFlag(String Emails_B_OriginalContactPoint_CorrectedFlag){
        this.Emails_B_OriginalContactPoint_CorrectedFlag = Emails_B_OriginalContactPoint_CorrectedFlag;
    }
    public String getEmails_B_OriginalContactPoint_CorrectedFlag(){
        return this.Emails_B_OriginalContactPoint_CorrectedFlag;
    }
    public void setEmails_B_OriginalContactPoint_UndeliverableFlag(String Emails_B_OriginalContactPoint_UndeliverableFlag){
        this.Emails_B_OriginalContactPoint_UndeliverableFlag = Emails_B_OriginalContactPoint_UndeliverableFlag;
    }
    public String getEmails_B_OriginalContactPoint_UndeliverableFlag(){
        return this.Emails_B_OriginalContactPoint_UndeliverableFlag;
    }
    public void setEmails_B_OriginalContactPoint_EmailDomain(String Emails_B_OriginalContactPoint_EmailDomain){
        this.Emails_B_OriginalContactPoint_EmailDomain = Emails_B_OriginalContactPoint_EmailDomain;
    }
    public String getEmails_B_OriginalContactPoint_EmailDomain(){
        return this.Emails_B_OriginalContactPoint_EmailDomain;
    }
    public void setEmails_B_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Emails_B_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getEmails_B_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Emails_B_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setEmails_B_OriginalContactPoint_Status(String Emails_B_OriginalContactPoint_Status){
        this.Emails_B_OriginalContactPoint_Status = Emails_B_OriginalContactPoint_Status;
    }
    public String getEmails_B_OriginalContactPoint_Status(){
        return this.Emails_B_OriginalContactPoint_Status;
    }
    public void setEmails_B_OriginalContactPoint_CreateUser(String Emails_B_OriginalContactPoint_CreateUser){
        this.Emails_B_OriginalContactPoint_CreateUser = Emails_B_OriginalContactPoint_CreateUser;
    }
    public String getEmails_B_OriginalContactPoint_CreateUser(){
        return this.Emails_B_OriginalContactPoint_CreateUser;
    }
    public void setEmails_B_OriginalContactPoint_CreateDate(Date date){
        this.Emails_B_OriginalContactPoint_CreateDate = date;
    }
    public Date getEmails_B_OriginalContactPoint_CreateDate(){
        return this.Emails_B_OriginalContactPoint_CreateDate;
    }
    public void setEmails_B_OriginalContactPoint_UpdateUser(String Emails_B_OriginalContactPoint_UpdateUser){
        this.Emails_B_OriginalContactPoint_UpdateUser = Emails_B_OriginalContactPoint_UpdateUser;
    }
    public String getEmails_B_OriginalContactPoint_UpdateUser(){
        return this.Emails_B_OriginalContactPoint_UpdateUser;
    }
    public void setEmails_B_OriginalContactPoint_UpdateDate(Date date){
        this.Emails_B_OriginalContactPoint_UpdateDate = date;
    }
    public Date getEmails_B_OriginalContactPoint_UpdateDate(){
        return this.Emails_B_OriginalContactPoint_UpdateDate;
    }
    public void setEmails_B_Status(String Emails_B_Status){
        this.Emails_B_Status = Emails_B_Status;
    }
    public String getEmails_B_Status(){
        return this.Emails_B_Status;
    }
    public void setEmails_H_EmailId(String Emails_H_EmailId){
        this.Emails_H_EmailId = Emails_H_EmailId;
    }
    public String getEmails_H_EmailId(){
        return this.Emails_H_EmailId;
    }
    public void setEmails_H_EmailAddress(String Emails_H_EmailAddress){
        this.Emails_H_EmailAddress = Emails_H_EmailAddress;
    }
    public String getEmails_H_EmailAddress(){
        return this.Emails_H_EmailAddress;
    }
    public void setEmails_H_SourceEmailAddress(String Emails_H_SourceEmailAddress){
        this.Emails_H_SourceEmailAddress = Emails_H_SourceEmailAddress;
    }
    public String getEmails_H_SourceEmailAddress(){
        return this.Emails_H_SourceEmailAddress;
    }
    public void setEmails_H_ChannelCode(String Emails_H_ChannelCode){
        this.Emails_H_ChannelCode = Emails_H_ChannelCode;
    }
    public String getEmails_H_ChannelCode(){
        return this.Emails_H_ChannelCode;
    }
    public void setEmails_H_LocationCode(String Emails_H_LocationCode){
        this.Emails_H_LocationCode = Emails_H_LocationCode;
    }
    public String getEmails_H_LocationCode(){
        return this.Emails_H_LocationCode;
    }
    public void setEmails_H_IsPreferred(boolean Emails_H_IsPreferred){
        this.Emails_H_IsPreferred = Emails_H_IsPreferred;
    }
    public boolean getEmails_H_IsPreferred(){
        return this.Emails_H_IsPreferred;
    }
    public void setEmails_H_DeliveryStatus(String Emails_H_DeliveryStatus){
        this.Emails_H_DeliveryStatus = Emails_H_DeliveryStatus;
    }
    public String getEmails_H_DeliveryStatus(){
        return this.Emails_H_DeliveryStatus;
    }
    public void setEmails_H_ContactPointId(String Emails_H_ContactPointId){
        this.Emails_H_ContactPointId = Emails_H_ContactPointId;
    }
    public String getEmails_H_ContactPointId(){
        return this.Emails_H_ContactPointId;
    }
    public void setEmails_H_OriginalContactPoint_ContactPointId(String Emails_H_OriginalContactPoint_ContactPointId){
        this.Emails_H_OriginalContactPoint_ContactPointId = Emails_H_OriginalContactPoint_ContactPointId;
    }
    public String getEmails_H_OriginalContactPoint_ContactPointId(){
        return this.Emails_H_OriginalContactPoint_ContactPointId;
    }
    public void setEmails_H_OriginalContactPoint_ActiveContactPointId(String Emails_H_OriginalContactPoint_ActiveContactPointId){
        this.Emails_H_OriginalContactPoint_ActiveContactPointId = Emails_H_OriginalContactPoint_ActiveContactPointId;
    }
    public String getEmails_H_OriginalContactPoint_ActiveContactPointId(){
        return this.Emails_H_OriginalContactPoint_ActiveContactPointId;
    }
    public void setEmails_H_OriginalContactPoint_ContactPointTypeCode(String Emails_H_OriginalContactPoint_ContactPointTypeCode){
        this.Emails_H_OriginalContactPoint_ContactPointTypeCode = Emails_H_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getEmails_H_OriginalContactPoint_ContactPointTypeCode(){
        return this.Emails_H_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setEmails_H_OriginalContactPoint_ContactPointStatusCode(String Emails_H_OriginalContactPoint_ContactPointStatusCode){
        this.Emails_H_OriginalContactPoint_ContactPointStatusCode = Emails_H_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getEmails_H_OriginalContactPoint_ContactPointStatusCode(){
        return this.Emails_H_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setEmails_H_OriginalContactPoint_ContactPointValue(String Emails_H_OriginalContactPoint_ContactPointValue){
        this.Emails_H_OriginalContactPoint_ContactPointValue = Emails_H_OriginalContactPoint_ContactPointValue;
    }
    public String getEmails_H_OriginalContactPoint_ContactPointValue(){
        return this.Emails_H_OriginalContactPoint_ContactPointValue;
    }
    public void setEmails_H_OriginalContactPoint_ValidFlag(String Emails_H_OriginalContactPoint_ValidFlag){
        this.Emails_H_OriginalContactPoint_ValidFlag = Emails_H_OriginalContactPoint_ValidFlag;
    }
    public String getEmails_H_OriginalContactPoint_ValidFlag(){
        return this.Emails_H_OriginalContactPoint_ValidFlag;
    }
    public void setEmails_H_OriginalContactPoint_CorrectedFlag(String Emails_H_OriginalContactPoint_CorrectedFlag){
        this.Emails_H_OriginalContactPoint_CorrectedFlag = Emails_H_OriginalContactPoint_CorrectedFlag;
    }
    public String getEmails_H_OriginalContactPoint_CorrectedFlag(){
        return this.Emails_H_OriginalContactPoint_CorrectedFlag;
    }
    public void setEmails_H_OriginalContactPoint_UndeliverableFlag(String Emails_H_OriginalContactPoint_UndeliverableFlag){
        this.Emails_H_OriginalContactPoint_UndeliverableFlag = Emails_H_OriginalContactPoint_UndeliverableFlag;
    }
    public String getEmails_H_OriginalContactPoint_UndeliverableFlag(){
        return this.Emails_H_OriginalContactPoint_UndeliverableFlag;
    }
    public void setEmails_H_OriginalContactPoint_EmailDomain(String Emails_H_OriginalContactPoint_EmailDomain){
        this.Emails_H_OriginalContactPoint_EmailDomain = Emails_H_OriginalContactPoint_EmailDomain;
    }
    public String getEmails_H_OriginalContactPoint_EmailDomain(){
        return this.Emails_H_OriginalContactPoint_EmailDomain;
    }
    public void setEmails_H_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Emails_H_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getEmails_H_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Emails_H_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setEmails_H_OriginalContactPoint_Status(String Emails_H_OriginalContactPoint_Status){
        this.Emails_H_OriginalContactPoint_Status = Emails_H_OriginalContactPoint_Status;
    }
    public String getEmails_H_OriginalContactPoint_Status(){
        return this.Emails_H_OriginalContactPoint_Status;
    }
    public void setEmails_H_OriginalContactPoint_CreateUser(String Emails_H_OriginalContactPoint_CreateUser){
        this.Emails_H_OriginalContactPoint_CreateUser = Emails_H_OriginalContactPoint_CreateUser;
    }
    public String getEmails_H_OriginalContactPoint_CreateUser(){
        return this.Emails_H_OriginalContactPoint_CreateUser;
    }
    public void setEmails_H_OriginalContactPoint_CreateDate(Date date){
        this.Emails_H_OriginalContactPoint_CreateDate = date;
    }
    public Date getEmails_H_OriginalContactPoint_CreateDate(){
        return this.Emails_H_OriginalContactPoint_CreateDate;
    }
    public void setEmails_H_OriginalContactPoint_UpdateUser(String Emails_H_OriginalContactPoint_UpdateUser){
        this.Emails_H_OriginalContactPoint_UpdateUser = Emails_H_OriginalContactPoint_UpdateUser;
    }
    public String getEmails_H_OriginalContactPoint_UpdateUser(){
        return this.Emails_H_OriginalContactPoint_UpdateUser;
    }
    public void setEmails_H_OriginalContactPoint_UpdateDate(Date date){
        this.Emails_H_OriginalContactPoint_UpdateDate = date;
    }
    public Date getEmails_H_OriginalContactPoint_UpdateDate(){
        return this.Emails_H_OriginalContactPoint_UpdateDate;
    }
    public void setEmails_H_Status(String Emails_H_Status){
        this.Emails_H_Status = Emails_H_Status;
    }
    public String getEmails_H_Status(){
        return this.Emails_H_Status;
    }
    public void setEmails_O_EmailId(String Emails_O_EmailId){
        this.Emails_O_EmailId = Emails_O_EmailId;
    }
    public String getEmails_O_EmailId(){
        return this.Emails_O_EmailId;
    }
    public void setEmails_O_EmailAddress(String Emails_O_EmailAddress){
        this.Emails_O_EmailAddress = Emails_O_EmailAddress;
    }
    public String getEmails_O_EmailAddress(){
        return this.Emails_O_EmailAddress;
    }
    public void setEmails_O_SourceEmailAddress(String Emails_O_SourceEmailAddress){
        this.Emails_O_SourceEmailAddress = Emails_O_SourceEmailAddress;
    }
    public String getEmails_O_SourceEmailAddress(){
        return this.Emails_O_SourceEmailAddress;
    }
    public void setEmails_O_ChannelCode(String Emails_O_ChannelCode){
        this.Emails_O_ChannelCode = Emails_O_ChannelCode;
    }
    public String getEmails_O_ChannelCode(){
        return this.Emails_O_ChannelCode;
    }
    public void setEmails_O_LocationCode(String Emails_O_LocationCode){
        this.Emails_O_LocationCode = Emails_O_LocationCode;
    }
    public String getEmails_O_LocationCode(){
        return this.Emails_O_LocationCode;
    }
    public void setEmails_O_IsPreferred(boolean Emails_O_IsPreferred){
        this.Emails_O_IsPreferred = Emails_O_IsPreferred;
    }
    public boolean getEmails_O_IsPreferred(){
        return this.Emails_O_IsPreferred;
    }
    public void setEmails_O_DeliveryStatus(String Emails_O_DeliveryStatus){
        this.Emails_O_DeliveryStatus = Emails_O_DeliveryStatus;
    }
    public String getEmails_O_DeliveryStatus(){
        return this.Emails_O_DeliveryStatus;
    }
    public void setEmails_O_ContactPointId(String Emails_O_ContactPointId){
        this.Emails_O_ContactPointId = Emails_O_ContactPointId;
    }
    public String getEmails_O_ContactPointId(){
        return this.Emails_O_ContactPointId;
    }
    public void setEmails_O_OriginalContactPoint_ContactPointId(String Emails_O_OriginalContactPoint_ContactPointId){
        this.Emails_O_OriginalContactPoint_ContactPointId = Emails_O_OriginalContactPoint_ContactPointId;
    }
    public String getEmails_O_OriginalContactPoint_ContactPointId(){
        return this.Emails_O_OriginalContactPoint_ContactPointId;
    }
    public void setEmails_O_OriginalContactPoint_ActiveContactPointId(String Emails_O_OriginalContactPoint_ActiveContactPointId){
        this.Emails_O_OriginalContactPoint_ActiveContactPointId = Emails_O_OriginalContactPoint_ActiveContactPointId;
    }
    public String getEmails_O_OriginalContactPoint_ActiveContactPointId(){
        return this.Emails_O_OriginalContactPoint_ActiveContactPointId;
    }
    public void setEmails_O_OriginalContactPoint_ContactPointTypeCode(String Emails_O_OriginalContactPoint_ContactPointTypeCode){
        this.Emails_O_OriginalContactPoint_ContactPointTypeCode = Emails_O_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getEmails_O_OriginalContactPoint_ContactPointTypeCode(){
        return this.Emails_O_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setEmails_O_OriginalContactPoint_ContactPointStatusCode(String Emails_O_OriginalContactPoint_ContactPointStatusCode){
        this.Emails_O_OriginalContactPoint_ContactPointStatusCode = Emails_O_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getEmails_O_OriginalContactPoint_ContactPointStatusCode(){
        return this.Emails_O_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setEmails_O_OriginalContactPoint_ContactPointValue(String Emails_O_OriginalContactPoint_ContactPointValue){
        this.Emails_O_OriginalContactPoint_ContactPointValue = Emails_O_OriginalContactPoint_ContactPointValue;
    }
    public String getEmails_O_OriginalContactPoint_ContactPointValue(){
        return this.Emails_O_OriginalContactPoint_ContactPointValue;
    }
    public void setEmails_O_OriginalContactPoint_ValidFlag(String Emails_O_OriginalContactPoint_ValidFlag){
        this.Emails_O_OriginalContactPoint_ValidFlag = Emails_O_OriginalContactPoint_ValidFlag;
    }
    public String getEmails_O_OriginalContactPoint_ValidFlag(){
        return this.Emails_O_OriginalContactPoint_ValidFlag;
    }
    public void setEmails_O_OriginalContactPoint_CorrectedFlag(String Emails_O_OriginalContactPoint_CorrectedFlag){
        this.Emails_O_OriginalContactPoint_CorrectedFlag = Emails_O_OriginalContactPoint_CorrectedFlag;
    }
    public String getEmails_O_OriginalContactPoint_CorrectedFlag(){
        return this.Emails_O_OriginalContactPoint_CorrectedFlag;
    }
    public void setEmails_O_OriginalContactPoint_UndeliverableFlag(String Emails_O_OriginalContactPoint_UndeliverableFlag){
        this.Emails_O_OriginalContactPoint_UndeliverableFlag = Emails_O_OriginalContactPoint_UndeliverableFlag;
    }
    public String getEmails_O_OriginalContactPoint_UndeliverableFlag(){
        return this.Emails_O_OriginalContactPoint_UndeliverableFlag;
    }
    public void setEmails_O_OriginalContactPoint_EmailDomain(String Emails_O_OriginalContactPoint_EmailDomain){
        this.Emails_O_OriginalContactPoint_EmailDomain = Emails_O_OriginalContactPoint_EmailDomain;
    }
    public String getEmails_O_OriginalContactPoint_EmailDomain(){
        return this.Emails_O_OriginalContactPoint_EmailDomain;
    }
    public void setEmails_O_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Emails_O_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getEmails_O_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Emails_O_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setEmails_O_OriginalContactPoint_Status(String Emails_O_OriginalContactPoint_Status){
        this.Emails_O_OriginalContactPoint_Status = Emails_O_OriginalContactPoint_Status;
    }
    public String getEmails_O_OriginalContactPoint_Status(){
        return this.Emails_O_OriginalContactPoint_Status;
    }
    public void setEmails_O_OriginalContactPoint_CreateUser(String Emails_O_OriginalContactPoint_CreateUser){
        this.Emails_O_OriginalContactPoint_CreateUser = Emails_O_OriginalContactPoint_CreateUser;
    }
    public String getEmails_O_OriginalContactPoint_CreateUser(){
        return this.Emails_O_OriginalContactPoint_CreateUser;
    }
    public void setEmails_O_OriginalContactPoint_CreateDate(Date date){
        this.Emails_O_OriginalContactPoint_CreateDate = date;
    }
    public Date getEmails_O_OriginalContactPoint_CreateDate(){
        return this.Emails_O_OriginalContactPoint_CreateDate;
    }
    public void setEmails_O_OriginalContactPoint_UpdateUser(String Emails_O_OriginalContactPoint_UpdateUser){
        this.Emails_O_OriginalContactPoint_UpdateUser = Emails_O_OriginalContactPoint_UpdateUser;
    }
    public String getEmails_O_OriginalContactPoint_UpdateUser(){
        return this.Emails_O_OriginalContactPoint_UpdateUser;
    }
    public void setEmails_O_OriginalContactPoint_UpdateDate(Date date){
        this.Emails_O_OriginalContactPoint_UpdateDate = date;
    }
    public Date getEmails_O_OriginalContactPoint_UpdateDate(){
        return this.Emails_O_OriginalContactPoint_UpdateDate;
    }
    public void setEmails_O_Status(String Emails_O_Status){
        this.Emails_O_Status = Emails_O_Status;
    }
    public String getEmails_O_Status(){
        return this.Emails_O_Status;
    }
    public void setPhones_W_PhoneId(String Phones_W_PhoneId){
        this.Phones_W_PhoneId = Phones_W_PhoneId;
    }
    public String getPhones_W_PhoneId(){
        return this.Phones_W_PhoneId;
    }
    public void setPhones_W_PhoneNumber(String Phones_W_PhoneNumber){
        this.Phones_W_PhoneNumber = Phones_W_PhoneNumber;
    }
    public String getPhones_W_PhoneNumber(){
        return this.Phones_W_PhoneNumber;
    }
    public void setPhones_W_SourcePhoneNumber(String Phones_W_SourcePhoneNumber){
        this.Phones_W_SourcePhoneNumber = Phones_W_SourcePhoneNumber;
    }
    public String getPhones_W_SourcePhoneNumber(){
        return this.Phones_W_SourcePhoneNumber;
    }
    public void setPhones_W_PhoneCountryCode(String Phones_W_PhoneCountryCode){
        this.Phones_W_PhoneCountryCode = Phones_W_PhoneCountryCode;
    }
    public String getPhones_W_PhoneCountryCode(){
        return this.Phones_W_PhoneCountryCode;
    }
    public void setPhones_W_AcceptsText(boolean Phones_W_AcceptsText){
        this.Phones_W_AcceptsText = Phones_W_AcceptsText;
    }
    public boolean getPhones_W_AcceptsText(){
        return this.Phones_W_AcceptsText;
    }
    public void setPhones_W_Frequency(long l){
        this.Phones_W_Frequency = l;
    }
    public long getPhones_W_Frequency(){
        return this.Phones_W_Frequency;
    }
    public void setPhones_W_NeverBefore(Date date){
        this.Phones_W_NeverBefore = date;
    }
    public Date getPhones_W_NeverBefore(){
        return this.Phones_W_NeverBefore;
    }
    public void setPhones_W_NeverAfter(Date date){
        this.Phones_W_NeverAfter = date;
    }
    public Date getPhones_W_NeverAfter(){
        return this.Phones_W_NeverAfter;
    }
    public void setPhones_W_ChannelCode(String Phones_W_ChannelCode){
        this.Phones_W_ChannelCode = Phones_W_ChannelCode;
    }
    public String getPhones_W_ChannelCode(){
        return this.Phones_W_ChannelCode;
    }
    public void setPhones_W_LocationCode(String Phones_W_LocationCode){
        this.Phones_W_LocationCode = Phones_W_LocationCode;
    }
    public String getPhones_W_LocationCode(){
        return this.Phones_W_LocationCode;
    }
    public void setPhones_W_IsPreferred(boolean Phones_W_IsPreferred){
        this.Phones_W_IsPreferred = Phones_W_IsPreferred;
    }
    public boolean getPhones_W_IsPreferred(){
        return this.Phones_W_IsPreferred;
    }
    public void setPhones_W_DeliveryStatus(String Phones_W_DeliveryStatus){
        this.Phones_W_DeliveryStatus = Phones_W_DeliveryStatus;
    }
    public String getPhones_W_DeliveryStatus(){
        return this.Phones_W_DeliveryStatus;
    }
    public void setPhones_W_ContactPointId(String Phones_W_ContactPointId){
        this.Phones_W_ContactPointId = Phones_W_ContactPointId;
    }
    public String getPhones_W_ContactPointId(){
        return this.Phones_W_ContactPointId;
    }
    public void setPhones_W_OriginalContactPoint_ContactPointId(String Phones_W_OriginalContactPoint_ContactPointId){
        this.Phones_W_OriginalContactPoint_ContactPointId = Phones_W_OriginalContactPoint_ContactPointId;
    }
    public String getPhones_W_OriginalContactPoint_ContactPointId(){
        return this.Phones_W_OriginalContactPoint_ContactPointId;
    }
    public void setPhones_W_OriginalContactPoint_ActiveContactPointId(String Phones_W_OriginalContactPoint_ActiveContactPointId){
        this.Phones_W_OriginalContactPoint_ActiveContactPointId = Phones_W_OriginalContactPoint_ActiveContactPointId;
    }
    public String getPhones_W_OriginalContactPoint_ActiveContactPointId(){
        return this.Phones_W_OriginalContactPoint_ActiveContactPointId;
    }
    public void setPhones_W_OriginalContactPoint_ContactPointTypeCode(String Phones_W_OriginalContactPoint_ContactPointTypeCode){
        this.Phones_W_OriginalContactPoint_ContactPointTypeCode = Phones_W_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getPhones_W_OriginalContactPoint_ContactPointTypeCode(){
        return this.Phones_W_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setPhones_W_OriginalContactPoint_ContactPointStatusCode(String Phones_W_OriginalContactPoint_ContactPointStatusCode){
        this.Phones_W_OriginalContactPoint_ContactPointStatusCode = Phones_W_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getPhones_W_OriginalContactPoint_ContactPointStatusCode(){
        return this.Phones_W_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setPhones_W_OriginalContactPoint_ContactPointValue(String Phones_W_OriginalContactPoint_ContactPointValue){
        this.Phones_W_OriginalContactPoint_ContactPointValue = Phones_W_OriginalContactPoint_ContactPointValue;
    }
    public String getPhones_W_OriginalContactPoint_ContactPointValue(){
        return this.Phones_W_OriginalContactPoint_ContactPointValue;
    }
    public void setPhones_W_OriginalContactPoint_ValidFlag(String Phones_W_OriginalContactPoint_ValidFlag){
        this.Phones_W_OriginalContactPoint_ValidFlag = Phones_W_OriginalContactPoint_ValidFlag;
    }
    public String getPhones_W_OriginalContactPoint_ValidFlag(){
        return this.Phones_W_OriginalContactPoint_ValidFlag;
    }
    public void setPhones_W_OriginalContactPoint_CorrectedFlag(String Phones_W_OriginalContactPoint_CorrectedFlag){
        this.Phones_W_OriginalContactPoint_CorrectedFlag = Phones_W_OriginalContactPoint_CorrectedFlag;
    }
    public String getPhones_W_OriginalContactPoint_CorrectedFlag(){
        return this.Phones_W_OriginalContactPoint_CorrectedFlag;
    }
    public void setPhones_W_OriginalContactPoint_UndeliverableFlag(String Phones_W_OriginalContactPoint_UndeliverableFlag){
        this.Phones_W_OriginalContactPoint_UndeliverableFlag = Phones_W_OriginalContactPoint_UndeliverableFlag;
    }
    public String getPhones_W_OriginalContactPoint_UndeliverableFlag(){
        return this.Phones_W_OriginalContactPoint_UndeliverableFlag;
    }
    public void setPhones_W_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Phones_W_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getPhones_W_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Phones_W_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setPhones_W_OriginalContactPoint_Status(String Phones_W_OriginalContactPoint_Status){
        this.Phones_W_OriginalContactPoint_Status = Phones_W_OriginalContactPoint_Status;
    }
    public String getPhones_W_OriginalContactPoint_Status(){
        return this.Phones_W_OriginalContactPoint_Status;
    }
    public void setPhones_W_OriginalContactPoint_CreateUser(String Phones_W_OriginalContactPoint_CreateUser){
        this.Phones_W_OriginalContactPoint_CreateUser = Phones_W_OriginalContactPoint_CreateUser;
    }
    public String getPhones_W_OriginalContactPoint_CreateUser(){
        return this.Phones_W_OriginalContactPoint_CreateUser;
    }
    public void setPhones_W_OriginalContactPoint_CreateDate(Date date){
        this.Phones_W_OriginalContactPoint_CreateDate = date;
    }
    public Date getPhones_W_OriginalContactPoint_CreateDate(){
        return this.Phones_W_OriginalContactPoint_CreateDate;
    }
    public void setPhones_W_OriginalContactPoint_UpdateUser(String Phones_W_OriginalContactPoint_UpdateUser){
        this.Phones_W_OriginalContactPoint_UpdateUser = Phones_W_OriginalContactPoint_UpdateUser;
    }
    public String getPhones_W_OriginalContactPoint_UpdateUser(){
        return this.Phones_W_OriginalContactPoint_UpdateUser;
    }
    public void setPhones_W_OriginalContactPoint_UpdateDate(Date date){
        this.Phones_W_OriginalContactPoint_UpdateDate = date;
    }
    public Date getPhones_W_OriginalContactPoint_UpdateDate(){
        return this.Phones_W_OriginalContactPoint_UpdateDate;
    }
    public void setPhones_W_Status(String Phones_W_Status){
        this.Phones_W_Status = Phones_W_Status;
    }
    public String getPhones_W_Status(){
        return this.Phones_W_Status;
    }
    public void setPhones_C_PhoneId(String Phones_C_PhoneId){
        this.Phones_C_PhoneId = Phones_C_PhoneId;
    }
    public String getPhones_C_PhoneId(){
        return this.Phones_C_PhoneId;
    }
    public void setPhones_C_PhoneNumber(String Phones_C_PhoneNumber){
        this.Phones_C_PhoneNumber = Phones_C_PhoneNumber;
    }
    public String getPhones_C_PhoneNumber(){
        return this.Phones_C_PhoneNumber;
    }
    public void setPhones_C_SourcePhoneNumber(String Phones_C_SourcePhoneNumber){
        this.Phones_C_SourcePhoneNumber = Phones_C_SourcePhoneNumber;
    }
    public String getPhones_C_SourcePhoneNumber(){
        return this.Phones_C_SourcePhoneNumber;
    }
    public void setPhones_C_PhoneCountryCode(String Phones_C_PhoneCountryCode){
        this.Phones_C_PhoneCountryCode = Phones_C_PhoneCountryCode;
    }
    public String getPhones_C_PhoneCountryCode(){
        return this.Phones_C_PhoneCountryCode;
    }
    public void setPhones_C_AcceptsText(boolean Phones_C_AcceptsText){
        this.Phones_C_AcceptsText = Phones_C_AcceptsText;
    }
    public boolean getPhones_C_AcceptsText(){
        return this.Phones_C_AcceptsText;
    }
    public void setPhones_C_Frequency(long l){
        this.Phones_C_Frequency = l;
    }
    public long getPhones_C_Frequency(){
        return this.Phones_C_Frequency;
    }
    public void setPhones_C_NeverBefore(Date date){
        this.Phones_C_NeverBefore = date;
    }
    public Date getPhones_C_NeverBefore(){
        return this.Phones_C_NeverBefore;
    }
    public void setPhones_C_NeverAfter(Date date){
        this.Phones_C_NeverAfter = date;
    }
    public Date getPhones_C_NeverAfter(){
        return this.Phones_C_NeverAfter;
    }
    public void setPhones_C_ChannelCode(String Phones_C_ChannelCode){
        this.Phones_C_ChannelCode = Phones_C_ChannelCode;
    }
    public String getPhones_C_ChannelCode(){
        return this.Phones_C_ChannelCode;
    }
    public void setPhones_C_LocationCode(String Phones_C_LocationCode){
        this.Phones_C_LocationCode = Phones_C_LocationCode;
    }
    public String getPhones_C_LocationCode(){
        return this.Phones_C_LocationCode;
    }
    public void setPhones_C_IsPreferred(boolean Phones_C_IsPreferred){
        this.Phones_C_IsPreferred = Phones_C_IsPreferred;
    }
    public boolean getPhones_C_IsPreferred(){
        return this.Phones_C_IsPreferred;
    }
    public void setPhones_C_DeliveryStatus(String Phones_C_DeliveryStatus){
        this.Phones_C_DeliveryStatus = Phones_C_DeliveryStatus;
    }
    public String getPhones_C_DeliveryStatus(){
        return this.Phones_C_DeliveryStatus;
    }
    public void setPhones_C_ContactPointId(String Phones_C_ContactPointId){
        this.Phones_C_ContactPointId = Phones_C_ContactPointId;
    }
    public String getPhones_C_ContactPointId(){
        return this.Phones_C_ContactPointId;
    }
    public void setPhones_C_OriginalContactPoint_ContactPointId(String Phones_C_OriginalContactPoint_ContactPointId){
        this.Phones_C_OriginalContactPoint_ContactPointId = Phones_C_OriginalContactPoint_ContactPointId;
    }
    public String getPhones_C_OriginalContactPoint_ContactPointId(){
        return this.Phones_C_OriginalContactPoint_ContactPointId;
    }
    public void setPhones_C_OriginalContactPoint_ActiveContactPointId(String Phones_C_OriginalContactPoint_ActiveContactPointId){
        this.Phones_C_OriginalContactPoint_ActiveContactPointId = Phones_C_OriginalContactPoint_ActiveContactPointId;
    }
    public String getPhones_C_OriginalContactPoint_ActiveContactPointId(){
        return this.Phones_C_OriginalContactPoint_ActiveContactPointId;
    }
    public void setPhones_C_OriginalContactPoint_ContactPointTypeCode(String Phones_C_OriginalContactPoint_ContactPointTypeCode){
        this.Phones_C_OriginalContactPoint_ContactPointTypeCode = Phones_C_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getPhones_C_OriginalContactPoint_ContactPointTypeCode(){
        return this.Phones_C_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setPhones_C_OriginalContactPoint_ContactPointStatusCode(String Phones_C_OriginalContactPoint_ContactPointStatusCode){
        this.Phones_C_OriginalContactPoint_ContactPointStatusCode = Phones_C_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getPhones_C_OriginalContactPoint_ContactPointStatusCode(){
        return this.Phones_C_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setPhones_C_OriginalContactPoint_ContactPointValue(String Phones_C_OriginalContactPoint_ContactPointValue){
        this.Phones_C_OriginalContactPoint_ContactPointValue = Phones_C_OriginalContactPoint_ContactPointValue;
    }
    public String getPhones_C_OriginalContactPoint_ContactPointValue(){
        return this.Phones_C_OriginalContactPoint_ContactPointValue;
    }
    public void setPhones_C_OriginalContactPoint_ValidFlag(String Phones_C_OriginalContactPoint_ValidFlag){
        this.Phones_C_OriginalContactPoint_ValidFlag = Phones_C_OriginalContactPoint_ValidFlag;
    }
    public String getPhones_C_OriginalContactPoint_ValidFlag(){
        return this.Phones_C_OriginalContactPoint_ValidFlag;
    }
    public void setPhones_C_OriginalContactPoint_CorrectedFlag(String Phones_C_OriginalContactPoint_CorrectedFlag){
        this.Phones_C_OriginalContactPoint_CorrectedFlag = Phones_C_OriginalContactPoint_CorrectedFlag;
    }
    public String getPhones_C_OriginalContactPoint_CorrectedFlag(){
        return this.Phones_C_OriginalContactPoint_CorrectedFlag;
    }
    public void setPhones_C_OriginalContactPoint_UndeliverableFlag(String Phones_C_OriginalContactPoint_UndeliverableFlag){
        this.Phones_C_OriginalContactPoint_UndeliverableFlag = Phones_C_OriginalContactPoint_UndeliverableFlag;
    }
    public String getPhones_C_OriginalContactPoint_UndeliverableFlag(){
        return this.Phones_C_OriginalContactPoint_UndeliverableFlag;
    }
    public void setPhones_C_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Phones_C_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getPhones_C_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Phones_C_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setPhones_C_OriginalContactPoint_Status(String Phones_C_OriginalContactPoint_Status){
        this.Phones_C_OriginalContactPoint_Status = Phones_C_OriginalContactPoint_Status;
    }
    public String getPhones_C_OriginalContactPoint_Status(){
        return this.Phones_C_OriginalContactPoint_Status;
    }
    public void setPhones_C_OriginalContactPoint_CreateUser(String Phones_C_OriginalContactPoint_CreateUser){
        this.Phones_C_OriginalContactPoint_CreateUser = Phones_C_OriginalContactPoint_CreateUser;
    }
    public String getPhones_C_OriginalContactPoint_CreateUser(){
        return this.Phones_C_OriginalContactPoint_CreateUser;
    }
    public void setPhones_C_OriginalContactPoint_CreateDate(Date date){
        this.Phones_C_OriginalContactPoint_CreateDate = date;
    }
    public Date getPhones_C_OriginalContactPoint_CreateDate(){
        return this.Phones_C_OriginalContactPoint_CreateDate;
    }
    public void setPhones_C_OriginalContactPoint_UpdateUser(String Phones_C_OriginalContactPoint_UpdateUser){
        this.Phones_C_OriginalContactPoint_UpdateUser = Phones_C_OriginalContactPoint_UpdateUser;
    }
    public String getPhones_C_OriginalContactPoint_UpdateUser(){
        return this.Phones_C_OriginalContactPoint_UpdateUser;
    }
    public void setPhones_C_OriginalContactPoint_UpdateDate(Date date){
        this.Phones_C_OriginalContactPoint_UpdateDate = date;
    }
    public Date getPhones_C_OriginalContactPoint_UpdateDate(){
        return this.Phones_C_OriginalContactPoint_UpdateDate;
    }
    public void setPhones_C_Status(String Phones_C_Status){
        this.Phones_C_Status = Phones_C_Status;
    }
    public String getPhones_C_Status(){
        return this.Phones_C_Status;
    }
    public void setPhones_P_PhoneId(String Phones_P_PhoneId){
        this.Phones_P_PhoneId = Phones_P_PhoneId;
    }
    public String getPhones_P_PhoneId(){
        return this.Phones_P_PhoneId;
    }
    public void setPhones_P_PhoneNumber(String Phones_P_PhoneNumber){
        this.Phones_P_PhoneNumber = Phones_P_PhoneNumber;
    }
    public String getPhones_P_PhoneNumber(){
        return this.Phones_P_PhoneNumber;
    }
    public void setPhones_P_SourcePhoneNumber(String Phones_P_SourcePhoneNumber){
        this.Phones_P_SourcePhoneNumber = Phones_P_SourcePhoneNumber;
    }
    public String getPhones_P_SourcePhoneNumber(){
        return this.Phones_P_SourcePhoneNumber;
    }
    public void setPhones_P_PhoneCountryCode(String Phones_P_PhoneCountryCode){
        this.Phones_P_PhoneCountryCode = Phones_P_PhoneCountryCode;
    }
    public String getPhones_P_PhoneCountryCode(){
        return this.Phones_P_PhoneCountryCode;
    }
    public void setPhones_P_AcceptsText(boolean Phones_P_AcceptsText){
        this.Phones_P_AcceptsText = Phones_P_AcceptsText;
    }
    public boolean getPhones_P_AcceptsText(){
        return this.Phones_P_AcceptsText;
    }
    public void setPhones_P_Frequency(long l){
        this.Phones_P_Frequency = l;
    }
    public long getPhones_P_Frequency(){
        return this.Phones_P_Frequency;
    }
    public void setPhones_P_NeverBefore(Date date){
        this.Phones_P_NeverBefore = date;
    }
    public Date getPhones_P_NeverBefore(){
        return this.Phones_P_NeverBefore;
    }
    public void setPhones_P_NeverAfter(Date date){
        this.Phones_P_NeverAfter = date;
    }
    public Date getPhones_P_NeverAfter(){
        return this.Phones_P_NeverAfter;
    }
    public void setPhones_P_ChannelCode(String Phones_P_ChannelCode){
        this.Phones_P_ChannelCode = Phones_P_ChannelCode;
    }
    public String getPhones_P_ChannelCode(){
        return this.Phones_P_ChannelCode;
    }
    public void setPhones_P_LocationCode(String Phones_P_LocationCode){
        this.Phones_P_LocationCode = Phones_P_LocationCode;
    }
    public String getPhones_P_LocationCode(){
        return this.Phones_P_LocationCode;
    }
    public void setPhones_P_IsPreferred(boolean Phones_P_IsPreferred){
        this.Phones_P_IsPreferred = Phones_P_IsPreferred;
    }
    public boolean getPhones_P_IsPreferred(){
        return this.Phones_P_IsPreferred;
    }
    public void setPhones_P_DeliveryStatus(String Phones_P_DeliveryStatus){
        this.Phones_P_DeliveryStatus = Phones_P_DeliveryStatus;
    }
    public String getPhones_P_DeliveryStatus(){
        return this.Phones_P_DeliveryStatus;
    }
    public void setPhones_P_ContactPointId(String Phones_P_ContactPointId){
        this.Phones_P_ContactPointId = Phones_P_ContactPointId;
    }
    public String getPhones_P_ContactPointId(){
        return this.Phones_P_ContactPointId;
    }
    public void setPhones_P_OriginalContactPoint_ContactPointId(String Phones_P_OriginalContactPoint_ContactPointId){
        this.Phones_P_OriginalContactPoint_ContactPointId = Phones_P_OriginalContactPoint_ContactPointId;
    }
    public String getPhones_P_OriginalContactPoint_ContactPointId(){
        return this.Phones_P_OriginalContactPoint_ContactPointId;
    }
    public void setPhones_P_OriginalContactPoint_ActiveContactPointId(String Phones_P_OriginalContactPoint_ActiveContactPointId){
        this.Phones_P_OriginalContactPoint_ActiveContactPointId = Phones_P_OriginalContactPoint_ActiveContactPointId;
    }
    public String getPhones_P_OriginalContactPoint_ActiveContactPointId(){
        return this.Phones_P_OriginalContactPoint_ActiveContactPointId;
    }
    public void setPhones_P_OriginalContactPoint_ContactPointTypeCode(String Phones_P_OriginalContactPoint_ContactPointTypeCode){
        this.Phones_P_OriginalContactPoint_ContactPointTypeCode = Phones_P_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getPhones_P_OriginalContactPoint_ContactPointTypeCode(){
        return this.Phones_P_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setPhones_P_OriginalContactPoint_ContactPointStatusCode(String Phones_P_OriginalContactPoint_ContactPointStatusCode){
        this.Phones_P_OriginalContactPoint_ContactPointStatusCode = Phones_P_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getPhones_P_OriginalContactPoint_ContactPointStatusCode(){
        return this.Phones_P_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setPhones_P_OriginalContactPoint_ContactPointValue(String Phones_P_OriginalContactPoint_ContactPointValue){
        this.Phones_P_OriginalContactPoint_ContactPointValue = Phones_P_OriginalContactPoint_ContactPointValue;
    }
    public String getPhones_P_OriginalContactPoint_ContactPointValue(){
        return this.Phones_P_OriginalContactPoint_ContactPointValue;
    }
    public void setPhones_P_OriginalContactPoint_ValidFlag(String Phones_P_OriginalContactPoint_ValidFlag){
        this.Phones_P_OriginalContactPoint_ValidFlag = Phones_P_OriginalContactPoint_ValidFlag;
    }
    public String getPhones_P_OriginalContactPoint_ValidFlag(){
        return this.Phones_P_OriginalContactPoint_ValidFlag;
    }
    public void setPhones_P_OriginalContactPoint_CorrectedFlag(String Phones_P_OriginalContactPoint_CorrectedFlag){
        this.Phones_P_OriginalContactPoint_CorrectedFlag = Phones_P_OriginalContactPoint_CorrectedFlag;
    }
    public String getPhones_P_OriginalContactPoint_CorrectedFlag(){
        return this.Phones_P_OriginalContactPoint_CorrectedFlag;
    }
    public void setPhones_P_OriginalContactPoint_UndeliverableFlag(String Phones_P_OriginalContactPoint_UndeliverableFlag){
        this.Phones_P_OriginalContactPoint_UndeliverableFlag = Phones_P_OriginalContactPoint_UndeliverableFlag;
    }
    public String getPhones_P_OriginalContactPoint_UndeliverableFlag(){
        return this.Phones_P_OriginalContactPoint_UndeliverableFlag;
    }
    public void setPhones_P_OriginalContactPoint_ContactPointSequenceNumber(String string){
        this.Phones_P_OriginalContactPoint_ContactPointSequenceNumber = string;
    }
    public String getPhones_P_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Phones_P_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setPhones_P_OriginalContactPoint_Status(String Phones_P_OriginalContactPoint_Status){
        this.Phones_P_OriginalContactPoint_Status = Phones_P_OriginalContactPoint_Status;
    }
    public String getPhones_P_OriginalContactPoint_Status(){
        return this.Phones_P_OriginalContactPoint_Status;
    }
    public void setPhones_P_OriginalContactPoint_CreateUser(String Phones_P_OriginalContactPoint_CreateUser){
        this.Phones_P_OriginalContactPoint_CreateUser = Phones_P_OriginalContactPoint_CreateUser;
    }
    public String getPhones_P_OriginalContactPoint_CreateUser(){
        return this.Phones_P_OriginalContactPoint_CreateUser;
    }
    public void setPhones_P_OriginalContactPoint_CreateDate(Date date){
        this.Phones_P_OriginalContactPoint_CreateDate = date;
    }
    public Date getPhones_P_OriginalContactPoint_CreateDate(){
        return this.Phones_P_OriginalContactPoint_CreateDate;
    }
    public void setPhones_P_OriginalContactPoint_UpdateUser(String Phones_P_OriginalContactPoint_UpdateUser){
        this.Phones_P_OriginalContactPoint_UpdateUser = Phones_P_OriginalContactPoint_UpdateUser;
    }
    public String getPhones_P_OriginalContactPoint_UpdateUser(){
        return this.Phones_P_OriginalContactPoint_UpdateUser;
    }
    public void setPhones_P_OriginalContactPoint_UpdateDate(Date date){
        this.Phones_P_OriginalContactPoint_UpdateDate = date;
    }
    public Date getPhones_P_OriginalContactPoint_UpdateDate(){
        return this.Phones_P_OriginalContactPoint_UpdateDate;
    }
    public void setPhones_P_Status(String Phones_P_Status){
        this.Phones_P_Status = Phones_P_Status;
    }
    public String getPhones_P_Status(){
        return this.Phones_P_Status;
    }
    public void setPhones_F_PhoneId(String Phones_F_PhoneId){
        this.Phones_F_PhoneId = Phones_F_PhoneId;
    }
    public String getPhones_F_PhoneId(){
        return this.Phones_F_PhoneId;
    }
    public void setPhones_F_PhoneNumber(String Phones_F_PhoneNumber){
        this.Phones_F_PhoneNumber = Phones_F_PhoneNumber;
    }
    public String getPhones_F_PhoneNumber(){
        return this.Phones_F_PhoneNumber;
    }
    public void setPhones_F_SourcePhoneNumber(String Phones_F_SourcePhoneNumber){
        this.Phones_F_SourcePhoneNumber = Phones_F_SourcePhoneNumber;
    }
    public String getPhones_F_SourcePhoneNumber(){
        return this.Phones_F_SourcePhoneNumber;
    }
    public void setPhones_F_PhoneCountryCode(String Phones_F_PhoneCountryCode){
        this.Phones_F_PhoneCountryCode = Phones_F_PhoneCountryCode;
    }
    public String getPhones_F_PhoneCountryCode(){
        return this.Phones_F_PhoneCountryCode;
    }
    public void setPhones_F_AcceptsText(boolean Phones_F_AcceptsText){
        this.Phones_F_AcceptsText = Phones_F_AcceptsText;
    }
    public boolean getPhones_F_AcceptsText(){
        return this.Phones_F_AcceptsText;
    }
    public void setPhones_F_Frequency(int Phones_F_Frequency){
        this.Phones_F_Frequency = Phones_F_Frequency;
    }
    public int getPhones_F_Frequency(){
        return this.Phones_F_Frequency;
    }
    public void setPhones_F_NeverBefore(String Phones_F_NeverBefore){
        this.Phones_F_NeverBefore = Phones_F_NeverBefore;
    }
    public String getPhones_F_NeverBefore(){
        return this.Phones_F_NeverBefore;
    }
    public void setPhones_F_NeverAfter(String Phones_F_NeverAfter){
        this.Phones_F_NeverAfter = Phones_F_NeverAfter;
    }
    public String getPhones_F_NeverAfter(){
        return this.Phones_F_NeverAfter;
    }
    public void setPhones_F_ChannelCode(String Phones_F_ChannelCode){
        this.Phones_F_ChannelCode = Phones_F_ChannelCode;
    }
    public String getPhones_F_ChannelCode(){
        return this.Phones_F_ChannelCode;
    }
    public void setPhones_F_LocationCode(String Phones_F_LocationCode){
        this.Phones_F_LocationCode = Phones_F_LocationCode;
    }
    public String getPhones_F_LocationCode(){
        return this.Phones_F_LocationCode;
    }
    public void setPhones_F_IsPreferred(boolean Phones_F_IsPreferred){
        this.Phones_F_IsPreferred = Phones_F_IsPreferred;
    }
    public boolean getPhones_F_IsPreferred(){
        return this.Phones_F_IsPreferred;
    }
    public void setPhones_F_DeliveryStatus(String Phones_F_DeliveryStatus){
        this.Phones_F_DeliveryStatus = Phones_F_DeliveryStatus;
    }
    public String getPhones_F_DeliveryStatus(){
        return this.Phones_F_DeliveryStatus;
    }
    public void setPhones_F_ContactPointId(String Phones_F_ContactPointId){
        this.Phones_F_ContactPointId = Phones_F_ContactPointId;
    }
    public String getPhones_F_ContactPointId(){
        return this.Phones_F_ContactPointId;
    }
    public void setPhones_F_OriginalContactPoint_ContactPointId(String Phones_F_OriginalContactPoint_ContactPointId){
        this.Phones_F_OriginalContactPoint_ContactPointId = Phones_F_OriginalContactPoint_ContactPointId;
    }
    public String getPhones_F_OriginalContactPoint_ContactPointId(){
        return this.Phones_F_OriginalContactPoint_ContactPointId;
    }
    public void setPhones_F_OriginalContactPoint_ActiveContactPointId(String Phones_F_OriginalContactPoint_ActiveContactPointId){
        this.Phones_F_OriginalContactPoint_ActiveContactPointId = Phones_F_OriginalContactPoint_ActiveContactPointId;
    }
    public String getPhones_F_OriginalContactPoint_ActiveContactPointId(){
        return this.Phones_F_OriginalContactPoint_ActiveContactPointId;
    }
    public void setPhones_F_OriginalContactPoint_ContactPointTypeCode(String Phones_F_OriginalContactPoint_ContactPointTypeCode){
        this.Phones_F_OriginalContactPoint_ContactPointTypeCode = Phones_F_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getPhones_F_OriginalContactPoint_ContactPointTypeCode(){
        return this.Phones_F_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setPhones_F_OriginalContactPoint_ContactPointStatusCode(String Phones_F_OriginalContactPoint_ContactPointStatusCode){
        this.Phones_F_OriginalContactPoint_ContactPointStatusCode = Phones_F_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getPhones_F_OriginalContactPoint_ContactPointStatusCode(){
        return this.Phones_F_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setPhones_F_OriginalContactPoint_ContactPointValue(String Phones_F_OriginalContactPoint_ContactPointValue){
        this.Phones_F_OriginalContactPoint_ContactPointValue = Phones_F_OriginalContactPoint_ContactPointValue;
    }
    public String getPhones_F_OriginalContactPoint_ContactPointValue(){
        return this.Phones_F_OriginalContactPoint_ContactPointValue;
    }
    public void setPhones_F_OriginalContactPoint_ValidFlag(String Phones_F_OriginalContactPoint_ValidFlag){
        this.Phones_F_OriginalContactPoint_ValidFlag = Phones_F_OriginalContactPoint_ValidFlag;
    }
    public String getPhones_F_OriginalContactPoint_ValidFlag(){
        return this.Phones_F_OriginalContactPoint_ValidFlag;
    }
    public void setPhones_F_OriginalContactPoint_CorrectedFlag(String Phones_F_OriginalContactPoint_CorrectedFlag){
        this.Phones_F_OriginalContactPoint_CorrectedFlag = Phones_F_OriginalContactPoint_CorrectedFlag;
    }
    public String getPhones_F_OriginalContactPoint_CorrectedFlag(){
        return this.Phones_F_OriginalContactPoint_CorrectedFlag;
    }
    public void setPhones_F_OriginalContactPoint_UndeliverableFlag(String Phones_F_OriginalContactPoint_UndeliverableFlag){
        this.Phones_F_OriginalContactPoint_UndeliverableFlag = Phones_F_OriginalContactPoint_UndeliverableFlag;
    }
    public String getPhones_F_OriginalContactPoint_UndeliverableFlag(){
        return this.Phones_F_OriginalContactPoint_UndeliverableFlag;
    }
    public void setPhones_F_OriginalContactPoint_ContactPointSequenceNumber(int Phones_F_OriginalContactPoint_ContactPointSequenceNumber){
        this.Phones_F_OriginalContactPoint_ContactPointSequenceNumber = Phones_F_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public int getPhones_F_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Phones_F_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setPhones_F_OriginalContactPoint_Status(String Phones_F_OriginalContactPoint_Status){
        this.Phones_F_OriginalContactPoint_Status = Phones_F_OriginalContactPoint_Status;
    }
    public String getPhones_F_OriginalContactPoint_Status(){
        return this.Phones_F_OriginalContactPoint_Status;
    }
    public void setPhones_F_OriginalContactPoint_CreateUser(String Phones_F_OriginalContactPoint_CreateUser){
        this.Phones_F_OriginalContactPoint_CreateUser = Phones_F_OriginalContactPoint_CreateUser;
    }
    public String getPhones_F_OriginalContactPoint_CreateUser(){
        return this.Phones_F_OriginalContactPoint_CreateUser;
    }
    public void setPhones_F_OriginalContactPoint_CreateDate(String Phones_F_OriginalContactPoint_CreateDate){
        this.Phones_F_OriginalContactPoint_CreateDate = Phones_F_OriginalContactPoint_CreateDate;
    }
    public String getPhones_F_OriginalContactPoint_CreateDate(){
        return this.Phones_F_OriginalContactPoint_CreateDate;
    }
    public void setPhones_F_OriginalContactPoint_UpdateUser(String Phones_F_OriginalContactPoint_UpdateUser){
        this.Phones_F_OriginalContactPoint_UpdateUser = Phones_F_OriginalContactPoint_UpdateUser;
    }
    public String getPhones_F_OriginalContactPoint_UpdateUser(){
        return this.Phones_F_OriginalContactPoint_UpdateUser;
    }
    public void setPhones_F_OriginalContactPoint_UpdateDate(String Phones_F_OriginalContactPoint_UpdateDate){
        this.Phones_F_OriginalContactPoint_UpdateDate = Phones_F_OriginalContactPoint_UpdateDate;
    }
    public String getPhones_F_OriginalContactPoint_UpdateDate(){
        return this.Phones_F_OriginalContactPoint_UpdateDate;
    }
    public void setPhones_F_Status(String Phones_F_Status){
        this.Phones_F_Status = Phones_F_Status;
    }
    public String getPhones_F_Status(){
        return this.Phones_F_Status;
    }
    public void setPhones_O_PhoneId(String Phones_O_PhoneId){
        this.Phones_O_PhoneId = Phones_O_PhoneId;
    }
    public String getPhones_O_PhoneId(){
        return this.Phones_O_PhoneId;
    }
    public void setPhones_O_PhoneNumber(String Phones_O_PhoneNumber){
        this.Phones_O_PhoneNumber = Phones_O_PhoneNumber;
    }
    public String getPhones_O_PhoneNumber(){
        return this.Phones_O_PhoneNumber;
    }
    public void setPhones_O_SourcePhoneNumber(String Phones_O_SourcePhoneNumber){
        this.Phones_O_SourcePhoneNumber = Phones_O_SourcePhoneNumber;
    }
    public String getPhones_O_SourcePhoneNumber(){
        return this.Phones_O_SourcePhoneNumber;
    }
    public void setPhones_O_PhoneCountryCode(String Phones_O_PhoneCountryCode){
        this.Phones_O_PhoneCountryCode = Phones_O_PhoneCountryCode;
    }
    public String getPhones_O_PhoneCountryCode(){
        return this.Phones_O_PhoneCountryCode;
    }
    public void setPhones_O_AcceptsText(boolean Phones_O_AcceptsText){
        this.Phones_O_AcceptsText = Phones_O_AcceptsText;
    }
    public boolean getPhones_O_AcceptsText(){
        return this.Phones_O_AcceptsText;
    }
    public void setPhones_O_Frequency(int Phones_O_Frequency){
        this.Phones_O_Frequency = Phones_O_Frequency;
    }
    public int getPhones_O_Frequency(){
        return this.Phones_O_Frequency;
    }
    public void setPhones_O_NeverBefore(String Phones_O_NeverBefore){
        this.Phones_O_NeverBefore = Phones_O_NeverBefore;
    }
    public String getPhones_O_NeverBefore(){
        return this.Phones_O_NeverBefore;
    }
    public void setPhones_O_NeverAfter(String Phones_O_NeverAfter){
        this.Phones_O_NeverAfter = Phones_O_NeverAfter;
    }
    public String getPhones_O_NeverAfter(){
        return this.Phones_O_NeverAfter;
    }
    public void setPhones_O_ChannelCode(String Phones_O_ChannelCode){
        this.Phones_O_ChannelCode = Phones_O_ChannelCode;
    }
    public String getPhones_O_ChannelCode(){
        return this.Phones_O_ChannelCode;
    }
    public void setPhones_O_LocationCode(String Phones_O_LocationCode){
        this.Phones_O_LocationCode = Phones_O_LocationCode;
    }
    public String getPhones_O_LocationCode(){
        return this.Phones_O_LocationCode;
    }
    public void setPhones_O_IsPreferred(boolean Phones_O_IsPreferred){
        this.Phones_O_IsPreferred = Phones_O_IsPreferred;
    }
    public boolean getPhones_O_IsPreferred(){
        return this.Phones_O_IsPreferred;
    }
    public void setPhones_O_DeliveryStatus(String Phones_O_DeliveryStatus){
        this.Phones_O_DeliveryStatus = Phones_O_DeliveryStatus;
    }
    public String getPhones_O_DeliveryStatus(){
        return this.Phones_O_DeliveryStatus;
    }
    public void setPhones_O_ContactPointId(String Phones_O_ContactPointId){
        this.Phones_O_ContactPointId = Phones_O_ContactPointId;
    }
    public String getPhones_O_ContactPointId(){
        return this.Phones_O_ContactPointId;
    }
    public void setPhones_O_OriginalContactPoint_ContactPointId(String Phones_O_OriginalContactPoint_ContactPointId){
        this.Phones_O_OriginalContactPoint_ContactPointId = Phones_O_OriginalContactPoint_ContactPointId;
    }
    public String getPhones_O_OriginalContactPoint_ContactPointId(){
        return this.Phones_O_OriginalContactPoint_ContactPointId;
    }
    public void setPhones_O_OriginalContactPoint_ActiveContactPointId(String Phones_O_OriginalContactPoint_ActiveContactPointId){
        this.Phones_O_OriginalContactPoint_ActiveContactPointId = Phones_O_OriginalContactPoint_ActiveContactPointId;
    }
    public String getPhones_O_OriginalContactPoint_ActiveContactPointId(){
        return this.Phones_O_OriginalContactPoint_ActiveContactPointId;
    }
    public void setPhones_O_OriginalContactPoint_ContactPointTypeCode(String Phones_O_OriginalContactPoint_ContactPointTypeCode){
        this.Phones_O_OriginalContactPoint_ContactPointTypeCode = Phones_O_OriginalContactPoint_ContactPointTypeCode;
    }
    public String getPhones_O_OriginalContactPoint_ContactPointTypeCode(){
        return this.Phones_O_OriginalContactPoint_ContactPointTypeCode;
    }
    public void setPhones_O_OriginalContactPoint_ContactPointStatusCode(String Phones_O_OriginalContactPoint_ContactPointStatusCode){
        this.Phones_O_OriginalContactPoint_ContactPointStatusCode = Phones_O_OriginalContactPoint_ContactPointStatusCode;
    }
    public String getPhones_O_OriginalContactPoint_ContactPointStatusCode(){
        return this.Phones_O_OriginalContactPoint_ContactPointStatusCode;
    }
    public void setPhones_O_OriginalContactPoint_ContactPointValue(String Phones_O_OriginalContactPoint_ContactPointValue){
        this.Phones_O_OriginalContactPoint_ContactPointValue = Phones_O_OriginalContactPoint_ContactPointValue;
    }
    public String getPhones_O_OriginalContactPoint_ContactPointValue(){
        return this.Phones_O_OriginalContactPoint_ContactPointValue;
    }
    public void setPhones_O_OriginalContactPoint_ValidFlag(String Phones_O_OriginalContactPoint_ValidFlag){
        this.Phones_O_OriginalContactPoint_ValidFlag = Phones_O_OriginalContactPoint_ValidFlag;
    }
    public String getPhones_O_OriginalContactPoint_ValidFlag(){
        return this.Phones_O_OriginalContactPoint_ValidFlag;
    }
    public void setPhones_O_OriginalContactPoint_CorrectedFlag(String Phones_O_OriginalContactPoint_CorrectedFlag){
        this.Phones_O_OriginalContactPoint_CorrectedFlag = Phones_O_OriginalContactPoint_CorrectedFlag;
    }
    public String getPhones_O_OriginalContactPoint_CorrectedFlag(){
        return this.Phones_O_OriginalContactPoint_CorrectedFlag;
    }
    public void setPhones_O_OriginalContactPoint_UndeliverableFlag(String Phones_O_OriginalContactPoint_UndeliverableFlag){
        this.Phones_O_OriginalContactPoint_UndeliverableFlag = Phones_O_OriginalContactPoint_UndeliverableFlag;
    }
    public String getPhones_O_OriginalContactPoint_UndeliverableFlag(){
        return this.Phones_O_OriginalContactPoint_UndeliverableFlag;
    }
    public void setPhones_O_OriginalContactPoint_ContactPointSequenceNumber(int Phones_O_OriginalContactPoint_ContactPointSequenceNumber){
        this.Phones_O_OriginalContactPoint_ContactPointSequenceNumber = Phones_O_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public int getPhones_O_OriginalContactPoint_ContactPointSequenceNumber(){
        return this.Phones_O_OriginalContactPoint_ContactPointSequenceNumber;
    }
    public void setPhones_O_OriginalContactPoint_Status(String Phones_O_OriginalContactPoint_Status){
        this.Phones_O_OriginalContactPoint_Status = Phones_O_OriginalContactPoint_Status;
    }
    public String getPhones_O_OriginalContactPoint_Status(){
        return this.Phones_O_OriginalContactPoint_Status;
    }
    public void setPhones_O_OriginalContactPoint_CreateUser(String Phones_O_OriginalContactPoint_CreateUser){
        this.Phones_O_OriginalContactPoint_CreateUser = Phones_O_OriginalContactPoint_CreateUser;
    }
    public String getPhones_O_OriginalContactPoint_CreateUser(){
        return this.Phones_O_OriginalContactPoint_CreateUser;
    }
    public void setPhones_O_OriginalContactPoint_CreateDate(String Phones_O_OriginalContactPoint_CreateDate){
        this.Phones_O_OriginalContactPoint_CreateDate = Phones_O_OriginalContactPoint_CreateDate;
    }
    public String getPhones_O_OriginalContactPoint_CreateDate(){
        return this.Phones_O_OriginalContactPoint_CreateDate;
    }
    public void setPhones_O_OriginalContactPoint_UpdateUser(String Phones_O_OriginalContactPoint_UpdateUser){
        this.Phones_O_OriginalContactPoint_UpdateUser = Phones_O_OriginalContactPoint_UpdateUser;
    }
    public String getPhones_O_OriginalContactPoint_UpdateUser(){
        return this.Phones_O_OriginalContactPoint_UpdateUser;
    }
    public void setPhones_O_OriginalContactPoint_UpdateDate(String Phones_O_OriginalContactPoint_UpdateDate){
        this.Phones_O_OriginalContactPoint_UpdateDate = Phones_O_OriginalContactPoint_UpdateDate;
    }
    public String getPhones_O_OriginalContactPoint_UpdateDate(){
        return this.Phones_O_OriginalContactPoint_UpdateDate;
    }
    public void setPhones_O_Status(String Phones_O_Status){
        this.Phones_O_Status = Phones_O_Status;
    }
    public String getPhones_O_Status(){
        return this.Phones_O_Status;
    }
    public void setSocialAccounts_0_SocialAccountId(String SocialAccounts_0_SocialAccountId){
        this.SocialAccounts_0_SocialAccountId = SocialAccounts_0_SocialAccountId;
    }
    public String getSocialAccounts_0_SocialAccountId(){
        return this.SocialAccounts_0_SocialAccountId;
    }
    public void setSocialAccounts_0_SocialAccountType(String SocialAccounts_0_SocialAccountType){
        this.SocialAccounts_0_SocialAccountType = SocialAccounts_0_SocialAccountType;
    }
    public String getSocialAccounts_0_SocialAccountType(){
        return this.SocialAccounts_0_SocialAccountType;
    }
    public void setSocialAccounts_0_SocialToken(String SocialAccounts_0_SocialToken){
        this.SocialAccounts_0_SocialToken = SocialAccounts_0_SocialToken;
    }
    public String getSocialAccounts_0_SocialToken(){
        return this.SocialAccounts_0_SocialToken;
    }
    public void setSocialAccounts_1_SocialAccountId(String SocialAccounts_1_SocialAccountId){
        this.SocialAccounts_1_SocialAccountId = SocialAccounts_1_SocialAccountId;
    }
    public String getSocialAccounts_1_SocialAccountId(){
        return this.SocialAccounts_1_SocialAccountId;
    }
    public void setSocialAccounts_1_SocialAccountType(String SocialAccounts_1_SocialAccountType){
        this.SocialAccounts_1_SocialAccountType = SocialAccounts_1_SocialAccountType;
    }
    public String getSocialAccounts_1_SocialAccountType(){
        return this.SocialAccounts_1_SocialAccountType;
    }
    public void setSocialAccounts_1_SocialToken(String SocialAccounts_1_SocialToken){
        this.SocialAccounts_1_SocialToken = SocialAccounts_1_SocialToken;
    }
    public String getSocialAccounts_1_SocialToken(){
        return this.SocialAccounts_1_SocialToken;
    }
    public void setSocialNetworks_0_SocialNetworkCode(String SocialNetworks_0_SocialNetworkCode){
        this.SocialNetworks_0_SocialNetworkCode = SocialNetworks_0_SocialNetworkCode;
    }
    public String getSocialNetworks_0_SocialNetworkCode(){
        return this.SocialNetworks_0_SocialNetworkCode;
    }
    public void setSocialNetworks_0_SocialNetworkUserName(String SocialNetworks_0_SocialNetworkUserName){
        this.SocialNetworks_0_SocialNetworkUserName = SocialNetworks_0_SocialNetworkUserName;
    }
    public String getSocialNetworks_0_SocialNetworkUserName(){
        return this.SocialNetworks_0_SocialNetworkUserName;
    }
    public void setSocialNetworks_1_SocialNetworkCode(String SocialNetworks_1_SocialNetworkCode){
        this.SocialNetworks_1_SocialNetworkCode = SocialNetworks_1_SocialNetworkCode;
    }
    public String getSocialNetworks_1_SocialNetworkCode(){
        return this.SocialNetworks_1_SocialNetworkCode;
    }
    public void setSocialNetworks_1_SocialNetworkUserName(String SocialNetworks_1_SocialNetworkUserName){
        this.SocialNetworks_1_SocialNetworkUserName = SocialNetworks_1_SocialNetworkUserName;
    }
    public String getSocialNetworks_1_SocialNetworkUserName(){
        return this.SocialNetworks_1_SocialNetworkUserName;
    }
    public void setProgramCode(String ProgramCode){
        this.ProgramCode = ProgramCode;
    }
    public String getProgramCode(){
        return this.ProgramCode;
    }
    public void setSourceCode(String SourceCode){
        this.SourceCode = SourceCode;
    }
    public String getSourceCode(){
        return this.SourceCode;
    }
    public void setEnrollmentStatus(String EnrollmentStatus){
        this.EnrollmentStatus = EnrollmentStatus;
    }
    public String getEnrollmentStatus(){
        return this.EnrollmentStatus;
    }
    public void setJoinDate(Date date){
        this.JoinDate = date;
    }
    public Date getJoinDate(){
        return this.JoinDate;
    }
    public void setEnrollChannelCode(String EnrollChannelCode){
        this.EnrollChannelCode = EnrollChannelCode;
    }
    public String getEnrollChannelCode(){
        return this.EnrollChannelCode;
    }
    public void setTierCode(String TierCode){
        this.TierCode = TierCode;
    }
    public String getTierCode(){
        return this.TierCode;
    }
    public void setUsername(String Username){
        this.Username = Username;
    }
    public String getUsername(){
        return this.Username;
    }
    public void setCardNumber(String CardNumber){
        this.CardNumber = CardNumber;
    }
    public String getCardNumber(){
        return this.CardNumber;
    }
    public void setStatus(String Status){
        this.Status = Status;
    }
    public String getStatus(){
        return this.Status;
    }
    public void setTermsConditionsAcceptedInd(boolean TermsConditionsAcceptedInd){
        this.TermsConditionsAcceptedInd = TermsConditionsAcceptedInd;
    }
    public boolean getTermsConditionsAcceptedInd(){
        return this.TermsConditionsAcceptedInd;
    }
    public void setAccountSourceCode(String AccountSourceCode){
        this.AccountSourceCode = AccountSourceCode;
    }
    public String getAccountSourceCode(){
        return this.AccountSourceCode;
    }
    public void setSourceAccountNumber(String SourceAccountNumber){
        this.SourceAccountNumber = SourceAccountNumber;
    }
    public String getSourceAccountNumber(){
        return this.SourceAccountNumber;
    }
    public void setBrandOrgCode(String BrandOrgCode){
        this.BrandOrgCode = BrandOrgCode;
    }
    public String getBrandOrgCode(){
        return this.BrandOrgCode;
    }
    public void setActivityDate(Date date){
        this.ActivityDate = date;
    }
    public Date getActivityDate(){
        return this.ActivityDate;
    }
    public void setCreateFileId(long l){
        this.CreateFileId = l;
    }
    public long getCreateFileId(){
        return this.CreateFileId;
    }
    public void setCreateRecordNumber(long l){
        this.CreateRecordNumber = l;
    }
    public long getCreateRecordNumber(){
        return this.CreateRecordNumber;
    }
    public void setUpdateFileId(long l){
        this.UpdateFileId = l;
    }
    public long getUpdateFileId(){
        return this.UpdateFileId;
    }
    public void setUpdateRecordNumber(long l){
        this.UpdateRecordNumber = l;
    }
    public long getUpdateRecordNumber(){
        return this.UpdateRecordNumber;
    }
    public void setAutoRewardOptInInd(boolean AutoRewardOptInInd){
        this.AutoRewardOptInInd = AutoRewardOptInInd;
    }
    public boolean getAutoRewardOptInInd(){
        return this.AutoRewardOptInInd;
    }
    public void setGamerAlias(String GamerAlias){
        this.GamerAlias = GamerAlias;
    }
    public String getGamerAlias(){
        return this.GamerAlias;
    }
    public void setGamerAvatar(String GamerAvatar){
        this.GamerAvatar = GamerAvatar;
    }
    public String getGamerAvatar(){
        return this.GamerAvatar;
    }
    public void setIsTestProfile(boolean IsTestProfile){
        this.IsTestProfile = IsTestProfile;
    }
    public boolean getIsTestProfile(){
        return this.IsTestProfile;
    }
    public void setPostingKeys_0_PostingKeyId(String PostingKeys_0_PostingKeyId){
        this.PostingKeys_0_PostingKeyId = PostingKeys_0_PostingKeyId;
    }
    public String getPostingKeys_0_PostingKeyId(){
        return this.PostingKeys_0_PostingKeyId;
    }
    public void setPostingKeys_0_PostingKeyCode(String PostingKeys_0_PostingKeyCode){
        this.PostingKeys_0_PostingKeyCode = PostingKeys_0_PostingKeyCode;
    }
    public String getPostingKeys_0_PostingKeyCode(){
        return this.PostingKeys_0_PostingKeyCode;
    }
    public void setPostingKeys_0_PostingKeyValue(String PostingKeys_0_PostingKeyValue){
        this.PostingKeys_0_PostingKeyValue = PostingKeys_0_PostingKeyValue;
    }
    public String getPostingKeys_0_PostingKeyValue(){
        return this.PostingKeys_0_PostingKeyValue;
    }
    public void setPostingKeys_1_PostingKeyId(String PostingKeys_1_PostingKeyId){
        this.PostingKeys_1_PostingKeyId = PostingKeys_1_PostingKeyId;
    }
    public String getPostingKeys_1_PostingKeyId(){
        return this.PostingKeys_1_PostingKeyId;
    }
    public void setPostingKeys_1_PostingKeyCode(String PostingKeys_1_PostingKeyCode){
        this.PostingKeys_1_PostingKeyCode = PostingKeys_1_PostingKeyCode;
    }
    public String getPostingKeys_1_PostingKeyCode(){
        return this.PostingKeys_1_PostingKeyCode;
    }
    public void setPostingKeys_1_PostingKeyValue(String PostingKeys_1_PostingKeyValue){
        this.PostingKeys_1_PostingKeyValue = PostingKeys_1_PostingKeyValue;
    }
    public String getPostingKeys_1_PostingKeyValue(){
        return this.PostingKeys_1_PostingKeyValue;
    }
    public void setCreateUser(String CreateUser){
        this.CreateUser = CreateUser;
    }
    public String getCreateUser(){
        return this.CreateUser;
    }
    public void setCreateDate(Date date){
        this.CreateDate = date;
    }
    public Date getCreateDate(){
        return this.CreateDate;
    }
    public void setUpdateUser(String UpdateUser){
        this.UpdateUser = UpdateUser;
    }
    public String getUpdateUser(){
        return this.UpdateUser;
    }
    public void setUpdateDate(Date date){
        this.UpdateDate = date;
    }
    public Date getUpdateDate(){
        return this.UpdateDate;
    }
    public void setStatus_change_dt(String Status_change_dt){
        this.Status_change_dt = Status_change_dt;
    }
    public String getStatus_change_dt(){
        return this.Status_change_dt;
    }
    public void setPreferred_channel_cd(String preferred_channel_cd){
        this.preferred_channel_cd = preferred_channel_cd;
    }
    public String getPreferred_channel_cd(){
        return this.preferred_channel_cd;
    }
    public void setUnparsed_nm(String unparsed_nm){
        this.unparsed_nm = unparsed_nm;
    }
    public String getUnparsed_nm(){
        return this.unparsed_nm;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public String getTitle(){
        return this.title;
    }
    public void setOrig_dt(String orig_dt){
        this.orig_dt = orig_dt;
    }
    public String getOrig_dt(){
        return this.orig_dt;
    }
    public void setHardkey_1(String hardkey_1){
        this.hardkey_1 = hardkey_1;
    }
    public String getHardkey_1(){
        return this.hardkey_1;
    }
    public void setHardkey_2(String hardkey_2){
        this.hardkey_2 = hardkey_2;
    }
    public String getHardkey_2(){
        return this.hardkey_2;
    }
    public void setHardkey_3(String hardkey_3){
        this.hardkey_3 = hardkey_3;
    }
    public String getHardkey_3(){
        return this.hardkey_3;
    }
    public void setHardkey_4(String hardkey_4){
        this.hardkey_4 = hardkey_4;
    }
    public String getHardkey_4(){
        return this.hardkey_4;
    }
    public void setHardkey_5(String hardkey_5){
        this.hardkey_5 = hardkey_5;
    }
    public String getHardkey_5(){
        return this.hardkey_5;
    }
    public void setHardkey_6(String hardkey_6){
        this.hardkey_6 = hardkey_6;
    }
    public String getHardkey_6(){
        return this.hardkey_6;
    }
    public void setHardkey_7(String hardkey_7){
        this.hardkey_7 = hardkey_7;
    }
    public String getHardkey_7(){
        return this.hardkey_7;
    }
    public void setHardkey_8(String hardkey_8){
        this.hardkey_8 = hardkey_8;
    }
    public String getHardkey_8(){
        return this.hardkey_8;
    }
    public void setHardkey_9(String hardkey_9){
        this.hardkey_9 = hardkey_9;
    }
    public String getHardkey_9(){
        return this.hardkey_9;
    }
    public void setHardkey_10(String hardkey_10){
        this.hardkey_10 = hardkey_10;
    }
    public String getHardkey_10(){
        return this.hardkey_10;
    }
    public void setDo_not_promote_ind(String do_not_promote_ind){
        this.do_not_promote_ind = do_not_promote_ind;
    }
    public String getDo_not_promote_ind(){
        return this.do_not_promote_ind;
    }
    public void setDo_not_call_ind(String do_not_call_ind){
        this.do_not_call_ind = do_not_call_ind;
    }
    public String getDo_not_call_ind(){
        return this.do_not_call_ind;
    }
    public void setDo_not_mail_ind(String do_not_mail_ind){
        this.do_not_mail_ind = do_not_mail_ind;
    }
    public String getDo_not_mail_ind(){
        return this.do_not_mail_ind;
    }
    public void setDo_not_sms_ind(String do_not_sms_ind){
        this.do_not_sms_ind = do_not_sms_ind;
    }
    public String getDo_not_sms_ind(){
        return this.do_not_sms_ind;
    }
    public void setDo_not_email_ind(String do_not_email_ind){
        this.do_not_email_ind = do_not_email_ind;
    }
    public String getDo_not_email_ind(){
        return this.do_not_email_ind;
    }
    public void setDo_not_rent_ind(String do_not_rent_ind){
        this.do_not_rent_ind = do_not_rent_ind;
    }
    public String getDo_not_rent_ind(){
        return this.do_not_rent_ind;
    }
}
