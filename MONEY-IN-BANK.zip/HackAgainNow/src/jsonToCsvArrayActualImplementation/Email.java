package jsonToCsvArrayActualImplementation;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Email {

	@JsonProperty("ProfileId")
	private String ProfileId;
	
	@JsonProperty("EmailId")
	private String EmailId;
	
	@JsonProperty("EmailAddress")
	private String EmailAddress;
	
	@JsonProperty("SourceEmailAddress")
	private String SourceEmailAddress;
	
	@JsonProperty("ChannelCode")
	private String ChannelCode;
	
	@JsonProperty("LocationCode")
	private String LocationCode;
	
	@JsonProperty("IsPreferred")
	private boolean IsPreferred;
	
	@JsonProperty("DeliveryStatus")
	private String DeliveryStatus;
	
	@JsonProperty("AccountSourceCode")
	private String AccountSourceCode;
	
	@JsonProperty("SourceAccountNumber")
	private String SourceAccountNumber;
	
	@JsonProperty("BrandOrgCode")
	private String BrandOrgCode;
	
	@JsonProperty("ActivityDate")
	private Date ActivityDate;
	
	@JsonProperty("CreateFileId")
	private long CreateFileId;
	
	@JsonProperty("CreateRecordNumber")
	private long CreateRecordNumber;
	
	@JsonProperty("UpdateFileId")
	private long UpdateFileId;
	
	@JsonProperty("UpdateRecordNumber")
	private long UpdateRecordNumber;
	
	@JsonProperty("ContactPointId")
	private String ContactPointId;
	
	@JsonProperty("OriginalContactPoint")
	private OriginalContactPoint OriginalContactPoint;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("CreateUser")
	private String CreateUser;
	
	@JsonProperty("CreateDate")
	private Date CreateDate;
	
	@JsonProperty("UpdateUser")
	private String UpdateUser;
	
	@JsonProperty("UpdateDate")
	private Date UpdateDate;
	
	public String getProfileId() {
		return ProfileId;
	}
	public void setProfileId(String profileId) {
		ProfileId = profileId;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public String getEmailAddress() {
		return EmailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}
	public String getSourceEmailAddress() {
		return SourceEmailAddress;
	}
	public void setSourceEmailAddress(String sourceEmailAddress) {
		SourceEmailAddress = sourceEmailAddress;
	}
	public String getChannelCode() {
		return ChannelCode;
	}
	public void setChannelCode(String channelCode) {
		ChannelCode = channelCode;
	}
	public String getLocationCode() {
		return LocationCode;
	}
	public void setLocationCode(String locationCode) {
		LocationCode = locationCode;
	}

	public boolean isIsPreferred() {
		return IsPreferred;
	}
	public void setIsPreferred(boolean isPreferred) {
		IsPreferred = isPreferred;
	}
	public String getDeliveryStatus() {
		return DeliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		DeliveryStatus = deliveryStatus;
	}
	public String getAccountSourceCode() {
		return AccountSourceCode;
	}
	public void setAccountSourceCode(String accountSourceCode) {
		AccountSourceCode = accountSourceCode;
	}
	public String getSourceAccountNumber() {
		return SourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		SourceAccountNumber = sourceAccountNumber;
	}
	public String getBrandOrgCode() {
		return BrandOrgCode;
	}
	public void setBrandOrgCode(String brandOrgCode) {
		BrandOrgCode = brandOrgCode;
	}
	public Date getActivityDate() {
		return ActivityDate;
	}
	public void setActivityDate(Date activityDate) {
		ActivityDate = activityDate;
	}
	public long getCreateFileId() {
		return CreateFileId;
	}
	public void setCreateFileId(long createFileId) {
		CreateFileId = createFileId;
	}
	public long getCreateRecordNumber() {
		return CreateRecordNumber;
	}
	public void setCreateRecordNumber(long createRecordNumber) {
		CreateRecordNumber = createRecordNumber;
	}
	public long getUpdateFileId() {
		return UpdateFileId;
	}
	public void setUpdateFileId(long updateFileId) {
		UpdateFileId = updateFileId;
	}
	public long getUpdateRecordNumber() {
		return UpdateRecordNumber;
	}
	public void setUpdateRecordNumber(long updateRecordNumber) {
		UpdateRecordNumber = updateRecordNumber;
	}
	public String getContactPointId() {
		return ContactPointId;
	}
	public void setContactPointId(String contactPointId) {
		ContactPointId = contactPointId;
	}
	public OriginalContactPoint getOriginalContactPoint() {
		return OriginalContactPoint;
	}
	public void setOriginalContactPoint(OriginalContactPoint originalContactPoint) {
		OriginalContactPoint = originalContactPoint;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getCreateUser() {
		return CreateUser;
	}
	public void setCreateUser(String createUser) {
		CreateUser = createUser;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public String getUpdateUser() {
		return UpdateUser;
	}
	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}
	public Date getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}
	
	
	
}
