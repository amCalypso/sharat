package jsonToCsvArrayActualImplementation;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MappingToCSVDemoRun {

	public static void main(String[] args) {
		MappingToCSVDemoRun obj = new MappingToCSVDemoRun();
		obj.run();
	}

	void run() {
		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonInString = "{\n\t\"ProfileId\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\"ClientAccountId\": \"\",\n\t\"Prefix\": \"\",\n\t\"SourcePrefix\": \"\",\n\t\"FirstName\": \"Mohit123\",\n\t\"SourceFirstName\": \"Mohit123\",\n\t\"MiddleInit\": \"G\",\n\t\"SourceMiddleInit\": \"G\",\n\t\"LastName\": \"Doe\",\n\t\"SourceLastName\": \"Doe\",\n\t\"Suffix\": \"\",\n\t\"SourceSuffix\": \"\",\n\t\"GlobalOptOut\": false,\n\t\"GlobalOptDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\"GlobalOptSource\": \"\",\n\t\"LanguageCode\": \"EN\",\n\t\"MaritalStatus\": \"S\",\n\t\"Gender\": \"M\",\n\t\"SourceGender\": \"M\",\n\t\"BirthDate\": \"1989\",\n\t\"CompanyName\": \"Epsilon\",\n\t\"Addresses\": [{\n\t\t\"ProfileId\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"AddressId\": \"1d1c6db2-302c-4366-8982-43f8ae4a6508\",\n\t\t\"AddressLine1\": \"123 THE RD\",\n\t\t\"SourceAddressLine1\": \"123 THE RD\",\n\t\t\"AddressLine2\": \"#3333\",\n\t\t\"SourceAddressLine2\": \"#3333\",\n\t\t\"AddressLine3\": \"\",\n\t\t\"SourceAddressLine3\": \"\",\n\t\t\"City\": \"IRVING\",\n\t\t\"SourceCity\": \"IRVING\",\n\t\t\"StateCode\": \"TX\",\n\t\t\"SourceStateCode\": \"TX\",\n\t\t\"CountryCode\": \"USA\",\n\t\t\"SourceCountryCode\": \"USA\",\n\t\t\"PostalCode\": \"75080\",\n\t\t\"SourcePostalCode\": \"75080\",\n\t\t\"ChannelCode\": \"DM\",\n\t\t\"LocationCode\": \"H\",\n\t\t\"IsPreferred\": true,\n\t\t\"DeliveryStatus\": \"G\",\n\t\t\"DoNotStandardize\": false,\n\t\t\"AccountSourceCode\": \"ALMACCT\",\n\t\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\t\"CreateFileId\": 987654321,\n\t\t\"CreateRecordNumber\": 987654322,\n\t\t\"UpdateFileId\": 987654323,\n\t\t\"UpdateRecordNumber\": 987654324,\n\t\t\"Status\": \"A\",\n\t\t\"CreateUser\": \"JWOOTEN\",\n\t\t\"CreateDate\": \"2017-11-17T13:00:16.588288Z\",\n\t\t\"UpdateUser\": \"JWOOTEN\",\n\t\t\"UpdateDate\": \"2017-11-17T13:00:16.588288Z\"\n\t}],\n\t\"Emails\": [{\n\t\t\"ProfileId\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"EmailId\": \"07dc10e5-ae7b-49af-8d3a-b96d04056b99\",\n\t\t\"EmailAddress\": \"pmagruder@epsilon.com\",\n\t\t\"SourceEmailAddress\": \"pmagruder@epsilon.com\",\n\t\t\"ChannelCode\": \"EM\",\n\t\t\"LocationCode\": \"B\",\n\t\t\"IsPreferred\": true,\n\t\t\"DeliveryStatus\": \"G\",\n\t\t\"AccountSourceCode\": \"ALMACCT\",\n\t\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\t\"CreateFileId\": 987654321,\n\t\t\"CreateRecordNumber\": 987654322,\n\t\t\"UpdateFileId\": 987654323,\n\t\t\"UpdateRecordNumber\": 987654324,\n\t\t\"ContactPointId\": \"55b11931-fcfd-4b3d-8d72-c9953c6a8c02\",\n\t\t\"OriginalContactPoint\": {\n\t\t\t\"ContactPointId\": \"55b11931-fcfd-4b3d-8d72-c9953c6a8c02\",\n\t\t\t\"ActiveContactPointId\": \"55b11931-fcfd-4b3d-8d72-c9953c6a8c02\",\n\t\t\t\"ContactPointTypeCode\": \"EM\",\n\t\t\t\"ContactPointStatusCode\": \"A\",\n\t\t\t\"ContactPointValue\": \"pmagruder@epsilon.com\",\n\t\t\t\"ValidFlag\": \"Y\",\n\t\t\t\"CorrectedFlag\": \"N\",\n\t\t\t\"UndeliverableFlag\": \"N\",\n\t\t\t\"EmailDomain\": \"epsilon.com\",\n\t\t\t\"ContactPointSequenceNumber\": 43,\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\n\t\t\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\t\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\t\t\"CreateFileId\": 987654321,\n\t\t\t\"CreateRecordNumber\": 987654322,\n\t\t\t\"UpdateFileId\": 987654323,\n\t\t\t\"UpdateRecordNumber\": 987654324,\n\t\t\t\"Status\": \"A\",\n\t\t\t\"CreateUser\": \"CFROSONI\",\n\t\t\t\"CreateDate\": \"2017-08-28T17:03:08.395604Z\",\n\t\t\t\"UpdateUser\": \"CFROSONI\",\n\t\t\t\"UpdateDate\": \"2017-08-28T17:03:08.395604Z\"\n\t\t},\n\t\t\"Status\": \"A\",\n\t\t\"CreateUser\": \"JWOOTEN\",\n\t\t\"CreateDate\": \"2017-11-17T13:00:16.450286Z\",\n\t\t\"UpdateUser\": \"JWOOTEN\",\n\t\t\"UpdateDate\": \"2017-11-17T13:00:16.450286Z\"\n\t}],\n\t\"Phones\": [{\n\t\t\"ProfileId\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"PhoneId\": \"b69010d3-1d82-4ef1-a0f8-1141e5cbb01e\",\n\t\t\"PhoneNumber\": \"1232343456\",\n\t\t\"SourcePhoneNumber\": \"1232343456\",\n\t\t\"PhoneCountryCode\": \"USA\",\n\t\t\"AcceptsText\": true,\n\t\t\"Frequency\": 7,\n\t\t\"NeverBefore\": \"0001-01-01T08:00:00.000000Z\",\n\t\t\"NeverAfter\": \"0001-01-01T23:00:00.000000Z\",\n\t\t\"ChannelCode\": \"SM\",\n\t\t\"LocationCode\": \"H\",\n\t\t\"IsPreferred\": true,\n\t\t\"DeliveryStatus\": \"G\",\n\t\t\"AccountSourceCode\": \"ALMACCT\",\n\t\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\t\"CreateFileId\": 987654321,\n\t\t\"CreateRecordNumber\": 987654322,\n\t\t\"UpdateFileId\": 987654323,\n\t\t\"UpdateRecordNumber\": 987654324,\n\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\n\t\t\"OriginalContactPoint\": {\n\t\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\n\t\t\t\"ActiveContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\n\t\t\t\"ContactPointTypeCode\": \"PH\",\n\t\t\t\"ContactPointStatusCode\": \"A\",\n\t\t\t\"ContactPointValue\": \"1232343456\",\n\t\t\t\"ValidFlag\": \"Y\",\n\t\t\t\"CorrectedFlag\": \"N\",\n\t\t\t\"UndeliverableFlag\": \"N\",\n\t\t\t\"ContactPointSequenceNumber\": 41,\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\n\t\t\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\t\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\t\t\"CreateFileId\": 987654321,\n\t\t\t\"CreateRecordNumber\": 987654322,\n\t\t\t\"UpdateFileId\": 987654323,\n\t\t\t\"UpdateRecordNumber\": 987654324,\n\t\t\t\"Status\": \"A\",\n\t\t\t\"CreateUser\": \"CFROSONI\",\n\t\t\t\"CreateDate\": \"2017-08-24T18:05:44.033089Z\",\n\t\t\t\"UpdateUser\": \"CFROSONI\",\n\t\t\t\"UpdateDate\": \"2017-08-24T18:05:44.033089Z\"\n\t\t},\n\t\t\"Status\": \"A\",\n\t\t\"CreateUser\": \"JWOOTEN\",\n\t\t\"CreateDate\": \"2017-11-17T13:00:16.450286Z\",\n\t\t\"UpdateUser\": \"JWOOTEN\",\n\t\t\"UpdateDate\": \"2017-11-17T13:00:16.450286Z\"\n\t}],\n\t\"SocialNetworks\": [\n{\n\"SocialNetworkCode\":\"TWITTER\",\n\"SocialNetworkUserName\": \"MyPersonalUser\"\n    }\n  ],\n\t\"SocialAccounts\": [\n    {\n      \"SocialAccountId\": \"g61EKR_DtB\",\n      \"SocialAccountType\": \"Facebook\",\n      \"SocialToken\": \"abcde12345\"\n    }\n  ],\n\t\"ProgramCode\": \"FR\",\n\t\"SourceCode\": \"FR_WEB\",\n\t\"EnrollmentStatus\": \"A\",\n\t\"JoinDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\"EnrollChannelCode\": \"WEB\",\n\t\"TierCode\": \"FR-BRONZE\",\n\t\"Username\": \"SAMAPIUSER123\",\n\t\"CardNumber\": \"76534353535\",\n\t\"Status\": \"A\",\n\t\"TermsConditionsAcceptedInd\": false,\n\t\"AccountSourceCode\": \"ALMACCT\",\n\t\"SourceAccountNumber\": \"6669a8c6-4444-4064-927a-c00a9eb9a45f\",\n\t\"BrandOrgCode\": \"ALM_BRAND\",\n\t\"ActivityDate\": \"2017-11-17T10:24:22.145020Z\",\n\t\"CreateFileId\": 987654321,\n\t\"CreateRecordNumber\": 987654322,\n\t\"UpdateFileId\": 987654323,\n\t\"UpdateRecordNumber\": 987654324,\n\t\"AutoRewardOptInInd\": true,\n\t\"GamerAlias\": \"JD12\",\n\t\"GamerAvatar\": \"john.png\",\n\t\"IsTestProfile\": false,\n\t\"PostingKeys\": [],\n\t\"CreateUser\": \"JWOOTEN\",\n\t\"CreateDate\": \"2017-11-17T13:00:16.450286Z\",\n\t\"UpdateUser\": \"JWOOTEN\",\n\t\"UpdateDate\": \"2017-11-17T13:00:16.450286Z\"\n}";
			
			AddProfileResponse profile = mapper.readValue(jsonInString, AddProfileResponse.class);

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	


}