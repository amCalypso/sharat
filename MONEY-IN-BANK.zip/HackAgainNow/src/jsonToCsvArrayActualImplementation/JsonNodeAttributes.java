package jsonToCsvArrayActualImplementation;

public class JsonNodeAttributes {
	
	private String csv_header;
	private String from_json_node;
	
	public String getCsv_header() {
		return csv_header;
	}
	public void setCsv_header(String csv_header) {
		this.csv_header = csv_header;
	}
	public String getFrom_json_node() {
		return from_json_node;
	}
	public void setFrom_json_node(String from_json_node) {
		this.from_json_node = from_json_node;
	}
	@Override
	public String toString() {
		return "csv_header=" + csv_header + ", from_json_node=" + from_json_node + " ";
	}
}
