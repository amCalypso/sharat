package jsonToCsvArrayActualImplementation;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OriginalContactPoint {

	
	@JsonProperty("ContactPointId")
	private String ContactPointId;
	
	@JsonProperty("ActiveContactPointId")
	private String ActiveContactPointId;
	
	@JsonProperty("ContactPointTypeCode")
	private String ContactPointTypeCode;
	
	@JsonProperty("ContactPointStatusCode")
	private String ContactPointStatusCode;
	
	@JsonProperty("ContactPointValue")
	private String ContactPointValue;
	
	@JsonProperty("ValidFlag")
	private String ValidFlag;
	
	@JsonProperty("CorrectedFlag")
	private String CorrectedFlag;
	
	@JsonProperty("UndeliverableFlag")
	private String UndeliverableFlag;
	
	@JsonProperty("EmailDomain")
	private String EmailDomain;
	
	@JsonProperty("ContactPointSequenceNumber")
	private String ContactPointSequenceNumber;
	
	@JsonProperty("AccountSourceCode")
	private String AccountSourceCode;
	
	@JsonProperty("SourceAccountNumber")
	private String SourceAccountNumber;
	
	@JsonProperty("BrandOrgCode")
	private String BrandOrgCode;
	
	@JsonProperty("ActivityDate")
	private Date ActivityDate;
	
	@JsonProperty("CreateFileId")
	private long CreateFileId;
	
	@JsonProperty("CreateRecordNumber")
	private long CreateRecordNumber;
	
	@JsonProperty("UpdateFileId")
	private long UpdateFileId;
	
	@JsonProperty("UpdateRecordNumber")
	private long UpdateRecordNumber;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("CreateUser")
	private String CreateUser;
	
	@JsonProperty("CreateDate")
	private Date CreateDate;
	
	@JsonProperty("UpdateUser")
	private String UpdateUser;
	
	@JsonProperty("UpdateDate")
	private Date UpdateDate;
	
	public String getContactPointId() {
		return ContactPointId;
	}
	public void setContactPointId(String contactPointId) {
		ContactPointId = contactPointId;
	}
	public String getActiveContactPointId() {
		return ActiveContactPointId;
	}
	public void setActiveContactPointId(String activeContactPointId) {
		ActiveContactPointId = activeContactPointId;
	}
	public String getContactPointTypeCode() {
		return ContactPointTypeCode;
	}
	public void setContactPointTypeCode(String contactPointTypeCode) {
		ContactPointTypeCode = contactPointTypeCode;
	}
	public String getContactPointStatusCode() {
		return ContactPointStatusCode;
	}
	public void setContactPointStatusCode(String contactPointStatusCode) {
		ContactPointStatusCode = contactPointStatusCode;
	}
	public String getContactPointValue() {
		return ContactPointValue;
	}
	public void setContactPointValue(String contactPointValue) {
		ContactPointValue = contactPointValue;
	}
	public String getValidFlag() {
		return ValidFlag;
	}
	public void setValidFlag(String validFlag) {
		ValidFlag = validFlag;
	}
	public String getCorrectedFlag() {
		return CorrectedFlag;
	}
	public void setCorrectedFlag(String correctedFlag) {
		CorrectedFlag = correctedFlag;
	}
	public String getUndeliverableFlag() {
		return UndeliverableFlag;
	}
	public void setUndeliverableFlag(String undeliverableFlag) {
		UndeliverableFlag = undeliverableFlag;
	}
	public String getEmailDomain() {
		return EmailDomain;
	}
	public void setEmailDomain(String emailDomain) {
		EmailDomain = emailDomain;
	}
	public String getContactPointSequenceNumber() {
		return ContactPointSequenceNumber;
	}
	public void setContactPointSequenceNumber(String contactPointSequenceNumber) {
		ContactPointSequenceNumber = contactPointSequenceNumber;
	}
	public String getAccountSourceCode() {
		return AccountSourceCode;
	}
	public void setAccountSourceCode(String accountSourceCode) {
		AccountSourceCode = accountSourceCode;
	}
	public String getSourceAccountNumber() {
		return SourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		SourceAccountNumber = sourceAccountNumber;
	}
	public String getBrandOrgCode() {
		return BrandOrgCode;
	}
	public void setBrandOrgCode(String brandOrgCode) {
		BrandOrgCode = brandOrgCode;
	}
	public Date getActivityDate() {
		return ActivityDate;
	}
	public void setActivityDate(Date activityDate) {
		ActivityDate = activityDate;
	}
	public long getCreateFileId() {
		return CreateFileId;
	}
	public void setCreateFileId(long createFileId) {
		CreateFileId = createFileId;
	}
	public long getCreateRecordNumber() {
		return CreateRecordNumber;
	}
	public void setCreateRecordNumber(long createRecordNumber) {
		CreateRecordNumber = createRecordNumber;
	}
	public long getUpdateFileId() {
		return UpdateFileId;
	}
	public void setUpdateFileId(long updateFileId) {
		UpdateFileId = updateFileId;
	}
	public long getUpdateRecordNumber() {
		return UpdateRecordNumber;
	}
	public void setUpdateRecordNumber(long updateRecordNumber) {
		UpdateRecordNumber = updateRecordNumber;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getCreateUser() {
		return CreateUser;
	}
	public void setCreateUser(String createUser) {
		CreateUser = createUser;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public String getUpdateUser() {
		return UpdateUser;
	}
	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}
	public Date getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}
	
	

	
	
	
	
}
