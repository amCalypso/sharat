package jsonToCsvArrayActualImplementation;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonTocCsvMapFinal {

	public static void main(String[] args) {
		JsonTocCsvMapFinal obj = new JsonTocCsvMapFinal();
		
		System.out.println("hi");
		obj.run();
	}

	private void run() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonInString = "{\r\n\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\"ClientAccountId\": \"\",\r\n\t\"Prefix\": \"\",\r\n\t\"SourcePrefix\": \"\",\r\n\t\"FirstName\": \"Angie\",\r\n\t\"SourceFirstName\": \"Angie\",\r\n\t\"MiddleInit\": \"\",\r\n\t\"SourceMiddleInit\": \"\",\r\n\t\"LastName\": \"Potter\",\r\n\t\"SourceLastName\": \"Potter\",\r\n\t\"Suffix\": \"\",\r\n\t\"SourceSuffix\": \"\",\r\n\t\"GlobalOptOut\": false,\r\n\t\"GlobalOptDate\": \"2017-10-26T13:29:25.501684Z\",\r\n\t\"GlobalOptSource\": \"\",\r\n\t\"LanguageCode\": \"EN\",\r\n\t\"MaritalStatus\": \"S\",\r\n\t\"Gender\": \"M\",\r\n\t\"SourceGender\": \"M\",\r\n\t\"BirthDate\": \"1989-06-05T00:00:00.000000Z\",\r\n\t\"CompanyName\": \"Epsilon\",\r\n\t\"Addresses\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"AddressId\": \"ea2d8fee-3521-4028-ad82-87e37dd4d694\",\r\n\t\t\t\"AddressLine1\": \"123 THE RD\",\r\n\t\t\t\"SourceAddressLine1\": \"123 THE RD\",\r\n\t\t\t\"AddressLine2\": \"#3333\",\r\n\t\t\t\"SourceAddressLine2\": \"#3333\",\r\n\t\t\t\"AddressLine3\": \"\",\r\n\t\t\t\"SourceAddressLine3\": \"\",\r\n\t\t\t\"City\": \"IRVING\",\r\n\t\t\t\"SourceCity\": \"IRVING\",\r\n\t\t\t\"StateCode\": \"TX\",\r\n\t\t\t\"SourceStateCode\": \"TX\",\r\n\t\t\t\"CountryCode\": \"USA\",\r\n\t\t\t\"SourceCountryCode\": \"USA\",\r\n\t\t\t\"PostalCode\": \"75080\",\r\n\t\t\t\"SourcePostalCode\": \"75080\",\r\n\t\t\t\"ChannelCode\": \"DM\",\r\n\t\t\t\"LocationCode\": \"H\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"DoNotStandardize\": false,\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.907201Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.907201Z\"\r\n\t\t}\r\n\t],\r\n\t\"Emails\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"EmailId\": \"53720199-f3db-461a-bf4d-9dabde29f4a4\",\r\n\t\t\t\"EmailAddress\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\"SourceEmailAddress\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\"ChannelCode\": \"EM\",\r\n\t\t\t\"LocationCode\": \"B\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"ContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\"OriginalContactPoint\": {\r\n\t\t\t\t\"ContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\t\"ActiveContactPointId\": \"09026c91-2d05-4170-9bec-8c6d73a4391a\",\r\n\t\t\t\t\"ContactPointTypeCode\": \"EM\",\r\n\t\t\t\t\"ContactPointStatusCode\": \"A\",\r\n\t\t\t\t\"ContactPointValue\": \"carlee.frosoni@epsilon.com\",\r\n\t\t\t\t\"ValidFlag\": \"Y\",\r\n\t\t\t\t\"CorrectedFlag\": \"N\",\r\n\t\t\t\t\"UndeliverableFlag\": \"N\",\r\n\t\t\t\t\"EmailDomain\": \"epsilon.com\",\r\n\t\t\t\t\"ContactPointSequenceNumber\": 42,\r\n\t\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\t\"Status\": \"A\",\r\n\t\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\t\"CreateDate\": \"2017-08-24T18:05:44.029089Z\",\r\n\t\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\t\"UpdateDate\": \"2017-08-24T18:05:44.029089Z\"\r\n\t\t\t},\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n\t\t}\r\n\t],\r\n\t\"Phones\": [\r\n\t\t{\r\n\t\t\t\"ProfileId\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"PhoneId\": \"36fb45ba-2ac1-4577-b5b2-9b8c463ec863\",\r\n\t\t\t\"PhoneNumber\": \"1232343456\",\r\n\t\t\t\"SourcePhoneNumber\": \"1232343456\",\r\n\t\t\t\"PhoneCountryCode\": \"USA\",\r\n\t\t\t\"AcceptsText\": true,\r\n\t\t\t\"Frequency\": 7,\r\n\t\t\t\"NeverBefore\": \"0001-01-01T08:00:00.000000Z\",\r\n\t\t\t\"NeverAfter\": \"0001-01-01T23:00:00.000000Z\",\r\n\t\t\t\"ChannelCode\": \"SM\",\r\n\t\t\t\"LocationCode\": \"H\",\r\n\t\t\t\"IsPreferred\": true,\r\n\t\t\t\"DeliveryStatus\": \"G\",\r\n\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\"OriginalContactPoint\": {\r\n\t\t\t\t\"ContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\t\"ActiveContactPointId\": \"0cd32946-63a0-4416-92d5-d1272aca87f1\",\r\n\t\t\t\t\"ContactPointTypeCode\": \"PH\",\r\n\t\t\t\t\"ContactPointStatusCode\": \"A\",\r\n\t\t\t\t\"ContactPointValue\": \"1232343456\",\r\n\t\t\t\t\"ValidFlag\": \"Y\",\r\n\t\t\t\t\"CorrectedFlag\": \"N\",\r\n\t\t\t\t\"UndeliverableFlag\": \"N\",\r\n\t\t\t\t\"ContactPointSequenceNumber\": 41,\r\n\t\t\t\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\t\t\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\t\t\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\t\t\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\t\t\t\"CreateFileId\": 987654321,\r\n\t\t\t\t\"CreateRecordNumber\": 987654322,\r\n\t\t\t\t\"UpdateFileId\": 987654323,\r\n\t\t\t\t\"UpdateRecordNumber\": 987654324,\r\n\t\t\t\t\"Status\": \"A\",\r\n\t\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\t\"CreateDate\": \"2017-08-24T18:05:44.033089Z\",\r\n\t\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\t\"UpdateDate\": \"2017-08-24T18:05:44.033089Z\"\r\n\t\t\t},\r\n\t\t\t\"Status\": \"A\",\r\n\t\t\t\"CreateUser\": \"CFROSONI\",\r\n\t\t\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\t\t\"UpdateUser\": \"CFROSONI\",\r\n\t\t\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n\t\t}\r\n\t],\r\n\t\"SocialNetworks\": [],\r\n\t\"SocialAccounts\": [],\r\n\t\"ProgramCode\": \"PP\",\r\n\t\"SourceCode\": \"PP_CALL_IN\",\r\n\t\"EnrollmentStatus\": \"A\",\r\n\t\"JoinDate\": \"2017-10-26T13:29:25.501684Z\",\r\n\t\"EnrollChannelCode\": \"WEB\",\r\n\t\"TierCode\": \"BARN\",\r\n\t\"Username\": \"ANGIEPOTTER\",\r\n\t\"CardNumber\": \"456\",\r\n\t\"Status\": \"A\",\r\n\t\"TermsConditionsAcceptedInd\": false,\r\n\t\"AccountSourceCode\": \"ALMACCT\",\r\n\t\"SourceAccountNumber\": \"49a32c8a-e086-4127-b354-31d98e7b52dc\",\r\n\t\"BrandOrgCode\": \"ALM_BRAND\",\r\n\t\"ActivityDate\": \"2017-10-26T13:29:25.495704Z\",\r\n\t\"CreateFileId\": 987654321,\r\n\t\"CreateRecordNumber\": 987654322,\r\n\t\"UpdateFileId\": 987654323,\r\n\t\"UpdateRecordNumber\": 987654324,\r\n\t\"AutoRewardOptInInd\": true,\r\n\t\"GamerAlias\": \"AP\",\r\n\t\"GamerAvatar\": \"angie.png\",\r\n\t\"IsTestProfile\": false,\r\n\t\"PostingKeys\": [],\r\n\t\"CreateUser\": \"CFROSONI\",\r\n\t\"CreateDate\": \"2017-10-26T20:01:16.826152Z\",\r\n\t\"UpdateUser\": \"CFROSONI\",\r\n\t\"UpdateDate\": \"2017-10-26T20:01:16.826152Z\"\r\n}";
			//String  JSON_SOURCE= "{\n  \"1\": {\n    \"csv_header\": \"brand_cd\",\n    \"from_json_node\": \"Addresses[0].BrandOrgCode\"\n  },\n  \"2\": {\n    \"csv_header\": \"acct_src_cd\",\n    \"from_json_node\": \"AccountSourceCode\"\n  },\n  \"3\": {\n    \"csv_header\": \"acct_src_nbr\",\n    \"from_json_node\": \"SourceAccountNumber\"\n  },\n  \"4\": {\n    \"csv_header\": \"status\",\n    \"from_json_node\": \"\"\n  },\n  \"5\": {\n    \"csv_header\": \"Status_change_dt\",\n    \"from_json_node\": \"\"\n  },\n  \"6\": {\n    \"csv_header\": \"preferred_channel_cd\",\n    \"from_json_node\": \"\"\n  },\n  \"7\": {\n    \"csv_header\": \"gender_cd\",\n    \"from_json_node\": \"Gender\"\n  },\n  \"8\": {\n    \"csv_header\": \"prefix\",\n    \"from_json_node\": \"Prefix\"\n  },\n  \"9\": {\n    \"csv_header\": \"first_nm\",\n    \"from_json_node\": \"FirstName\"\n  },\n  \"10\": {\n    \"csv_header\": \"middle_nm\",\n    \"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n  },\n  \"11\": {\n    \"csv_header\": \"last_nm\",\n    \"from_json_node\": \"firstname\"\n  },\n  \n  \"12\": {\n    \"csv_header\": \"addr_line_1\",\n    \"from_json_node\": \"firstname\"\n  },\n  \"13\": {\n    \"csv_header\": \"addr_line_2\",\n    \"from_json_node\": \"middlename\"\n  },\n  \"14\": {\n    \"csv_header\": \"addr_line_3\",\n    \"from_json_node\": \"firstname\"\n  },\n  \"15\": {\n    \"csv_header\": \"addr_line_4\",\n    \"from_json_node\": \"Addresses[0].ProfileId\"\n  },\n  \"6\": {\n    \"csv_header\": \"city\",\n    \"from_json_node\": \"Emails[].OriginalContactPoint.ValidFlag\"\n  }\n}";
			String JSON_SOURCE = "{\n\t\"1\": {\n\t\t\"csv_header\": \"ProfileId\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"2\": {\n\t\t\"csv_header\": \"ClientAccountId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"3\": {\n\t\t\"csv_header\": \"Prefix\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"4\": {\n\t\t\"csv_header\": \"FirstName\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"5\": {\n\t\t\"csv_header\": \"MiddleInit\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"6\": {\n\t\t\"csv_header\": \"LastName\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"7\": {\n\t\t\"csv_header\": \"Suffix\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"8\": {\n\t\t\"csv_header\": \"GlobalOptOut\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\n\t\"10\": {\n\t\t\"csv_header\": \"GlobalOptDate\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"11\": {\n\t\t\"csv_header\": \"GlobalOptSource\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"12\": {\n\t\t\"csv_header\": \"LanguageCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"13\": {\n\t\t\"csv_header\": \"MaritalStatus\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"14\": {\n\t\t\"csv_header\": \"Gender\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"15\": {\n\t\t\"csv_header\": \"BirthDate\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"16\": {\n\t\t\"csv_header\": \"day_of_birth\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"17\": {\n\t\t\"csv_header\": \"month_of_birth\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"18\": {\n\t\t\"csv_header\": \"year_of_birth\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"19\": {\n\t\t\"csv_header\": \"CompanyName\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"20\": {\n\t\t\"csv_header\": \"Addresses_H_AddressId\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"21\": {\n\t\t\"csv_header\": \"Addresses_H_AddressLine1\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"22\": {\n\t\t\"csv_header\": \"Addresses_H_SourceAddressLine1\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"23\": {\n\t\t\"csv_header\": \"Addresses_H_AddressLine2\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"24\": {\n\t\t\"csv_header\": \"Addresses_H_SourceAddressLine2\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"25\": {\n\t\t\"csv_header\": \"Addresses_H_AddressLine3\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"26\": {\n\t\t\"csv_header\": \"Addresses_H_SourceAddressLine3\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"27\": {\n\t\t\"csv_header\": \"Addresses_H_AddressLine4\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"28\": {\n\t\t\"csv_header\": \"Addresses_H_City\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"29\": {\n\t\t\"csv_header\": \"Addresses_H_SourceCity\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"30\": {\n\t\t\"csv_header\": \"Addresses_H_StateCode\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"31\": {\n\t\t\"csv_header\": \"Addresses_H_SourceStateCode\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"32\": {\n\t\t\"csv_header\": \"Addresses_H_CountryCode\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"33\": {\n\t\t\"csv_header\": \"Addresses_H_SourceCountryCode\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"34\": {\n\t\t\"csv_header\": \"Addresses_H_PostalCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"35\": {\n\t\t\"csv_header\": \"Addresses_H_SourcePostalCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"36\": {\n\t\t\"csv_header\": \"Addresses_H_ChannelCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"37\": {\n\t\t\"csv_header\": \"Addresses_H_LocationCode\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"38\": {\n\t\t\"csv_header\": \"Addresses_H_IsPreferred\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"39\": {\n\t\t\"csv_header\": \"Addresses_H_DeliveryStatus\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"40\": {\n\t\t\"csv_header\": \"Addresses_H_DoNotStandardize\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"41\": {\n\t\t\"csv_header\": \"Addresses_W_AddressId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"42\": {\n\t\t\"csv_header\": \"Addresses_W_AddressLine1\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"43\": {\n\t\t\"csv_header\": \"Addresses_W_SourceAddressLine1\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"44\": {\n\t\t\"csv_header\": \"Addresses_W_AddressLine2\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"45\": {\n\t\t\"csv_header\": \"Addresses_W_SourceAddressLine2\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"46\": {\n\t\t\"csv_header\": \"Addresses_W_AddressLine3\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"47\": {\n\t\t\"csv_header\": \"Addresses_W_SourceAddressLine3\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"48\": {\n\t\t\"csv_header\": \"Addresses_W_AddressLine4\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"49\": {\n\t\t\"csv_header\": \"Addresses_W_City\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"50\": {\n\t\t\"csv_header\": \"Addresses_W_SourceCity\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"51\": {\n\t\t\"csv_header\": \"Addresses_W_SourceStateCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"52\": {\n\t\t\"csv_header\": \"Addresses_W_CountryCode\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"53\": {\n\t\t\"csv_header\": \"Addresses_W_SourceCountryCode\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"54\": {\n\t\t\"csv_header\": \"Addresses_W_PostalCode\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"55\": {\n\t\t\"csv_header\": \"Addresses_W_SourcePostalCode\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"56\": {\n\t\t\"csv_header\": \"Addresses_W_ChannelCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"57\": {\n\t\t\"csv_header\": \"Addresses_W_LocationCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"58\": {\n\t\t\"csv_header\": \"Addresses_W_IsPreferred\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"59\": {\n\t\t\"csv_header\": \"Addresses_W_DeliveryStatus\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"60\": {\n\t\t\"csv_header\": \"Addresses_W_DoNotStandardize\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"61\": {\n\t\t\"csv_header\": \"Emails_B_EmailId\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"62\": {\n\t\t\"csv_header\": \"Emails_B_EmailAddress\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"63\": {\n\t\t\"csv_header\": \"Emails_B_SourceEmailAddress\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"64\": {\n\t\t\"csv_header\": \"Emails_B_ChannelCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"65\": {\n\t\t\"csv_header\": \"Emails_B_LocationCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"66\": {\n\t\t\"csv_header\": \"Emails_B_IsPreferred\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"67\": {\n\t\t\"csv_header\": \"Emails_B_DeliveryStatus\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"68\": {\n\t\t\"csv_header\": \"Emails_B_ContactPointId\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"69\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"70\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"71\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"72\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"73\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"74\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"75\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"76\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"77\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_EmailDomain\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"78\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"79\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"80\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"81\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"82\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"83\": {\n\t\t\"csv_header\": \"Emails_B_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"84\": {\n\t\t\"csv_header\": \"Emails_B_Status\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"85\": {\n\t\t\"csv_header\": \"Emails_H_EmailId\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"86\": {\n\t\t\"csv_header\": \"Emails_H_EmailAddress\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"87\": {\n\t\t\"csv_header\": \"Emails_H_SourceEmailAddress\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"88\": {\n\t\t\"csv_header\": \"Emails_H_ChannelCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"89\": {\n\t\t\"csv_header\": \"Emails_H_LocationCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"90\": {\n\t\t\"csv_header\": \"Emails_H_IsPreferred\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"91\": {\n\t\t\"csv_header\": \"Emails_H_DeliveryStatus\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"92\": {\n\t\t\"csv_header\": \"Emails_H_ContactPointId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"93\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"94\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"95\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"96\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"97\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"Gender\"\n\t},\n\t\"98\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"99\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"100\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"101\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_EmailDomain\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"102\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"103\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"104\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"105\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"106\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"107\": {\n\t\t\"csv_header\": \"Emails_H_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"108\": {\n\t\t\"csv_header\": \"Emails_H_Status\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"109\": {\n\t\t\"csv_header\": \"Emails_O_EmailId\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"110\": {\n\t\t\"csv_header\": \"Emails_O_EmailAddress\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"111\": {\n\t\t\"csv_header\": \"Emails_O_SourceEmailAddress\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"112\": {\n\t\t\"csv_header\": \"Emails_O_ChannelCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"113\": {\n\t\t\"csv_header\": \"Emails_O_LocationCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"114\": {\n\t\t\"csv_header\": \"Emails_O_IsPreferred\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"115\": {\n\t\t\"csv_header\": \"Emails_O_DeliveryStatus\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"116\": {\n\t\t\"csv_header\": \"Emails_O_ContactPointId\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"117\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"118\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"119\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"120\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"121\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"122\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"123\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"124\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"125\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_EmailDomain\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"126\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"127\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"128\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"129\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"130\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"131\": {\n\t\t\"csv_header\": \"Emails_O_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"132\": {\n\t\t\"csv_header\": \"Emails_O_Status\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"133\": {\n\t\t\"csv_header\": \"Phones_W_PhoneId\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"134\": {\n\t\t\"csv_header\": \"Phones_W_PhoneNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"135\": {\n\t\t\"csv_header\": \"Phones_W_SourcePhoneNumber\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"136\": {\n\t\t\"csv_header\": \"Phones_W_PhoneCountryCode\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"137\": {\n\t\t\"csv_header\": \"Phones_W_AcceptsText\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"138\": {\n\t\t\"csv_header\": \"Phones_W_Frequency\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"139\": {\n\t\t\"csv_header\": \"Phones_W_NeverBefore\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"140\": {\n\t\t\"csv_header\": \"Phones_W_NeverAfter\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"141\": {\n\t\t\"csv_header\": \"Phones_W_ChannelCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"142\": {\n\t\t\"csv_header\": \"Phones_W_LocationCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"143\": {\n\t\t\"csv_header\": \"Phones_W_IsPreferred\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"144\": {\n\t\t\"csv_header\": \"Phones_W_DeliveryStatus\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"145\": {\n\t\t\"csv_header\": \"Phones_W_ContactPointId\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"146\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"147\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"148\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"149\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"150\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"151\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"152\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"153\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"154\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"155\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"156\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"157\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"158\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"159\": {\n\t\t\"csv_header\": \"Phones_W_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"160\": {\n\t\t\"csv_header\": \"Phones_W_Status\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"161\": {\n\t\t\"csv_header\": \"Phones_C_PhoneId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"162\": {\n\t\t\"csv_header\": \"Phones_C_PhoneNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"163\": {\n\t\t\"csv_header\": \"Phones_C_SourcePhoneNumber\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"164\": {\n\t\t\"csv_header\": \"Phones_C_PhoneCountryCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"165\": {\n\t\t\"csv_header\": \"Phones_C_AcceptsText\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"166\": {\n\t\t\"csv_header\": \"Phones_C_Frequency\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"167\": {\n\t\t\"csv_header\": \"Phones_C_NeverBefore\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"168\": {\n\t\t\"csv_header\": \"Phones_C_NeverAfter\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"169\": {\n\t\t\"csv_header\": \"Phones_C_ChannelCode\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"170\": {\n\t\t\"csv_header\": \"Phones_C_LocationCode\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"171\": {\n\t\t\"csv_header\": \"Phones_C_IsPreferred\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"172\": {\n\t\t\"csv_header\": \"Phones_C_DeliveryStatus\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"173\": {\n\t\t\"csv_header\": \"Phones_C_ContactPointId\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"174\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"175\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"176\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"177\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"178\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"179\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"180\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"181\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"182\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"183\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"184\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"185\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"186\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"187\": {\n\t\t\"csv_header\": \"Phones_C_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"188\": {\n\t\t\"csv_header\": \"Phones_C_Status\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"189\": {\n\t\t\"csv_header\": \"Phones_P_PhoneId\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"190\": {\n\t\t\"csv_header\": \"Phones_P_PhoneNumber\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"191\": {\n\t\t\"csv_header\": \"Phones_P_SourcePhoneNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"192\": {\n\t\t\"csv_header\": \"Phones_P_PhoneCountryCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"193\": {\n\t\t\"csv_header\": \"Phones_P_AcceptsText\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"194\": {\n\t\t\"csv_header\": \"Phones_P_Frequency\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"195\": {\n\t\t\"csv_header\": \"Phones_P_NeverBefore\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"196\": {\n\t\t\"csv_header\": \"Phones_P_NeverAfter\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"197\": {\n\t\t\"csv_header\": \"Phones_P_ChannelCode\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"198\": {\n\t\t\"csv_header\": \"Phones_P_LocationCode\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"199\": {\n\t\t\"csv_header\": \"Phones_P_IsPreferred\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"200\": {\n\t\t\"csv_header\": \"Phones_P_DeliveryStatus\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"201\": {\n\t\t\"csv_header\": \"Phones_P_ContactPointId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"202\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"203\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"204\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"205\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"206\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"207\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"208\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"209\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"210\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"211\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"212\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"213\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"214\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"215\": {\n\t\t\"csv_header\": \"Phones_P_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"216\": {\n\t\t\"csv_header\": \"Phones_P_Status\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"217\": {\n\t\t\"csv_header\": \"Phones_F_PhoneId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"218\": {\n\t\t\"csv_header\": \"Phones_F_PhoneNumber\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"219\": {\n\t\t\"csv_header\": \"Phones_F_SourcePhoneNumber\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"220\": {\n\t\t\"csv_header\": \"Phones_F_PhoneCountryCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"221\": {\n\t\t\"csv_header\": \"Phones_F_AcceptsText\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"222\": {\n\t\t\"csv_header\": \"Phones_F_Frequency\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"223\": {\n\t\t\"csv_header\": \"Phones_F_NeverBefore\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"224\": {\n\t\t\"csv_header\": \"Phones_F_NeverAfter\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"225\": {\n\t\t\"csv_header\": \"Phones_F_ChannelCode\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"226\": {\n\t\t\"csv_header\": \"Phones_F_LocationCode\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"227\": {\n\t\t\"csv_header\": \"Phones_F_IsPreferred\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"228\": {\n\t\t\"csv_header\": \"Phones_F_DeliveryStatus\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"229\": {\n\t\t\"csv_header\": \"Phones_F_ContactPointId\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"230\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"231\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"232\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"233\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"234\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"235\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"236\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"237\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"238\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"239\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"240\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"241\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"242\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"243\": {\n\t\t\"csv_header\": \"Phones_F_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"244\": {\n\t\t\"csv_header\": \"Phones_F_Status\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"245\": {\n\t\t\"csv_header\": \"Phones_O_PhoneId\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"246\": {\n\t\t\"csv_header\": \"Phones_O_PhoneNumber\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"247\": {\n\t\t\"csv_header\": \"Phones_O_SourcePhoneNumber\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"248\": {\n\t\t\"csv_header\": \"Phones_O_PhoneCountryCode\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"249\": {\n\t\t\"csv_header\": \"Phones_O_AcceptsText\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"250\": {\n\t\t\"csv_header\": \"Phones_O_Frequency\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"251\": {\n\t\t\"csv_header\": \"Phones_O_NeverBefore\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"252\": {\n\t\t\"csv_header\": \"Phones_O_NeverAfter\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"253\": {\n\t\t\"csv_header\": \"Phones_O_ChannelCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"254\": {\n\t\t\"csv_header\": \"Phones_O_LocationCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"255\": {\n\t\t\"csv_header\": \"Phones_O_IsPreferred\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"256\": {\n\t\t\"csv_header\": \"Phones_O_DeliveryStatus\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"257\": {\n\t\t\"csv_header\": \"Phones_O_ContactPointId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"258\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ContactPointId\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"259\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ActiveContactPointId\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"260\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ContactPointTypeCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"261\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ContactPointStatusCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"262\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ContactPointValue\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"263\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ValidFlag\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"264\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_CorrectedFlag\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"265\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_UndeliverableFlag\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"266\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_ContactPointSequenceNumber\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"267\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_Status\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"268\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_CreateUser\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"269\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_CreateDate\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"270\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_UpdateUser\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"271\": {\n\t\t\"csv_header\": \"Phones_O_OriginalContactPoint_UpdateDate\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"272\": {\n\t\t\"csv_header\": \"Phones_O_Status\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"273\": {\n\t\t\"csv_header\": \"SocialAccounts_0_SocialAccountId\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"274\": {\n\t\t\"csv_header\": \"SocialAccounts_0_SocialAccountType\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"275\": {\n\t\t\"csv_header\": \"SocialAccounts_0_SocialToken\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"276\": {\n\t\t\"csv_header\": \"SocialAccounts_1_SocialAccountId\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"277\": {\n\t\t\"csv_header\": \"SocialAccounts_1_SocialAccountType\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"278\": {\n\t\t\"csv_header\": \"SocialAccounts_1_SocialToken\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"279\": {\n\t\t\"csv_header\": \"SocialNetworks_0_SocialNetworkCode\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"280\": {\n\t\t\"csv_header\": \"SocialNetworks_0_SocialNetworkUserName\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"281\": {\n\t\t\"csv_header\": \"SocialNetworks_1_SocialNetworkCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"282\": {\n\t\t\"csv_header\": \"SocialNetworks_1_SocialNetworkUserName\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"283\": {\n\t\t\"csv_header\": \"ProgramCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"284\": {\n\t\t\"csv_header\": \"SourceCode\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"285\": {\n\t\t\"csv_header\": \"EnrollmentStatus\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"286\": {\n\t\t\"csv_header\": \"JoinDate\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"287\": {\n\t\t\"csv_header\": \"EnrollChannelCode\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"288\": {\n\t\t\"csv_header\": \"TierCode\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"289\": {\n\t\t\"csv_header\": \"Username\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"290\": {\n\t\t\"csv_header\": \"CardNumber\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"291\": {\n\t\t\"csv_header\": \"Status\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"292\": {\n\t\t\"csv_header\": \"TermsConditionsAcceptedInd\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"293\": {\n\t\t\"csv_header\": \"AccountSourceCode\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"294\": {\n\t\t\"csv_header\": \"SourceAccountNumber\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"295\": {\n\t\t\"csv_header\": \"BrandOrgCode\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"296\": {\n\t\t\"csv_header\": \"ActivityDate\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"297\": {\n\t\t\"csv_header\": \"CreateFileId\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"298\": {\n\t\t\"csv_header\": \"CreateRecordNumber\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"299\": {\n\t\t\"csv_header\": \"UpdateFileId\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"300\": {\n\t\t\"csv_header\": \"UpdateRecordNumber\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"301\": {\n\t\t\"csv_header\": \"AutoRewardOptInInd\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"302\": {\n\t\t\"csv_header\": \"GamerAlias\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"303\": {\n\t\t\"csv_header\": \"GamerAvatar\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"304\": {\n\t\t\"csv_header\": \"IsTestProfile\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"305\": {\n\t\t\"csv_header\": \"PostingKeys_0_PostingKeyId\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"306\": {\n\t\t\"csv_header\": \"PostingKeys_0_PostingKeyCode\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"307\": {\n\t\t\"csv_header\": \"PostingKeys_0_PostingKeyValue\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"308\": {\n\t\t\"csv_header\": \"PostingKeys_1_PostingKeyId\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"309\": {\n\t\t\"csv_header\": \"PostingKeys_1_PostingKeyCode\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"310\": {\n\t\t\"csv_header\": \"PostingKeys_1_PostingKeyValue\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"311\": {\n\t\t\"csv_header\": \"CreateUser\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"312\": {\n\t\t\"csv_header\": \"CreateDate\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"313\": {\n\t\t\"csv_header\": \"UpdateUser\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"314\": {\n\t\t\"csv_header\": \"UpdateDate\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"315\": {\n\t\t\"csv_header\": \"Status_change_dt\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"316\": {\n\t\t\"csv_header\": \"preferred_channel_cd\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"317\": {\n\t\t\"csv_header\": \"unparsed_nm\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\"318\": {\n\t\t\"csv_header\": \"title\",\n\t\t\"from_json_node\": \"SourceAccountNumber\"\n\t},\n\t\"319\": {\n\t\t\"csv_header\": \"orig_dt\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"320\": {\n\t\t\"csv_header\": \"hardkey_1\",\n\t\t\"from_json_node\": \"\"\n\t},\n\t\"321\": {\n\t\t\"csv_header\": \"hardkey_2\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"322\": {\n\t\t\"csv_header\": \"hardkey_3\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"323\": {\n\t\t\"csv_header\": \"hardkey_4\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"324\": {\n\t\t\"csv_header\": \"hardkey_5\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"325\": {\n\t\t\"csv_header\": \"hardkey_6\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t},\n\t\"326\": {\n\t\t\"csv_header\": \"hardkey_7\",\n\t\t\"from_json_node\": \"Addresses[0].BrandOrgCode\"\n\t},\n\t\"327\": {\n\t\t\"csv_header\": \"hardkey_8\",\n\t\t\"from_json_node\": \"AccountSourceCode\"\n\t},\n\t\n\t\"328\": {\n\t\t\"csv_header\": \"hardkey_9\",\n\t\t\"from_json_node\": \"Prefix\"\n\t},\n\t\"329\": {\n\t\t\"csv_header\": \"hardkey_10\",\n\t\t\"from_json_node\": \"FirstName\"\n\t},\n\t\"330\": {\n\t\t\"csv_header\": \"do_not_promote_ind\",\n\t\t\"from_json_node\": \"Emails[0].OriginalContactPoint.ValidFlag\"\n\t},\n\t\"331\": {\n\t\t\"csv_header\": \"do_not_call_ind\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"332\": {\n\t\t\"csv_header\": \"do_not_mail_ind\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"333\": {\n\t\t\"csv_header\": \"do_not_sms_ind\",\n\t\t\"from_json_node\": \"middlename\"\n\t},\n\t\"334\": {\n\t\t\"csv_header\": \"do_not_email_ind\",\n\t\t\"from_json_node\": \"firstname\"\n\t},\n\t\"335\": {\n\t\t\"csv_header\": \"do_not_rent_ind\",\n\t\t\"from_json_node\": \"Addresses[0].ProfileId\"\n\t}\n\n}\n\t\t\t";
			AddProfileResponse profile = mapper.readValue(jsonInString, AddProfileResponse.class);
			
			System.out.println("hi");
			getStandardLayout(profile,JSON_SOURCE);

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static MappingJsonToCSV getStandardLayout(AddProfileResponse profileResponse, String JSON_SOURCE) throws JsonParseException, JsonMappingException, IOException{

		ObjectMapper mapper = new ObjectMapper();
		List<String> headers = new ArrayList<String>();
		Map<String,JsonNodeAttributes> result =
				mapper.readValue(JSON_SOURCE, new TypeReference<Map<String,JsonNodeAttributes>>() {});

		for (Entry<String, JsonNodeAttributes> entry : result.entrySet()) {
			JsonNodeAttributes header = entry.getValue();
			String headerCsv = header.getCsv_header();
			headers.add(headerCsv);
		}

		MappingJsonToCSV mappingJsonToCsv = new MappingJsonToCSV();

		mappingJsonToCsv.setProfileId(profileResponse.getProfileId());
		mappingJsonToCsv.setClientAccountId(profileResponse.getClientAccountId());
		mappingJsonToCsv.setPrefix(profileResponse.getPrefix());
		mappingJsonToCsv.setFirstName(profileResponse.getFirstName());
		mappingJsonToCsv.setMiddleInit(profileResponse.getMiddleInit());
		mappingJsonToCsv.setLastName(profileResponse.getLastName());
		mappingJsonToCsv.setSuffix(profileResponse.getSuffix());
		mappingJsonToCsv.setGlobalOptOut(profileResponse.getGlobalOptOut());
		mappingJsonToCsv.setGlobalOptDate(profileResponse.getGlobalOptDate());
		mappingJsonToCsv.setGlobalOptSource(profileResponse.getGlobalOptSource());
		mappingJsonToCsv.setLanguageCode(profileResponse.getLanguageCode());
		mappingJsonToCsv.setMaritalStatus(profileResponse.getMaritalStatus());
		mappingJsonToCsv.setGender(profileResponse.getGender());
		mappingJsonToCsv.setBirthDate(profileResponse.getBirthDate());
		mappingJsonToCsv.setDay_of_birth(null);
		mappingJsonToCsv.setMonth_of_birth(null);
		mappingJsonToCsv.setYear_of_birth(null);
		mappingJsonToCsv.setCompanyName(profileResponse.getCompanyName());
		mappingJsonToCsv.setProgramCode(profileResponse.getProgramCode());
		mappingJsonToCsv.setSourceCode(profileResponse.getProgramCode());
		mappingJsonToCsv.setEnrollmentStatus(profileResponse.getEnrollmentStatus());
		mappingJsonToCsv.setJoinDate(profileResponse.getJoinDate());
		mappingJsonToCsv.setEnrollChannelCode(profileResponse.getEnrollChannelCode());
		mappingJsonToCsv.setTierCode(profileResponse.getTierCode());
		mappingJsonToCsv.setUsername(profileResponse.getUsername());
		mappingJsonToCsv.setCardNumber(profileResponse.getCardNumber());
		mappingJsonToCsv.setStatus(profileResponse.getStatus());
		mappingJsonToCsv.setTermsConditionsAcceptedInd(false);
		mappingJsonToCsv.setAccountSourceCode(profileResponse.getAccountSourceCode());
		mappingJsonToCsv.setSourceAccountNumber(profileResponse.getSourceAccountNumber());
		mappingJsonToCsv.setBrandOrgCode(profileResponse.getBrandOrgCode());
		mappingJsonToCsv.setActivityDate(profileResponse.getActivityDate());
		mappingJsonToCsv.setCreateFileId(profileResponse.getCreateFileId());
		mappingJsonToCsv.setCreateRecordNumber(profileResponse.getCreateRecordNumber());
		mappingJsonToCsv.setUpdateFileId(profileResponse.getUpdateFileId());
		mappingJsonToCsv.setUpdateRecordNumber(profileResponse.getUpdateRecordNumber());
		mappingJsonToCsv.setAutoRewardOptInInd(false);
		mappingJsonToCsv.setGamerAlias(profileResponse.getGamerAlias());
		mappingJsonToCsv.setGamerAvatar(profileResponse.getGamerAvatar());
		mappingJsonToCsv.setIsTestProfile(false);
		mappingJsonToCsv.setCreateUser(profileResponse.getCreateUser());
		mappingJsonToCsv.setCreateDate(profileResponse.getCreateDate());
		mappingJsonToCsv.setUpdateUser(profileResponse.getUpdateUser());
		mappingJsonToCsv.setUpdateDate(profileResponse.getUpdateDate());
		mappingJsonToCsv.setStatus_change_dt(null);
		mappingJsonToCsv.setPreferred_channel_cd(null);
		mappingJsonToCsv.setUnparsed_nm(null);
		mappingJsonToCsv.setTitle(null);
		mappingJsonToCsv.setOrig_dt(null);
		mappingJsonToCsv.setHardkey_1(null);
		mappingJsonToCsv.setHardkey_2(null);
		mappingJsonToCsv.setHardkey_3(null);
		mappingJsonToCsv.setHardkey_4(null);
		mappingJsonToCsv.setHardkey_5(null);
		mappingJsonToCsv.setHardkey_6(null);
		mappingJsonToCsv.setHardkey_7(null);
		mappingJsonToCsv.setHardkey_8(null);
		mappingJsonToCsv.setHardkey_9(null);
		mappingJsonToCsv.setHardkey_10(null);
		mappingJsonToCsv.setDo_not_promote_ind(null);
		mappingJsonToCsv.setDo_not_call_ind(null);
		mappingJsonToCsv.setDo_not_mail_ind(null);
		mappingJsonToCsv.setDo_not_sms_ind(null);
		mappingJsonToCsv.setDo_not_email_ind(null);
		mappingJsonToCsv.setDo_not_rent_ind(null);



		if(!profileResponse.getAddresses().isEmpty()){
			Address addr = new Address();
			for (int i = 0, size= profileResponse.getAddresses().size(); i < size; i++)
			{
				addr = profileResponse.getAddresses().get(i);
				if(addr.getLocationCode().equals("H")){
					mappingJsonToCsv.setAddresses_H_AddressId(addr.getAddressId());
					mappingJsonToCsv.setAddresses_H_AddressLine1(addr.getAddressLine1());
					mappingJsonToCsv.setAddresses_H_AddressLine2(addr.getAddressLine2());
					mappingJsonToCsv.setAddresses_H_AddressLine3(addr.getAddressLine3());
					mappingJsonToCsv.setAddresses_H_AddressLine4(null);
					mappingJsonToCsv.setAddresses_H_ChannelCode(addr.getChannelCode());
					mappingJsonToCsv.setAddresses_H_City(addr.getCity());
					mappingJsonToCsv.setAddresses_H_CountryCode(addr.getCountryCode());
					mappingJsonToCsv.setAddresses_H_DeliveryStatus(addr.getDeliveryStatus());
					mappingJsonToCsv.setAddresses_H_IsPreferred(addr.isIsPreferred());
					mappingJsonToCsv.setAddresses_H_LocationCode(addr.getLocationCode());
					mappingJsonToCsv.setAddresses_H_PostalCode(addr.getPostalCode());
					mappingJsonToCsv.setAddresses_H_SourceAddressLine1(addr.getSourceAddressLine1());
					mappingJsonToCsv.setAddresses_H_SourceAddressLine2(addr.getAddressLine2());
					mappingJsonToCsv.setAddresses_H_SourceAddressLine3(addr.getAddressLine3());
					mappingJsonToCsv.setAddresses_H_SourceCity(addr.getSourceCity());
					mappingJsonToCsv.setAddresses_H_SourceCountryCode(addr.getSourceCountryCode());
					mappingJsonToCsv.setAddresses_H_SourcePostalCode(addr.getSourcePostalCode());
					mappingJsonToCsv.setAddresses_H_SourceStateCode(addr.getSourceStateCode());
					mappingJsonToCsv.setAddresses_H_StateCode(addr.getStateCode());
				}

				if(addr.getLocationCode().equals("B")){
					mappingJsonToCsv.setAddresses_W_AddressId(addr.getAddressId());
					mappingJsonToCsv.setAddresses_W_AddressLine1(addr.getAddressLine1());
					mappingJsonToCsv.setAddresses_W_AddressLine2(addr.getAddressLine2());
					mappingJsonToCsv.setAddresses_W_AddressLine3(addr.getAddressLine3());
					mappingJsonToCsv.setAddresses_W_AddressLine4(null);
					mappingJsonToCsv.setAddresses_W_ChannelCode(addr.getChannelCode());
					mappingJsonToCsv.setAddresses_W_City(addr.getCity());
					mappingJsonToCsv.setAddresses_W_CountryCode(addr.getCountryCode());
					mappingJsonToCsv.setAddresses_W_DeliveryStatus(addr.getDeliveryStatus());
					mappingJsonToCsv.setAddresses_W_IsPreferred(addr.isIsPreferred());
					mappingJsonToCsv.setAddresses_W_LocationCode(addr.getLocationCode());
					mappingJsonToCsv.setAddresses_W_PostalCode(addr.getPostalCode());
					mappingJsonToCsv.setAddresses_W_SourceAddressLine1(addr.getSourceAddressLine1());
					mappingJsonToCsv.setAddresses_W_SourceAddressLine2(addr.getAddressLine2());
					mappingJsonToCsv.setAddresses_W_SourceAddressLine3(addr.getAddressLine3());
					mappingJsonToCsv.setAddresses_W_SourceCity(addr.getSourceCity());
					mappingJsonToCsv.setAddresses_W_SourceCountryCode(addr.getSourceCountryCode());
					mappingJsonToCsv.setAddresses_W_SourcePostalCode(addr.getSourcePostalCode());
					mappingJsonToCsv.setAddresses_W_SourceStateCode(addr.getSourceStateCode());
					mappingJsonToCsv.setAddresses_W_StateCode(addr.getStateCode());
				}
			}
		}
	if(!profileResponse.getEmails().isEmpty()){
			Email email = new Email();
		for (int i = 0, size= profileResponse.getEmails().size(); i < size; i++)
			{
				email = profileResponse.getEmails().get(i);
				if(email.getLocationCode().equals("B")){
					mappingJsonToCsv.setEmails_B_ChannelCode(email.getChannelCode());
					mappingJsonToCsv.setEmails_B_ContactPointId(email.getContactPointId());
					mappingJsonToCsv.setEmails_B_DeliveryStatus(email.getDeliveryStatus());
					mappingJsonToCsv.setEmails_B_EmailAddress(email.getEmailAddress());
					mappingJsonToCsv.setEmails_B_EmailId(email.getEmailId());
					mappingJsonToCsv.setEmails_B_IsPreferred(email.isIsPreferred());
					mappingJsonToCsv.setEmails_B_LocationCode(email.getLocationCode());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ActiveContactPointId(email.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ContactPointId(email.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ContactPointSequenceNumber(email.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ContactPointStatusCode(email.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ContactPointTypeCode(email.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_CorrectedFlag(email.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_CreateDate(email.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_CreateUser(email.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_EmailDomain(email.getOriginalContactPoint().getEmailDomain());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_Status(email.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_UndeliverableFlag(email.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_UpdateDate(email.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_UpdateUser(email.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setEmails_B_OriginalContactPoint_ValidFlag(email.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setEmails_B_SourceEmailAddress(email.getSourceEmailAddress());
					mappingJsonToCsv.setEmails_B_Status(email.getStatus());
				}
        	if(email.getLocationCode().equals("H")){
					mappingJsonToCsv.setEmails_H_ChannelCode(email.getChannelCode());
					mappingJsonToCsv.setEmails_H_ContactPointId(email.getContactPointId());
					mappingJsonToCsv.setEmails_H_DeliveryStatus(email.getDeliveryStatus());
					mappingJsonToCsv.setEmails_H_EmailAddress(email.getEmailAddress());
					mappingJsonToCsv.setEmails_H_EmailId(email.getEmailId());
					mappingJsonToCsv.setEmails_H_IsPreferred(email.isIsPreferred());
					mappingJsonToCsv.setEmails_H_LocationCode(email.getLocationCode());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ActiveContactPointId(email.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ContactPointId(email.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ContactPointSequenceNumber(email.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ContactPointStatusCode(email.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ContactPointTypeCode(email.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_CorrectedFlag(email.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_CreateDate(email.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_CreateUser(email.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_EmailDomain(email.getOriginalContactPoint().getEmailDomain());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_Status(email.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_UndeliverableFlag(email.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_UpdateDate(email.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_UpdateUser(email.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setEmails_H_OriginalContactPoint_ValidFlag(email.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setEmails_H_SourceEmailAddress(email.getSourceEmailAddress());
					mappingJsonToCsv.setEmails_H_Status(email.getStatus());
				}
			if(email.getLocationCode().equals("O")){
					mappingJsonToCsv.setEmails_O_ChannelCode(email.getChannelCode());
					mappingJsonToCsv.setEmails_O_ContactPointId(email.getContactPointId());
					mappingJsonToCsv.setEmails_O_DeliveryStatus(email.getDeliveryStatus());
					mappingJsonToCsv.setEmails_O_EmailAddress(email.getEmailAddress());
					mappingJsonToCsv.setEmails_O_EmailId(email.getEmailId());
					mappingJsonToCsv.setEmails_O_IsPreferred(email.isIsPreferred());
					mappingJsonToCsv.setEmails_O_LocationCode(email.getLocationCode());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ActiveContactPointId(email.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ContactPointId(email.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ContactPointSequenceNumber(email.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ContactPointStatusCode(email.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ContactPointTypeCode(email.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_CorrectedFlag(email.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_CreateDate(email.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_CreateUser(email.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_EmailDomain(email.getOriginalContactPoint().getEmailDomain());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_Status(email.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_UndeliverableFlag(email.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_UpdateDate(email.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_UpdateUser(email.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setEmails_O_OriginalContactPoint_ValidFlag(email.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setEmails_O_SourceEmailAddress(email.getSourceEmailAddress());
					mappingJsonToCsv.setEmails_O_Status(email.getStatus());
				}
			}
		}
	if(!profileResponse.getPhones().isEmpty()){
			Phone phone = new Phone();
			for (int i = 0, size= profileResponse.getPhones().size(); i < size; i++)
			{
				phone = profileResponse.getPhones().get(i);
				if(phone.getLocationCode().equals("H")){
					mappingJsonToCsv.setPhones_P_AcceptsText(phone.isAcceptsText());
					mappingJsonToCsv.setPhones_P_ChannelCode(phone.getChannelCode());
					mappingJsonToCsv.setPhones_P_ContactPointId(phone.getContactPointId());
					mappingJsonToCsv.setPhones_P_DeliveryStatus(phone.getDeliveryStatus());
					mappingJsonToCsv.setPhones_P_Frequency(phone.getFrequency());
					mappingJsonToCsv.setPhones_P_IsPreferred(phone.isIsPreferred());
					mappingJsonToCsv.setPhones_P_LocationCode(phone.getLocationCode());
					mappingJsonToCsv.setPhones_P_NeverAfter(phone.getNeverAfter());
					mappingJsonToCsv.setPhones_P_NeverBefore(phone.getNeverBefore());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ActiveContactPointId(phone.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ContactPointId(phone.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ContactPointSequenceNumber(phone.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ContactPointStatusCode(phone.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ContactPointTypeCode(phone.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ContactPointValue(phone.getOriginalContactPoint().getContactPointValue());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_CorrectedFlag(phone.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_CreateDate(phone.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_CreateUser(phone.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_Status(phone.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_UndeliverableFlag(phone.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_UpdateDate(phone.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_UpdateUser(phone.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setPhones_P_OriginalContactPoint_ValidFlag(phone.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setPhones_P_PhoneCountryCode(phone.getPhoneCountryCode());
					mappingJsonToCsv.setPhones_P_PhoneId(phone.getPhoneId());
					mappingJsonToCsv.setPhones_P_PhoneNumber(phone.getPhoneNumber());
					mappingJsonToCsv.setPhones_P_SourcePhoneNumber(phone.getSourcePhoneNumber());
					mappingJsonToCsv.setPhones_P_Status(phone.getStatus());
				}
		if(phone.getLocationCode().equals("W")){
					mappingJsonToCsv.setPhones_W_AcceptsText(phone.isAcceptsText());
					mappingJsonToCsv.setPhones_W_ChannelCode(phone.getChannelCode());
					mappingJsonToCsv.setPhones_W_ContactPointId(phone.getContactPointId());
					mappingJsonToCsv.setPhones_W_DeliveryStatus(phone.getDeliveryStatus());
					mappingJsonToCsv.setPhones_W_Frequency(phone.getFrequency());
					mappingJsonToCsv.setPhones_W_IsPreferred(phone.isIsPreferred());
					mappingJsonToCsv.setPhones_W_LocationCode(phone.getLocationCode());
					mappingJsonToCsv.setPhones_W_NeverAfter(phone.getNeverAfter());
					mappingJsonToCsv.setPhones_W_NeverBefore(phone.getNeverBefore());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ActiveContactPointId(phone.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ContactPointId(phone.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ContactPointSequenceNumber(phone.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ContactPointStatusCode(phone.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ContactPointTypeCode(phone.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ContactPointValue(phone.getOriginalContactPoint().getContactPointValue());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_CorrectedFlag(phone.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_CreateDate(phone.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_CreateUser(phone.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_Status(phone.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_UndeliverableFlag(phone.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_UpdateDate(phone.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_UpdateUser(phone.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setPhones_W_OriginalContactPoint_ValidFlag(phone.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setPhones_W_PhoneCountryCode(phone.getPhoneCountryCode());
					mappingJsonToCsv.setPhones_W_PhoneId(phone.getPhoneId());
					mappingJsonToCsv.setPhones_W_PhoneNumber(phone.getPhoneNumber());
					mappingJsonToCsv.setPhones_W_SourcePhoneNumber(phone.getSourcePhoneNumber());
					mappingJsonToCsv.setPhones_W_Status(phone.getStatus());
				}
		if(phone.getLocationCode().equals("C")){
					mappingJsonToCsv.setPhones_C_AcceptsText(phone.isAcceptsText());
					mappingJsonToCsv.setPhones_C_ChannelCode(phone.getChannelCode());
					mappingJsonToCsv.setPhones_C_ContactPointId(phone.getContactPointId());
					mappingJsonToCsv.setPhones_C_DeliveryStatus(phone.getDeliveryStatus());
					mappingJsonToCsv.setPhones_C_Frequency(phone.getFrequency());
					mappingJsonToCsv.setPhones_C_IsPreferred(phone.isIsPreferred());
					mappingJsonToCsv.setPhones_C_LocationCode(phone.getLocationCode());
					mappingJsonToCsv.setPhones_C_NeverAfter(phone.getNeverAfter());
					mappingJsonToCsv.setPhones_C_NeverBefore(phone.getNeverBefore());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ActiveContactPointId(phone.getOriginalContactPoint().getActiveContactPointId());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ContactPointId(phone.getOriginalContactPoint().getContactPointId());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ContactPointSequenceNumber(phone.getOriginalContactPoint().getContactPointSequenceNumber());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ContactPointStatusCode(phone.getOriginalContactPoint().getContactPointStatusCode());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ContactPointTypeCode(phone.getOriginalContactPoint().getContactPointTypeCode());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ContactPointValue(phone.getOriginalContactPoint().getContactPointValue());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_CorrectedFlag(phone.getOriginalContactPoint().getCorrectedFlag());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_CreateDate(phone.getOriginalContactPoint().getCreateDate());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_CreateUser(phone.getOriginalContactPoint().getCreateUser());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_Status(phone.getOriginalContactPoint().getStatus());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_UndeliverableFlag(phone.getOriginalContactPoint().getUndeliverableFlag());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_UpdateDate(phone.getOriginalContactPoint().getUpdateDate());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_UpdateUser(phone.getOriginalContactPoint().getUpdateUser());
					mappingJsonToCsv.setPhones_C_OriginalContactPoint_ValidFlag(phone.getOriginalContactPoint().getValidFlag());
					mappingJsonToCsv.setPhones_C_PhoneCountryCode(phone.getPhoneCountryCode());
					mappingJsonToCsv.setPhones_C_PhoneId(phone.getPhoneId());
					mappingJsonToCsv.setPhones_C_PhoneNumber(phone.getPhoneNumber());
					mappingJsonToCsv.setPhones_C_SourcePhoneNumber(phone.getSourcePhoneNumber());
					mappingJsonToCsv.setPhones_C_Status(phone.getStatus());
				}
			}  
		}
     	if(!profileResponse.getSocialAccounts().isEmpty()){
				SocialAccount socialAccount = new SocialAccount();
				socialAccount=profileResponse.getSocialAccounts().get(0);
				mappingJsonToCsv.setSocialAccounts_0_SocialAccountId(socialAccount.getSocialAccountId());
				mappingJsonToCsv.setSocialAccounts_0_SocialAccountType(socialAccount.getSocialAccountType());
				mappingJsonToCsv.setSocialAccounts_0_SocialToken(socialAccount.getSocialToken());
				socialAccount=profileResponse.getSocialAccounts().get(1);
				mappingJsonToCsv.setSocialAccounts_1_SocialAccountId(socialAccount.getSocialAccountId());
				mappingJsonToCsv.setSocialAccounts_1_SocialAccountType(socialAccount.getSocialAccountType());
				mappingJsonToCsv.setSocialAccounts_1_SocialToken(socialAccount.getSocialToken());
			}
     	if(!profileResponse.getSocialNetworks().isEmpty()){
				SocialNetwork socialNetwork = new SocialNetwork();
				socialNetwork=profileResponse.getSocialNetworks().get(0);
				mappingJsonToCsv.setSocialNetworks_0_SocialNetworkCode(socialNetwork.getSocialNetworkCode());
				mappingJsonToCsv.setSocialNetworks_0_SocialNetworkUserName(socialNetwork.getSocialNetworkUserName());
				socialNetwork=profileResponse.getSocialNetworks().get(1);
				mappingJsonToCsv.setSocialNetworks_1_SocialNetworkCode(socialNetwork.getSocialNetworkCode());
				mappingJsonToCsv.setSocialNetworks_1_SocialNetworkUserName(socialNetwork.getSocialNetworkUserName());
			}
    	if(!profileResponse.getPostingKeys().isEmpty()){
				PostingKey postingKey = new PostingKey();
				postingKey=profileResponse.getPostingKeys().get(0);
				mappingJsonToCsv.setPostingKeys_0_PostingKeyCode(postingKey.getPostingKeyCode());
				mappingJsonToCsv.setPostingKeys_0_PostingKeyId(postingKey.getPostingKeyId());
				mappingJsonToCsv.setPostingKeys_0_PostingKeyValue(postingKey.getPostingKeyValue());
				postingKey=profileResponse.getPostingKeys().get(1);
				mappingJsonToCsv.setPostingKeys_1_PostingKeyCode(postingKey.getPostingKeyCode());
				mappingJsonToCsv.setPostingKeys_1_PostingKeyId(postingKey.getPostingKeyId());
				mappingJsonToCsv.setPostingKeys_1_PostingKeyValue(postingKey.getPostingKeyValue());
			}
		writeCSVFile(mappingJsonToCsv ,headers);
		return mappingJsonToCsv;
	}

	static void writeCSVFile( MappingJsonToCSV mappingJsonToCsv, List<String> headers) {
		System.out.println(mappingJsonToCsv);
		ICsvBeanWriter beanWriter = null;
		StringWriter writer = new StringWriter();
		final CellProcessor[] processors = getProcessors();
		try {
			beanWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);

			String[] header = new String[headers.size()];
			header = headers.toArray(header);
			beanWriter.writeHeader(header);
			beanWriter.write(mappingJsonToCsv, header, processors);
		} catch (IOException ex) {
			System.err.println("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();
				} catch (IOException ex) {
					System.err.println("Error closing the writer: " + ex);
				}
			}
		}

		System.out.println("CSV Data\n"+writer.toString());

	}

	private static CellProcessor[] getProcessors() {

		final CellProcessor[] processors = new CellProcessor[] { 

				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				new Optional(), // Role
				//new Optional(), // Role
		};
		return processors;
	}


}