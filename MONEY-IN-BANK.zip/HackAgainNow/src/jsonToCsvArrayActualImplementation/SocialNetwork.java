package jsonToCsvArrayActualImplementation;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SocialNetwork {
	
	@JsonProperty("SocialNetworkCode")
	private String SocialNetworkCode ;
	@JsonProperty("SocialNetworkUserName")
	private String  SocialNetworkUserName;
	
	
	public String getSocialNetworkCode() {
		return SocialNetworkCode;
	}
	public void setSocialNetworkCode(String socialNetworkCode) {
		SocialNetworkCode = socialNetworkCode;
	}
	public String getSocialNetworkUserName() {
		return SocialNetworkUserName;
	}
	public void setSocialNetworkUserName(String socialNetworkUserName) {
		SocialNetworkUserName = socialNetworkUserName;
	}
	
	

}
