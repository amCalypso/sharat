import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

public class ReadJsonArray {

	public static void main(String[] args) {

		File jsonInputFile = new File("C:\\Users\\shnaik\\Desktop\\JUPITER\\jsonArray.json");
		
		try {
			InputStream input = new FileInputStream(jsonInputFile);
			JsonReader reader = Json.createReader(input);
			JsonObject empObj = reader.readObject();
			reader.close();
			System.out.println("Emp Name: " + empObj.getString("emp_name"));
			System.out.println("Emp Id: " + empObj.getInt("emp_id"));
			JsonArray arrObj = empObj.getJsonArray("direct_reports");
			System.out.println("\nDirect Reports:");
			for(JsonValue value : arrObj){
				System.out.println(value.toString());
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}

