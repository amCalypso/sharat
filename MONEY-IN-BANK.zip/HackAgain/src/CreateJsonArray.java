
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.JSONArray;

public class CreateJsonArray {

	public static void main(String[] args) throws JSONException {

		JSONObject obj = new JSONObject();
		obj.put("name", "sharat");
		obj.put("place", "Bangalore");

		JSONArray list = new JSONArray();
		list.add("Hi");
		list.add("How");
		list.add("You");
		obj.put("messages", list);
		System.out.println(obj.toString());
	}
}


