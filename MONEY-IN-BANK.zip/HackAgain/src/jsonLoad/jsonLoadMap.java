package jsonLoad;

import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

public class jsonLoadMap {

	
	public static void main(String[] args) {
		
		HashMap<String,Object> result =  new ObjectMapper().readValue(JSON_SOURCE, HashMap.class);
		
		
		
	}
}
