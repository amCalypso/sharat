package parse;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ParseJson1 {
	
	public static void main(String[] args) throws JSONException, JsonProcessingException, IOException {
		
		String returnString = "{ \"URI\": { \"ProfileId\": \"user28\" }, \"Header\": { \"ProgramCode\": \"MY-PROG\" }, \"PurchaseTxn\": { \"TransactionNetTotal\": 49.99, \"TransactionEligible\": 34.99, \"PostSalesAdjustment\": 0, \"ShippingAndHandling\": 0, \"Gratuity\": 0, \"TransactionTotalTax\": 6.5, \"TransactionNumber\": \"09191985\", \"CurrencyCode\": \"USD\", \"TransactionDateTime\": \"2016-04-05T08:28:06.3672102Z\", \"TransactionEndDateTime\": \"2016-04-12T08:28:06.3672102Z\", \"SuspendReasonCode\": \"\", \"TransactionDescription\": \"SampleTransaction\", \"FileId\": 0, \"DeviceId\": \"Unused\", \"DeviceUserid\": \"Unused\", \"AuthorizationCode\": \"Unused\", \"StoreCode\": \"NEXTSTORE1\", \"Certificates\": [ { \"CertificateNumber\": \"7c5d0777-61f0-4228-95e7-9ff1c0f7cbc0\" }, { \"CertificateNumber\": \"c5b436e7-82d8-4c79-9f33-949af7977ba0\" } ], \"TransactionDetails\": [ { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100100\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 1, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1230\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1231\" } ] }, { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100101\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 2, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1233\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1234\" } ] } ], \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1235\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1236\" } ], \"Tenders\": [ { \"TenderCode\": \"CASH\", \"TenderAmount\": 15 }, { \"TenderCode\": \"CREDIT\", \"TenderAmount\": 12 } ], \"Discounts\": [ { \"DiscountCode\": \"ABC\" }, { \"DiscountCode\": \"XYZ\" } ], \"ActivityDate\": \"2016-04-05T08:28:06.3672102Z\", \"CreateFileId\": 1234235653, \"CreateRecordNumber\": 67520961487, \"UpdateFileId\": 10984032, \"UpdateRecordNumber\": 90184710 } }";

		
		
		parse(returnString);
	/*	JSONObject partsData = new JSONObject(returnString);
		Iterator<String> iterator = partsData.keys();
		
		while(iterator.hasNext()) {
	        // loop to get the dynamic key
	        String currentDynamicKey = (String)iterator.next();
	        System.out.println(currentDynamicKey);

		}*/
		
		
	}
	
	public static void parse(String json) throws JsonProcessingException, IOException  {
	       JsonFactory factory = new JsonFactory();

	       ObjectMapper mapper = new ObjectMapper(factory);
	       JsonNode rootNode = mapper.readTree(json);  

	       Iterator<Map.Entry<String,JsonNode>> fieldsIterator = rootNode.fields();
	       while (fieldsIterator.hasNext()) {

	           Map.Entry<String,JsonNode> field = fieldsIterator.next();
	           System.out.println("Key: " + field.getKey() + "\tValue:" + field.getValue());
	           
	       }
	}
	
	

}
