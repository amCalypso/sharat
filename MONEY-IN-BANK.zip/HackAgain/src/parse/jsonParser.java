package parse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class jsonParser {
	
	static List<String> apiNamesList = new ArrayList<String>();
	static List<String> jsonNodesParse = new ArrayList<String>();
	
	public static void main(String[] args) throws JSONException {
		
//String returnString = "{ \"URI\": { \"ProfileId\": \"user28\" }, \"Header\": { \"ProgramCode\": \"MY-PROG\" }, \"PurchaseTxn\": { \"TransactionNetTotal\": 49.99, \"TransactionEligible\": 34.99, \"PostSalesAdjustment\": 0, \"ShippingAndHandling\": 0, \"Gratuity\": 0, \"TransactionTotalTax\": 6.5, \"TransactionNumber\": \"09191985\", \"CurrencyCode\": \"USD\", \"TransactionDateTime\": \"2016-04-05T08:28:06.3672102Z\", \"TransactionEndDateTime\": \"2016-04-12T08:28:06.3672102Z\", \"SuspendReasonCode\": \"\", \"TransactionDescription\": \"SampleTransaction\", \"FileId\": 0, \"DeviceId\": \"Unused\", \"DeviceUserid\": \"Unused\", \"AuthorizationCode\": \"Unused\", \"StoreCode\": \"NEXTSTORE1\", \"Certificates\": [ { \"CertificateNumber\": \"7c5d0777-61f0-4228-95e7-9ff1c0f7cbc0\" }, { \"CertificateNumber\": \"c5b436e7-82d8-4c79-9f33-949af7977ba0\" } ], \"TransactionDetails\": [ { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100100\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 1, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1230\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1231\" } ] }, { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100101\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 2, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1233\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1234\" } ] } ], \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1235\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1236\" } ], \"Tenders\": [ { \"TenderCode\": \"CASH\", \"TenderAmount\": 15 }, { \"TenderCode\": \"CREDIT\", \"TenderAmount\": 12 } ], \"Discounts\": [ { \"DiscountCode\": \"ABC\" }, { \"DiscountCode\": \"XYZ\" } ], \"ActivityDate\": \"2016-04-05T08:28:06.3672102Z\", \"CreateFileId\": 1234235653, \"CreateRecordNumber\": 67520961487, \"UpdateFileId\": 10984032, \"UpdateRecordNumber\": 90184710 } }";

String returnStr = "{\"type\":\"record\",\"name\":\"avro_schema\",\"fields\":[{\"name\":\"user\",\"type\":\"string\",\"doc\":\"Type inferred from 'joe'\"},{\"name\":\"product\",\"type\":\"string\",\"doc\":\"Type inferred from 'abc'\"},{\"name\":\"rating\",\"type\":\"int\",\"doc\":\"Type inferred from '1'\"},{\"name\":\"score\",\"type\":\"double\",\"doc\":\"Type inferred from '4.75'\"},{\"name\":\"scoredate\",\"type\":\"string\",\"doc\":\"Type inferred from '2016-05-24'\"}]}";

JSONObject json = new JSONObject(returnStr); 
		//System.out.println(json);
		listJson(json);
		
		for(String  apiname : apiNamesList ) {

		//	System.out.println("API Names   "  +apiname);  
			
		}
	}

	private static void listJson(JSONObject json) throws JSONException {
		listJSONObject("", json);
		
	}
	
	private static void listJSONObject(String parent, JSONObject json) throws JSONException {
		Iterator it = json.keys();    

		while (it.hasNext()) {
			String key = (String)it.next();
			Object child = json.get(key);
			System.out.println("KEY   " +key + "\n"  + "CHILD " +child);
			String childKey = parent.isEmpty() ? key : parent + "." + key;
			System.out.println("childKey------------>" +childKey);
			System.out.println("child------------>" +child);
			String childName = child.toString();
			apiNamesList.add(childName);
			listObject(childKey, child);
		}
	}
	
	private static void listObject(String parent, Object data) throws JSONException {
		if (data instanceof JSONObject) {	
			System.out.println("data instanceof JSONObject\n\n");
			listJSONObject(parent, (JSONObject)data);
		} else if (data instanceof JSONArray) {	 
			System.out.println("data instanceof JSONArray\n\n");
			listJSONArray(parent, (JSONArray) data);	      
		} else {	    	
			System.out.println("data instanceof listPrimitive\n\n");
			listPrimitive(parent);
		}    
	}
	
	
	private static void listJSONArray(String parent, JSONArray json) throws JSONException {
		for (int i = 0; i < json.length(); i++) {
			Object data = json.get(i);
			System.out.println("data----------------->" +data);
			listObject(parent, data);
		}
	}
	
	private static void listPrimitive(String parent) {
		String newString = parent.substring(parent.lastIndexOf(".")+1 );
	//	System.out.println("parent ---- primitive " +parent);
	//	System.out.println("newString----------------->" +newString);
		jsonNodesParse.add(newString);		 
	}
	
	
	

}
	
