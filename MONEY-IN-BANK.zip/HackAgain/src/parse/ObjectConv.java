package parse;

public class ObjectConv {
	
	public static void main(String[] args) {
		
		ParseJson p = new ParseJson();
		String a = p.toString();
		System.out.println(p.getClass());
		
		
	}

}
