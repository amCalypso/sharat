package jsonW;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class jsonTraverse {
	public static void main(String[] args) throws JsonProcessingException, IOException {
		String returnString = "{    \"result\": {        \"identification\": {            \"transactionid\": \"Merchant Assigned ID\",            \"uniqueid\": \"d91ac8ff6e9945b8a125d6e725155fb6\",            \"shortid\": \"0000.0005.6238\",            \"customerid\": \"customerid 12345\"        },        \"payment\": {            \"amount\": \"2400\",            \"currency\": \"EUR\",            \"descriptor\": \"order number\"        },        \"level\": 0,        \"code\": 0,        \"method\": \"creditcard\",        \"type\": \"preauthorization\",        \"message\": \"approved\",        \"merchant\": {            \"key1\": \"Value1\",            \"key0\": \"Value0\"        }    },    \"id\": 1,    \"jsonrpc\": \"2.0\"}";
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.readTree(returnString);
		Iterator<Entry<String, JsonNode>> nodes = rootNode.fields();
		while (nodes.hasNext()) {
			Map.Entry<String, JsonNode> entry = (Map.Entry<String, JsonNode>) nodes.next();
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
	}

}
