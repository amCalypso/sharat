package jsonW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

public class MyJSONTest {
	
	 static Map<String,String> mp = new HashMap<String,String>(); 
	 static List<String> Numericstr = new ArrayList<String>();
	 static List<String> Allstr = new ArrayList<String>();
	 
	 public static void main(String[] args) throws JSONException {
		    //String data ="{ \"URI\": { \"ProfileId\": \"user28\" }, \"Header\": { \"ProgramCode\": \"MY-PROG\" }, \"PurchaseTxn\": { \"TransactionNetTotal\": 49.99, \"TransactionEligible\": 34.99, \"PostSalesAdjustment\": 0, \"ShippingAndHandling\": 0, \"Gratuity\": 0, \"TransactionTotalTax\": 6.5, \"TransactionNumber\": \"09191985\", \"CurrencyCode\": \"USD\", \"TransactionDateTime\": \"2016-04-05T08:28:06.3672102Z\", \"TransactionEndDateTime\": \"2016-04-12T08:28:06.3672102Z\", \"SuspendReasonCode\": \"\", \"TransactionDescription\": \"SampleTransaction\", \"FileId\": 0, \"DeviceId\": \"Unused\", \"DeviceUserid\": \"Unused\", \"AuthorizationCode\": \"Unused\", \"StoreCode\": \"NEXTSTORE1\", \"Certificates\": [ { \"CertificateNumber\": \"7c5d0777-61f0-4228-95e7-9ff1c0f7cbc0\" }, { \"CertificateNumber\": \"c5b436e7-82d8-4c79-9f33-949af7977ba0\" } ], \"TransactionDetails\": [ { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100100\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 1, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1230\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1231\" } ] }, { \"TaxAmount\": 10, \"DollarValueGross\": 10, \"DollarValueNet\": 9, \"EligibleRevenue\": 12, \"ItemNumber\": \"100101\", \"ItemNumberTypeCode\": \"S\", \"Quantity\": 123, \"LineNumber\": 2, \"LineItemAmountTypeCode\": \"NA\", \"AllocatedBonusPoints\": 0, \"AllocatedBasePoints\": 0, \"AllocatedRedeemedPoints\": 0, \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1233\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1234\" } ] } ], \"Coupons\": [ { \"CouponAmount\": 12.43, \"CouponNumber\": \"1235\" }, { \"CouponAmount\": 21.31, \"CouponNumber\": \"1236\" } ], \"Tenders\": [ { \"TenderCode\": \"CASH\", \"TenderAmount\": 15 }, { \"TenderCode\": \"CREDIT\", \"TenderAmount\": 12 } ], \"Discounts\": [ { \"DiscountCode\": \"ABC\" }, { \"DiscountCode\": \"XYZ\" } ], \"ActivityDate\": \"2016-04-05T08:28:06.3672102Z\", \"CreateFileId\": 1234235653, \"CreateRecordNumber\": 67520961487, \"UpdateFileId\": 10984032, \"UpdateRecordNumber\": 90184710 } }";
			 String data ="{\"type\":\"record\",\"name\":\"avro1\",\"fields\":[{\"name\":\"tenantid\",\"type\":\"string\",\"doc\":\"Typeinferredfrom'client1'\"},{\"name\":\"programId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'program1'\"},{\"name\":\"eventTypeId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'7C4D54CEDC9F4EB7BEE7EF672156C62A'\"},{\"name\":\"internalCustomerKey\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'12e9eee2-3f7c-42b2-893a-e88126b28527'\"},{\"name\":\"clientIndivId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'234092834'\"},{\"name\":\"panopticIdentifier\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'1234891264'\"},{\"name\":\"adminUserId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'someAdminUIusername'\"},{\"name\":\"channel\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'iOS'\"},{\"name\":\"eventId\",\"type\":\"string\",\"doc\":\"Typeinferredfrom'<event>'\"},{\"name\":\"eventDateTime\",\"type\":\"long\",\"doc\":\"Typeinferredfrom'1486056960000'\"},{\"name\":\"eventResponse\",\"type\":\"string\",\"doc\":\"Typeinferredfrom'Pass'\"},{\"name\":\"eventData\",\"type\":[\"null\",{\"type\":\"record\",\"name\":\"eventData\",\"fields\":[{\"name\":\"login\",\"type\":{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"login\",\"fields\":[{\"name\":\"username\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'someUsername'\"}]},\"doc\":\"Typeinferredfrom'{username:someUsername}'\"},{\"name\":\"profileUpdate\",\"type\":[\"null\",{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"profileUpdate\",\"fields\":[{\"name\":\"name\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"address\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"email\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"phone\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"password\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"}]}],\"default\":null,\"doc\":\"Typeinferredfrom'{name:1,address:1,email:1,phone:1,password:1}'\"},{\"name\":\"profileLink\",\"type\":{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"profileLink\",\"fields\":[{\"name\":\"delta\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'2'\"}]},\"doc\":\"Typeinferredfrom'{delta:2}'\"},{\"name\":\"points\",\"type\":{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"points\",\"fields\":[{\"name\":\"pointTypeId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'24d8ccc1-3f7c-42b2-893a-e88126b18789'\"},{\"name\":\"totalPoints\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'0'\"}]}},\"doc\":\"Typeinferredfrom'[{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:0},{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18780,totalPoints:100}]'\"},{\"name\":\"redemption\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"redemption\",\"fields\":[{\"name\":\"pointTypeId\",\"type\":[\"null\",\"string\"],\"default\":null,\"doc\":\"Typeinferredfrom'24d8ccc1-3f7c-42b2-893a-e88126b18789'\"},{\"name\":\"totalPoints\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'100'\"},{\"name\":\"totalQuantity\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'2'\"},{\"name\":\"certificateQuantity\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"certificatePoints\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'50'\"},{\"name\":\"electronicQuantity\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'0'\"},{\"name\":\"electronicPoints\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'0'\"},{\"name\":\"shippedQuantity\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"},{\"name\":\"shippedPoints\",\"type\":[\"null\",\"int\"],\"default\":null,\"doc\":\"Typeinferredfrom'1'\"}]}}],\"default\":null,\"doc\":\"Typeinferredfrom'[{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:100,totalQuantity:2,certificateQuantity:1,certificatePoints:50,electronicQuantity:0,electronicPoints:0,shippedQuantity:1,shippedPoints:1},{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:100,totalQuantity:2,certificateQuantity:1,certificatePoints:50,electronicQuantity:0,electronicPoints:0,shippedQuantity:1,shippedPoints:1}]'\"},{\"name\":\"transaction\",\"type\":[\"null\",{\"type\":\"record\",\"name\":\"eventData\",\"namespace\":\"transaction\",\"fields\":[{\"name\":\"totalNetRevenue\",\"type\":[\"null\",\"double\"],\"default\":null,\"doc\":\"Typeinferredfrom'123.45'\"}]}],\"default\":null,\"doc\":\"Typeinferredfrom'{totalNetRevenue:123.45}'\"}]}],\"default\":null,\"doc\":\"Typeinferredfrom'{login:{username:someUsername},profileUpdate:{name:1,address:1,email:1,phone:1,password:1},profileLink:{delta:2},points:[{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:0},{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18780,totalPoints:100}],redemption:[{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:100,totalQuantity:2,certificateQuantity:1,certificatePoints:50,electronicQuantity:0,electronicPoints:0,shippedQuantity:1,shippedPoints:1},{pointTypeId:24d8ccc1-3f7c-42b2-893a-e88126b18789,totalPoints:100,totalQuantity:2,certificateQuantity:1,certificatePoints:50,electronicQuantity:0,electronicPoints:0,shippedQuantity:1,shippedPoints:1}],transaction:{totalNetRevenue:123.45}}'\"}]}";
			 
			 JSONObject json = new JSONObject(data);    
		   // System.out.println(json.toString(2));
		    listJson(json);
		  
		    
		    mp.forEach((k,v)->{
		    	//System.out.println("Json Node Elements : " + k + "------>" + v);
		    	filterNodeNonNumeric(k,v);
		    });

		    mp.forEach((k,v)->{
		    	//System.out.println("Json Node Elements : " + k + "------>" + v);
		    	NofilterNode(k,v);
		    });
		    
		    java.util.Collections.sort(Numericstr);
		    java.util.Collections.sort(Allstr);
		    
		    for (String k : Numericstr){
		    	//System.out.println(k);
		    }
		    
		    for (String kStr : Allstr){
		    //	System.out.println(kStr);
		    }
		  }

	 private static void NofilterNode(String k, String v) {
		 Allstr.add(k);		   
	 }

  private static void filterNodeNonNumeric(String k, String v) {
	  //  System.out.println("Node---->"+k + "----->" +v);
	  Boolean status = v != null && v.matches("[-+]?\\d*\\.?\\d*"); 
	  if(status){		    	
		  Numericstr.add(k);		    	
	  }
	  // System.out.println("Status " +status);
  }

private static void listJson(JSONObject json) throws JSONException {
    listJSONObject("", json);
  }

  private static void listObject(String parent, Object data) throws JSONException {
    if (data instanceof JSONObject) {
      listJSONObject(parent, (JSONObject)data);
    } else if (data instanceof JSONArray) {
      listJSONArray(parent, (JSONArray) data);
    } else {
      listPrimitive(parent, data);
    }    
  }

  private static void listJSONObject(String parent, JSONObject json) throws JSONException {
    Iterator it = json.keys();
    while (it.hasNext()) {
      String key = (String)it.next();
      Object child = json.get(key);
      String childKey = parent.isEmpty() ? key : parent + "." + key;
      listObject(childKey, child);
    }
  }

  private static void listJSONArray(String parent, JSONArray json) throws JSONException {
    for (int i = 0; i < json.length(); i++) {
      Object data = json.get(i);
      listObject(parent + "[" + i + "]", data);
    }
  }

  private static void listPrimitive(String parent, Object obj) {
   System.out.println(parent + "  :  "  + obj);
    String objectValue = obj.toString();
   
    mp.put(parent, objectValue);
  }

 

}