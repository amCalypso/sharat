package jsonW;

public class stringManipulate {
	
	public static void main(String[] args) {
		
		String a = null ;
		String b = "Y";
		
		if(a != null){
			System.out.println("Inside if");
		} else {
			System.out.println("Inside Else");
			
		}
		
		
	}

}
