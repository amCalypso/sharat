package jsonW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonNodeUtil {

	static Map<String,String> jsonNodeMap = new HashMap<String,String>(); 
	static Map<String,String> lookUpJsonNodeMap = new HashMap<String,String>(); 

	static List<String> jsonNode = new ArrayList<String>();
	static List<String> numericJsonNode = new ArrayList<String>();

	static boolean numeric = false;
	private static String avroFlag = "A";
	private static String jsonFlag = "J";

	public static List<String> parseJson(String jsonExample, String avroSchema, String isNumeric) throws Exception{

		//Implicitly parse json example
		parseJsonNodeAndExtract(jsonFlag, jsonExample);


		//Implicitly add to jsonNode 
		jsonNodeMap.forEach((key,value)->{
			jsonNode.add(key);	
		});

		// if isNumeric parse avro schema
		if(isNumeric != null && isNumeric.equalsIgnoreCase("Y")){
			numeric = true;
			parseJsonNodeAndExtract(avroFlag, avroSchema);
		}  

		if(isNumeric != null && !isNumeric.matches("[yY]+")){
			throw new Exception("Invalid isNumeric passed");
		}

		if(numeric){
			List<String> listName = filterNodeNumeric();
			findNumericNodeByCompare(listName);

			for(String listNames : listName ){
				//	System.out.println(listNames);
			}
		}

		//Logger statements to trace the json and avro schema
		numericJsonNode.stream()  
		.collect(Collectors.toCollection(() -> 
		new TreeSet<String>((p1, p2) -> p1.compareTo(p2)) 
				));
		if(numeric){
			for(String NumericjsonNodeElements : numericJsonNode){
				//System.out.println(NumericjsonNodeElements);
			}
		} else{
			for(String jsonNodeElements : jsonNode){
				//	System.out.println(jsonNodeElements);
			}
		}
		if(numeric){
			return numericJsonNode;
		} else {
			return jsonNode;
		}
	}

	/**
	 * Pulls JSON Nodes and stores in a List.
	 * 
	 * @param JsonInput
	 * @return
	 * @throws JSONException 
	 */
	private static void parseJsonNodeAndExtract(String flag, String jsonInput) throws JSONException {
		JSONObject json = new JSONObject(jsonInput);
		listJSONObject(flag, "", json);
	}

	private static  void listJSONObject(String flag,String parent, JSONObject json) throws JSONException {
		Iterator<String> it = json.keys();
		while (it.hasNext()) {
			String key = (String)it.next();
			Object child = json.get(key);
			String childKey = parent.isEmpty() ? key : parent + "." + key;
			listObject(flag, childKey, child);
		}
	}

	/**
	 * check if it is JSON Array or JSON object.
	 * 
	 * @param JsonInput
	 * @return
	 */
	private static  void listObject(String flag,String parent, Object data) throws JSONException {
		if (data instanceof JSONObject) {
			listJSONObject(flag, parent, (JSONObject)data);
		} else if (data instanceof JSONArray) {
			listJSONArray(flag, parent, (JSONArray) data);
		} else {
			listPrimitive(flag, parent, data);
		}    
	}

	private static  void listJSONArray(String flag,String parent, JSONArray json) throws JSONException {
		for (int i = 0; i < json.length(); i++) {
			Object data = json.get(i);
			listObject(flag, parent + "[" + i + "]", data);
		}
	}

	private static  void listPrimitive(String flag,String parent, Object obj) {
		String objectValue = obj.toString();
		if( flag.equals(jsonFlag)){
			jsonNodeMap.put(parent, objectValue);
		} else {
			lookUpJsonNodeMap.put(parent, objectValue);
		}
	}

	/**
	 * filters Node which are numeric
	 * 
	 * @return
	 */
	private static  List<String> filterNodeNumeric() {


		List<String> listName = new ArrayList<String>();
		lookUpJsonNodeMap.forEach((key, value) -> {
			//System.out.println(key + "-----------> " +value );
			if(value.equalsIgnoreCase("long") || value.equalsIgnoreCase("int") || value.equalsIgnoreCase("double") || value.equalsIgnoreCase("float")){
				int index = key.lastIndexOf('.');
				String formName = key.substring(0,index);
				StringBuilder formNameNode=new StringBuilder();  
				formNameNode.append(formName).append(".").append("name"); 
				listName.add(formNameNode.toString());			 
			}
		});
		return listName;
	}

	/**
	 * compares and extracts the node values
	 * 
	 * @return
	 */
	private static void findNumericNodeByCompare(List<String> listName) {
		List<String> listKey = new ArrayList<String>();
		for(String keyList : listName){
			lookUpJsonNodeMap.forEach((key, value) -> {
				if(key.equals(keyList)){
					listKey.add(value);
				}
			});
		}
		List<String> listNameWithoutDuplicates = listKey.stream().distinct().collect(Collectors.toList());

		for (String listKeyTemp : listNameWithoutDuplicates){
			for (String jsonNodeTemp : jsonNode){
				String lastWord = jsonNodeTemp.substring(jsonNodeTemp.lastIndexOf('.') + 1);
				if(listKeyTemp.equals(lastWord)) {
					numericJsonNode.add(jsonNodeTemp);					
				}
			}
		}
	}
}
