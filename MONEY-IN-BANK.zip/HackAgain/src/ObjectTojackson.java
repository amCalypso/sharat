import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectTojackson {
	
	public static void main(String[] args) throws JsonProcessingException {
		
		System.out.println("Object to Jackson");
		
		ObjectMapper mapper = new ObjectMapper();
		Student student = new Student();
		
		//Object to JSON in String
		String jsonInString = mapper.writeValueAsString(student);
		
		System.out.println(jsonInString);
	}

}
