import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JSonArrayExample {
	
	public static void main(String[] args) throws JSONException {
		
		String oneString = "{\"name\":\"sharat\"}";

		JSONObject jsonObj = new JSONObject(oneString);
		String name = jsonObj.getString("name");
		System.out.println(name);
	}

}
