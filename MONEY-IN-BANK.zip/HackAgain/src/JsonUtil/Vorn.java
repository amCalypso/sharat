package JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class Vorn {

	public static void main(String[] args) {

		List<String> listKey = new ArrayList<String>();
		List<String> jsonNode = new ArrayList<String>();
		List<String> numericJsonNode = new ArrayList<String>();

		listKey.add("name");
		listKey.add("email");
		jsonNode.add("eventData.profileUpdate.name");
		jsonNode.add("eventData.login.username");

		for (String listKeyTemp : listKey){
			for (String jsonNodeTemp : jsonNode){
				//jsonNodeTemp.
				String lastWord = jsonNodeTemp.substring(jsonNodeTemp.lastIndexOf('.') + 1);
				//System.out.println(lastWord);
				if(listKeyTemp.equals(lastWord)) {
					numericJsonNode.add(jsonNodeTemp);
				}
			}
		}

		for (String numericJsonNodes : numericJsonNode){
			System.out.println(numericJsonNodes);
		}

	}

}


