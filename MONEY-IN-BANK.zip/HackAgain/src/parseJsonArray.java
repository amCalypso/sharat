import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class parseJsonArray {
	
	public static void main(String[] args) throws JSONException {
		
		
		String json = "[{\"name\":\"Sharat\",\"url\":\"url1\"},{\"name\":\"name2\",\"url\":\"url2\"}]";
		
		JSONArray jsonarray = new JSONArray(json);
		for (int i = 0; i < jsonarray.length(); i++) {
		    JSONObject jsonobject = jsonarray.getJSONObject(i);
		    String name = jsonobject.getString("name");
		    String url = jsonobject.getString("url");
		    
		    System.out.println("NAME ---> "+name);
		    System.out.println("URL ---> "+url);
		}
		
		
		
	}

}
