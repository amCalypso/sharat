package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DLocationRepository;
import com.epsilon.dcrm.db.repository.DProfileAddressRepository;
import com.epsilon.dcrm.db.repository.DTransactionHeaderRepository;
import com.epsilon.dcrm.db.repository.DvTransactionRepository;
import com.epsilon.dcrm.db.repository.MTransactionRepository;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.dimension.DimensionIndividual;
import com.epsilon.dcrm.model.dimension.DimensionIndividualAddress;
import com.epsilon.dcrm.model.dimension.DimensionLocation;
import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;
import com.epsilon.dcrm.model.dimension.DvTransaction;
import com.epsilon.dcrm.model.mart.MTransaction;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class MTransactionTest extends BaseTest {

    @Autowired
    private DLocationRepository dLocationRepo;

    @Autowired
    private DEmployeeRepository dEmployeeRepo;

    @Autowired
    private DIndividualAddressRepository dIndivAddressRepo;

    @Autowired
    private DProfileAddressRepository dProfAddrRepo;

    @Autowired
    private DIndividualRepository dIndivRepo;

    @Autowired
    private DTransactionHeaderRepository dTransactionRepo;

    @Autowired
    private DvTransactionRepository dvTransactionRepo;

    @Autowired
    private MTransactionRepository mTransactionRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final long EPOCH_MILLIS = Instant.now().toEpochMilli();
    private static final String BRAND_CD = "BRND1";
    private static final long FILE_ID = (long) Math.ceil(Math.random() * 10000);

    @BeforeClass
    public void setup() {
        dLocationRepo.insertSimpleTestRecord(RAND_STRING.substring(0, 5), RAND_STRING, FILE_ID, (long) (Math.random() * 1000), BRAND_CD);
        dEmployeeRepo.insertSimpleTestRecord(BRAND_CD, Long.toString(EPOCH_MILLIS));
        dIndivRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS - 100, FILE_ID);
        dIndivAddressRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, "road 1", "street 1", "area 1", "Anchorage", "Alask", "75000", "0000", "USA", FILE_ID, (long) (Math.random() * 1000));
        dProfAddrRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, FILE_ID, (long) (Math.random() * 1000));
        dTransactionRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, RAND_STRING.substring(0, 5), EPOCH_MILLIS);
    }

    @Rollback(false)
    @Test(groups = "M_Transaction")
    public void testMTransaction() {
        String filename = new StringBuilder().append("MTransactionAutomationTest_").append(RAND_STRING).toString();
        try {
            List<DimensionTransactionHeader> dTransactionRecords = dTransactionRepo.findByTxnNbr(RAND_STRING);
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION);
            List<DvTransaction> dvTransactionRecords = assertDvTransactionView(dTransactionRecords);
            assertMTransactionTable(dvTransactionRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    private void cleanUp() {
        dTransactionRepo.deleteByBrandCd(BRAND_CD);
        dLocationRepo.deleteByBrandCd(BRAND_CD);
        dEmployeeRepo.deleteByEmployeeId(Long.toString(EPOCH_MILLIS));
        dIndivAddressRepo.deleteByUpdateFileId(FILE_ID);
        dIndivRepo.deleteByIndivId(EPOCH_MILLIS);
        mTransactionRepo.deleteByTxnNbr(RAND_STRING);
    }

    private List<DvTransaction> assertDvTransactionView(List<DimensionTransactionHeader> dTransactionRecords) {
        List<DvTransaction> actualRecs = dvTransactionRepo.findByTxnNbr(RAND_STRING);
        List<DvTransaction> expectedRecs = new ArrayList<>();

        for (DimensionTransactionHeader dTrans : dTransactionRecords) {
            DvTransaction dimConvertedRec = new DvTransaction();
            BeanUtils.copyProperties(dTrans, dimConvertedRec);
            dimConvertedRec.setTxnBrandCd(dTrans.getBrandCd());
            dimConvertedRec.setBrandCd(dTrans.getBillBrandCd());
            dimConvertedRec.setIndivId(0L);

            List<DimensionLocation> dLocationRecords = dLocationRepo.findByLocationCd(dTrans.getSalesLocationCd());
            if (!dLocationRecords.isEmpty()) {
                dimConvertedRec.setDcrmLocationId(Long.valueOf(dLocationRecords.get(0).getDcrmLocationId()));
            }

            List<DimensionEmployee> dEmployeeRecords = dEmployeeRepo.findByEmployeeId(dTrans.getEmployeeId());
            if (!dEmployeeRecords.isEmpty()) {
                dimConvertedRec.setDcrmEmployeeId(Long.valueOf(dEmployeeRecords.get(0).getDcrmEmployeeId()));
            }

            List<DimensionIndividualAddress> dIndivAddrRecords = dIndivAddressRepo.findByIndivId(EPOCH_MILLIS);
            if (!dIndivAddrRecords.isEmpty()) {
                dimConvertedRec.setHholdId(dIndivAddrRecords.get(0).getHholdId());
                List<DimensionIndividual> dIndivRecords = dIndivRepo.findByIndivId(dIndivAddrRecords.get(0).getIndivId());
                if (!dIndivRecords.isEmpty()) {
                    dimConvertedRec.setIndivId(dIndivRecords.get(0).getCurrIndiv_id());
                }
            }
            expectedRecs.add(dimConvertedRec);

        }

        Collections.sort(expectedRecs);
        Collections.sort(actualRecs);

        assertEquals(actualRecs, expectedRecs, "Records in dv_transaction do not match with expected records");
        return actualRecs;
    }

    private void assertMTransactionTable(List<DvTransaction> dvTransactionRecords) throws ParseException {
        List<MTransaction> actualRecs = mTransactionRepo.findByTxnNbr(RAND_STRING);
        List<MTransaction> expectedRecs = new ArrayList<>();

        for (DvTransaction dvTransRecord : dvTransactionRecords) {
            MTransaction dvConvertedRec = new MTransaction();
            BeanUtils.copyProperties(dvTransRecord, dvConvertedRec);
            expectedRecs.add(dvConvertedRec);
        }

        Collections.sort(expectedRecs);
        Collections.sort(actualRecs);
        assertEquals(actualRecs, expectedRecs, "Records in m_transaction do not match with expected records");
    }

}