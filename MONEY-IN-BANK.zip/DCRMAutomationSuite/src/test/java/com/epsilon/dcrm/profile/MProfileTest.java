package com.epsilon.dcrm.profile;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DProfileAddressRepository;
import com.epsilon.dcrm.db.repository.DProfileAddressStandardRepository;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.DvProfileRepository;
import com.epsilon.dcrm.db.repository.MProfileRepository;
import com.epsilon.dcrm.model.dimension.DimensionIndividual;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.dimension.DimensionProfileAddress;
import com.epsilon.dcrm.model.dimension.DimensionProfileAddressStandard;
import com.epsilon.dcrm.model.dimension.DvProfile;
import com.epsilon.dcrm.model.mart.MProfile;
import com.epsilon.dcrm.objects.comparer.DvProfileComparer;
import com.epsilon.dcrm.objects.comparer.MProfileComparer;

@RunWith(SpringRunner.class)
public class MProfileTest extends BaseTest {

    private static final Long FILE_ID = 1645L;
    private static final String BRAND_CD = "A1645";
    private static final String SRC_ACCT_NBR = "rec-1";
    private static final String ACTIVE_ADDR_IND = "1";

    @Autowired
    private DProfileRepository dProfileRepo;

    @Autowired
    private DProfileAddressStandardRepository dProfileAddressStandardRepo;

    @Autowired
    private DIndividualAddressRepository dIndivAddressRepo;

    @Autowired
    private DProfileAddressRepository dProfAddrRepo;

    @Autowired
    private DIndividualRepository dIndividualRepo;

    @Autowired
    private DvProfileRepository dvProfileRepo;

    @Autowired
    private MProfileRepository mProfileRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.M_PROFILE_TEST_DATA_LOAD, false);
    }

    @Rollback(false)
    @Test(groups = "M_Profile")
    public void testMProfile() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("MProfileAutomationTest_").append(testId).toString();
        try {
            List<DimensionProfile> dProfileRecords = dProfileRepo.findByBrandCd(BRAND_CD);
            for (DimensionProfile dProfileRecord : dProfileRecords) {
                if (SRC_ACCT_NBR.equals(dProfileRecord.getAcctSrcNbr())) {
                    dProfileAddressStandardRepo.insertTestRecord(dProfileRecords.get(0).getDcrmProfileId());
                }
            }
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_PROFILE);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_PROFILE);
            // Assertions
            List<DvProfile> dvProfileRecords = assertdvProfileView(dProfileRecords);
            assertMProfileTable(dvProfileRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    private void cleanUp() {
        dProfileRepo.deleteByBrandCd(BRAND_CD);
        dProfileAddressStandardRepo.deleteByUpdateFileId(FILE_ID);
        dIndivAddressRepo.deleteByUpdateFileId(FILE_ID);
        dIndividualRepo.deleteByUpdateFileId(FILE_ID);
        mProfileRepo.deleteByBrandCd(BRAND_CD);
        dProfAddrRepo.deleteByUpdateFileId(FILE_ID);
    }

    private List<DvProfile> assertdvProfileView(List<DimensionProfile> dProfileRecords) {
        List<DvProfileComparer> dvProfileComparerExpextedRecords = new ArrayList<DvProfileComparer>();
        List<DvProfileComparer> dvProfileComparerActualRecords = new ArrayList<DvProfileComparer>();

        for (DimensionProfile dProfileRecord : dProfileRecords) {
            DvProfileComparer rec = new DvProfileComparer();
            BeanUtils.copyProperties(dProfileRecord, rec);

            List<DimensionProfileAddressStandard> dProfileAddressStandardRecords = dProfileAddressStandardRepo.findByDcrmProfileId(dProfileRecord.getDcrmProfileId());
            if (!dProfileAddressStandardRecords.isEmpty()) {
                BeanUtils.copyProperties(dProfileAddressStandardRecords.get(0), rec);
                rec.setProfileAddressDcrmProfileId(dProfileAddressStandardRecords.get(0).getDcrmProfileId());
            }
            List<DimensionProfileAddress> dProfileAddressRecords = dProfAddrRepo.selectActiveProfileAddressRecords(ACTIVE_ADDR_IND, dProfileRecord.getBrandCd(), dProfileRecord.getAcctSrcCd(), dProfileRecord.getAcctSrcNbr());
            assertEquals(dProfileAddressRecords.size(), 1, String.format("Did not match expected record count in d_profile_Address table. Actual - %s, Expected - %s", dProfileAddressRecords.size(), 1));

            List<DimensionIndividual> dIndividualRecords = dIndividualRepo.findByIndivId(dProfileAddressRecords.get(0).getIndivId());
            assertEquals(dIndividualRecords.size(), 1, String.format("Did not match expected record count in d_individual table. Actual - %s, Expected - %s", dIndividualRecords.size(), 1));

            rec.setIndivAddressBrandCd(dProfileAddressRecords.get(0).getBrandCd());
            rec.setIndivAddressAcctSrcCd(dProfileAddressRecords.get(0).getAcctSrcCd());
            rec.setIndivAddressSrcAcctNbr(dProfileAddressRecords.get(0).getSrcAcctNbr());
            rec.setIndivAddressIndivId(new Long(dProfileAddressRecords.get(0).getIndivId()));
            rec.setCurrIndivId(new Long(dIndividualRecords.get(0).getCurrIndiv_id()));
            dvProfileComparerExpextedRecords.add(rec);

        }

        List<DvProfile> dvProfileRecords = dvProfileRepo.findByBrandCd(BRAND_CD);
        for (DvProfile dvProfileRecord : dvProfileRecords) {
            DvProfileComparer rec = new DvProfileComparer();
            BeanUtils.copyProperties(dvProfileRecord, rec);
            dvProfileComparerActualRecords.add(rec);
        }

        Collections.sort(dvProfileComparerExpextedRecords);
        Collections.sort(dvProfileComparerActualRecords);
        assertEquals(dvProfileComparerActualRecords, dvProfileComparerExpextedRecords, "Records in dv_profile do not match with expected records");

        return dvProfileRecords;
    }

    private void assertMProfileTable(List<DvProfile> dvProfileRecords) throws ParseException {
        List<MProfile> mProfileRecords = mProfileRepo.findByBrandCd(BRAND_CD);
        List<MProfileComparer> mprofileComparerExpectedRecords = new ArrayList<MProfileComparer>();
        List<MProfileComparer> mprofileComparerActualRecords = new ArrayList<MProfileComparer>();
        for (MProfile mProfileRecord : mProfileRecords) {
            MProfileComparer rec = new MProfileComparer();
            BeanUtils.copyProperties(mProfileRecord, rec);
            mprofileComparerActualRecords.add(rec);
        }

        for (DvProfile dvProfileRecord : dvProfileRecords) {
            MProfileComparer rec = new MProfileComparer();
            BeanUtils.copyProperties(dvProfileRecord, rec);
            if (dvProfileRecord.getGaId() != null) {
                rec.setGaId(new Long(dvProfileRecord.getGaId()));
            }
            rec.setIndivId(dvProfileRecord.getCurrIndivId());
            mprofileComparerExpectedRecords.add(rec);
        }

        Collections.sort(mprofileComparerExpectedRecords);
        Collections.sort(mprofileComparerActualRecords);
        assertEquals(mprofileComparerActualRecords, mprofileComparerExpectedRecords, "Records in m_profile do not match with expected records");

    }

}
