package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefRecencyRepository;
import com.epsilon.dcrm.db.repository.MRefRecencyRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefRecency;
import com.epsilon.dcrm.model.mart.MRefRecency;
import com.epsilon.dcrm.objects.csv.RefRecency;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class MRefRecencyTest extends BaseTest {

    @Autowired
    private DRefRecencyRepository dRepo;

    @Autowired
    private MRefRecencyRepository mRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final Long CREATE_FILE_ID = (long) (Math.random() * 1000);
    private static final String RECENCY_CD = "RT9";//Refers to RefRecencyTest

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_RECENCY_CREATE, false);
        dRepo.insertTestData(RECENCY_CD, RAND_STRING.substring(0, 20), RAND_STRING, 3L, 6L, CREATE_FILE_ID, (long) Math.random() * 1000);
    }

    @Test
    public void testMartLoad() {
        String filename = new StringBuilder().append("MRefRecencyTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_RECENCY);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_RECENCY);
            assertData();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            dRepo.deleteByCreateFileId(CREATE_FILE_ID);
            mRepo.deleteById(RECENCY_CD);
        }
    }

    private void assertData() {
        MRefRecency mRec = mRepo.findByRecencyCd(RECENCY_CD);
        assertNotNull(mRec, "Null from mart refmonetary table");

        List<MRefRecency> mRecs = new ArrayList<>();
        mRecs.add(mRec);

        List<DimensionRefRecency> dRecs = dRepo.findByCreateFileId(CREATE_FILE_ID);
        assertNotNull(dRecs, "Null from dimension refrecency table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension refrecency table.");

        List<RefRecency> convertedDRecs = CopyUtil.convertRefRecencyDRecs(dRecs);
        List<RefRecency> convertedMRecs = CopyUtil.convertRefRecencyMRecs(mRecs);

        assertEquals(convertedMRecs, convertedDRecs, "MRecords donot match with DRecords for RefRecency");

    }

}
