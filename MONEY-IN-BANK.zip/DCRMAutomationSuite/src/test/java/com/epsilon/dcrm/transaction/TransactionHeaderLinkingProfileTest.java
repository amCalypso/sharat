package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.DTransactionHeaderRepository;
import com.epsilon.dcrm.db.repository.ProfileHashRepository;
import com.epsilon.dcrm.db.repository.SProfileRepository;
import com.epsilon.dcrm.db.repository.STransactionHeaderRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.ProfileHash;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.model.standard.StandardTransactionHeader;
import com.epsilon.dcrm.objects.MatillionJobAttributes;
import com.epsilon.dcrm.objects.MatillionWorkflowAttributes;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionHeaderComparer;
import com.epsilon.dcrm.objects.csv.TransactionHeader;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.properties.TransactionHeaderLinkingProfileTestScenarios;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;
import com.epsilon.dcrm.util.FormatUtil;
import com.epsilon.dcrm.util.JsonUtil;
import com.epsilon.dcrm.util.TestUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class TransactionHeaderLinkingProfileTest extends AbstractTransactionalTestNGSpringContextTests {
    private static final Logger logger = LoggerFactory.getLogger(TransactionHeaderLinkingProfileTest.class);

    @Autowired
    private TransactionHeaderLinkingProfileTestScenarios testScenarios;

    @Autowired
    private FrmsService testService;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private STransactionHeaderRepository sRepo;

    @Autowired
    private DTransactionHeaderRepository dRepo;

    @Autowired
    private SProfileRepository sProfRepository;

    @Autowired
    private DProfileRepository dProfRepository;

    @Autowired
    private ProfileHashRepository profHashRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> txnNbrs = new ArrayList<String>();
    private List<Long> fileIds = new ArrayList<Long>();
    private List<String> piiHashVals = new ArrayList<>();

    @Autowired
    private MessagePoller messagePoller;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_PROFILE_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_HEADER_TABLE, false);
        executeSqlScript(CommonConstants.CREATE_REFERENCE_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_HASH_TABLE, false);
        executeSqlScript(CommonConstants.REF_TABLE_DATA_LOAD, false);
        dProfRepository.deleteByRecSrcCd(CommonConstants.REC_SRC_CD_BILLTO);
    }

    @AfterGroups(alwaysRun = true, groups = { "Transaction_Header_LinkingProfile" })
    @Rollback(false)
    public void afterTestCleanup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(txnNbrs)) {
                for (String txnNbr : txnNbrs) {
                    dRepo.deleteByTxnNbr(txnNbr);
                    sRepo.deleteByTxnNbr(txnNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                logger.info("FileId used to delete records from tables  - {}", fileId);
                dRepo.deleteByCreateFileId(fileId);
                dProfRepository.deleteByCreateFileId(fileId);
                clearStandardTables(fileId);
            }
        }

        if (!CollectionUtils.isEmpty(piiHashVals)) {
            for (String piiHashVal : piiHashVals) {
                logger.info("piiHashVal used to delete records from tables  - {}", piiHashVal);
                profHashRepo.deleteByPiiHashVal(piiHashVal);
            }
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 1 - Tri-part key present (new transaction, new profile)")
    /**
     * Scenario 1 - Tri-part key present (new profile)
     * Expected :
     * -- New record in the m_hash_profile table
     * -- New record in s_profile and d_profile table
     * -- New record in d_transaction table. 
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario1() throws IOException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 1);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableUpdate(csvRecords);
            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);
            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 2 - Tri-part key present (new transaction, existing profile and later activity date)", dependsOnMethods = "testTransactionHeaderLinkingProfile_Scenario1")
    /**
     * Scenario 2 - Tri-part key present (new transaction, existing profile and later activity date) -- updated the first name
     * Expected :
     * -- Update record in the m_hash_profile table
     * -- New record in s_profile 
     * -- Update record in d_profile table
     * -- New record in d_transaction table. 
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario2() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 2);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableUpdate(csvRecords);
            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 3 - Tri-part key present (new transaction, existing profile and past activity date)", dependsOnMethods = "testTransactionHeaderLinkingProfile_Scenario2")
    /**
     * Scenario 3 - Tri-part key present (new transaction, existing profile and past activity date)
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No record in s_profile 
     * -- No updates to d_profile
     * -- New record in d_transaction table. 
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario3() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 3);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableNoUpdate(csvRecords);
            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));

            assertEquals(sProfileRecords.size(), 0,
                    String.format("Profile records found in s_profile table for create_file_id - %s. Not expected to ahve records in the table since activity date is past date.", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 4 - Tri-part key present (existing profile and empty PII)", dependsOnMethods = "testTransactionHeaderLinkingProfile_Scenario3")
    /**
     * Scenario 4 - Tri-part key present (existing profile and empty PII)
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No record in s_profile 
     * -- No updates to d_profile
     * -- New record in d_transaction table. 
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario4() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 4);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableNoUpdate(csvRecords);
            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));
            assertEquals(sProfileRecords.size(), 0,
                    String.format("Profile records found in s_profile table for create_file_id - %s ", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 5 - Tri-part key not present (new transaction, existing profile(matching PII found))", dependsOnMethods = "testTransactionHeaderLinkingProfile_Scenario2")
    /**
     * Scenario 5 - Tri-part key not present (new transaction, existing profile(matching PII found))
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No new record in s_profile 
     * -- Update record in s_transaction_header (srcAcctNbr to the srcAcctNbr of the matching PII from the hash table)
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario5() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 5);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            // There is only one record in test data
            String generatedHash = generateHash(csvRecords.get(0));
            piiHashVals.add(generatedHash);
            ProfileHash pHash = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(csvRecords.get(0).getBrandCd(), csvRecords.get(0).getBillAcctSrcCd(), generatedHash);
            assertNotNull(pHash, String.format("No record found in m_profile_hash table for srcCd - %s , brandCd - %s and piiHashVal - %s.", csvRecords.get(0).getBillAcctSrcCd(), csvRecords.get(0).getBrandCd(), generatedHash));
            csvRecords.get(0).setBillAcctSrcNbr(pHash.getSrcAcctNbr()); // Expected. Next steps would make sure csv data compares with the DB data.

            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));
            assertEquals(sProfileRecords.size(), 0, String.format("No Profile records from s_profile table for create_file_id - %s ", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_LinkingProfile", description = "Scenario 6 - Tripart key not present (new transaction, Matching profile(PII) not found)")
    /**
     * Scenario 6 - Tripart key not present (new transaction, Matching profile(PII) not found)
     * Expected :
     * -- New record in m_hash_profile table (srcAcctNbr being the piiHashVal)
     * -- New record in s_profile 
     * -- New record in d_profile
     * -- Update record in s_transaction_header (srcAcctNbr to the srcAcctNbr of the matching PII from the hash table)
     * -- New record in d_transaction table. 
     * @throws IOException
     */
    public void testTransactionHeaderLinkingProfile_Scenario6() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_HEADER_LINKPROF).append(testId).toString();

        try {
            List<TransactionHeader> csvRecords = startProcess(filename, 6);
            Long fileId = pollForMessages(filename);

            // Assertions begin
            // There is only one record in test data
            String generatedHash = generateHash(csvRecords.get(0));
            piiHashVals.add(generatedHash);

            ProfileHash pHash = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(csvRecords.get(0).getBrandCd(), csvRecords.get(0).getBillAcctSrcCd(), generatedHash);
            assertNotNull(pHash, String.format("No record found in m_profile_hash table for srcCd - %s , brandCd - %s and piiHashVal - %s.", csvRecords.get(0).getBillAcctSrcCd(), csvRecords.get(0).getBrandCd(), generatedHash));
            assertEquals(pHash.getPiiHashVal(), generatedHash, String.format("Hash value not equal. Expected - %s. Actual- %s", generatedHash, pHash.getPiiHashVal()));
            assertEquals(pHash.getSrcAcctNbr(), generatedHash, String.format("SrcAcctNbr not equal. Expected - %s. Actual- %s", generatedHash, pHash.getSrcAcctNbr()));

            csvRecords.get(0).setBillAcctSrcNbr(pHash.getSrcAcctNbr()); // Expected. Next steps would make sure csv data compares with the DB data.

            assertTransHeaderTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    private void clearStandardTables(Long fileId) {
        sRepo.deleteByCreateFileId(fileId);
        sProfRepository.deleteByCreateFileId(fileId);
    }

    private String generateHash(TransactionHeader record) throws NoSuchAlgorithmException {
        return TestUtil.generateMd5Hashvalue(
                record.getSrcFirstNm(),
                record.getSrcMiddleNm(),
                record.getSrcLastNm(),
                record.getSrcUnparsedNm(),
                record.getSrcBusinessNm(),
                record.getSrcAddrLine1(),
                record.getSrcAddrLine2(),
                record.getSrcAddrLine3(),
                record.getSrcAddrLine4(),
                record.getSrcCity(),
                record.getSrcState(),
                record.getPostalCd(),
                record.getSrcCountry(),
                record.getSrcCountryCd(),
                record.getEmailAddr(),
                record.getPhoneNbr());
    }

    private void assertCreateFileFields_CreateFlow(List<DimensionTransactionHeader> dimTranRecords) {
        for (DimensionTransactionHeader dimTranRecord : dimTranRecords) {
            assertEquals(dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId(),
                    String.format("CreateFileId and UpdateFileId does not match in DTransactionHeader table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId()));
            assertEquals(dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr(),
                    String.format("CreateRecNbr and UpdateRecNbr does not match in DTransactionHeader table . Actual - %s, Expected - %s", dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr()));
        }
    }

    private void assertStandardTableData(List<TransactionHeader> csvRecords, List<StandardTransactionHeader> dbRecords) throws ParseException {
        List<TransactionHeader> convertedStandardTransactionHeaderRecords = CopyUtil.convertStandardTransactionHeader(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardTransactionHeaderRecords, csvRecords, "STransactionHeader records donot match with test data");
    }

    private void assertDimensionTransHdrTableData(List<TransactionHeader> csvRecords, List<DimensionTransactionHeader> dimTranRecords) throws ParseException {
        List<DimensionTransactionHeaderComparer> convertedDimensionTransactionHeaderRecords = CopyUtil.convertDimensionTransactionHeader(dimTranRecords);

        List<DimensionTransactionHeaderComparer> convertedTransactionHeaderCsvRecords = new ArrayList<DimensionTransactionHeaderComparer>();
        for (TransactionHeader record : csvRecords) {
            DimensionTransactionHeaderComparer rec = new DimensionTransactionHeaderComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setBillBrandCd(record.getBrandCd());
            rec.setLocationBrandCd(record.getBrandCd());

            convertedTransactionHeaderCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedDimensionTransactionHeaderRecords, convertedTransactionHeaderCsvRecords, "DTransactionHeader records donot match with STransactionHeader records");
    }

    protected <T> void uploadDataFile(String filename, List<T> csvRecords) throws IOException {
        byte[] bytes = CSVUtil.getCsv(csvRecords).getBytes();
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
        byteArrayInputStream.close();
    }

    private List<TransactionHeader> startProcess(String filename, int scenario) throws IOException, ApplicationException, NoSuchAlgorithmException {
        List<TransactionHeader> csvRecords = Arrays.asList(
                CSVUtil.getObject(testScenarios.getScenario().get(scenario), TransactionHeader.class));
        assertNotNull(csvRecords, "Empty list of records from test csv");
        assertEquals(csvRecords.size(), 1, String.format("Test data count does not match. Expected - %s. Actual - %s", 1, csvRecords.size()));

        for (TransactionHeader record : csvRecords) {
            String generatedHash = generateHash(record);
            piiHashVals.add(generatedHash); // For cleanup later 
            if (scenario == 1) {
                // Clear the hash table for the very first test
                profHashRepo.deleteBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getBillAcctSrcCd(), record.getBillAcctSrcNbr());
            }
        }

        uploadDataFile(filename, csvRecords);
        testService.testEnable(CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_HEADER_WITH_PII);

        return csvRecords;
    }

    private void pollForProfileRefreshMessage(String filename) throws ApplicationException {
        // Poll SQS for the Success/Failure message
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_PII, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
    }

    private Long pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        Long fileId = null;
        messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_LDC, sqsUrl, 20);
        // assertEquals(pollFrmsMessageLDC.size(), 2, String.format("FRMS LDC polled message count. Expected - %s, Actual - %s", pollFrmsMessageLDC.size(), 2));
        //List<MessageDetails> pollFrmsMessageAWS = messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_AWS, sqsUrl, 50);
        //assertEquals(pollFrmsMessageAWS.size(), 2, String.format("FRMS AWS polled message count. Expected - %s, Actual - %s", pollFrmsMessageAWS.size(), 2));
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_TRANSACTION, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc()) && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            assertNotNull(pollMatillionMessage.getSrcSystem(), "Matiilion message object is null");
            assertNotNull(pollMatillionMessage.getSrcSystem().getData(), "Null SRCSytem from Matillion");
            MatillionWorkflowAttributes attributes = JsonUtil.getObject(pollMatillionMessage.getSrcSystem().getData(), MatillionWorkflowAttributes.class);
            assertNotNull(attributes, "Null Workflow attributes from matillion");
            List<MatillionJobAttributes> subJobs = attributes.getSubJobs();
            assertNotNull(subJobs, "Subjobs null from matillion");
            boolean jobPresent = subJobs.stream().anyMatch(item -> CommonConstants.MATILLION_JOB_NAME_LOAD_S_TRANSHDR_AND_S_PROFILE.equals(item.getJobName()));
            // The job should not be present for a Transaction Header feed when there is no PII update.
            assertTrue(jobPresent, "Matillion did not invoke Profile associated workflows for feed with PII update");

            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    private void assertProfileHashTableUpdate(List<TransactionHeader> csvRecords) throws NoSuchAlgorithmException, ParseException {
        // Assertions for profile_hash table.
        for (TransactionHeader record : csvRecords) {
            String generatedHash = generateHash(record);
            ProfileHash hashRecordInDB = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getBillAcctSrcCd(), record.getBillAcctSrcNbr());
            Timestamp activityTs = FormatUtil.getTimestampFromString(record.getActivityTs(), CommonConstants.TIMESTAMP_FORMAT);

            assertNotNull(hashRecordInDB, String.format("Null Hash Profile record in DB for brandCd - %s, acctSrcCd - %s, acctSrcNbr - %s", record.getBrandCd(), record.getBillAcctSrcCd(), record.getBillAcctSrcNbr()));
            assertEquals(hashRecordInDB.getPiiHashVal(), generatedHash, String.format("Hash value not equal. Expected - %s. Actual- %s", generatedHash, hashRecordInDB.getPiiHashVal()));
            assertEquals(hashRecordInDB.getActivityts(), activityTs, String.format("Activity timestamp not equal. Expected - %s. Actual- %s", activityTs, hashRecordInDB.getActivityts()));
        }
    }

    private void assertProfileHashTableNoUpdate(List<TransactionHeader> csvRecords) throws NoSuchAlgorithmException, ParseException {
        // Assertions for profile_hash table.
        for (TransactionHeader record : csvRecords) {
            String generatedHash = generateHash(record);
            ProfileHash hashRecordInDB = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getBillAcctSrcCd(), record.getBillAcctSrcNbr());
            Timestamp activityTs = FormatUtil.getTimestampFromString(record.getActivityTs(), CommonConstants.TIMESTAMP_FORMAT);

            assertNotNull(hashRecordInDB, String.format("Null Hash Profile record in DB for brandCd - %s, acctSrcCd - %s, acctSrcNbr - %s", record.getBrandCd(), record.getBillAcctSrcCd(), record.getBillAcctSrcNbr()));
            if (generatedHash.equals(hashRecordInDB.getPiiHashVal())) {
                assertTrue(false, String.format("Hash value equal. Should not get updated since activity date is a past date"));
            }
            if (activityTs.equals(hashRecordInDB.getActivityts())) {
                assertTrue(false, String.format("Activity timestamp value equal. Should not get updated since activity date is a past date"));
            }
        }
    }

    private void assertTransHeaderTables(List<TransactionHeader> csvRecords, Long fileId) throws ParseException {
        List<StandardTransactionHeader> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionTransactionHeader> dimTranRecords = dRepo.findByCreateFileId(fileId);
        assertNotNull(dimTranRecords, String.format("Null object for TransactionHeader records from d_transaction table for fileId - %s", fileId));
        assertDimensionTransHdrTableData(csvRecords, dimTranRecords);

        assertCreateFileFields_CreateFlow(dimTranRecords);

    }

    private void assertProfileTables(List<TransactionHeader> csvRecords, Long fileId) {
        List<DimensionProfile> dProfilerecords = dProfRepository.findByUpdateFileId(fileId);
        List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);

        assertNotNull(dProfilerecords, String.format("Null object for Profile records from d_profile table for fileId - %s", fileId));
        assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for fileId - %s", fileId));

        // There is only one record in test data 
        assertEquals(dProfilerecords.size(), 1, String.format("No Profile records from d_profile table for fileId - %s", fileId));
        assertEquals(sProfileRecords.size(), 1, String.format("No Profile records from s_profile table for fileId - %s", fileId));

        StandardProfile sProfileRec = sProfileRecords.get(0);
        assertNotNull(sProfileRec);

        assertEquals(sProfileRec.getRecSrcCd(), CommonConstants.REC_SRC_CD_BILLTO, String.format("REC_SRC_CD field not populated with expected value - %s. Found - %s", CommonConstants.REC_SRC_CD_BILLTO, sProfileRec.getRecSrcCd()));
        assertEquals(sProfileRec.getBrandCd(), csvRecords.get(0).getBrandCd(), String.format("BRAND_CD field not populated with expected value - %s. Found - %s", csvRecords.get(0).getBrandCd(), sProfileRec.getBrandCd()));
        assertEquals(sProfileRec.getAcctSrcCd(), csvRecords.get(0).getBillAcctSrcCd(), String.format("ACCT_SRC_CD field not populated with expected value - %s. Found - %s", csvRecords.get(0).getBillAcctSrcCd(), sProfileRec.getAcctSrcCd()));
        assertEquals(sProfileRec.getAcctSrcNbr(), csvRecords.get(0).getBillAcctSrcNbr(), String.format("SRC_ACCT_NBR field not populated with expected value - %s. Found - %s", csvRecords.get(0).getBillAcctSrcNbr(), sProfileRec.getAcctSrcNbr()));

        assertEquals(CopyUtil.partialConvertSProfile(sProfileRecords), CopyUtil.partialConvertDProfile(dProfilerecords), "Dprofile and SProfile records do not match.");
    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }
}
