package com.epsilon.dcrm.individual;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DvIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.MIndividualAddressRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DvIndividualAddress;
import com.epsilon.dcrm.model.mart.MIndividualAddress;
import com.epsilon.dcrm.objects.MatillionJobTriggerSQSMessage;
import com.epsilon.dcrm.objects.MatillionVariables;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.MIndividualAddressComparer;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.service.SQSService;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class IndividualAddressTest extends AbstractTransactionalTestNGSpringContextTests {

    private static final Long FILE_ID = 1024L;
    private static final String BRAND_CD = "TEST";

    @Autowired
    private MessagePoller messagePoller;

    @Autowired
    private SQSService sqsService;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Value("${matillion.sqs.url}")
    private String matillionSqsUrl;

    @Autowired
    private DIndividualRepository dIndivRepo;

    @Autowired
    private DIndividualAddressRepository dIndivAddrRepo;

    @Autowired
    private DvIndividualAddressRepository dvIndivAddrRepo;

    @Autowired
    private MIndividualAddressRepository mIndivAddrRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.INDIVIDUAL_ADDRESS_TEST_DATA_LOAD, false);
    }

    @Rollback(false)
    @Test(groups = "IndividualAddress")
    public void testIndividualAddress() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("IndividualAddressAutomationTest_").append(testId).toString();
        Long dcrmIndivAddrId = null;
        try {
            triggerMatillionJob(filename);
            pollForMessages(filename);
            // Assertions
            List<DvIndividualAddress> dvIndividualAddressRecords = assertIndividualAddressView();
            dcrmIndivAddrId = getDcrmIndivAddrId();
            assertMIndividualAddressTable(dvIndividualAddressRecords, dcrmIndivAddrId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(dcrmIndivAddrId);
        }
    }

    private Long assertMIndividualAddressTable(List<DvIndividualAddress> dvIndividualAddressRecords, Long dcrmIndivAddrId) throws ParseException {

        List<MIndividualAddress> mIndivAddrRecords = mIndivAddrRepo.findByDcrmIndivAddrId(dcrmIndivAddrId);
        assertEquals(mIndivAddrRecords.size(), 1, "more than 1 record in m_individual_address table");
        MIndividualAddress mIndivAddrRecord = mIndivAddrRecords.get(0);
        MIndividualAddressComparer mIndividualAddressComparerRecord = new MIndividualAddressComparer();
        BeanUtils.copyProperties(mIndivAddrRecord, mIndividualAddressComparerRecord);

        List<MIndividualAddressComparer> dvIndivAddrComparerRecords = new ArrayList<MIndividualAddressComparer>();

        for (DvIndividualAddress record : dvIndividualAddressRecords) {
            MIndividualAddressComparer rec = new MIndividualAddressComparer();
            BeanUtils.copyProperties(record, rec);
            dvIndivAddrComparerRecords.add(rec);
        }
        Collections.sort(dvIndivAddrComparerRecords);
        assertEquals(dvIndivAddrComparerRecords.size(), 2);
        MIndividualAddressComparer dvIndivAddrComparerRecord = dvIndivAddrComparerRecords.get(1);

        assertEquals(mIndividualAddressComparerRecord, dvIndivAddrComparerRecord, "m_indivual_address record do not match with test data");
        return dcrmIndivAddrId;

    }

    private Long getDcrmIndivAddrId() {
        // TODO get latest record instead of sorting and fetching - Deepika - refactor
        //TODO update according to current individual address columns
        /* List<DimensionIndividualAddress> dIndivAddressRecords = dIndivAddrRepo.findByBrandCd(BRAND_CD);
        //Assert the two individual address records added
        assertEquals(dIndivAddressRecords.size(), 2);
        Collections.sort(dIndivAddressRecords);
        DimensionIndividualAddress dimIndivAddressRecord = dIndivAddressRecords.get(1);
        assertNotNull(dimIndivAddressRecord, "d_individual_address record is null");
        return dimIndivAddressRecord.getDcrmIndivAddrId();*/
        return null;
    }

    private List<DvIndividualAddress> assertIndividualAddressView() {
        //TODO update according to current individual address columns
        /* List<DimensionIndividualAddress> dIndividualAddressRecords = dIndivAddrRepo.findByBrandCd(BRAND_CD);
        List<DvIndivAddrComparer> dIndivAddrComparerRecords = new ArrayList<DvIndivAddrComparer>();
        List<DvIndivAddrComparer> dvIndivAddrComparerRecords = new ArrayList<DvIndivAddrComparer>();
        
        for (DimensionIndividualAddress record : dIndividualAddressRecords) {
            DvIndivAddrComparer rec = new DvIndivAddrComparer();
            BeanUtils.copyProperties(record, rec);
            List<DimensionIndividual> dIndiviualRecords = dIndivRepo.findByIndivId(record.getIndivId());
            assertEquals(dIndiviualRecords.size(), 1, "more than 1 record in d_individual table");
            DimensionIndividual dIndiviualRecord = dIndiviualRecords.get(0);
            assertNotNull(dIndiviualRecord, "d_Individual record is null");
            rec.setIndivId(dIndiviualRecord.getCurrIndiv_id());
            dIndivAddrComparerRecords.add(rec);
        }
        Collections.sort(dIndivAddrComparerRecords);
        
        List<DvIndividualAddress> dvIndivAddrRecords = dvIndivAddrRepo.findByBrandCd(BRAND_CD);
        
        for (DvIndividualAddress record : dvIndivAddrRecords) {
            DvIndivAddrComparer rec = new DvIndivAddrComparer();
            BeanUtils.copyProperties(record, rec);
            dvIndivAddrComparerRecords.add(rec);
        }
        Collections.sort(dvIndivAddrComparerRecords);
        
        assertEquals(dvIndivAddrComparerRecords, dIndivAddrComparerRecords, "dv_individual_address records donot match with test data");
        
        return dvIndivAddrRecords;*/
        return null;
    }

    private void pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_ADDRESS, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        assertTrue(CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus()), "Refresh-M_Individual_Summary Matillion job failed");
    }

    private void triggerMatillionJob(String filename) {
        MatillionVariables variable = MatillionVariables.builder().fileName(filename).build();
        MatillionJobTriggerSQSMessage sqsMessage = MatillionJobTriggerSQSMessage.builder().group("DCRM").project("dcrm-main").version("default").job(CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_ADDRESS)
                .environment("Test").variables(variable).build();
        sqsService.postMessageToSQS(sqsMessage, matillionSqsUrl);
    }

    private void cleanUp(Long dcrmIndivAddrId) {
        dIndivAddrRepo.deleteByUpdateFileId(FILE_ID);
        dIndivRepo.deleteByUpdateFileId(FILE_ID);
        mIndivAddrRepo.deleteByDcrmIndivAddrId(dcrmIndivAddrId);

    }

}
