package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefRecencyRepository;
import com.epsilon.dcrm.db.repository.SRefRecencyRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefRecency;
import com.epsilon.dcrm.model.standard.StandardRefRecency;
import com.epsilon.dcrm.objects.csv.RefRecency;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class RefRecencyTest extends BaseTest {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/RefRecencyAutomation.txt";
    private static final Logger logger = LoggerFactory.getLogger(RefRecencyTest.class);

    @Autowired
    private SRefRecencyRepository sRepo;

    @Autowired
    private DRefRecencyRepository dRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_RECENCY_CREATE, false);
    }

    @AfterGroups(alwaysRun = true, groups = { "RefRecency" })
    public void afterGroup() {
        if (!CollectionUtils.isEmpty(fileIds)) {
            for (Long fileId : fileIds) {
                logger.info("FileId being used for deletion - {} ", fileId);
                sRepo.deleteByCreateFileId(fileId);
                dRepo.deleteByCreateFileId(fileId);
            }
        }

    }

    @Rollback(false)
    @Test(groups = "RefRecency")
    public void testRefRecency_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("RefRecencyAutomation_Create_").append(testId).toString();
        try {
            List<RefRecency> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, RefRecency.class, null);

            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_DATA_CONVERT_REF_RECENCY);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_D_REF_RECENCY);

            // Assertions
            assertData(fileId, csvRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {

        }
    }

    private void assertData(Long fileId, List<RefRecency> csvRecs) {

        Collections.sort(csvRecs);

        List<StandardRefRecency> sRecs = sRepo.findByCreateFileId(fileId);
        assertNotNull(sRecs, "Null from staging RefRecency table");
        assertNotEquals(sRecs.size(), 0, "Found 0 records in staging RefRecency table.");

        List<RefRecency> convertedSRecs = CopyUtil.convertRefRecencySRecs(sRecs);
        assertEquals(convertedSRecs, csvRecs, "SRecords donot match with test data for RefRecency");

        List<DimensionRefRecency> dRecs = dRepo.findByCreateFileId(fileId);
        assertNotNull(dRecs, "Null from dimension RefRecency table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension RefRecency table.");

        List<RefRecency> convertedDRecs = CopyUtil.convertRefRecencyDRecs(dRecs);
        assertEquals(convertedDRecs, convertedSRecs, "DRecords donot match with SRecords for RefRecency");

        assertAuditFields(fileId, dRecs);

    }

    private void assertAuditFields(Long fileId, List<DimensionRefRecency> dRecs) {
        for (DimensionRefRecency dRec : dRecs) {
            assertNotNull(dRec.getCreateFileId(), "Null from dimension RefRecency table for CreateFileId");
            assertEquals(dRec.getCreateFileId(), fileId, "CreateFileId and FIleId from FRMS donot match");
            assertNotNull(dRec.getCreateTs(), "Null from dimension RefRecency table for CreateTs");
        }
    }

}
