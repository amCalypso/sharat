package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.util.CollectionUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.util.IOUtils;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DTransactionAdjustmentRepository;
import com.epsilon.dcrm.db.repository.STransactionAdjustmentRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionTransactionAdjustment;
import com.epsilon.dcrm.model.standard.StandardTransactionAdjustment;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionAdjustmentComparer;
import com.epsilon.dcrm.objects.csv.TransactionAdjustment;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class TransactionAdjustmentTest extends AbstractTransactionalTestNGSpringContextTests {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/TransactionAdjustmentAutomationTestStandard_Create.txt";
    private static final String DATA_FILE_PATH_STANDARD = "processing/inbound/TransactionAdjustmentAutomationTestStandard";
    private static final String DATA_FILE_PATH_STANDARD_DATA = "processing/inbound/data.Automation_Transaction_Adjustment_Standard";
    private static final String DATA_FILE_PATH_STANDARD_SCHEMA = "processing/inbound/schema.Automation_Transaction_Adjustment_Standard";

    @Autowired
    private FrmsService testService;

    @Autowired
    private MessagePoller messagePoller;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private STransactionAdjustmentRepository sRepo;

    @Autowired
    private DTransactionAdjustmentRepository dRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> txnNbrs = new ArrayList<String>();

    private List<Long> fileIds = new ArrayList<Long>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_ADJUSTMENT_TABLES, false);
    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Transaction_Adjustment_Standard", "Transaction_Adjustment_Custom" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(txnNbrs)) {
                for (String txnNbr : txnNbrs) {
                    dRepo.deleteByTxnNbr(txnNbr);
                    sRepo.deleteByTxnNbr(txnNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                dRepo.deleteByCreateFileId(fileId);
            }
        }
    }

    // @AfterMethod
    public void afterTestCleanup(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_DATA);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_SCHEMA);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Adjustment_Standard")
    public void testTransactionAdjustmentRecord_Standard_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("TransactionAdjustmentAutomationTestStandard_Create_").append(testId).toString();
        try {
            List<TransactionAdjustment> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE);
            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ADJUSTMENT);
            Long fileId = pollForMessages(filename);
            // Assertions
            assertTransAdjustmentTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    //@Test(groups = "Transaction_Adjustment_Custom")
    public void testTransactionAdjustmentRecord_Custom_Create() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        // TODO - Future
    }

    private List<TransactionAdjustment> readTestData(String filename, String filepath) throws IOException {
        List<TransactionAdjustment> csvRecords = CSVUtil.readStaticFile(TransactionAdjustment.class, filepath, true);
        assertNotNull(csvRecords, "Empty list of records from test csv");
        assertNotEquals(csvRecords.size(), 0, String.format("Found 0 records in test data."));
        for (TransactionAdjustment record : csvRecords) {
            txnNbrs.add(record.getTxnNbr());
        }
        Collections.sort(csvRecords);
        return csvRecords;
    }

    private void startProcess(String filename, String filePath, String workFlowId) throws IOException {
        uploadDataFile(filename, filePath);
        testService.testEnable(workFlowId);
    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }

    private Long pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        Long fileId = null;
        messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_LDC, sqsUrl, 20);
        // assertEquals(pollFrmsMessageLDC.size(), 2, String.format("FRMS LDC polled message count. Expected - %s, Actual - %s", pollFrmsMessageLDC.size(), 2));
        //List<MessageDetails> pollFrmsMessageAWS = messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_AWS, sqsUrl, 50);
        //assertEquals(pollFrmsMessageAWS.size(), 2, String.format("FRMS AWS polled message count. Expected - %s, Actual - %s", pollFrmsMessageAWS.size(), 2));
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_TRANSACTION_ADJUSTMENT, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc()) && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    private void assertTransAdjustmentTables(List<TransactionAdjustment> csvRecords, Long fileId) throws ParseException {
        List<StandardTransactionAdjustment> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionTransactionAdjustment> dimTranRecords = dRepo.findByCreateFileId(fileId);
        assertDimensionTableData(csvRecords, dimTranRecords);
        assertCreateFileFields_CreateFlow(dimTranRecords);

    }

    private void assertCreateFileFields_CreateFlow(List<DimensionTransactionAdjustment> dimTranRecords) {
        for (DimensionTransactionAdjustment dimTranRecord : dimTranRecords) {
            assertEquals(dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId(),
                    String.format("D-UpdateFileId does not match with D-CreateFileId. Actual - %s, Expected - %s", dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId()));
            assertEquals(dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr(),
                    String.format("D-UpdateRecNbr does not match with D-CreateRecNbr. Actual - %s, Expected - %s", dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr()));
        }
    }

    private void assertStandardTableData(List<TransactionAdjustment> csvRecords, List<StandardTransactionAdjustment> dbRecords) throws ParseException {
        List<TransactionAdjustment> convertedStandardTransactionAdjustmentRecords = CopyUtil.convertStandardTransactionAdjustment(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardTransactionAdjustmentRecords, csvRecords, "STransactionAdjustment records donot match with test data");

    }

    private void assertDimensionTableData(List<TransactionAdjustment> csvRecords, List<DimensionTransactionAdjustment> dimTranRecords) throws ParseException {
        List<DimensionTransactionAdjustmentComparer> convertedDimensionTransactionAdjustmentRecords = CopyUtil.convertDimensionTransactionAdjustment(dimTranRecords);

        List<DimensionTransactionAdjustmentComparer> convertedTransactionAdjustmentCsvRecords = new ArrayList<DimensionTransactionAdjustmentComparer>();
        for (TransactionAdjustment record : csvRecords) {
            DimensionTransactionAdjustmentComparer rec = new DimensionTransactionAdjustmentComparer();
            BeanUtils.copyProperties(record, rec);

            convertedTransactionAdjustmentCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedDimensionTransactionAdjustmentRecords, convertedTransactionAdjustmentCsvRecords, "DTransactionAdjustment records don't match with STransactionAdjustment records");

    }

    private void uploadDataFile(String filename, String path) throws IOException {
        InputStream dataStream = TransactionAdjustmentTest.class.getResourceAsStream(path);
        byte[] bytes = IOUtils.toByteArray(dataStream);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
    }
}
