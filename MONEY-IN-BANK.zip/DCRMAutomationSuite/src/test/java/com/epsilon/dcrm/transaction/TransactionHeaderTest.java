package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DLocationRepository;
import com.epsilon.dcrm.db.repository.DTransactionHeaderRepository;
import com.epsilon.dcrm.db.repository.STransactionHeaderRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.dimension.DimensionLocation;
import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;
import com.epsilon.dcrm.model.standard.StandardTransactionHeader;
import com.epsilon.dcrm.objects.comparer.DimensionEmployeeComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionHeaderComparer;
import com.epsilon.dcrm.objects.csv.TransactionHeader;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class TransactionHeaderTest extends BaseTest {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/TransactionHeaderAutomationTestStandard_Create.txt";
    private static final String BRAND_CD = "TAuto";
    private static final String LOCATION_CD = "scd1";
    private static final String EXISTING_EMPLOYEE_ID = "64d99f6b-883c-4857-b";
    private static final String INVALID_CURRENCY_CD = "1LG";
    private static final String UNKNOWN_CURRENCY_CD = "U";
    private static final String EMPLOYMENT_STATUS_CD = "~";
    private static final String LOCATION_CD_PLACEHOLDER = "~";

    @Autowired
    private STransactionHeaderRepository sRepo;

    @Autowired
    private DTransactionHeaderRepository dRepo;

    @Autowired
    private DEmployeeRepository dEmployeeRepo;

    @Autowired
    private DLocationRepository dLocationRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> txnNbrs = new ArrayList<>();

    private List<Long> fileIds = new ArrayList<>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_HEADER_TABLE, false);
        executeSqlScript(CommonConstants.CREATE_EMPLOYEE_TABLES, false);
        executeSqlScript(CommonConstants.TRANSACTION_FEED_NEW_EMPLOYEE_TEST_DATA_LOAD, false);
    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Transaction_Header_Standard" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(txnNbrs)) {
                for (String txnNbr : txnNbrs) {
                    dRepo.deleteByTxnNbr(txnNbr);
                    sRepo.deleteByTxnNbr(txnNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                dRepo.deleteByCreateFileId(fileId);
            }
        }
        dEmployeeRepo.deleteByBrandCd(BRAND_CD);
        dLocationRepo.deleteByBrandCdAndLocationCd(BRAND_CD, LOCATION_CD);
    }

    @Rollback(false)
    @Test(groups = "Transaction_Header_Standard")
    public void testTransactionHeaderRecord_Standard_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("TransactionHeaderAutomationTestStandard_Create_").append(testId).toString();
        try {
            List<TransactionHeader> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, TransactionHeader.class, null);
            Collections.sort(csvRecords);
            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_HEADER_WITHOUT_PII_UPDATE);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_TRANSACTION);
            // Assertions
            assertTransHeaderTables(csvRecords, fileId);
            assertNewEmployeeIds(csvRecords, fileId);
            assertNewLocationCds(fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    // @Test(groups = "Transaction_Header_Custom")
    public void testTransactionHeaderRecord_Custom_Create() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        // TODO - Future
    }

    private void assertTransHeaderTables(List<TransactionHeader> csvRecords, Long fileId) throws ParseException {
        List<StandardTransactionHeader> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionTransactionHeader> dimTranRecords = dRepo.findByCreateFileId(fileId);
        assertDimensionTableData(csvRecords, dimTranRecords);

        assertCreateFileFields_CreateFlow(dimTranRecords);

    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }

    private void assertCreateFileFields_CreateFlow(List<DimensionTransactionHeader> dimTranRecords) {
        for (DimensionTransactionHeader dimTranRecord : dimTranRecords) {
            assertEquals(dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId(),
                    String.format("CreateFileId and UpdateFileId does not match in DTransactionHeader table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId()));
            assertEquals(dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr(),
                    String.format("CreateRecNbr and UpdateRecNbr does not match in DTransactionHeader table . Actual - %s, Expected - %s", dimTranRecord.getCreateRecNbr(), dimTranRecord.getUpdateRecNbr()));
        }
    }

    private void assertStandardTableData(List<TransactionHeader> csvRecords, List<StandardTransactionHeader> dbRecords) throws ParseException {
        List<TransactionHeader> convertedStandardTransactionHeaderRecords = CopyUtil.convertStandardTransactionHeader(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardTransactionHeaderRecords, csvRecords, "STransactionHeader records donot match the test data.");

    }

    private void assertDimensionTableData(List<TransactionHeader> csvRecords, List<DimensionTransactionHeader> dimTranRecords) throws ParseException {
        List<DimensionTransactionHeaderComparer> convertedDimensionTransactionHeaderRecords = CopyUtil.convertDimensionTransactionHeader(dimTranRecords);

        List<DimensionTransactionHeaderComparer> convertedTransactionHeaderCsvRecords = new ArrayList<DimensionTransactionHeaderComparer>();
        for (TransactionHeader record : csvRecords) {
            DimensionTransactionHeaderComparer rec = new DimensionTransactionHeaderComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setBillBrandCd(record.getBrandCd());
            rec.setLocationBrandCd(record.getBrandCd());
            rec.setCurrencyCd(INVALID_CURRENCY_CD.equals(record.getCurrencyCd()) ? UNKNOWN_CURRENCY_CD : record.getCurrencyCd());

            convertedTransactionHeaderCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedDimensionTransactionHeaderRecords, convertedTransactionHeaderCsvRecords, "DTransactionHeader records do not match test data.");

    }

    private void assertNewEmployeeIds(List<TransactionHeader> csvRecords, Long fileId) {
        List<DimensionEmployee> dimEmpRecords = dEmployeeRepo.findByBrandCd(BRAND_CD);
        assertEquals(dimEmpRecords.size(), 3, String.format("Did not match expected record count in d_employee table. Actual - %s, Expected - %s", dimEmpRecords.size(), 2));
        dimEmpRecords = dEmployeeRepo.findByCreateFileId(fileId);

        List<DimensionEmployeeComparer> expectedDimEmployeeComparerRecords = new ArrayList<DimensionEmployeeComparer>();
        List<DimensionEmployeeComparer> actualDimEmployeeComparerRecords = new ArrayList<DimensionEmployeeComparer>();

        for (DimensionEmployee record : dimEmpRecords) {
            DimensionEmployeeComparer rec = new DimensionEmployeeComparer();
            BeanUtils.copyProperties(record, rec);

            actualDimEmployeeComparerRecords.add(rec);
        }
        for (TransactionHeader record : csvRecords) {
            if (!EXISTING_EMPLOYEE_ID.equals(record.getEmployeeId())) {
                DimensionEmployeeComparer rec = new DimensionEmployeeComparer();
                rec.setEmployeeId(record.getEmployeeId());
                rec.setBrandCd(record.getBrandCd());
                rec.setEmploymentStatusCd(EMPLOYMENT_STATUS_CD);
                expectedDimEmployeeComparerRecords.add(rec);
            }
        }

        assertEquals(actualDimEmployeeComparerRecords, expectedDimEmployeeComparerRecords, String.format("Records in d_employee do not match with test data for fileId - %s", fileId));
        assertTrackingFieldsForNewDEmployeeRecords(dimEmpRecords);

    }

    private void assertNewLocationCds(Long fileId) {
        // get a new record from the source table
        List<DimensionTransactionHeader> dimTranRecords = dRepo.findByLocationBrandCdAndSalesLocationCd(BRAND_CD, LOCATION_CD);
        // get a new record from the target table and test that there are no duplicates
        List<DimensionLocation> dimLocationRecords = dLocationRepo.findByBrandCdAndLocationCd(BRAND_CD, LOCATION_CD);
        assertEquals(dimLocationRecords.size(), 1, String.format("Wrong number of records in the target d_location table (brand_cd=%s, location_cd=%s). Actual - %s, Expected - %s", BRAND_CD, LOCATION_CD, dimLocationRecords.size(), 1));
        // validate the new location in d_location table
        assertNotNull(dimLocationRecords.get(0).getDcrmLocationId(), "Empty dcrm_location_id in the d_location table");
        assertNotNull(dimLocationRecords.get(0).getCreateTs(), "Empty create_ts in the d_location table");
        assertEquals(dimLocationRecords.get(0).getBrandCd(), dimTranRecords.get(0).getLocationBrandCd(),
                String.format("Invalid d_location.brand_cd. Actual - %s, Expected - %s", dimLocationRecords.get(0).getBrandCd(), dimTranRecords.get(0).getLocationBrandCd()));
        assertEquals(dimLocationRecords.get(0).getLocationCd(), dimTranRecords.get(0).getSalesLocationCd(),
                String.format("Invalid d_location.location_cd. Actual - %s, Expected - %s", dimLocationRecords.get(0).getLocationCd(), dimTranRecords.get(0).getSalesLocationCd()));
        assertEquals(dimLocationRecords.get(0).getCreateFileId(), dimTranRecords.get(0).getCreateFileId(),
                String.format("Invalid d_location.create_file_id. Actual - %d, Expected - %d", dimLocationRecords.get(0).getCreateFileId(), dimTranRecords.get(0).getCreateFileId()));
        assertEquals(dimLocationRecords.get(0).getCreateRecNbr(), dimTranRecords.get(0).getCreateRecNbr(),
                String.format("Invalid d_location.create_rec_nbr. Actual - %d, Expected - %d", dimLocationRecords.get(0).getCreateRecNbr(), dimTranRecords.get(0).getCreateRecNbr()));
        assertEquals(dimLocationRecords.get(0).getLocationNm(), "Unknown location: " + dimTranRecords.get(0).getSalesLocationCd(),
                String.format("Invalid d_location.create_file_nm. Actual - %s, Expected - %s", dimLocationRecords.get(0).getLocationNm(), "Unknown location: " + dimTranRecords.get(0).getSalesLocationCd()));
        assertEquals(dimLocationRecords.get(0).getLocationTypeDsc(), LOCATION_CD_PLACEHOLDER,
                String.format("Invalid d_location.location_type_dsc. Actual - %s, Expected - %s", dimLocationRecords.get(0).getLocationTypeDsc(), LOCATION_CD_PLACEHOLDER));
    }

    private void assertTrackingFieldsForNewDEmployeeRecords(List<DimensionEmployee> dimEmpRecords) {
        for (DimensionEmployee dimEmpRecord : dimEmpRecords) {
            assertEquals(dimEmpRecord.getCreateFileId(), dimEmpRecord.getUpdateFileId(),
                    String.format("D-UpdateFileId does not match with D-CreateFileId. Actual - %s, Expected - %s", dimEmpRecord.getCreateFileId(), dimEmpRecord.getUpdateFileId()));
            assertEquals(dimEmpRecord.getCreateFileRecNbr(), dimEmpRecord.getUpdateRecNbr(),
                    String.format("D-UpdateRecNbr does not match with D-CreateRecNbr. Actual - %s, Expected - %s", dimEmpRecord.getCreateFileRecNbr(), dimEmpRecord.getUpdateRecNbr()));
            assertEquals(dimEmpRecord.getCreateTs(), dimEmpRecord.getUpdateTs(),
                    String.format("D-UpdateTs does not match with D-CreateTs. Actual - %s, Expected - %s", dimEmpRecord.getCreateTs(), dimEmpRecord.getUpdateTs()));
            assertNotNull(dimEmpRecord.getActivityTs(), "Activity_Ts is null");
        }
    }

}