package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefFrequencyRepository;
import com.epsilon.dcrm.db.repository.MRefFrequencyRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefFrequency;
import com.epsilon.dcrm.model.mart.MRefFrequency;
import com.epsilon.dcrm.objects.csv.RefFrequency;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class MRefFrequencyTest extends BaseTest {

    @Autowired
    private DRefFrequencyRepository dRepo;

    @Autowired
    private MRefFrequencyRepository mRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final Long CREATE_FILE_ID = (long) (Math.random() * 1000);
    private static final String FREQUENCY_CD = "RFT";//Refers to RefFrequencyTest

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_FREQUENCY_CREATE, false);
        dRepo.insertTestData(FREQUENCY_CD, RAND_STRING.substring(0, 20), RAND_STRING, 0, 0, CREATE_FILE_ID, 1L);
    }

    @Test
    public void testMartLoad() {
        String filename = new StringBuilder().append("MRefFrequencyTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_FREQUENCY);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_FREQUENCY);
            assertData();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            dRepo.deleteByCreateFileId(CREATE_FILE_ID);
            mRepo.deleteById(FREQUENCY_CD);
        }
    }

    private void assertData() {
        MRefFrequency mRec = mRepo.findByFrequencyCd(FREQUENCY_CD);
        assertNotNull(mRec, "Null from mart refFrequency table");

        List<MRefFrequency> mRecs = new ArrayList<>();
        mRecs.add(mRec);

        List<DimensionRefFrequency> dRecs = dRepo.findByCreateFileId(CREATE_FILE_ID);
        assertNotNull(dRecs, "Null from dimension refFrequency table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension refFrequency table.");

        List<RefFrequency> convertedDRecs = CopyUtil.convertRefFrequencyDRecs(dRecs);
        List<RefFrequency> convertedMRecs = CopyUtil.convertRefFrequencyMRecs(mRecs);

        assertEquals(convertedMRecs, convertedDRecs, "MRecords donot match with DRecords for RefFrequency");

    }
}
