package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefCustLifeCycleRepository;
import com.epsilon.dcrm.db.repository.MRefCustLifeCycleRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefCustLifeCycle;
import com.epsilon.dcrm.model.mart.MRefCustLifeCycle;
import com.epsilon.dcrm.objects.csv.RefCustLifeCycle;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class MRefCustLifeCycleTest extends BaseTest {

    @Autowired
    private DRefCustLifeCycleRepository dRepo;

    @Autowired
    private MRefCustLifeCycleRepository mRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final Long CREATE_FILE_ID = (long) (Math.random() * 1000);
    private static final String CUST_LIFECYCLE_CD = "RLT";//Refers to RefCustLifecycleTest

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_CUST_LIFECYCLE_CREATE, false);
        dRepo.insertTestData(CUST_LIFECYCLE_CD, RAND_STRING.substring(0, 20), RAND_STRING, CREATE_FILE_ID, 1L);
    }

    @Test
    public void testMartLoad() {
        String filename = new StringBuilder().append("MRefCustLifecycleTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_CUSTOMER_LIFECYCLE);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_CUSTOMER_LIFECYCLE);
            assertData();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            dRepo.deleteByCreateFileId(CREATE_FILE_ID);
            mRepo.deleteById(CUST_LIFECYCLE_CD);
        }
    }

    private void assertData() {
        MRefCustLifeCycle mRec = mRepo.findByCustLifeCycleCd(CUST_LIFECYCLE_CD);
        assertNotNull(mRec, "Null from mart refcustlifecycle table");

        List<MRefCustLifeCycle> mRecs = new ArrayList<>();
        mRecs.add(mRec);

        List<DimensionRefCustLifeCycle> dRecs = dRepo.findByCreateFileId(CREATE_FILE_ID);
        assertNotNull(dRecs, "Null from dimension refcustlifecycle table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension refCustLifecycle table.");

        List<RefCustLifeCycle> convertedDRecs = CopyUtil.convertRefCustLifeCycleRecs(dRecs, DimensionRefCustLifeCycle.class);
        List<RefCustLifeCycle> convertedMRecs = CopyUtil.convertRefCustLifeCycleRecs(mRecs, MRefCustLifeCycle.class);

        assertEquals(convertedMRecs, convertedDRecs, "MRecords donot match with DRecords for RefCustLifecycle");

    }
}
