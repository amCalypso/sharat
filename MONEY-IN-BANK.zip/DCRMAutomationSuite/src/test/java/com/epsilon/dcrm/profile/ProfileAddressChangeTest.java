package com.epsilon.dcrm.profile;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.util.CollectionUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.util.IOUtils;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.SProfileAddressChangeRepository;
import com.epsilon.dcrm.db.repository.SProfileRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.model.standard.StandardProfileAddressChange;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.DimensionCPCOAProfileComparer;
import com.epsilon.dcrm.objects.comparer.StandardCPCOAProfileComparer;
import com.epsilon.dcrm.objects.csv.ProfileAddressChange;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class ProfileAddressChangeTest extends AbstractTransactionalTestNGSpringContextTests {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/ProfileAddressChange_AutomationTestStandard_Create.txt";
    private static final String DATA_FILE_PATH_STANDARD = "processing/inbound/ProfileAddressChange_AutomationTestStandard";
    private static final String DATA_FILE_PATH_STANDARD_DATA = "processing/inbound/data.Automation_ProfileAddressChange_Standard";
    private static final String DATA_FILE_PATH_STANDARD_SCHEMA = "processing/inbound/schema.Automation_ProfileAddressChange_Standard";

    @Autowired
    private FrmsService frmsService;

    @Autowired
    private MessagePoller messagePoller;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private SProfileAddressChangeRepository sRepo;

    @Autowired
    private SProfileRepository standardProfileRepository;

    @Autowired
    private DProfileRepository dimensionProfileRepository;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> acctSrcNbrs = new ArrayList<String>();

    private List<Long> fileIds = new ArrayList<Long>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_PROFILE_ADDRESS_CHANGE_TABLES, false);
    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Profile_Address_Change_Standard" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(acctSrcNbrs)) {
                for (String acctSrcNbr : acctSrcNbrs) {
                    sRepo.deleteByAcctSrcNbr(acctSrcNbr);
                    standardProfileRepository.deleteByAcctSrcNbr(acctSrcNbr);
                    dimensionProfileRepository.deleteByAcctSrcNbr(acctSrcNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                dimensionProfileRepository.deleteByCreateFileId(fileId);
            }
        }
    }

    @AfterMethod
    public void afterTestCleanup(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_DATA);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_SCHEMA);
        }
    }

    @Rollback(false)
    @Test(groups = "Profile_Address_Change_Standard")
    public void testProfileAddressChange_Standard_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("ProfileAddressChange_AutomationTestStandard_Create")
                .append(testId).toString();
        try {
            List<ProfileAddressChange> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE);
            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE,
                    CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_PROFILE_ADDRESS_CHANGE);
            Long fileId = pollForMessages(filename);
            // Assertions 			
            //for standard ProfileAddressChange table
            assertProfileAddressChangeStandardTable(csvRecords, fileId);
            //for standard Profile table
            assertProfileStandardTable(csvRecords, fileId);
            //for dimension Profile table
            assertProfileDimensionTableData(csvRecords, fileId, true);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    private List<ProfileAddressChange> readTestData(String filename, String filepath) throws IOException {
        List<ProfileAddressChange> csvRecords = CSVUtil.readStaticFile(ProfileAddressChange.class, filepath, true);
        assertNotNull(csvRecords, "Empty list of records from test csv");
        assertNotEquals(csvRecords.size(), 0, String.format("Found 0 records in test data."));
        for (ProfileAddressChange record : csvRecords) {
            acctSrcNbrs.add(record.getAcctSrcNbr());
        }
        Collections.sort(csvRecords);
        return csvRecords;
    }

    private void startProcess(String filename, String filePath, String workFlowId) throws IOException {
        uploadDataFile(filename, filePath);
        frmsService.testEnable(workFlowId);
    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }

    private Long pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        Long fileId = null;
        messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_LDC, sqsUrl,
                20);
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename,
                CommonConstants.MATILLION_JOB_NAME_REFRESH_PROFILE_ADDRESS_CHANGE, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matillion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc())
                && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS
                        .equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    private void assertProfileAddressChangeStandardTable(List<ProfileAddressChange> csvRecords, Long fileId)
            throws ParseException {
        List<StandardProfileAddressChange> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);
    }

    private void assertStandardTableData(List<ProfileAddressChange> csvRecords, List<StandardProfileAddressChange> dbRecords) throws ParseException {
        List<ProfileAddressChange> convertedStandardProfileAddressChangeRecords = CopyUtil.convertStandardProfileAddressChange(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardProfileAddressChangeRecords, csvRecords, "SProfileAddressChange records donot match with test data");
    }

    private void assertProfileStandardTable(List<ProfileAddressChange> csvRecords, Long fileId) throws ParseException {
        List<StandardProfile> dbRecords = standardProfileRepository.findByCreateFileId(fileId);
        List<StandardCPCOAProfileComparer> convertedStandardProfileDbRecords = CopyUtil.convertStandardCPCOAProfile(dbRecords);
        List<StandardCPCOAProfileComparer> convertedPartialProfileCsvRecords = CopyUtil.convertCPCOAProfileCvs(csvRecords);
        assertEquals(convertedStandardProfileDbRecords, convertedPartialProfileCsvRecords, "s_profile records do not match with test data");
    }

    private void assertProfileDimensionTableData(List<ProfileAddressChange> csvRecords, Long fileId, boolean isCreateFlow) throws ParseException {

        List<DimensionProfile> dimProfileRecords = dimensionProfileRepository.findByUpdateFileId(fileId);
        List<DimensionCPCOAProfileComparer> convertedDimensionProfileRecords = CopyUtil.convertDimensionCPCOAProfile(dimProfileRecords);
        List<DimensionCPCOAProfileComparer> convertedPartialProfileCsvRecords = CopyUtil.convertCPCOADimProfileCvs(csvRecords);
        assertEquals(convertedDimensionProfileRecords, convertedPartialProfileCsvRecords, "d_profile records do not match with test data");
        if (isCreateFlow) {
            assertCreateFileFields_CreateFlow(dimProfileRecords);
        }

    }

    private void assertCreateFileFields_CreateFlow(List<DimensionProfile> dimProfileRecords) {
        for (DimensionProfile dimRecord : dimProfileRecords) {
            assertEquals(dimRecord.getCreateFileId(), dimRecord.getUpdateFileId(),
                    String.format("D-UpdateFileId does not match with D-CreateFileId. Actual - %s, Expected - %s", dimRecord.getCreateFileId(), dimRecord.getUpdateFileId()));
            assertEquals(dimRecord.getCreateFileRecNbr(), dimRecord.getUpdateRecNbr(),
                    String.format("D-UpdateRecNbr does not match with D-CreateRecNbr. Actual - %s, Expected - %s", dimRecord.getCreateFileRecNbr(), dimRecord.getUpdateRecNbr()));
        }
    }

    private void uploadDataFile(String filename, String path) throws IOException {
        InputStream dataStream = ProfileAddressChangeTest.class.getResourceAsStream(path);
        byte[] bytes = IOUtils.toByteArray(dataStream);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(
                new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
    }
}
