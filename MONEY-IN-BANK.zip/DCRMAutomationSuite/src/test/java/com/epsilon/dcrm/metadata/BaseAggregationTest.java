package com.epsilon.dcrm.metadata;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.model.loyalty.Aggregate;
import com.epsilon.dcrm.model.loyalty.AggregationDetail;
import com.epsilon.dcrm.model.loyalty.GroupByColumn;
import com.epsilon.dcrm.model.loyalty.TableColumn;
import com.epsilon.dcrm.service.LoyaltyService;

public class BaseAggregationTest extends BaseTest {

    @Autowired
    protected LoyaltyService loyaltyService;

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    enum AGGREGATE {
        COUNT,
        SUM,
        MIN,
        MAX,
        AVG
    }

    protected static final String DROP_TABLE = "drop table if exists {0}.{1}";
    protected static final String SELECT_STMT = "select * from {0}.{1}";
    protected static final String RAND_STRING = UUID.randomUUID().toString();
    protected static final Random RAND = new Random();
    protected static final int RAND_DOUBLE_PRECISION = 2;
    protected static final int RAND_MAX_INT = 1000;
    protected List<String> tableIds = new ArrayList<>();
    protected List<String> aggregationIds = new ArrayList<>();
    protected List<String> tableNames = new ArrayList<>();
    protected List<String> sourceTableRowIds = new ArrayList<>();

    /**
     * Check to makes sure we got the expected number of columns and that the column names are correct.
     * Checking the data will happen for each test as it can change.
     * @param aggDetail
     * @return
     */
    protected List<Map<String, Object>> assertColumns(AggregationDetail aggDetail) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                MessageFormat.format(SELECT_STMT, aggDetail.getTargetSchema(), aggDetail.getTargetSqlTableName()));

        assertTrue(rows.size() > 0, "Zero rows returned from target table.");

        // All rows will have the same number of columns so just get the first row.
        long actualColumnCount = rows.get(0).entrySet().stream().count();

        Set<String> expectedColumns = new HashSet<>();
        expectedColumns.addAll(aggDetail.getAggregates().stream()
                .map(agg -> agg.getSqlName().toUpperCase())
                .collect(Collectors.toSet()));
        expectedColumns.addAll(aggDetail.getGroupByColumns().stream()
                .map(groupBy -> groupBy.getColumnSqlName().toUpperCase())
                .collect(Collectors.toSet()));

        Set<String> actualColumns = rows.get(0).keySet().stream()
                .map(String::toUpperCase)
                .collect(Collectors.toSet());

        long expectedColumnCount = aggDetail.getAggregates().size() + aggDetail.getGroupByColumns().size();
        assertEquals(expectedColumnCount, actualColumnCount, "Column count mismatch");
        assertTrue(expectedColumns.containsAll(actualColumns), "Column name mismatch");
        return rows;
    }

    /**
     * Set minimal values needed to create columns for a Metadata Table.
     * @param name
     * @param columnType
     * @return
     */
    protected TableColumn createTestColumn(String name, String columnType) {
        TableColumn column = new TableColumn();
        column.setName(name);
        column.setSqlName(name);
        column.setDataType(columnType);
        return column;
    }

    /**
     * Build an AggregationDetail using the tableId, aggregate columns, and groupBy columns provided.
     * @param sourceTableId
     * @param aggregates
     * @param groupByColumns
     * @return
     */
    protected AggregationDetail buildAggregations(String sourceTableId, String targetSchema, String targetTable,
            List<Pair<String, AGGREGATE>> aggregates, String... groupByColumns) {
        AggregationDetail detail = new AggregationDetail();
        detail.setName(targetTable);
        detail.setSourceTableId(sourceTableId);
        detail.setTargetSchema(targetSchema);
        detail.setTargetSqlTableName(targetTable);
        detail.setGroupByColumns(buildGroupByColumns(groupByColumns));

        detail.setAggregates(new ArrayList<>());
        for (Pair<String, AGGREGATE> aggPair : aggregates) {
            detail.getAggregates().add(buildAggregate(aggPair.getLeft(), aggPair.getRight()));
        }
        detail = loyaltyService.createAggregation(detail);
        aggregationIds.add(detail.getAggregationId());
        tableNames.add(detail.getTargetSqlTableName());
        return detail;
    }

    /**
     * Create an aggregate on the aggregate column provided.  The tests should filter this list
     * if desired.
     * @param columnName
     * @param aggregateType
     * @return
     */
    protected Aggregate buildAggregate(String sourceColumn, AGGREGATE aggregateType) {
        String name = "generated_" + aggregateType + "_" + sourceColumn;
        return buildAggregate(sourceColumn, aggregateType, name);
    }

    /**
     * Create an aggregate on the aggregate column provided with the name provided.
     * @param columnName
     * @param aggregateTypes
     * @param targetColumnName
     * @return
     */
    protected Aggregate buildAggregate(String sourceColumn, AGGREGATE aggregateType, String targetColumn) {
        String name = targetColumn;
        Aggregate aggregate = new Aggregate();
        aggregate.setName(name);
        aggregate.setSqlName(name);
        aggregate.setAggregateType(aggregateType.toString());
        aggregate.setSourceSqlColumnName(sourceColumn);
        return aggregate;
    }

    /**
     * Build a list of group by columns to be applied to an AggregationDetail.
     * @param names
     * @return
     */
    protected List<GroupByColumn> buildGroupByColumns(String... names) {
        List<GroupByColumn> columns = new ArrayList<>();
        for (String name : names) {
            GroupByColumn column = new GroupByColumn();
            column.setColumnSqlName(name);
            columns.add(column);
        }
        return columns;
    }

    /**
     * Get a random double value.  This uses the RAND_MAX_INT and RAND_DOUBLE_PRECISION to return
     * a random floating point number such as 123333.12.
     * @return
     */
    protected double getRandDouble() {
        String randDouble = Double.toString(RAND.nextDouble()).substring(0, RAND_DOUBLE_PRECISION + 2);
        return RAND.nextInt(RAND_MAX_INT) + Double.valueOf(randDouble);
    }

    /**
     * Get a random element from the list provided.
     * @param elements
     * @return
     */
    protected <T> T randFromList(List<T> elements) {
        return elements.get(RAND.nextInt(elements.size()));
    }

}