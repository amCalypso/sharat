package com.epsilon.dcrm.household;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DHouseholdGoldenProfileRepository;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualEmailRepository;
import com.epsilon.dcrm.db.repository.DIndividualPhoneRepository;
import com.epsilon.dcrm.db.repository.DvHouseholdSummaryRepository;
import com.epsilon.dcrm.db.repository.MHouseholdSummaryRepository;
import com.epsilon.dcrm.model.dimension.DimensionHouseholdGoldenProfile;
import com.epsilon.dcrm.model.dimension.DimensionIndividualAddress;
import com.epsilon.dcrm.model.dimension.DimensionIndividualEmail;
import com.epsilon.dcrm.model.dimension.DimensionIndividualPhone;
import com.epsilon.dcrm.model.dimension.DvHouseholdSummary;
import com.epsilon.dcrm.model.mart.HouseholdSummary;
import com.epsilon.dcrm.objects.comparer.DvHouseholdSummaryComparer;
import com.epsilon.dcrm.objects.comparer.HouseholdSummaryComparer;
import com.epsilon.dcrm.util.FormatUtil;

@RunWith(SpringRunner.class)
public class HouseholdSummaryTest extends BaseTest {

    @Autowired
    private DIndividualAddressRepository dIndivAddrRepo;

    @Autowired
    private DIndividualEmailRepository dIndivEmailRepo;

    @Autowired
    private DIndividualPhoneRepository dIndivPhoneRepo;

    @Autowired
    private DHouseholdGoldenProfileRepository dHouseGoldenProfileRepo;

    @Autowired
    private DvHouseholdSummaryRepository dvHouseSummaryRepo;

    @Autowired
    private MHouseholdSummaryRepository mHouseSummaryRepo;

    private static final Long INDIV_ID = Instant.now().toEpochMilli();
    private static final Long FILE_ID = new Long((String.valueOf(INDIV_ID)).substring(0, 10));
    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final String BRAND_CD = "HholdSumTest";
    private static final String STATE_NM_ALASKA = "Alaska";
    private static final String STATE_CD_ALASKA = "US-AK";
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_HOUSEHOLD_SUMMARY_TABLES, false);
        dIndivAddrRepo.insertSimpleTestRecord(INDIV_ID, 1L, "road 1", "street 1", "area 1", "Anchorage", STATE_NM_ALASKA, "75000", "0000", "USA", FILE_ID, (long) (Math.random() * 1000));
        dIndivEmailRepo.insertSimpleTestRecord(INDIV_ID, "test@test.com", "Y", "Y", BRAND_CD, BRAND_CD, FILE_ID);
        dIndivPhoneRepo.insertSimpleTestRecord(RAND_STRING.substring(0, 9), FILE_ID);
    }

    @Rollback(false)
    @Test(groups = "HouseholdSummary")
    public void testHouseholdSummary() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("HouseholdSummaryAutomationTest_").append(testId).toString();
        try {
            Long dcrmIndivAddrId = getDcrmIndivAddrId();
            Long dcrmIndivEmailId = getDcrmIndivEmailId();
            Long dcrmIndivPhoneId = getDcrmIndivPhoneId();

            dHouseGoldenProfileRepo.insertTestRecordToHouseHoldGoldenProfile(2L, 2L, BRAND_CD, "HST", "HST", "HST", "HST",
                    Date.valueOf(LocalDate.now()), dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId, 2L);

            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_HOUSEHOLD_SUMMARY);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_HOUSEHOLD_SUMMARY);

            // Assertions
            List<DvHouseholdSummary> dvHouseholdSummaryRecords = assertHouseholdSummaryView(dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            assertMHouseholdSummaryTable(dvHouseholdSummaryRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    private void cleanUp() {
        dIndivAddrRepo.deleteByUpdateFileId(FILE_ID);
        dIndivEmailRepo.deleteByUpdateFileId(FILE_ID);
        dIndivPhoneRepo.deleteByUpdateFileId(FILE_ID);
        dHouseGoldenProfileRepo.deleteByBrandCd(BRAND_CD);
        mHouseSummaryRepo.deleteByBrandCd(BRAND_CD);
    }

    private Long getDcrmIndivAddrId() {
        List<DimensionIndividualAddress> dimIndivAddressRecords = dIndivAddrRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivAddressRecords.size(), 1);
        DimensionIndividualAddress dimIndivAddressRecord = dimIndivAddressRecords.get(0);
        assertNotNull(dimIndivAddressRecord, "DimensionIndividualAddress record is null");
        return dimIndivAddressRecord.getDcrmIndivAddrId();
    }

    private Long getDcrmIndivEmailId() {
        List<DimensionIndividualEmail> dimIndivEmailRecords = dIndivEmailRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivEmailRecords.size(), 1);
        DimensionIndividualEmail dimIndivEmailRecord = dimIndivEmailRecords.get(0);
        assertNotNull(dimIndivEmailRecord, "DimensionIndividualEmail record is null");
        return dimIndivEmailRecord.getDcrmIndivEmailId();
    }

    private Long getDcrmIndivPhoneId() {
        List<DimensionIndividualPhone> dimIndivPhoneRecords = dIndivPhoneRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivPhoneRecords.size(), 1);
        DimensionIndividualPhone dimIndivPhoneRecord = dimIndivPhoneRecords.get(0);
        assertNotNull(dimIndivPhoneRecord, "DimensionIndividualPhone record is null");
        return dimIndivPhoneRecord.getDcrmIndivPhoneId();
    }

    private List<DvHouseholdSummary> assertHouseholdSummaryView(Long dcrmIndivAddrId, Long dcrmIndivEmailId, Long dcrmIndivPhoneId) {
        List<DimensionHouseholdGoldenProfile> dHouseGoldenProfileRecords = dHouseGoldenProfileRepo.findByBrandCd(BRAND_CD);
        List<DvHouseholdSummaryComparer> dHouseGoldenProfileComparerRecords = new ArrayList<DvHouseholdSummaryComparer>();
        List<DvHouseholdSummaryComparer> dvHouseholdSummaryComparerRecords = new ArrayList<DvHouseholdSummaryComparer>();

        for (DimensionHouseholdGoldenProfile record : dHouseGoldenProfileRecords) {
            DvHouseholdSummaryComparer rec = new DvHouseholdSummaryComparer();
            BeanUtils.copyProperties(record, rec);

            if (record.getDcrmIndivAddrId() != null) {
                List<DimensionIndividualAddress> dimIndivAddrRecords = dIndivAddrRepo.findByDcrmIndivAddrId(dcrmIndivAddrId);
                assertEquals(dimIndivAddrRecords.size(), 1, "more than 1 record in d_individual_address table");
                DimensionIndividualAddress dimIndivAddressRecord = dimIndivAddrRecords.get(0);
                assertNotNull(dimIndivAddressRecord, "DimensionIndividualAddress record is null");
                rec.setAddrLine1(dimIndivAddressRecord.getAddrLine1());
                rec.setAddrLine2(dimIndivAddressRecord.getAddrLine2());
                rec.setAddrLine3(dimIndivAddressRecord.getAddrLine3());
                rec.setCityNm(dimIndivAddressRecord.getCityNm());
                rec.setPostalCd(dimIndivAddressRecord.getPostalCd());
                rec.setZip4(dimIndivAddressRecord.getZip4());
                rec.setStateCd(STATE_NM_ALASKA.equals(dimIndivAddressRecord.getStateNm()) ? STATE_CD_ALASKA : null);
                rec.setCountryCd(dimIndivAddressRecord.getCountryCd());
            }
            if (record.getDcrmIndivEmailId() != null) {
                List<DimensionIndividualEmail> dimIndivEmailRecords = dIndivEmailRepo.findByDcrmIndivEmailId(dcrmIndivEmailId);
                assertEquals(dimIndivEmailRecords.size(), 1, "more than 1 record in d_individual_email table");
                DimensionIndividualEmail dimIndivEmailRecord = dimIndivEmailRecords.get(0);
                assertNotNull(dimIndivEmailRecord, "DimensionIndividualEmail record is null");
                rec.setEmailAddr(dimIndivEmailRecord.getEmailAddr());
            }
            if (record.getDcrmIndivPhoneId() != null) {
                List<DimensionIndividualPhone> dimIndivPhoneRecords = dIndivPhoneRepo.findByDcrmIndivPhoneId(dcrmIndivPhoneId);
                assertEquals(dimIndivPhoneRecords.size(), 1, "more than 1 record in d_individual_phone table");
                DimensionIndividualPhone dimIndivPhoneRecord = dimIndivPhoneRecords.get(0);
                assertNotNull(dimIndivPhoneRecord, "DimensionIndividualPhone record is null");
                rec.setPhoneNbr(dimIndivPhoneRecord.getPhoneNbr());
            }
            dHouseGoldenProfileComparerRecords.add(rec);
        }
        Collections.sort(dHouseGoldenProfileComparerRecords);

        List<DvHouseholdSummary> dvHouseholdSummaryRecords = dvHouseSummaryRepo.findByBrandCd(BRAND_CD);
        for (DvHouseholdSummary record : dvHouseholdSummaryRecords) {
            DvHouseholdSummaryComparer rec = new DvHouseholdSummaryComparer();
            BeanUtils.copyProperties(record, rec);

            dvHouseholdSummaryComparerRecords.add(rec);
        }
        Collections.sort(dvHouseholdSummaryComparerRecords);

        assertEquals(dvHouseholdSummaryComparerRecords, dHouseGoldenProfileComparerRecords, "dv_household_summary records donot match with test data");
        return dvHouseholdSummaryRecords;
    }

    private void assertMHouseholdSummaryTable(List<DvHouseholdSummary> dvHouseholdSummaryRecords) throws ParseException {
        List<HouseholdSummary> householdSummayRecords = mHouseSummaryRepo.findByBrandCd(BRAND_CD);
        List<HouseholdSummaryComparer> dvHouseSummaryComparerRecords = new ArrayList<HouseholdSummaryComparer>();
        List<HouseholdSummaryComparer> houseSummaryComparerRecords = new ArrayList<HouseholdSummaryComparer>();

        for (DvHouseholdSummary record : dvHouseholdSummaryRecords) {
            HouseholdSummaryComparer rec = new HouseholdSummaryComparer();
            BeanUtils.copyProperties(record, rec);
            if (record.getBirthDt() != null) {
                String birthDate = FormatUtil.convertDate(record.getBirthDt(), DATE_FORMAT);
                rec.setBirthDay(new Integer(birthDate.substring(8, 10)));
                rec.setBirthMth(new Integer(birthDate.substring(5, 7)));
                rec.setBirthYr(new Integer(birthDate.substring(0, 4)));
            } else {
                DateFormat df = new SimpleDateFormat(DATE_FORMAT);
                Date birthDt = new java.sql.Date(df.parse("1900-01-01").getTime());
                rec.setBirthDt(birthDt);
                rec.setBirthDay(0);
                rec.setBirthMth(0);
                rec.setBirthYr(0);
            }
            dvHouseSummaryComparerRecords.add(rec);
        }

        Collections.sort(dvHouseSummaryComparerRecords);

        for (HouseholdSummary record : householdSummayRecords) {
            HouseholdSummaryComparer rec = new HouseholdSummaryComparer();
            BeanUtils.copyProperties(record, rec);
            houseSummaryComparerRecords.add(rec);
        }

        Collections.sort(houseSummaryComparerRecords);

        assertEquals(houseSummaryComparerRecords, dvHouseSummaryComparerRecords, "m_household_summary records do not match with test data");

        assertDefaultRecord();
    }

    private void assertDefaultRecord() {
        List<HouseholdSummary> householdSummaryRecords = mHouseSummaryRepo.findByBrandCd(CommonConstants.DEFAULT_RECORD_BRAND_CD);
        assertEquals(householdSummaryRecords.size(), 1, "m_household_summary has no default record");
        //assert hhold_id, indiv_id and dcrm_indiv_addr_id are zero for default record 
        assertEquals(householdSummaryRecords.get(0).getHHoldId().intValue(), 0, String.format("Default hhold_id - Expected 0. Found %s", householdSummaryRecords.get(0).getHHoldId().toString()));
        assertEquals(householdSummaryRecords.get(0).getIndivId().intValue(), 0, String.format("Default IndivId - Expected 0. Found %s", householdSummaryRecords.get(0).getIndivId().toString()));
        assertEquals(householdSummaryRecords.get(0).getDcrmIndivAddrId().intValue(), 0, String.format("Default DcrmIndivAddrId - Expected 0. Found %s", householdSummaryRecords.get(0).getDcrmIndivAddrId().toString()));

    }
}
