package com.epsilon.dcrm.employee;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.SEmployeeRepository;
import com.epsilon.dcrm.db.repository.SProfileRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.standard.StandardEmployee;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.DimensionEmployeeComparer;
import com.epsilon.dcrm.objects.comparer.EmployeeToProfilePartialComparer;
import com.epsilon.dcrm.objects.csv.Employee;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class EmployeeTest extends BaseTest {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/EmployeeAutomationTestStandard_Create.txt";
    private static final String DATA_FILE_PATH_STANDARD_UPDATE = "/files/EmployeeAutomationTestStandard_Update.txt";
    private static final String DATA_FILE_PATH_STANDARD = "processing/inbound/EmployeeAutomationTestStandard";
    private static final String DATA_FILE_PATH_STANDARD_DATA = "processing/inbound/data.Automation_Employee_Standard";
    private static final String DATA_FILE_PATH_STANDARD_SCHEMA = "processing/inbound/schema.Automation_Employee_Standard";

    @Autowired
    private SEmployeeRepository sRepo;

    @Autowired
    private DEmployeeRepository dRepo;

    @Autowired
    private SProfileRepository sProfileRepo;

    @Autowired
    private DProfileRepository dProfileRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> employeeIds = new ArrayList<String>();

    private List<StandardEmployee> dbRecords;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_EMPLOYEE_TABLES, false);
    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Employee_Standard", "Employee_Custom" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(employeeIds)) {
                for (String employeeId : employeeIds) {
                    dRepo.deleteByEmployeeId(employeeId);
                    sRepo.deleteByEmployeeId(employeeId);
                    dProfileRepo.deleteByAcctSrcNbr(employeeId);
                    sProfileRepo.deleteByAcctSrcNbr(employeeId);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                dRepo.deleteByCreateFileId(fileId);
                dProfileRepo.deleteByCreateFileId(fileId);
            }
        }
    }

    @AfterMethod
    public void afterTestCleanup(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_DATA);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_SCHEMA);
        }
    }

    @Rollback(false)
    @Test(groups = "Employee_Standard")
    public void testEmployeeRecord_Standard_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("EmployeeAutomationTestStandard_Create_").append(testId).toString();
        try {
            List<Employee> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, Employee.class, null);
            for (Employee record : csvRecords) {
                employeeIds.add(record.getEmployeeId());
            }
            Collections.sort(csvRecords);
            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_EMPLOYEE);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_EMPLOYEE);
            // Assertions
            assertEmployeeTables(csvRecords, fileId, true);
            assertSProfileTable(dbRecords, fileId);
            assertRefreshPiiJobStatus(filename);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Employee_Standard", dependsOnMethods = "testEmployeeRecord_Standard_Create")
    public void testEmployeeRecord_Standard_Update() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("EmployeeAutomationTestStandard_Update_").append(testId).toString();
        try {
            List<Employee> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_UPDATE, Employee.class, null);
            for (Employee record : csvRecords) {
                employeeIds.add(record.getEmployeeId());
            }
            Collections.sort(csvRecords);
            startProcess(filename, DATA_FILE_PATH_STANDARD_UPDATE, CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_EMPLOYEE);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_EMPLOYEE);
            // Assertions
            assertEmployeeTables(csvRecords, fileId, false);
            assertSProfileTable(dbRecords, fileId);
            assertRefreshPiiJobStatus(filename);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }

    private void assertEmployeeTables(List<Employee> csvRecords, Long fileId, boolean isCreateFlow) throws ParseException {
        dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionEmployee> dimEmpRecords = dRepo.findByUpdateFileId(fileId);
        assertDimensionTableData(csvRecords, dimEmpRecords);
        if (isCreateFlow)
            assertCreateFileFields_CreateFlow(dimEmpRecords);
        else {
            assertCreateFileFields_UpdateExisting(dimEmpRecords);
        }
    }

    private void assertSProfileTable(List<StandardEmployee> SEmployeeRecords, Long fileId) {
        List<StandardProfile> sProfileRecords = sProfileRepo.findByCreateFileId(fileId);

        List<EmployeeToProfilePartialComparer> convertedSEmployeeRecords = CopyUtil.convertSEmployeeToEmployeePartialProfile(SEmployeeRecords);
        List<EmployeeToProfilePartialComparer> convertedSProfileRecords = CopyUtil.convertSProfileToEmployeePartialProfile(sProfileRecords);

        assertEquals(convertedSProfileRecords, convertedSEmployeeRecords, "SProfile records don't match with SEmployee records");

        assertSrcCds(sProfileRecords);
    }

    private void assertSrcCds(List<StandardProfile> sProfileRecords) {
        for (StandardProfile record : sProfileRecords) {
            assertEquals(record.getRecSrcCd(), CommonConstants.REC_SRC_CD_EMPLOYEE,
                    String.format("rec_src_profile value does not match with expected value. Expected - %s, Actual - %s", record.getRecSrcCd(), CommonConstants.REC_SRC_CD_PROFILE));
            assertEquals(record.getAcctSrcCd(), CommonConstants.REC_SRC_CD_EMPLOYEE,
                    String.format("acctSrcCd value does not match with expected value. Expected - %s, Actual - %s", record.getRecSrcCd(), CommonConstants.REC_SRC_CD_PROFILE));
        }
    }

    private void assertRefreshPiiJobStatus(String filename) throws ApplicationException {
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_PII, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        assertTrue(CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus()), "RefreshPII Matillion job failed");
    }

    private void assertCreateFileFields_CreateFlow(List<DimensionEmployee> dimEmpRecords) {
        for (DimensionEmployee dimEmpRecord : dimEmpRecords) {
            assertEquals(dimEmpRecord.getCreateFileId(), dimEmpRecord.getUpdateFileId(),
                    String.format("D-UpdateFileId does not match with D-CreateFileId. Actual - %s, Expected - %s", dimEmpRecord.getCreateFileId(), dimEmpRecord.getUpdateFileId()));
            assertEquals(dimEmpRecord.getCreateFileRecNbr(), dimEmpRecord.getUpdateRecNbr(),
                    String.format("D-UpdateRecNbr does not match with D-CreateRecNbr. Actual - %s, Expected - %s", dimEmpRecord.getCreateFileRecNbr(), dimEmpRecord.getUpdateRecNbr()));
        }
    }

    private void assertCreateFileFields_UpdateExisting(List<DimensionEmployee> dimRecords) {
        for (DimensionEmployee dimRecord : dimRecords) {
            assertNotEquals(dimRecord.getUpdateFileId(), dimRecord.getCreateFileId(),
                    String.format("D-UpdateFileId matches with D-CreateFileId. Actual - %s, Expected - %s", dimRecord.getUpdateFileId(), dimRecord.getCreateFileId()));
            assertNotNull(dimRecord.getUpdateRecNbr(), "UpdateRecNbr is null");
            assertNotNull(dimRecord.getCreateFileRecNbr(), "CreateFileRecNbr is null");
        }
    }

    private void assertStandardTableData(List<Employee> csvRecords, List<StandardEmployee> dbRecords) throws ParseException {
        List<Employee> convertedStandardEmployeeRecords = CopyUtil.convertStandardEmployee(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardEmployeeRecords, csvRecords, "SEmployee records donot match with test data");

    }

    private void assertDimensionTableData(List<Employee> csvRecords, List<DimensionEmployee> dimEmpRecords) throws ParseException {
        List<DimensionEmployeeComparer> convertedDimensionEmployeeRecords = CopyUtil.convertDimensionEmployee(dimEmpRecords);

        List<DimensionEmployeeComparer> convertedEmployeeCsvRecords = new ArrayList<DimensionEmployeeComparer>();
        for (Employee record : csvRecords) {
            DimensionEmployeeComparer rec = new DimensionEmployeeComparer();
            BeanUtils.copyProperties(record, rec);

            convertedEmployeeCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedDimensionEmployeeRecords, convertedEmployeeCsvRecords, "DEmployee records don't match with SEmployee records");

    }
}
