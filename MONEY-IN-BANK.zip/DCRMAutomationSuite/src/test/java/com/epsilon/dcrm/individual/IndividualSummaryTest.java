package com.epsilon.dcrm.individual;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DAggregateMonetary12MonthsRepository;
import com.epsilon.dcrm.db.repository.DAggregateMonetary1324MonthsRepository;
import com.epsilon.dcrm.db.repository.DAggregateMonetaryLifeTimeRepository;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualEmailRepository;
import com.epsilon.dcrm.db.repository.DIndividualGoldenProfileRepository;
import com.epsilon.dcrm.db.repository.DIndividualPhoneRepository;
import com.epsilon.dcrm.db.repository.DRefFrequencyRepository;
import com.epsilon.dcrm.db.repository.DRefMonetaryRepository;
import com.epsilon.dcrm.db.repository.DRefRecencyRepository;
import com.epsilon.dcrm.db.repository.DvIndividualSummaryRepository;
import com.epsilon.dcrm.db.repository.MIndividualSummaryRepository;
import com.epsilon.dcrm.model.dimension.DimensionIndividualAddress;
import com.epsilon.dcrm.model.dimension.DimensionIndividualEmail;
import com.epsilon.dcrm.model.dimension.DimensionIndividualGoldenProfile;
import com.epsilon.dcrm.model.dimension.DimensionIndividualPhone;
import com.epsilon.dcrm.model.dimension.DimensionRefFrequency;
import com.epsilon.dcrm.model.dimension.DimensionRefMonetary;
import com.epsilon.dcrm.model.dimension.DimensionRefRecency;
import com.epsilon.dcrm.model.dimension.DvIndividualSummary;
import com.epsilon.dcrm.model.mart.IndividualSummary;
import com.epsilon.dcrm.objects.comparer.DvIndividualSummaryComparer;
import com.epsilon.dcrm.objects.comparer.IndividualSummaryComparer;
import com.epsilon.dcrm.util.FormatUtil;

@RunWith(SpringRunner.class)
public class IndividualSummaryTest extends BaseTest {

    @Autowired
    private DIndividualAddressRepository dIndivAddrRepo;

    @Autowired
    private DIndividualEmailRepository dIndivEmailRepo;

    @Autowired
    private DIndividualPhoneRepository dIndivPhoneRepo;

    @Autowired
    private DIndividualGoldenProfileRepository dIndivGoldenProfileRepo;

    @Autowired
    private DAggregateMonetary12MonthsRepository dAggMonetary12MonthsRepo;

    @Autowired
    private DAggregateMonetary1324MonthsRepository dAggMonetary1324MonthsRepo;

    @Autowired
    private DAggregateMonetaryLifeTimeRepository dAggMonetaryLifeTimeRepo;

    @Autowired
    private DvIndividualSummaryRepository dvIndivSummaryRepo;

    @Autowired
    private MIndividualSummaryRepository mIndivSummaryRepo;

    @Autowired
    private DRefFrequencyRepository dFrequencyRepo;

    @Autowired
    private DRefMonetaryRepository dMonetaryRepo;

    @Autowired
    private DRefRecencyRepository dRecencyRepo;

    private static final Long INDIV_ID = Instant.now().toEpochMilli();
    private static final Long FILE_ID = new Long((String.valueOf(INDIV_ID)).substring(0, 10));
    private static final String RAND_STRING = UUID.randomUUID().toString();

    private static final String BRAND_CD = "IndivSumTest";
    private static final String BRAND_CD1 = "IndivSumTest1";
    private static final String BRAND_CD2 = "IndivSumTest2";
    private static final String BRAND_CD3 = "IndivSumTest3";
    private static final String BRAND_CD4 = "IndEnterTest";
    private static final String STATE_NM_ALASKA = "Alaska";
    private static final String STATE_CD_ALASKA = "US-AK";
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final Integer M12_FREQUENCY_CNT = 2;
    private static final Double M12_GROSS_AMT = 3.0;
    private static final Double M12_DISCOUNT_AMT = 0.0;
    private static final Double M12_RETURN_AMT = 7.0;
    private static final Double M12_CANCEL_AMT = 1.0;
    private static final Double M12_NET_AMT = M12_GROSS_AMT - M12_DISCOUNT_AMT;
    private static final Integer M24_FREQUENCY_CNT = 0;
    private static final Double M24_GROSS_AMT = 12.0;
    private static final Double M24_DISCOUNT_AMT = 5.0;
    private static final Double M24_RETURN_AMT = 27.0;
    private static final Double M24_CANCEL_AMT = 6.0;
    private static final Double M24_NET_AMT = M24_GROSS_AMT - M24_DISCOUNT_AMT;
    private static final Integer LIFETIME_FREQUENCY_CNT = 2;
    private static final Double LIFETIME_GROSS_AMT = 111.0;
    private static final Double LIFETIME_DISCOUNT_AMT = 22.0;
    private static final Double LIFETIME_RETURN_AMT = 50.0;
    private static final Double LIFETIME_CANCEL_AMT = 17.0;
    private static final Double LIFETIME_NET_AMT = LIFETIME_GROSS_AMT - LIFETIME_DISCOUNT_AMT;
    private static final String M12_MONETARY_CD = "12M";
    private static final String M24_MONETARY_CD = "24M";
    private static final String LIFE_MONETARY_CD = "LMM";
    private static final String M12_FREQUENCY_CD = "12F";
    private static final String M24_FREQUENCY_CD = "24F";
    private static final String LIFE_FREQUENCY_CD = "LFF";
    private static final String RECENCY_CD = "RFF";
    private static final Long MONTHS_SINCE_LAST_TXN_DT = 5L;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_INDIVIDUAL_SUMMARY_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_D_INDIVIDUAL_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_AGG_MONETARY_LAST_12_MONTHS_TABLE, false);
        executeSqlScript(CommonConstants.CREATE_AGG_MONETARY_13_24_MONTHS_TABLE, false);
        executeSqlScript(CommonConstants.CREATE_AGG_MONETARY_LIFETIME_TABLE, false);
        dIndivAddrRepo.insertSimpleTestRecord(INDIV_ID, 1L, "road 1", "street 1", "area 1", "Anchorage", STATE_NM_ALASKA, "75000", "0000", "USA", FILE_ID, (long) (Math.random() * 1000));
        dIndivEmailRepo.insertSimpleTestRecord(INDIV_ID, "IndivSumTest@test.com", "Y", "Y", BRAND_CD, BRAND_CD, FILE_ID);
        dIndivPhoneRepo.insertSimpleTestRecord(RAND_STRING.substring(0, 9), FILE_ID);
        dAggMonetary12MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD, 2L, M12_GROSS_AMT, M12_DISCOUNT_AMT, M12_RETURN_AMT, M12_CANCEL_AMT);
        dAggMonetary1324MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD, 0L, M24_GROSS_AMT, M24_DISCOUNT_AMT, M24_RETURN_AMT, M24_CANCEL_AMT);
        Date LAST_TXN_DT = Date.valueOf(LocalDate.now().minusMonths(1));
        Date ORIG_TXN_DT = Date.valueOf(LocalDate.now().minusMonths(8));
        dAggMonetaryLifeTimeRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD, 2L, LIFETIME_GROSS_AMT, LIFETIME_DISCOUNT_AMT, LIFETIME_RETURN_AMT, LIFETIME_CANCEL_AMT, ORIG_TXN_DT, LAST_TXN_DT);

        dAggMonetary12MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD1, 0L, M12_GROSS_AMT, M12_DISCOUNT_AMT, M12_RETURN_AMT, M12_CANCEL_AMT);
        dAggMonetary1324MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD1, 3L, M24_GROSS_AMT, M24_DISCOUNT_AMT, M24_RETURN_AMT, M24_CANCEL_AMT);
        Date LAST_TXN_DT1 = Date.valueOf(LocalDate.now().minusMonths(1));
        Date ORIG_TXN_DT1 = Date.valueOf(LocalDate.now().minusMonths(38));
        dAggMonetaryLifeTimeRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD1, 3L, LIFETIME_GROSS_AMT, LIFETIME_DISCOUNT_AMT, LIFETIME_RETURN_AMT, LIFETIME_CANCEL_AMT, ORIG_TXN_DT1, LAST_TXN_DT1);

        dAggMonetary12MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD2, 2L, M12_GROSS_AMT, M12_DISCOUNT_AMT, M12_RETURN_AMT, M12_CANCEL_AMT);
        dAggMonetary1324MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD2, 3L, M24_GROSS_AMT, M24_DISCOUNT_AMT, M24_RETURN_AMT, M24_CANCEL_AMT);
        Date LAST_TXN_DT2 = Date.valueOf(LocalDate.now().minusMonths(1));
        Date ORIG_TXN_DT2 = Date.valueOf(LocalDate.now().minusMonths(38));
        dAggMonetaryLifeTimeRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD2, 5L, LIFETIME_GROSS_AMT, LIFETIME_DISCOUNT_AMT, LIFETIME_RETURN_AMT, LIFETIME_CANCEL_AMT, ORIG_TXN_DT2, LAST_TXN_DT2);

        dAggMonetary12MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD3, 1L, M12_GROSS_AMT, M12_DISCOUNT_AMT, M12_RETURN_AMT, M12_CANCEL_AMT);
        dAggMonetary1324MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD3, 0L, M24_GROSS_AMT, M24_DISCOUNT_AMT, M24_RETURN_AMT, M24_CANCEL_AMT);
        Date LAST_TXN_DT3 = Date.valueOf(LocalDate.now().minusMonths(1));
        Date ORIG_TXN_DT3 = Date.valueOf(LocalDate.now().minusMonths(38));
        dAggMonetaryLifeTimeRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD3, 4L, LIFETIME_GROSS_AMT, LIFETIME_DISCOUNT_AMT, LIFETIME_RETURN_AMT, LIFETIME_CANCEL_AMT, ORIG_TXN_DT3, LAST_TXN_DT3);

        dAggMonetary12MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD4, 0L, M12_GROSS_AMT, M12_DISCOUNT_AMT, M12_RETURN_AMT, M12_CANCEL_AMT);
        dAggMonetary1324MonthsRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD4, 0L, M24_GROSS_AMT, M24_DISCOUNT_AMT, M24_RETURN_AMT, M24_CANCEL_AMT);
        Date LAST_TXN_DT4 = Date.valueOf(LocalDate.now().minusMonths(1));
        Date ORIG_TXN_DT4 = Date.valueOf(LocalDate.now().minusMonths(38));
        dAggMonetaryLifeTimeRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD4, 0L, LIFETIME_GROSS_AMT, LIFETIME_DISCOUNT_AMT, LIFETIME_RETURN_AMT, LIFETIME_CANCEL_AMT, ORIG_TXN_DT4, LAST_TXN_DT4);

        //  dFrequencyRepo.insertTestData(M12_FREQUENCY_CD, "M12 frequency_nm", "M12 frequency_dsc", M12_FREQUENCY_CNT, M12_FREQUENCY_CNT, FILE_ID, 0L);
        //  dFrequencyRepo.insertTestData(M24_FREQUENCY_CD, "M24 frequency_nm", "M24 frequency_dsc", M24_FREQUENCY_CNT, M24_FREQUENCY_CNT, FILE_ID, 0L);
        //   dFrequencyRepo.insertTestData(LIFE_FREQUENCY_CD, "life frequency_nm", "life frequency_dsc", LIFETIME_FREQUENCY_CNT, LIFETIME_FREQUENCY_CNT, FILE_ID, 0L);

        //   dMonetaryRepo.insertTestData(M12_MONETARY_CD, "M12 monetary_nm", "M12 monetary_dsc", M12_NET_AMT, M12_NET_AMT, FILE_ID, 0L);
        //   dMonetaryRepo.insertTestData(M24_MONETARY_CD, "M24 monetary_nm", "M24 monetary_dsc", M24_NET_AMT, M24_NET_AMT, FILE_ID, 0L);
        //   dMonetaryRepo.insertTestData(LIFE_MONETARY_CD, "life monetary_nm", "life monetary_dsc", LIFETIME_NET_AMT, LIFETIME_NET_AMT, FILE_ID, 0L);

        //  dRecencyRepo.insertTestData(RECENCY_CD, "recency_nm", "recency_dsc", MONTHS_SINCE_LAST_TXN_DT, MONTHS_SINCE_LAST_TXN_DT, FILE_ID, 0L);

    }

    @Rollback(false)
    @Test(groups = "IndividualSummary")
    public void testIndividualSummary() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("IndividualSummaryAutomationTest_").append(testId).toString();
        try {
            Long dcrmIndivAddrId = getDcrmIndivAddrId();
            Long dcrmIndivEmailId = getDcrmIndivEmailId();
            Long dcrmIndivPhoneId = getDcrmIndivPhoneId();
            dIndivGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD, dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            dIndivGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD1, dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            dIndivGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD2, dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            dIndivGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD3, dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            dIndivGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD4, dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_SUMMARY);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_SUMMARY);

            // Assertions
            List<DvIndividualSummary> dvIndividualSummaryRecords = assertIndividualSummaryView(dcrmIndivAddrId, dcrmIndivEmailId, dcrmIndivPhoneId);
            assertMIndividualSummaryTable(dvIndividualSummaryRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    private void cleanUp() {
        dIndivAddrRepo.deleteByUpdateFileId(FILE_ID);
        dIndivEmailRepo.deleteByUpdateFileId(FILE_ID);
        dIndivPhoneRepo.deleteByUpdateFileId(FILE_ID);
        dIndivGoldenProfileRepo.deleteByIndivId(INDIV_ID);
        mIndivSummaryRepo.deleteByIndivId(INDIV_ID);
        dvIndivSummaryRepo.deleteByIndivId(INDIV_ID);
        dAggMonetary12MonthsRepo.deleteByIndivId(INDIV_ID);
        dAggMonetary1324MonthsRepo.deleteByIndivId(INDIV_ID);
        dAggMonetaryLifeTimeRepo.deleteByIndivId(INDIV_ID);

        //   dFrequencyRepo.deleteByFrequencyCdAndCreateFileId(M12_FREQUENCY_CD, FILE_ID);
        //   dFrequencyRepo.deleteByFrequencyCdAndCreateFileId(M24_FREQUENCY_CD, FILE_ID);
        //   dFrequencyRepo.deleteByFrequencyCdAndCreateFileId(LIFE_FREQUENCY_CD, FILE_ID);
        //    dMonetaryRepo.deleteByMonetaryCdAndCreateFileId(M12_MONETARY_CD, FILE_ID);
        //     dMonetaryRepo.deleteByMonetaryCdAndCreateFileId(M24_MONETARY_CD, FILE_ID);
        //    dMonetaryRepo.deleteByMonetaryCdAndCreateFileId(LIFE_MONETARY_CD, FILE_ID);
        //   dRecencyRepo.deleteByRecencyCdAndCreateFileId(RECENCY_CD, FILE_ID);

    }

    private Long getDcrmIndivAddrId() {
        List<DimensionIndividualAddress> dimIndivAddressRecords = dIndivAddrRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivAddressRecords.size(), 1);
        DimensionIndividualAddress dimIndivAddressRecord = dimIndivAddressRecords.get(0);
        assertNotNull(dimIndivAddressRecord, "DimensionIndividualAddress record is null");
        return dimIndivAddressRecord.getDcrmIndivAddrId();
    }

    private Long getDcrmIndivEmailId() {
        List<DimensionIndividualEmail> dimIndivEmailRecords = dIndivEmailRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivEmailRecords.size(), 1);
        DimensionIndividualEmail dimIndivEmailRecord = dimIndivEmailRecords.get(0);
        assertNotNull(dimIndivEmailRecord, "DimensionIndividualEmail record is null");
        return dimIndivEmailRecord.getDcrmIndivEmailId();
    }

    private Long getDcrmIndivPhoneId() {
        List<DimensionIndividualPhone> dimIndivPhoneRecords = dIndivPhoneRepo.findByUpdateFileId(FILE_ID);
        assertEquals(dimIndivPhoneRecords.size(), 1);
        DimensionIndividualPhone dimIndivPhoneRecord = dimIndivPhoneRecords.get(0);
        assertNotNull(dimIndivPhoneRecord, "DimensionIndividualPhone record is null");
        return dimIndivPhoneRecord.getDcrmIndivPhoneId();
    }

    private List<DvIndividualSummary> assertIndividualSummaryView(Long dcrmIndivAddrId, Long dcrmIndivEmailId, Long dcrmIndivPhoneId) {
        List<DimensionIndividualGoldenProfile> dIndiviGoldenProfileRecords = dIndivGoldenProfileRepo.findByIndivId(INDIV_ID);
        List<DvIndividualSummaryComparer> dIndiviGoldenProfileComparerRecords = new ArrayList<DvIndividualSummaryComparer>();
        List<DvIndividualSummaryComparer> dvIndividualSummaryComparerRecords = new ArrayList<DvIndividualSummaryComparer>();

        for (DimensionIndividualGoldenProfile record : dIndiviGoldenProfileRecords) {
            DvIndividualSummaryComparer rec = new DvIndividualSummaryComparer();
            BeanUtils.copyProperties(record, rec);

            if (record.getDcrmIndivAddrId() != null) {
                List<DimensionIndividualAddress> dimIndivAddrRecords = dIndivAddrRepo.findByDcrmIndivAddrId(dcrmIndivAddrId);
                assertEquals(dimIndivAddrRecords.size(), 1, "more than 1 record in d_individual_address table");
                DimensionIndividualAddress dimIndivAddressRecord = dimIndivAddrRecords.get(0);
                assertNotNull(dimIndivAddressRecord, "DimensionIndividualAddress record is null");
                rec.setAddrLine1(dimIndivAddressRecord.getAddrLine1());
                rec.setAddrLine2(dimIndivAddressRecord.getAddrLine2());
                rec.setAddrLine3(dimIndivAddressRecord.getAddrLine3());
                rec.setCityNm(dimIndivAddressRecord.getCityNm());
                rec.setPostalCd(dimIndivAddressRecord.getPostalCd());
                rec.setZip4(dimIndivAddressRecord.getZip4());
                rec.setStateCd(STATE_NM_ALASKA.equals(dimIndivAddressRecord.getStateNm()) ? STATE_CD_ALASKA : null);
                rec.setCountryCd(dimIndivAddressRecord.getCountryCd());
            }
            if (record.getDcrmIndivEmailId() != null) {
                List<DimensionIndividualEmail> dimIndivEmailRecords = dIndivEmailRepo.findByDcrmIndivEmailId(dcrmIndivEmailId);
                assertEquals(dimIndivEmailRecords.size(), 1, "more than 1 record in d_individual_email table");
                DimensionIndividualEmail dimIndivEmailRecord = dimIndivEmailRecords.get(0);
                assertNotNull(dimIndivEmailRecord, "DimensionIndividualEmail record is null");
                rec.setEmailAddr(dimIndivEmailRecord.getEmailAddr());
            }
            if (record.getDcrmIndivPhoneId() != null) {
                List<DimensionIndividualPhone> dimIndivPhoneRecords = dIndivPhoneRepo.findByDcrmIndivPhoneId(dcrmIndivPhoneId);
                assertEquals(dimIndivPhoneRecords.size(), 1, "more than 1 record in d_individual_phone table");
                DimensionIndividualPhone dimIndivPhoneRecord = dimIndivPhoneRecords.get(0);
                assertNotNull(dimIndivPhoneRecord, "DimensionIndividualPhone record is null");
                rec.setPhoneNbr(dimIndivPhoneRecord.getPhoneNbr());
            }

            dIndiviGoldenProfileComparerRecords.add(rec);
        }
        Collections.sort(dIndiviGoldenProfileComparerRecords);

        List<DvIndividualSummary> dvIndividualSummaryRecords = dvIndivSummaryRepo.findByIndivId(INDIV_ID);
        for (DvIndividualSummary record : dvIndividualSummaryRecords) {
            DvIndividualSummaryComparer rec = new DvIndividualSummaryComparer();
            BeanUtils.copyProperties(record, rec);

            dvIndividualSummaryComparerRecords.add(rec);
        }
        Collections.sort(dvIndividualSummaryComparerRecords);

        assertEquals(dvIndividualSummaryComparerRecords, dIndiviGoldenProfileComparerRecords, "dv_individual_summary records donot match with test data");
        return dvIndividualSummaryRecords;
    }

    private void assertMIndividualSummaryTable(List<DvIndividualSummary> dvIndividualSummaryRecords) throws ParseException {
        List<IndividualSummary> individualSummayRecords = mIndivSummaryRepo.findByIndivId(INDIV_ID);
        List<IndividualSummaryComparer> dvIndiviSummaryComparerRecords = new ArrayList<IndividualSummaryComparer>();
        List<IndividualSummaryComparer> indiviSummaryComparerRecords = new ArrayList<IndividualSummaryComparer>();

        for (DvIndividualSummary record : dvIndividualSummaryRecords) {
            IndividualSummaryComparer rec = new IndividualSummaryComparer();
            BeanUtils.copyProperties(record, rec);
            if (record.getBirthDt() != null) {
                String birthDate = FormatUtil.convertDate(record.getBirthDt(), DATE_FORMAT);
                rec.setBirthDay(new Integer(birthDate.substring(8, 10)));
                rec.setBirthMth(new Integer(birthDate.substring(5, 7)));
                rec.setBirthYr(new Integer(birthDate.substring(0, 4)));
            } else {
                DateFormat df = new SimpleDateFormat(DATE_FORMAT);
                Date birthDt = new java.sql.Date(df.parse("1900-01-01").getTime());
                rec.setBirthDt(birthDt);
                rec.setBirthDay(0);
                rec.setBirthMth(0);
                rec.setBirthYr(0);
            }

            LocalDate aMonthAgo = LocalDate.now().minusMonths(12);
            if (record.getOrigTxnDt().toLocalDate().isAfter(aMonthAgo)) {
                rec.setCustLifeCycleCd("NEW");
            } else if (record.getM1324FrequencyCnt() > 0 && record.getM12FrequencyCnt() > 0) {
                rec.setCustLifeCycleCd("RET");
            } else if (record.getM1324FrequencyCnt() > 0 && record.getM12FrequencyCnt() == 0) {
                rec.setCustLifeCycleCd("LAP");
            } else if (record.getM1324FrequencyCnt() == 0 && record.getM12FrequencyCnt() > 0) {
                if (record.getLifeTimeFrequencyCnt() > record.getM12FrequencyCnt()) {
                    rec.setCustLifeCycleCd("RCT");
                }
            } else
                rec.setCustLifeCycleCd("HNR");

            dvIndiviSummaryComparerRecords.add(rec);
        }

        Collections.sort(dvIndiviSummaryComparerRecords);

        for (IndividualSummary record : individualSummayRecords) {
            assertCodes(record);
            IndividualSummaryComparer rec = new IndividualSummaryComparer();
            BeanUtils.copyProperties(record, rec);
            indiviSummaryComparerRecords.add(rec);
        }

        Collections.sort(indiviSummaryComparerRecords);

        assertEquals(indiviSummaryComparerRecords, dvIndiviSummaryComparerRecords, "m_individual_summary records do not match with test data");

        //assertDefaultRecord();
    }

    private void assertCodes(IndividualSummary record) {
        // frequency_cd

        List<DimensionRefFrequency> frequencyM12Records = dFrequencyRepo.findByValue(record.getM12FrequencyCnt());
        assertEquals(frequencyM12Records.size(), 1, "d_ref_frequency 12 has more than 1 record");
        assertEquals(record.getM12FrequencyCd(), frequencyM12Records.get(0).getFrequencyCd(), "invalid m12_frequency_cd");

        //assertEquals(record.getM12FrequencyCd(), M12_FREQUENCY_CD, "invalid m12_frequency_cd");

        List<DimensionRefFrequency> frequencyM1324Records = dFrequencyRepo.findByValue(record.getM1324FrequencyCnt());
        assertEquals(frequencyM1324Records.size(), 1, "d_ref_frequency 1324 has more than 1 record");
        assertEquals(record.getM1324FrequencyCd(), frequencyM1324Records.get(0).getFrequencyCd(), "invalid m13_24_frequency_cd");

        //assertEquals(record.getM1324FrequencyCd(), M24_FREQUENCY_CD, "invalid m13_24_frequency_cd");

        List<DimensionRefFrequency> frequencyLtRecords = dFrequencyRepo.findByValue(record.getLifeTimeFrequencyCnt());
        assertEquals(frequencyLtRecords.size(), 1, "d_ref_frequency Life has more than 1 record");
        assertEquals(record.getLifetimeFrequencyCd(), frequencyLtRecords.get(0).getFrequencyCd(), "invalid lifetime_frequency_cd");

        // monetary_cd
        List<DimensionRefMonetary> monetaryM12Records = dMonetaryRepo.findByValue(record.getM12NetAmt());
        assertEquals(monetaryM12Records.size(), 1, "d_ref_monetary (M12) has more than 1 record");
        assertEquals(record.getM12MonetaryCd(), monetaryM12Records.get(0).getMonetaryCd(), "invalid m12_monetary_cd");

        //assertEquals(record.getM12MonetaryCd(), M12_MONETARY_CD, "invalid m12_monetary_cd");

        List<DimensionRefMonetary> monetaryM1324Records = dMonetaryRepo.findByValue(record.getM1324NetAmt());
        assertEquals(monetaryM1324Records.size(), 1, "d_ref_monetary (M1324) has more than 1 record");
        assertEquals(record.getM1324MonetaryCd(), monetaryM1324Records.get(0).getMonetaryCd(), "invalid m13_24_monetary_cd");

        //assertEquals(record.getM1324MonetaryCd(), M24_MONETARY_CD, "invalid m13_24_monetary_cd");

        List<DimensionRefMonetary> monetaryLtRecords = dMonetaryRepo.findByValue(record.getLifeTimeNetAmt());
        assertEquals(monetaryLtRecords.size(), 1, "d_ref_monetary(Lifetime) has more than 1 record");
        assertEquals(record.getLifetimeMonetaryCd(), monetaryLtRecords.get(0).getMonetaryCd(), "invalid lifetime_monetary_cd");

        //assertEquals(record.getLifetimeMonetaryCd(), LIFE_MONETARY_CD, "invalid lifetime_monetary_cd");

        // recency_cd
        List<DimensionRefRecency> recencyRecords = dRecencyRepo.findByValue(record.getLastTxnDt());
        assertEquals(recencyRecords.size(), 1, "d_ref_monetary(Lifetime) has more than 1 record");
        assertEquals(record.getRecencyCd(), recencyRecords.get(0).getRecencyCd(), "invalid recency_cd");

        // assertEquals(record.getRecencyCd(), RECENCY_CD, "invalid recency_cd");

    }

    private void assertDefaultRecord() {
        List<IndividualSummary> individualSummayRecords = mIndivSummaryRepo.findByBrandCd(CommonConstants.DEFAULT_RECORD_BRAND_CD);
        assertEquals(individualSummayRecords.size(), 1, "m_individual_summary has no default record");
        assertEquals(individualSummayRecords.get(0).getIndivId().intValue(), 0, String.format("Default indiv_id - Expected 0. Found %s", individualSummayRecords.get(0).getIndivId().toString()));
    }

}