package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefFrequencyRepository;
import com.epsilon.dcrm.db.repository.SRefFrequencyRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefFrequency;
import com.epsilon.dcrm.model.standard.StandardRefFrequency;
import com.epsilon.dcrm.objects.csv.RefFrequency;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class RefFrequencyTest extends BaseTest {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/RefFrequencyAutomation.txt";
    private static final Logger logger = LoggerFactory.getLogger(RefFrequencyTest.class);

    @Autowired
    private SRefFrequencyRepository sRepo;

    @Autowired
    private DRefFrequencyRepository dRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_FREQUENCY_CREATE, false);
    }

    @Test
    public void testWarehouseLoad() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("RefFrequencyAutomation_").append(testId).toString();
        try {
            List<RefFrequency> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, RefFrequency.class, null);

            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_DATA_CONVERT_REF_FREQUENCY);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_D_REF_FREQUENCY);

            // Assertions
            assertData(fileId, csvRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            if (!CollectionUtils.isEmpty(fileIds)) {
                for (Long fileId : fileIds) {
                    logger.info("FileId being used for deletion - {} ", fileId);
                    sRepo.deleteByCreateFileId(fileId);
                    dRepo.deleteByCreateFileId(fileId);
                }
            }
        }
    }

    private void assertData(Long fileId, List<RefFrequency> csvRecs) {

        Collections.sort(csvRecs);

        List<StandardRefFrequency> sRecs = sRepo.findByCreateFileId(fileId);
        assertNotNull(sRecs, "Null from staging refFrequency table");
        assertNotEquals(sRecs.size(), 0, "Found 0 records in staging refFrequency table.");

        List<RefFrequency> convertedSRecs = CopyUtil.convertRefFrequencySRecs(sRecs);
        assertEquals(convertedSRecs, csvRecs, "SRecords donot match with test data for RefFrequency");

        List<DimensionRefFrequency> dRecs = dRepo.findByCreateFileId(fileId);
        assertNotNull(dRecs, "Null from dimension refFrequency table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension refFrequency table.");

        List<RefFrequency> convertedDRecs = CopyUtil.convertRefFrequencyDRecs(dRecs);
        assertEquals(convertedDRecs, convertedSRecs, "DRecords donot match with SRecords for RefFrequency");

        assertAuditFields(fileId, dRecs);

    }

    private void assertAuditFields(Long fileId, List<DimensionRefFrequency> dRecs) {
        for (DimensionRefFrequency dRec : dRecs) {
            assertNotNull(dRec.getCreateFileId(), "Null from dimension refFrequency table for CreateFileId");
            assertEquals(dRec.getCreateFileId(), fileId, "CreateFileId and FIleId from FRMS donot match");
            assertNotNull(dRec.getCreateTs(), "Null from dimension refFrequency table for CreateTs");
        }
    }

}
