package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.standard.StandardTransactionItem;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionItemComparer;
import com.epsilon.dcrm.objects.csv.TransactionItem;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;
import com.epsilon.dcrm.util.TestUtil;

public class TransactionItemBaseTest extends AbstractTransactionalTestNGSpringContextTests {

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    protected String generateHash(TransactionItem record) throws NoSuchAlgorithmException {
        return TestUtil.generateMd5Hashvalue(
                record.getShipToFirstNm(),
                record.getShipToMiddleNm(),
                record.getShipToLastNm(),
                record.getShipToUnparsedNm(),
                record.getShipToBusinessNm(),
                record.getShipToAddrLine1(),
                record.getShipToAddrLine2(),
                record.getShipToAddrLine3(),
                record.getShipToAddrLine4(),
                record.getShipToCity(),
                record.getShipToState(),
                record.getShipToPostalCd(),
                record.getShipToCountry(),
                record.getShipToCountryCd(),
                record.getShipToEmailAddr(),
                record.getShipToPhoneNbr());
    }

    protected void assertCreateFileFields_CreateFlow(List<DimensionTransactionItem> dimTranRecords) {
        for (DimensionTransactionItem dimTranRecord : dimTranRecords) {
            assertEquals(dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId(),
                    String.format("CreateFileId and UpdateFileId do not match in DTransactionItem table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId()));
            assertEquals(dimTranRecord.getCreateFileRecNbr(), dimTranRecord.getUpdateFileRecNbr(),
                    String.format("CreateRecNbr and UpdateRecNbr do not match in DTransactionItem table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileRecNbr(), dimTranRecord.getUpdateFileRecNbr()));
        }
    }

    protected void assertStandardTableData(List<TransactionItem> csvRecords, List<StandardTransactionItem> dbRecords) throws ParseException {
        List<TransactionItem> convertedStandardTransactionItemRecords = CopyUtil.convertStandardTransactionItem(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(csvRecords, convertedStandardTransactionItemRecords);
    }

    protected void assertDimensionTableData(List<TransactionItem> csvRecords, List<DimensionTransactionItem> dimTranRecords) throws ParseException {
        List<DimensionTransactionItemComparer> convertedDimensionTransactionItemRecords = CopyUtil.convertDimensionTransactionItem(dimTranRecords);

        List<DimensionTransactionItemComparer> convertedTransactionItemCsvRecords = new ArrayList<DimensionTransactionItemComparer>();
        for (TransactionItem record : csvRecords) {
            DimensionTransactionItemComparer rec = new DimensionTransactionItemComparer();
            BeanUtils.copyProperties(record, rec);
            // Business requirements : to populate these fields from the Brand_cd in the input
            rec.setShipToBrandCd(record.getBrandCd());
            rec.setProdCatalogBrandCd(record.getBrandCd());
            convertedTransactionItemCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedTransactionItemCsvRecords, convertedDimensionTransactionItemRecords);

    }

    protected <T> void uploadDataFile(String filename, List<T> csvRecords) throws IOException {
        byte[] bytes = CSVUtil.getCsv(csvRecords).getBytes();
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
        byteArrayInputStream.close();
    }

}
