package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DProfileAddressRepository;
import com.epsilon.dcrm.db.repository.DStoreRepository;
import com.epsilon.dcrm.db.repository.DTransactionHeaderRepository;
import com.epsilon.dcrm.db.repository.DTransactionTenderRepository;
import com.epsilon.dcrm.db.repository.DvTransactionTenderRepository;
import com.epsilon.dcrm.db.repository.MTransactionTenderOrphanRepository;
import com.epsilon.dcrm.db.repository.MTransactionTenderRepository;
import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;
import com.epsilon.dcrm.model.dimension.DimensionTransactionTender;
import com.epsilon.dcrm.model.dimension.DvTransactionTender;
import com.epsilon.dcrm.model.mart.MTransactionTender;
import com.epsilon.dcrm.model.mart.MTransactionTenderOrphan;
import com.epsilon.dcrm.objects.comparer.DvTransactionTenderComparer;

@RunWith(SpringRunner.class)
public class MTransactionTenderTest extends BaseTest {

    @Autowired
    private MTransactionTenderOrphanRepository mTxnTndrOrphanRepo;

    @Autowired
    private MTransactionTenderRepository mTxnTndrRepo;

    @Autowired
    private DvTransactionTenderRepository txnTenderRepository;

    @Autowired
    private DStoreRepository dStoreRepo;

    @Autowired
    private DEmployeeRepository dEmployeeRepo;

    @Autowired
    private DIndividualAddressRepository dIndivAddressRepo;

    @Autowired
    private DProfileAddressRepository dProfAddrRepo;

    @Autowired
    private DIndividualRepository dIndivRepo;

    @Autowired
    private DTransactionHeaderRepository dTransactionRepo;

    @Autowired
    private DTransactionTenderRepository dTenderRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final long EPOCH_MILLIS = Instant.now().toEpochMilli();
    private static final String BRAND_CD = "MTXNTENDER";
    private static final String MATCHING_TXN_NBR = RAND_STRING;
    private static final String NON_MATCHING_TXN_NBR = UUID.randomUUID().toString();
    private static final long FILE_ID = (long) Math.ceil(Math.random() * 10000);

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_TENDER_TABLES, false);
        executeSqlScript(CommonConstants.MART_TRANSACTION_TABLES_CREATE, false);
        dStoreRepo.insertSimpleTestRecord(RAND_STRING.substring(0, 5), RAND_STRING, BRAND_CD);
        dEmployeeRepo.insertSimpleTestRecord(BRAND_CD, Long.toString(EPOCH_MILLIS));
        dIndivRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS - 100, FILE_ID);

        //Matching record in individual_address and profile_address tables for match in transaction views based on tri-part key
        dIndivAddressRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, "road 1", "street 1", "area 1", "Anchorage", "Alask", "75000", "0000", "USA", FILE_ID, (long) (Math.random() * 1000));
        dProfAddrRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, FILE_ID, (long) (Math.random() * 1000));

        dTransactionRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), MATCHING_TXN_NBR, RAND_STRING.substring(0, 5), EPOCH_MILLIS);

        // Non-orphan record
        dTenderRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), MATCHING_TXN_NBR, (long) (Math.random() * 1000), MATCHING_TXN_NBR.substring(0, 5),
                MATCHING_TXN_NBR.substring(0, 5), Math.random() * 1000, MATCHING_TXN_NBR.substring(0, 10), MATCHING_TXN_NBR.substring(0, 6),
                MATCHING_TXN_NBR.substring(6, 10), (long) (Math.random() * 1000), (long) (Math.random() * 1000));

        // Orphan record
        dTenderRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), NON_MATCHING_TXN_NBR, (long) (Math.random() * 1000), NON_MATCHING_TXN_NBR.substring(0, 5),
                NON_MATCHING_TXN_NBR.substring(0, 5), Math.random() * 1000, NON_MATCHING_TXN_NBR.substring(0, 10), NON_MATCHING_TXN_NBR.substring(0, 6),
                NON_MATCHING_TXN_NBR.substring(6, 10), (long) (Math.random() * 1000), (long) (Math.random() * 1000));

    }

    @Test
    public void testMartLoad() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("MTransactionTenderTest_").append(testId).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_TENDER);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_TENDER);

            List<DimensionTransactionTender> txnTenderRecs = dTenderRepo.findByBrandCd(BRAND_CD);
            assertNotNull(txnTenderRecs, "No records found in DTransactionTender.");

            List<DvTransactionTenderComparer> recordsInView = assertRecordsInMartView(txnTenderRecs);

            assertTxnTender(txnTenderRecs, recordsInView);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    public void cleanUp() {
        dTenderRepo.deleteByBrandCd(BRAND_CD);
        mTxnTndrOrphanRepo.deleteByBrandCd(BRAND_CD);
        mTxnTndrRepo.deleteByBrandCd(BRAND_CD);

        dTransactionRepo.deleteByBrandCd(BRAND_CD);
        dStoreRepo.deleteByStoreNm(RAND_STRING);
        dEmployeeRepo.deleteByEmployeeId(Long.toString(EPOCH_MILLIS));
        dIndivAddressRepo.deleteByUpdateFileId(FILE_ID);
        dProfAddrRepo.deleteByBrandCd(BRAND_CD);
        dIndivRepo.deleteByIndivId(EPOCH_MILLIS);
    }

    private void assertTxnTender(List<DimensionTransactionTender> txnTenderRecs, List<DvTransactionTenderComparer> txnTdrViewRecs) {
        List<DvTransactionTenderComparer> orphanRecords = txnTdrViewRecs.stream().filter(rec -> (rec.getDcrmTxnId() == null || rec.getDcrmTxnId() == 0)).collect(Collectors.toList());

        List<DvTransactionTenderComparer> nonOrphanRecords = txnTdrViewRecs.stream().filter(rec -> (rec.getDcrmTxnId() != null && rec.getDcrmTxnId() != 0)).collect(Collectors.toList());

        List<MTransactionTender> recs = mTxnTndrRepo.findByBrandCd(BRAND_CD);
        assertNotNull(recs, "No records found in MTransactionTender.");

        assertEquals(recs.size(), orphanRecords.size(), String.format("Expected %s records in view. Found %s", orphanRecords.size(), recs.size()));

        List<MTransactionTenderOrphan> orphanRecs = mTxnTndrOrphanRepo.findByBrandCd(BRAND_CD);
        assertNotNull(orphanRecs, "No records found in MTransactionTenderOrphan.");

        assertEquals(orphanRecs.size(), orphanRecords.size(), String.format("Expected %s records in view. Found %s", orphanRecords.size(), orphanRecs.size()));

        DvTransactionTenderComparer dvTxnTender = null;
        List<DvTransactionTenderComparer> foundRecordsList = new ArrayList<DvTransactionTenderComparer>();

        for (MTransactionTender rec : recs) {
            dvTxnTender = new DvTransactionTenderComparer();
            BeanUtils.copyProperties(rec, dvTxnTender);
            foundRecordsList.add(dvTxnTender);
        }
        Collections.sort(foundRecordsList);
        Collections.sort(nonOrphanRecords);

        assertEquals(foundRecordsList, nonOrphanRecords, "m_transaction_tender records donot match with dv_transaction_tender");

        List<DvTransactionTenderComparer> foundOrphanRecordsList = new ArrayList<DvTransactionTenderComparer>();

        for (MTransactionTenderOrphan orphanRec : orphanRecs) {
            dvTxnTender = new DvTransactionTenderComparer();
            BeanUtils.copyProperties(orphanRec, dvTxnTender);
            dvTxnTender.setDcrmTxnId(null);
            foundOrphanRecordsList.add(dvTxnTender);
        }
        Collections.sort(foundOrphanRecordsList);
        Collections.sort(orphanRecords);

        assertEquals(foundOrphanRecordsList, orphanRecords, "m_transaction_tender_orphan records donot match with dv_transaction_tender");

    }

    private List<DvTransactionTenderComparer> assertRecordsInMartView(List<DimensionTransactionTender> txnTenderRecs) {
        List<DvTransactionTender> txnTdrViewRecs = txnTenderRepository.findByBrandCd(BRAND_CD);
        assertNotNull(txnTdrViewRecs, "No records found in DvTransactionTender.");

        // For every record in d_transaction_tender, there should be a record in dv_transaction_tender
        assertEquals(txnTdrViewRecs.size(), txnTenderRecs.size(), String.format("Expected %s records in view. Found %s", txnTenderRecs.size(), txnTdrViewRecs.size()));

        List<DvTransactionTenderComparer> expectedRecordsListInView = new ArrayList<DvTransactionTenderComparer>();
        List<DvTransactionTenderComparer> foundRecordsListInView = new ArrayList<DvTransactionTenderComparer>();

        DvTransactionTenderComparer dvTxnTender = null;
        for (DimensionTransactionTender masterRec : txnTenderRecs) {
            dvTxnTender = new DvTransactionTenderComparer();
            BeanUtils.copyProperties(masterRec, dvTxnTender);

            if (MATCHING_TXN_NBR.equals(masterRec.getTxnNbr())) {
                dvTxnTender.setIndivId(EPOCH_MILLIS - 100);
                dvTxnTender.setHHoldId(0L);
                List<DimensionTransactionHeader> recs = dTransactionRepo.findByTxnNbr(MATCHING_TXN_NBR);
                assertNotNull(recs.get(0), "No records found in DTransactionHeader.");
                dvTxnTender.setDcrmTxnId(recs.get(0).getDcrmTxnId());
            } else {
                dvTxnTender.setIndivId(0L);
                dvTxnTender.setHHoldId(0L);
                dvTxnTender.setDcrmTxnId(null);
            }

            expectedRecordsListInView.add(dvTxnTender);
        }
        Collections.sort(expectedRecordsListInView);

        for (DvTransactionTender viewRec : txnTdrViewRecs) {
            dvTxnTender = new DvTransactionTenderComparer();
            BeanUtils.copyProperties(viewRec, dvTxnTender);
            if (dvTxnTender.getIndivId() == null) {
                dvTxnTender.setIndivId(0L);
            }
            if (dvTxnTender.getHHoldId() == null) {
                dvTxnTender.setHHoldId(0L);
            }
            foundRecordsListInView.add(dvTxnTender);
        }
        Collections.sort(foundRecordsListInView);

        assertEquals(foundRecordsListInView, expectedRecordsListInView, "dv_transaction_tender records donot match with test data");

        return foundRecordsListInView;
    }
}
