package com.epsilon.dcrm.individual;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DIndividualPhoneRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DvIndividualPhoneRepository;
import com.epsilon.dcrm.db.repository.MIndividualPhoneRepository;
import com.epsilon.dcrm.db.repository.MPhoneRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionIndividual;
import com.epsilon.dcrm.model.dimension.DvIndividualPhone;
import com.epsilon.dcrm.model.mart.MIndividualPhone;
import com.epsilon.dcrm.objects.MatillionJobTriggerSQSMessage;
import com.epsilon.dcrm.objects.MatillionVariables;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.DvIndivPhoneComparer;
import com.epsilon.dcrm.objects.comparer.MIndividualPhoneComparer;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.service.SQSService;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class IndividualPhoneTest extends AbstractTransactionalTestNGSpringContextTests {

    private static final Long FILE_ID = 1039L;
    private static final String BRAND_CD = "TEST11";

    @Autowired
    private MessagePoller messagePoller;

    @Autowired
    private SQSService sqsService;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Value("${matillion.sqs.url}")
    private String matillionSqsUrl;

    @Autowired
    private DIndividualRepository dIndivRepo;

    @Autowired
    private DIndividualPhoneRepository dIndivPhoneRepo;

    @Autowired
    private DvIndividualPhoneRepository dvIndivPhoneRepo;

    @Autowired
    private MIndividualPhoneRepository mIndivPhoneRepo;

    @Autowired
    private MPhoneRepository mPhoneRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.INDIVIDUAL_PHONE_TEST_DATA_LOAD, false);
    }

    @Rollback(false)
    @Test(groups = "IndividualPhone")
    public void testIndividualPhone() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("IndividualPhoneAutomationTest_").append(testId).toString();
        Long dcrmPhoneId = null;
        try {
            triggerMatillionJob(filename);
            pollForMessages(filename);
            // Assertions
            List<DvIndividualPhone> dvIndividualPhoneRecords = assertIndividualPhoneView();
            dcrmPhoneId = getDcrmPhoneId();
            assertMIndividualPhoneTable(dvIndividualPhoneRecords, dcrmPhoneId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(dcrmPhoneId);
        }
    }

    private Long assertMIndividualPhoneTable(List<DvIndividualPhone> dvIndividualPhoneRecords, Long dcrmPhoneId) throws ParseException {

        List<MIndividualPhone> mIndivPhoneRecords = mIndivPhoneRepo.findByDcrmPhoneId(dcrmPhoneId);
        assertEquals(mIndivPhoneRecords.size(), 1, "more than 1 record in m_individual_phone table");
        MIndividualPhone mIndivPhoneRecord = mIndivPhoneRecords.get(0);
        MIndividualPhoneComparer mIndividualPhoneComparerRecord = new MIndividualPhoneComparer();
        BeanUtils.copyProperties(mIndivPhoneRecord, mIndividualPhoneComparerRecord);

        List<MIndividualPhoneComparer> dvIndivPhoneComparerRecords = new ArrayList<MIndividualPhoneComparer>();

        for (DvIndividualPhone record : dvIndividualPhoneRecords) {
            MIndividualPhoneComparer rec = new MIndividualPhoneComparer();
            BeanUtils.copyProperties(record, rec);
            dvIndivPhoneComparerRecords.add(rec);
        }
        Collections.sort(dvIndivPhoneComparerRecords);
        assertEquals(dvIndivPhoneComparerRecords.size(), 2);
        MIndividualPhoneComparer dvIndivPhoneComparerRecord = dvIndivPhoneComparerRecords.get(1);

        assertEquals(mIndividualPhoneComparerRecord, dvIndivPhoneComparerRecord, "m_indivual_phone record do not match with test data");
        return dcrmPhoneId;

    }

    private Long getDcrmPhoneId() {
        List<DvIndividualPhone> dvIndivPhoneRecords = dvIndivPhoneRepo.findByBrandCd(BRAND_CD);
        assertEquals(dvIndivPhoneRecords.size(), 2);
        DvIndividualPhone dimIndivPhoneRecord = dvIndivPhoneRecords.get(1);
        assertNotNull(dimIndivPhoneRecord, "d_individual  record is null");
        return dimIndivPhoneRecord.getDcrmPhoneId();
    }

    private List<DvIndividualPhone> assertIndividualPhoneView() {

        List<DvIndividualPhone> dvIndividualPhoneRecords = dvIndivPhoneRepo.findByBrandCd(BRAND_CD);
        List<DvIndivPhoneComparer> dIndivPhoneComparerRecords = new ArrayList<DvIndivPhoneComparer>();
        List<DvIndivPhoneComparer> dvIndivPhoneComparerRecords = new ArrayList<DvIndivPhoneComparer>();

        for (DvIndividualPhone record : dvIndividualPhoneRecords) {
            DvIndivPhoneComparer rec = new DvIndivPhoneComparer();
            BeanUtils.copyProperties(record, rec);
            List<DimensionIndividual> dIndiviualRecords = dIndivRepo.findByIndivId(record.getIndivId());
            assertEquals(dIndiviualRecords.size(), 1, "more than 1 record in d_individual table");
            DimensionIndividual dIndiviualRecord = dIndiviualRecords.get(0);
            assertNotNull(dIndiviualRecord, "d_Individual record is null");
            dIndivPhoneComparerRecords.add(rec);
        }
        Collections.sort(dIndivPhoneComparerRecords);

        List<DvIndividualPhone> dvIndivPhoneRecords = dvIndivPhoneRepo.findByBrandCd(BRAND_CD);

        for (DvIndividualPhone record : dvIndivPhoneRecords) {
            DvIndivPhoneComparer rec = new DvIndivPhoneComparer();
            BeanUtils.copyProperties(record, rec);
            dvIndivPhoneComparerRecords.add(rec);
        }
        Collections.sort(dvIndivPhoneComparerRecords);

        assertEquals(dvIndivPhoneComparerRecords, dIndivPhoneComparerRecords, "dv_individual_phone records donot match with test data");

        return dvIndivPhoneRecords;
    }

    private void pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_PHONE, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        assertTrue(CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus()), "Refresh-M_Individual_Phone Matillion job failed");
    }

    private void triggerMatillionJob(String filename) {
        MatillionVariables variable = MatillionVariables.builder().fileName(filename).build();
        MatillionJobTriggerSQSMessage sqsMessage = MatillionJobTriggerSQSMessage.builder().group("DCRM").project("dcrm-main").version("default").job(CommonConstants.MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_PHONE)
                .environment("Test").variables(variable).build();
        sqsService.postMessageToSQS(sqsMessage, matillionSqsUrl);
    }

    private void cleanUp(Long dcrmPhoneId) {
        dIndivRepo.deleteByUpdateFileId(FILE_ID);
        mIndivPhoneRepo.deleteByDcrmPhoneId(dcrmPhoneId);
        mPhoneRepo.deleteByDcrmPhoneId(dcrmPhoneId);
        dIndivPhoneRepo.deleteByUpdateFileId(FILE_ID);
    }

}
