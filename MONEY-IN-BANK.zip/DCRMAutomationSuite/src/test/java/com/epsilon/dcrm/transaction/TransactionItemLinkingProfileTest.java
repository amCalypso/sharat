package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.DTransactionItemRepository;
import com.epsilon.dcrm.db.repository.ProfileHashRepository;
import com.epsilon.dcrm.db.repository.SProfileRepository;
import com.epsilon.dcrm.db.repository.STransactionItemRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.ProfileHash;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.model.standard.StandardTransactionItem;
import com.epsilon.dcrm.objects.MatillionJobAttributes;
import com.epsilon.dcrm.objects.MatillionWorkflowAttributes;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.csv.TransactionItem;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.properties.TransactionItemLinkingProfileTestScenarios;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;
import com.epsilon.dcrm.util.FormatUtil;
import com.epsilon.dcrm.util.JsonUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class TransactionItemLinkingProfileTest extends TransactionItemBaseTest {
    private static final Logger logger = LoggerFactory.getLogger(TransactionItemLinkingProfileTest.class);

    @Autowired
    private TransactionItemLinkingProfileTestScenarios testScenarios;

    @Autowired
    private FrmsService frmsService;

    @Autowired
    private MessagePoller messagePoller;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private STransactionItemRepository sRepo;

    @Autowired
    private DTransactionItemRepository dRepo;

    @Autowired
    private SProfileRepository sProfRepository;

    @Autowired
    private DProfileRepository dProfRepository;

    @Autowired
    private ProfileHashRepository profHashRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> txnNbrs = new ArrayList<>();
    private List<Long> fileIds = new ArrayList<>();
    private List<String> piiHashVals = new ArrayList<>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_PROFILE_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_ITEM_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_REFERENCE_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_HASH_TABLE, false);
        executeSqlScript(CommonConstants.REF_TABLE_DATA_LOAD, false);
        dProfRepository.deleteByRecSrcCd(CommonConstants.REC_SRC_CD_SHIPTO);
    }

    @AfterGroups(alwaysRun = true, groups = { "Transaction_Item_LinkingProfile" })
    @Rollback(false)
    public void afterTestCleanup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(txnNbrs)) {
                for (String txnNbr : txnNbrs) {
                    dRepo.deleteByTxnNbr(txnNbr);
                    sRepo.deleteByTxnNbr(txnNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                logger.info("FileId used to delete records from tables  - {}", fileId);
                dRepo.deleteByCreateFileId(fileId);
                dProfRepository.deleteByCreateFileId(fileId);
                clearStandardTables(fileId);
            }
        }

        if (!CollectionUtils.isEmpty(piiHashVals)) {
            for (String piiHashVal : piiHashVals) {
                logger.info("piiHashVal used to delete records from tables  - {}", piiHashVal);
                profHashRepo.deleteByPiiHashVal(piiHashVal);
            }
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 1 - Tri-part key present (new transaction, new profile)")
    /**
     * Scenario 1 - Tri-part key present (new profile)
     * Expected :
     * -- New record in the m_hash_profile table
     * -- New record in s_profile and d_profile table
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario1() throws IOException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 1);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableUpdate(csvRecords);
            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);
            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 2 - Tri-part key present (new transaction, existing profile and later activity date)", dependsOnMethods = "testTransactionItemLinkingProfile_Scenario1")
    /**
     * Scenario 2 - Tri-part key present (new transaction, existing profile and later activity date) -- updated the first name
     * Expected :
     * -- Update record in the m_hash_profile table
     * -- New record in s_profile 
     * -- Update record in d_profile table
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario2() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 2);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableUpdate(csvRecords);
            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 3 - Tri-part key present (new transaction, existing profile and past activity date)", dependsOnMethods = "testTransactionItemLinkingProfile_Scenario2")
    /**
     * Scenario 3 - Tri-part key present (new transaction, existing profile and past activity date)
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No record in s_profile 
     * -- No updates to d_profile
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario3() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 3);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableNoUpdate(csvRecords);
            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));

            assertEquals(sProfileRecords.size(), 0,
                    String.format("Profile records found in s_profile table for create_file_id - %s. Not expected to ahve records in the table since activity date is past date.", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 4 - Tri-part key present (existing profile and empty PII)", dependsOnMethods = "testTransactionItemLinkingProfile_Scenario3")
    /**
     * Scenario 4 - Tri-part key present (existing profile and empty PII)
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No record in s_profile 
     * -- No updates to d_profile
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario4() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 4);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            assertProfileHashTableNoUpdate(csvRecords);
            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));
            assertEquals(sProfileRecords.size(), 0,
                    String.format("Profile records found in s_profile table for create_file_id - %s ", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 5 - Tri-part key not present (new transaction, existing profile(matching PII found))", dependsOnMethods = "testTransactionItemLinkingProfile_Scenario2")
    /**
     * Scenario 5 - Tri-part key not present (new transaction, existing profile(matching PII found))
     * Expected :
     * -- Do not update m_hash_profile table
     * -- No new record in s_profile 
     * -- Update record in s_transaction_item (srcAcctNbr to the srcAcctNbr of the matching PII from the hash table)
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario5() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 5);

            Long fileId = pollForMessages(filename);

            // Assertions begin
            // There is only one record in test data
            String generatedHash = generateHash(csvRecords.get(0));
            piiHashVals.add(generatedHash);
            ProfileHash pHash = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(csvRecords.get(0).getBrandCd(), csvRecords.get(0).getShipToAcctSrcCd(), generatedHash);
            assertNotNull(pHash, String.format("No record found in m_profile_hash table for srcCd - %s , brandCd - %s and piiHashVal - %s.", csvRecords.get(0).getShipToAcctSrcCd(), csvRecords.get(0).getBrandCd(), generatedHash));
            csvRecords.get(0).setShipToAcctSrcNbr(pHash.getSrcAcctNbr()); // Expected. Next steps would make sure csv data compares with the DB data.

            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s ", fileId));
            assertEquals(sProfileRecords.size(), 0, String.format("No Profile records from s_profile table for create_file_id - %s ", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 6 - Tri-part key not present (new transaction, Matching profile(PII) not found)")
    /**
     * Scenario 6 - Tripart key not present (new transaction, Matching profile(PII) not found)
     * Expected :
     * -- New record in m_hash_profile table (srcAcctNbr being the piiHashVal)
     * -- New record in s_profile 
     * -- New record in d_profile
     * -- Update record in s_transaction_item (srcAcctNbr to the srcAcctNbr of the matching PII from the hash table)
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario6() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 6);
            Long fileId = pollForMessages(filename);

            // Assertions begin
            // There is only one record in test data
            String generatedHash = generateHash(csvRecords.get(0));
            piiHashVals.add(generatedHash);

            ProfileHash pHash = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(csvRecords.get(0).getBrandCd(), csvRecords.get(0).getShipToAcctSrcCd(), generatedHash);
            assertNotNull(pHash, String.format("No record found in m_profile_hash table for srcCd - %s , brandCd - %s and piiHashVal - %s.", csvRecords.get(0).getShipToAcctSrcCd(), csvRecords.get(0).getBrandCd(), generatedHash));
            assertEquals(pHash.getPiiHashVal(), generatedHash, String.format("Hash value not equal. Expected - %s. Actual- %s", generatedHash, pHash.getPiiHashVal()));
            assertEquals(pHash.getSrcAcctNbr(), generatedHash, String.format("SrcAcctNbr not equal. Expected - %s. Actual- %s", generatedHash, pHash.getSrcAcctNbr()));

            csvRecords.get(0).setShipToAcctSrcNbr(pHash.getSrcAcctNbr()); // Expected. Next steps would make sure csv data compares with the DB data.

            assertTransactionItemTables(csvRecords, fileId);
            pollForProfileRefreshMessage(filename);
            assertProfileTables(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    @Rollback(false)
    @Test(groups = "Transaction_Item_LinkingProfile", description = "Scenario 7 - Tri-part key not present (Matching profile not found) -- billto_shipto_ind = 1 (same)")
    /**
     * Scenario 7 - Tri-part key not present (Matching profile not found) -- billto_shipto_ind = 1 (same)
     * Expected :
     * -- New record in m_hash_profile table (srcAcctNbr being the piiHashVal)
     * -- No record in s_profile 
     * -- No record in d_profile
     * -- Update record in s_transaction_item (srcAcctNbr to the srcAcctNbr of the matching PII from the hash table)
     * -- New record in d_transaction_item table. 
     * @throws IOException
     */
    public void testTransactionItemLinkingProfile_Scenario7() throws ParseException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append(CommonConstants.FILE_PREFIX_TRANS_ITEM_LINKPROF).append(testId).toString();

        try {
            List<TransactionItem> csvRecords = startProcess(filename, 7);
            Long fileId = pollForMessages(filename);

            // There is only one record in test data
            String generatedHash = generateHash(csvRecords.get(0));
            piiHashVals.add(generatedHash);

            ProfileHash pHash = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(csvRecords.get(0).getBrandCd(), csvRecords.get(0).getShipToAcctSrcCd(), generatedHash);
            assertNotNull(pHash, String.format("No record found in m_profile_hash table for srcCd - %s , brandCd - %s and piiHashVal - %s.", csvRecords.get(0).getShipToAcctSrcCd(), csvRecords.get(0).getBrandCd(), generatedHash));
            assertEquals(pHash.getPiiHashVal(), generatedHash, String.format("Hash value not equal. Expected - %s. Actual- %s", generatedHash, pHash.getPiiHashVal()));
            assertEquals(pHash.getSrcAcctNbr(), generatedHash, String.format("SrcAcctNbr not equal. Expected - %s. Actual- %s", generatedHash, pHash.getSrcAcctNbr()));

            csvRecords.get(0).setShipToAcctSrcNbr(pHash.getSrcAcctNbr()); // Expected. Next steps would make sure csv data compares with the DB data.

            assertTransactionItemTables(csvRecords, fileId);

            pollForProfileRefreshMessage(filename);

            List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);
            assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s", fileId));
            assertEquals(sProfileRecords.size(), 0, String.format("No Profile records from s_profile table for create_file_id - %s", fileId));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    private void clearStandardTables(Long fileId) {
        sRepo.deleteByCreateFileId(fileId);
        sProfRepository.deleteByCreateFileId(fileId);
    }

    private List<TransactionItem> startProcess(String filename, int scenario) throws IOException, ApplicationException, NoSuchAlgorithmException {
        List<TransactionItem> csvRecords = Arrays.asList(
                CSVUtil.getObject(testScenarios.getScenario().get(scenario), TransactionItem.class));
        assertNotNull(csvRecords, "Empty list of records from test csv");
        assertEquals(csvRecords.size(), 1, String.format("Test data count does not match. Expected - %s. Actual - %s", 1, csvRecords.size()));

        for (TransactionItem record : csvRecords) {
            String generatedHash = generateHash(record);
            piiHashVals.add(generatedHash); // For cleanup later 
            if (scenario == 1) {
                // Clear the hash table for the very first test
                profHashRepo.deleteBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getShipToAcctSrcCd(), record.getShipToAcctSrcNbr());
            }
        }

        uploadDataFile(filename, csvRecords);
        frmsService.testEnable(CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ITEM_WITH_PII);

        return csvRecords;
    }

    private void pollForProfileRefreshMessage(String filename) throws ApplicationException {

        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(
                filename,
                CommonConstants.MATILLION_JOB_NAME_REFRESH_PII,
                sqsUrl,
                50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
    }

    private Long pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        Long fileId = null;
        messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_LDC, sqsUrl, 20);
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_TRANSACTION_ITEM, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matillion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc()) && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            assertNotNull(pollMatillionMessage.getSrcSystem(), "Matiilion message object is null");
            assertNotNull(pollMatillionMessage.getSrcSystem().getData(), "Null SRCSytem from Matillion");
            MatillionWorkflowAttributes attributes = JsonUtil.getObject(pollMatillionMessage.getSrcSystem().getData(), MatillionWorkflowAttributes.class);
            assertNotNull(attributes, "Null Workflow attributes from matillion");
            List<MatillionJobAttributes> subJobs = attributes.getSubJobs();
            assertNotNull(subJobs, "Subjobs null from matillion");
            boolean jobPresent = subJobs.stream().anyMatch(item -> CommonConstants.MATILLION_JOB_NAME_LOAD_S_TRANSITM_AND_S_PROFILE.equals(item.getJobName()));
            // The job should not be present for a Transaction Item feed when there is no PII update.
            assertTrue(jobPresent, "Matillion did not invoke Profile associated workflows for feed with PII update");

            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    private void assertProfileHashTableUpdate(List<TransactionItem> csvRecords) throws NoSuchAlgorithmException, ParseException {
        // Assertions for profile_hash table.
        for (TransactionItem record : csvRecords) {
            String generatedHash = generateHash(record);
            ProfileHash hashRecordInDB = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getShipToAcctSrcCd(), record.getShipToAcctSrcNbr());
            Timestamp activityTs = FormatUtil.getTimestampFromString(record.getActivityTs(), CommonConstants.TIMESTAMP_FORMAT);

            assertNotNull(hashRecordInDB, String.format("Null Hash Profile record in DB for brandCd - %s, acctSrcCd - %s, acctSrcNbr - %s", record.getBrandCd(), record.getShipToAcctSrcCd(), record.getShipToAcctSrcNbr()));
            assertEquals(hashRecordInDB.getPiiHashVal(), generatedHash, String.format("Hash value not equal. Expected - %s. Actual- %s", generatedHash, hashRecordInDB.getPiiHashVal()));
            assertEquals(hashRecordInDB.getActivityts(), activityTs, String.format("Activity timestamp not equal. Expected - %s. Actual- %s", activityTs, hashRecordInDB.getActivityts()));
        }
    }

    private void assertProfileHashTableNoUpdate(List<TransactionItem> csvRecords) throws NoSuchAlgorithmException, ParseException {

        for (TransactionItem record : csvRecords) {
            String generatedHash = generateHash(record);
            ProfileHash hashRecordInDB = profHashRepo.findBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(record.getBrandCd(), record.getShipToAcctSrcCd(), record.getShipToAcctSrcNbr());
            Timestamp activityTs = FormatUtil.getTimestampFromString(record.getActivityTs(), CommonConstants.TIMESTAMP_FORMAT);

            assertNotNull(hashRecordInDB, String.format("Null Hash Profile record in DB for brandCd - %s, acctSrcCd - %s, acctSrcNbr - %s", record.getBrandCd(), record.getShipToAcctSrcCd(), record.getShipToAcctSrcNbr()));
            if (generatedHash.equals(hashRecordInDB.getPiiHashVal())) {
                assertTrue(false, String.format("Hash value equal. Should not get updated since activity date is a past date"));
            }
            if (activityTs.equals(hashRecordInDB.getActivityts())) {
                assertTrue(false, String.format("Activity timestamp value equal. Should not get updated since activity date is a past date"));
            }
        }
    }

    private void assertTransactionItemTables(List<TransactionItem> csvRecords, Long fileId) throws ParseException {
        List<StandardTransactionItem> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionTransactionItem> dimTranRecords = dRepo.findByUpdateFileId(fileId);
        assertNotNull(dimTranRecords, String.format("Null object for TransactionItem records from d_transaction_item table for update_file_id - %s", fileId));
        assertDimensionTableData(csvRecords, dimTranRecords);

        assertCreateFileFields_CreateFlow(dimTranRecords);

    }

    private void assertProfileTables(List<TransactionItem> csvRecords, Long fileId) {
        List<DimensionProfile> dProfileRecords = dProfRepository.findByUpdateFileId(fileId);
        List<StandardProfile> sProfileRecords = sProfRepository.findByCreateFileId(fileId);

        assertNotNull(dProfileRecords, String.format("Null object for Profile records from d_profile table for update_file_id - %s", fileId));
        assertNotNull(sProfileRecords, String.format("Null object for Profile records from s_profile table for create_file_id - %s", fileId));

        // There is only one record in test data 
        assertEquals(dProfileRecords.size(), 1, String.format("No Profile records from d_profile table for update_file_id - %s", fileId));
        assertEquals(sProfileRecords.size(), 1, String.format("No Profile records from s_profile table for create_file_id - %s", fileId));

        StandardProfile sProfileRec = sProfileRecords.get(0);
        assertNotNull(sProfileRec);

        assertEquals(sProfileRec.getRecSrcCd(), CommonConstants.REC_SRC_CD_SHIPTO, String.format("REC_SRC_CD field not populated with expected value - %s. Found - %s", CommonConstants.REC_SRC_CD_SHIPTO, sProfileRec.getRecSrcCd()));
        assertEquals(sProfileRec.getBrandCd(), csvRecords.get(0).getBrandCd(), String.format("BRAND_CD field not populated with expected value - %s. Found - %s", csvRecords.get(0).getBrandCd(), sProfileRec.getBrandCd()));
        assertEquals(sProfileRec.getAcctSrcCd(), csvRecords.get(0).getShipToAcctSrcCd(), String.format("ACCT_SRC_CD field not populated with expected value - %s. Found - %s", csvRecords.get(0).getShipToAcctSrcCd(), sProfileRec.getAcctSrcCd()));
        assertEquals(sProfileRec.getAcctSrcNbr(), csvRecords.get(0).getShipToAcctSrcNbr(), String.format("SRC_ACCT_NBR field not populated with expected value - %s. Found - %s", csvRecords.get(0).getShipToAcctSrcNbr(), sProfileRec.getAcctSrcNbr()));

        assertEquals(CopyUtil.partialConvertSProfile(sProfileRecords), CopyUtil.partialConvertDProfile(dProfileRecords), "Dprofile and SProfile records do not match.");
    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }
}
