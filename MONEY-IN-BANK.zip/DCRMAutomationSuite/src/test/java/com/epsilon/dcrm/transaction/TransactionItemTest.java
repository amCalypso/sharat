package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DProductCatalogRepository;
import com.epsilon.dcrm.db.repository.DTransactionItemRepository;
import com.epsilon.dcrm.db.repository.STransactionItemRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionProductCatalog;
import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.standard.StandardTransactionItem;
import com.epsilon.dcrm.objects.comparer.DimensionProductCatalogComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionItemComparer;
import com.epsilon.dcrm.objects.csv.TransactionItem;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class TransactionItemTest extends BaseTest {
    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/TransactionItemAutomationTestStandard_Create.txt";
    private static final String EXISTING_SKU = "1LSoesyaWsb8nxsXsa1o2mataH4f3CSt";
    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final long FILE_ID = (long) Math.ceil(Math.random() * 10000);
    private static final String BRAND_CD = "Ford";

    @Autowired
    private STransactionItemRepository sRepo;

    @Autowired
    private DTransactionItemRepository dRepo;

    @Autowired
    private DProductCatalogRepository dProdCatalogRepo;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    private List<String> txnNbrs = new ArrayList<>();
    private List<Long> fileIds = new ArrayList<>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_TRANSACTION_ITEM_TABLES, false);
        executeSqlScript(CommonConstants.CREATE_PRODUCTCATALOG_TABLES, false);
        dProdCatalogRepo.insertSimpleTestRecord(EXISTING_SKU, BRAND_CD, FILE_ID, 0L);

    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Transaction_Item_Standard", "Transaction_Item_Custom" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(txnNbrs)) {
                for (String txnNbr : txnNbrs) {
                    dRepo.deleteByTxnNbr(txnNbr);
                    sRepo.deleteByTxnNbr(txnNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                dRepo.deleteByCreateFileId(fileId);
            }
        }
        dProdCatalogRepo.deleteByBrandCd(BRAND_CD);
    }

    /***
     * 1. Upload file to S3
     * 2. Start the FRMS workflow
     * 3. Read the csv data (test data)
     * 4. Poll the SQS for matillion job status
     * {
        "jobName":"Refresh-D_TRANSACTION_ITEM",
        "status":"completed",
        "create_file_nm" :"TransactionItemAutomationTestStandard_Create_114cbfb1-d23f-41f7-a39d-5d3d844ac099",
        "create_file_ts" :"2017-09-08 18:47:14",
        "automationTestId":"114cbfb1-d23f-41f7-a39d-5d3d844ac099"
        } 
     * 5. Assertions
     *   // TODO - Add rolling table assertions
     */
    @Rollback(false)
    @Test(groups = "Transaction_Item_Standard")
    public void testTransactionItemRecord_Standard_Create() {

        String filename = new StringBuilder().append("TransactionItemAutomationTestStandard_Create_").append(RAND_STRING).toString();
        try {
            List<TransactionItem> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, TransactionItem.class, null);
            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ITEM_WITHOUT_PII_UPDATE);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_TRANSACTION_ITEM);
            // Assertions
            assertTransItemTables(csvRecords, fileId);
            assertNewSkuIds(csvRecords, fileId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(filename);
        }
    }

    //   @Test(groups = "Transaction_Item_Custom")
    public void testTransactionItemRecord_Custom_Create() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        // TODO - Future
    }

    private void assertCreateFileFields_CreateFlow(List<DimensionTransactionItem> dimTranRecords) {
        for (DimensionTransactionItem dimTranRecord : dimTranRecords) {
            assertEquals(dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId(),
                    String.format("CreateFileId and UpdateFileId does not match in DTransactionItem table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileId(), dimTranRecord.getUpdateFileId()));
            assertEquals(dimTranRecord.getCreateFileRecNbr(), dimTranRecord.getUpdateFileRecNbr(),
                    String.format("CreateRecNbr and UpdateRecNbr does not match in DTransactionItem table . Actual - %s, Expected - %s", dimTranRecord.getCreateFileRecNbr(), dimTranRecord.getUpdateFileRecNbr()));
        }
    }

    private void assertStandardTableData(List<TransactionItem> csvRecords, List<StandardTransactionItem> dbRecords) throws ParseException {
        List<TransactionItem> convertedStandardTransactionItemRecords = CopyUtil.convertStandardTransactionItem(dbRecords);
        // Confirm the records in the test file are loaded to the standard table.
        assertEquals(convertedStandardTransactionItemRecords, csvRecords, "STransactionItem records donot match the test data.");
    }

    private void assertDimensionTableData(List<TransactionItem> csvRecords, List<DimensionTransactionItem> dimTranRecords) throws ParseException {
        List<DimensionTransactionItemComparer> convertedDimensionTransactionItemRecords = CopyUtil.convertDimensionTransactionItem(dimTranRecords);

        List<DimensionTransactionItemComparer> convertedTransactionItemCsvRecords = new ArrayList<DimensionTransactionItemComparer>();
        for (TransactionItem record : csvRecords) {
            DimensionTransactionItemComparer rec = new DimensionTransactionItemComparer();
            BeanUtils.copyProperties(record, rec);
            // Business requirements : to populate these fields from the Brand_cd in the input
            rec.setShipToBrandCd(record.getBrandCd());
            rec.setProdCatalogBrandCd(record.getBrandCd());
            convertedTransactionItemCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedTransactionItemCsvRecords, convertedDimensionTransactionItemRecords, "DTransactionItem records do not match test data.");
    }

    private void assertNewSkuIds(List<TransactionItem> csvRecords, Long fileId) {
        List<DimensionProductCatalog> dimProdRecords = dProdCatalogRepo.findByBrandCd(BRAND_CD);
        assertEquals(dimProdRecords.size(), 2, String.format("Did not match expected record count in d_product_catalog table. Actual - %s, Expected - %s", dimProdRecords.size(), 2));
        dimProdRecords = dProdCatalogRepo.findByCreateFileId(fileId);

        List<DimensionProductCatalogComparer> expectedDimProductComparerRecords = new ArrayList<DimensionProductCatalogComparer>();
        List<DimensionProductCatalogComparer> actualDimProductComparerRecords = new ArrayList<DimensionProductCatalogComparer>();

        for (DimensionProductCatalog record : dimProdRecords) {
            DimensionProductCatalogComparer rec = new DimensionProductCatalogComparer();
            BeanUtils.copyProperties(record, rec);

            actualDimProductComparerRecords.add(rec);
        }
        for (TransactionItem record : csvRecords) {
            if (!EXISTING_SKU.equals(record.getSku())) {
                DimensionProductCatalogComparer rec = new DimensionProductCatalogComparer();
                rec.setSku(record.getSku());
                rec.setBrandCd(record.getBrandCd());
                expectedDimProductComparerRecords.add(rec);
            }
        }

        assertEquals(actualDimProductComparerRecords, expectedDimProductComparerRecords, String.format("Records in d_product_catalog do not match with test data for fileId - %s", fileId));

    }

    private void cleanUp(String filename) {
        String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
    }

    private void assertTransItemTables(List<TransactionItem> csvRecords, Long fileId) throws ParseException {
        List<StandardTransactionItem> dbRecords = sRepo.findByCreateFileId(fileId);
        assertStandardTableData(csvRecords, dbRecords);

        List<DimensionTransactionItem> dimTranRecords = dRepo.findByCreateFileId(fileId);
        assertDimensionTableData(csvRecords, dimTranRecords);

        assertCreateFileFields_CreateFlow(dimTranRecords);
    }
}
