package com.epsilon.dcrm.metadata;

import static org.testng.Assert.assertEquals;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.MetadataSourceRepository;
import com.epsilon.dcrm.db.repository.VMetadataSourceRepository;
import com.epsilon.dcrm.model.loyalty.AggregationDetail;
import com.epsilon.dcrm.model.loyalty.TableColumn;
import com.epsilon.dcrm.model.loyalty.TableDetail;
import com.epsilon.dcrm.model.mart.MetadataSource;
import com.epsilon.dcrm.objects.MatillionVariables;

/**
 * This test class is used for generic tests for all of the supported Aggregate functions. This doesn't 
 * include Story specific tests which would utilize the Aggregate tables created.
 * @author jblasingame
 *
 */
@RunWith(SpringRunner.class)
public class StandardAggregationTest extends BaseAggregationTest {

    @Autowired
    private MetadataSourceRepository metaTableRepo;

    @Autowired
    private VMetadataSourceRepository metaViewRepo;

    private static List<String> brand_cds = new ArrayList<>();
    private static final String SOURCE_SCHEMA = "test_crm_mart_passive";
    private static final String SOURCE_TABLE = "metadata_source";
    private static final String SOURCE_VIEW = "v_metadata_source";
    private static final String TARGET_SCHEMA = "test_crm_mart_passive";
    private static final int TEST_RECORD_CNT = 10;
    private static final long CURRENT_MILLIS = System.currentTimeMillis();
    private static final long MILLIS_IN_MONTH = 5259492000L;
    private static final String TEST_FILE_PREFIX = "MetadataProcessorTest_";
    private static final String PURCH_TXN_AMT_COLUMN = "purch_txn_amt";
    private static final String BRAND_CD_COLUMN = "brand_cd";
    private static final String TXN_MONTH_COLUMN = "txn_yyyymm";

    private static TableDetail metadataTableDetail;
    private static TableDetail metadataViewDetail;

    @BeforeClass
    public void setup() {
        IntStream.rangeClosed(1, 3).forEach(x -> brand_cds.add(UUID.randomUUID().toString().substring(0, 5)));
        IntStream.rangeClosed(1, TEST_RECORD_CNT).forEach(x -> insertSourceRecord());
        metaTableRepo.flush();
        metadataTableDetail = createMetadataTable(false);
        metadataViewDetail = createMetadataTable(true);
    }

    @AfterClass
    public void teardown() {
        aggregationIds.forEach(id -> loyaltyService.deleteAggregation(id));
        tableIds.forEach(id -> loyaltyService.deleteTable(id));
        tableNames.forEach(tableName -> jdbcTemplate.execute(MessageFormat.format(DROP_TABLE, TARGET_SCHEMA, tableName)));
        sourceTableRowIds.forEach(id -> metaTableRepo.delete(id));
    }

    /**
     * This test uses a View as the source and creates an aggregate table with multiple aggregates
     * using multiple group by columns.
     * Confirms: DCM-1652 --> Test aggregate that uses more than one GroupBy clause
     * Confirms: DCM-1654 --> Leverage a user-defined view
     */
    @Test
    public void multiGroupByMultiAggregateViewNumericTest() throws Exception {
        String filename = new StringBuilder().append(TEST_FILE_PREFIX).append(RAND_STRING).toString();

        AggregationDetail aggDetail = buildAggregations(metadataViewDetail.getTableId(),
                TARGET_SCHEMA,
                "automation_" + UUID.randomUUID().toString().replaceAll("-", ""),
                Arrays.asList(
                        Pair.of(PURCH_TXN_AMT_COLUMN, AGGREGATE.COUNT),
                        Pair.of(PURCH_TXN_AMT_COLUMN, AGGREGATE.MIN),
                        Pair.of(PURCH_TXN_AMT_COLUMN, AGGREGATE.MAX),
                        Pair.of(PURCH_TXN_AMT_COLUMN, AGGREGATE.SUM),
                        Pair.of(PURCH_TXN_AMT_COLUMN, AGGREGATE.AVG)),
                BRAND_CD_COLUMN, TXN_MONTH_COLUMN);

        triggerMatillionJob(CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR,
                buildMatillionVars(filename, SOURCE_VIEW, aggDetail.getTargetSqlTableName()));

        pollForMetadataMessages(aggDetail.getTargetSqlTableName(), CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR);
        List<Map<String, Object>> actualRows = assertColumns(aggDetail);
        long expectedRowCount = metaViewRepo.findAll().stream()
                .map(row -> row.getBrandCd().concat(row.getTxnMonth()))
                .distinct()
                .count();
        assertEquals(expectedRowCount, actualRows.size(), "Expected row count does not match with actual.");
    }

    /**
     * This test uses a Table as the source and creates an aggregate table with multiple aggregates
     * using a single group by column.
     * Confirms: DCM-1751 --> Aggregate with one GroupBy and one aggregation column
     */
    @Test
    public void singleGroupByMultiAggregateTest() throws Exception {
        String filename = new StringBuilder().append(TEST_FILE_PREFIX).append(RAND_STRING).toString();

        AggregationDetail aggDetail = buildAggregations(metadataTableDetail.getTableId(),
                TARGET_SCHEMA,
                "automation_" + UUID.randomUUID().toString().replaceAll("-", ""),
                Arrays.asList(
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.COUNT),
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.MIN),
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.MAX)),
                BRAND_CD_COLUMN);

        triggerMatillionJob(CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR,
                buildMatillionVars(filename, SOURCE_TABLE, aggDetail.getTargetSqlTableName()));

        pollForMetadataMessages(aggDetail.getTargetSqlTableName(), CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR);
        List<Map<String, Object>> actualRows = assertColumns(aggDetail);
        long expectedRowCount = metaTableRepo.findAll().stream()
                .map(row -> row.getBrandCd())
                .distinct()
                .count();
        assertEquals(expectedRowCount, actualRows.size(), "Expected row count does not match with actual.");
    }

    /**
     * This test uses a View as the source and creates an aggregate table with multiple aggregates
     * using multiple group by columns.
     * Confirms: DCM-1652 --> Test aggregate that uses more than one GroupBy clause
     * Confirms: DCM-1654 --> Leverage a user-defined view
     */
    @Test
    public void multiGroupByMultiAggregateViewTest() throws Exception {
        String filename = new StringBuilder().append(TEST_FILE_PREFIX).append(RAND_STRING).toString();

        AggregationDetail aggDetail = buildAggregations(metadataViewDetail.getTableId(),
                TARGET_SCHEMA,
                "automation_" + UUID.randomUUID().toString().replaceAll("-", ""),
                Arrays.asList(
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.COUNT),
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.MIN),
                        Pair.of(BRAND_CD_COLUMN, AGGREGATE.MAX)),
                BRAND_CD_COLUMN, TXN_MONTH_COLUMN);

        triggerMatillionJob(CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR,
                buildMatillionVars(filename, SOURCE_VIEW, aggDetail.getTargetSqlTableName()));

        pollForMetadataMessages(aggDetail.getTargetSqlTableName(), CommonConstants.MATILLION_JOB_NAME_METADATA_PROCESSOR);
        List<Map<String, Object>> actualRows = assertColumns(aggDetail);
        long expectedRowCount = metaViewRepo.findAll().stream()
                .map(row -> row.getBrandCd().concat(row.getTxnMonth()))
                .distinct()
                .count();
        assertEquals(expectedRowCount, actualRows.size(), "Expected row count does not match with actual.");
    }

    /**
     * Build the source table to be created in the Metadata API.
     * @return
     */
    private TableDetail createMetadataTable(boolean isView) {
        List<TableColumn> tableColumns = new ArrayList<>();
        if (isView) {
            tableColumns.add(createTestColumn(TXN_MONTH_COLUMN, "varchar(6)"));
        }
        tableColumns.add(createTestColumn("row_id", "int8"));
        tableColumns.add(createTestColumn("txn_tx", "timestamp"));
        tableColumns.add(createTestColumn("indiv_id", "numeric(20,0)"));
        tableColumns.add(createTestColumn(BRAND_CD_COLUMN, "varchar(5)"));
        tableColumns.add(createTestColumn(PURCH_TXN_AMT_COLUMN, "numeric(15,2)"));

        String ddlString = new StringBuilder()
                .append("create ")
                .append(isView ? "view " : "table ")
                .append(SOURCE_SCHEMA)
                .append(isView ? SOURCE_VIEW : SOURCE_TABLE)
                .append(" (row_id int8 NOT NULL IDENTITY(1,1), txn_ts timestamp,")
                .append(" indiv_id numeric(20,0), brand_cd varchar(5),")
                .append(" purch_txn_amt numeric(15,2));")
                .toString();

        TableDetail detail = TableDetail.builder()
                .schema(SOURCE_SCHEMA)
                .sqlName(isView ? SOURCE_VIEW : SOURCE_TABLE)
                .subjectArea("Automation")
                .view(isView)
                .ddl(ddlString)
                .columns(tableColumns)
                .build();
        detail.setName(isView ? SOURCE_VIEW : SOURCE_TABLE);
        detail = loyaltyService.createTable(detail);
        tableIds.add(detail.getTableId());
        return detail;
    }

    /**
     * Insert generated source record into the metadata_source table
     */
    private void insertSourceRecord() {
        String rowId = UUID.randomUUID().toString();
        sourceTableRowIds.add(rowId);

        Timestamp insertTs = new Timestamp(ThreadLocalRandom.current().nextLong(CURRENT_MILLIS - MILLIS_IN_MONTH, CURRENT_MILLIS));

        MetadataSource newRecord = MetadataSource.builder()
                .brandCd(randFromList(brand_cds))
                .indivId(RAND.nextLong())
                .txnTs(insertTs)
                .purchTxnAmt(getRandDouble())
                .rowId(rowId)
                .build();
        metaTableRepo.save(newRecord);
    }

    private MatillionVariables buildMatillionVars(String filename, String sourceTableName, String targetTableName) {
        return MatillionVariables.builder()
                .fileName(filename)
                .sourceSchemaName(SOURCE_SCHEMA)
                .sourceTableName(sourceTableName)
                .targetSchemaName(TARGET_SCHEMA)
                .targetTableName(targetTableName)
                .metadataAggregateFlag(Boolean.TRUE.toString())
                .build();
    }

}