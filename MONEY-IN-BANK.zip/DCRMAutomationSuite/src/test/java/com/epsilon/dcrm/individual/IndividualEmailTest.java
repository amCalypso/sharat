package com.epsilon.dcrm.individual;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmailAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualEmailRepository;
import com.epsilon.dcrm.db.repository.DIndividualGoldenProfileRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DvIndividualEmailRepository;
import com.epsilon.dcrm.db.repository.MEmailAddressRepository;
import com.epsilon.dcrm.db.repository.MIndividualEmailRepository;
import com.epsilon.dcrm.model.dimension.DimensionEmailAddress;
import com.epsilon.dcrm.model.dimension.DimensionIndividual;
import com.epsilon.dcrm.model.dimension.DimensionIndividualEmail;
import com.epsilon.dcrm.model.dimension.DimensionIndividualGoldenProfile;
import com.epsilon.dcrm.model.dimension.DvIndividualEmail;
import com.epsilon.dcrm.model.mart.MEmailAddress;
import com.epsilon.dcrm.model.mart.MIndividualEmail;
import com.epsilon.dcrm.objects.comparer.DvIndivEmailComparer;
import com.epsilon.dcrm.objects.comparer.MEmailAddressComparer;
import com.epsilon.dcrm.objects.comparer.MIndividualEmailComparer;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class IndividualEmailTest extends BaseTest {

    private static final long FILE_ID = (long) Math.ceil(Math.random() * 10000);
    private static final Long INDIV_ID = 1000000817464L;
    private static final String BRAND_CD = "ie-brand-cd-1";
    private static final String EMAIL_ADDR = "kot@pirog.org";

    @Value("${sqs.url}")
    private String sqsrUl;

    @Value("${matillion.sqs.url}")
    private String matillionSqsUrl;

    @Autowired
    private DIndividualRepository dIndividualRepo;

    @Autowired
    private DIndividualGoldenProfileRepository dIndividualGoldenProfileRepo;

    @Autowired
    private DEmailAddressRepository dEmailAddressRepo;

    @Autowired
    private DIndividualEmailRepository dIndivEmailRepo;

    @Autowired
    private DvIndividualEmailRepository dvIndivEmailRepo;

    @Autowired
    private MIndividualEmailRepository mIndividualEmailRepo;

    @Autowired
    private MEmailAddressRepository mEmailAddressRepo;

    @BeforeClass
    public void setup() {
        dIndividualRepo.insertSimpleTestRecord(INDIV_ID, 55L, FILE_ID);
        dEmailAddressRepo.insertSimpleTestRecord(EMAIL_ADDR, FILE_ID);
        dIndivEmailRepo.insertSimpleTestRecord(INDIV_ID, EMAIL_ADDR, "Y", "Y", BRAND_CD, "source1", FILE_ID);
        // set d_individual_golden_profile.dcrm_indiv_email_id = d_individual_email.dcrm_indiv_email_id
        for (DimensionIndividualEmail record : dIndivEmailRepo.findByUpdateFileId(FILE_ID)) {
            dIndividualGoldenProfileRepo.insertSimpleTestRecord(INDIV_ID, BRAND_CD, 0L, record.getDcrmIndivEmailId(), 0L);
        }
    }

    @Rollback(false)
    @Test(groups = "IndividualEmail")
    public void testIndividualEmail() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("IndividualEmailAutomationTest_").append(testId).toString();
        String job = CommonConstants.MATILLION_JOB_NAME_REFRESH_M_EMAIL;
        Long dcrmEmailAddrId = 0L;
        try {
            triggerMatillionJob(filename, job);
            pollForMessages(filename, job);

            // compare dv_individual_email view with d_ tables
            List<DvIndividualEmail> dvIndividualEmailRecords = dvIndivEmailRepo
                    .findByIndivIdAndBrandCdAndEmailAddrOrderByUpdateTsDesc(INDIV_ID, BRAND_CD, EMAIL_ADDR);
            validateView(dvIndividualEmailRecords);

            // compare m_ table with the dv_individual_email view
            dcrmEmailAddrId = dvIndividualEmailRecords.get(0).getDcrmEmailAddrId();
            Long currIndivId = dvIndividualEmailRecords.get(0).getCurrIndivId();
            validateMart(dvIndividualEmailRecords, dcrmEmailAddrId, currIndivId);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp(dcrmEmailAddrId);
        }
    }

    private List<DvIndivEmailComparer> getViewComparerRecords(List<DvIndividualEmail> dvIndividualEmailRecords) {
        List<DvIndivEmailComparer> dvIndivEmailComparerRecords = new ArrayList<DvIndivEmailComparer>();
        for (DvIndividualEmail record : dvIndividualEmailRecords) {
            DvIndivEmailComparer rec = new DvIndivEmailComparer();
            BeanUtils.copyProperties(record, rec);
            dvIndivEmailComparerRecords.add(rec);
        }
        Collections.sort(dvIndivEmailComparerRecords);
        return dvIndivEmailComparerRecords;
    }

    private void validateView(List<DvIndividualEmail> dvIndividualEmailRecords) {

        // dv_individual_email comparer records
        List<DvIndivEmailComparer> dvIndivEmailComparerRecords = getViewComparerRecords(dvIndividualEmailRecords);
        List<DimensionIndividualEmail> dIndivEmailRecords = dIndivEmailRepo.findByUpdateFileId(FILE_ID);

        // d_ tables comparer records
        List<DvIndivEmailComparer> dTablesComparerRecords = new ArrayList<DvIndivEmailComparer>();
        for (DimensionIndividualEmail record : dIndivEmailRecords) {
            DvIndivEmailComparer rec = new DvIndivEmailComparer();
            BeanUtils.copyProperties(record, rec);
            // d_individual.curr_indiv_id
            List<DimensionIndividual> dIndividualRecords = dIndividualRepo.findByIndivId(record.getIndivId());
            assertEquals(dIndividualRecords.size(), 1, "cannot find single indiv_id in d_individual");
            rec.setCurrIndivId(dIndividualRecords.get(0).getCurrIndiv_id());
            // d_email_address.dcrm_email_addr_id
            List<DimensionEmailAddress> dEmailAddressRecords = dEmailAddressRepo.findByEmailAddr(record.getEmailAddr());
            assertEquals(dEmailAddressRecords.size(), 1, "cannot find single email_addr in d_email_address");
            rec.setDcrmEmailAddrId(dEmailAddressRecords.get(0).getDcrmEmailAddrId());
            // d_individual_golden_profile.dcrm_indiv_email_id
            List<DimensionIndividualGoldenProfile> dIndividualGoldenProfileRecords = dIndividualGoldenProfileRepo.findByDcrmIndivEmailId(record.getDcrmIndivEmailId());
            if (dIndividualGoldenProfileRecords.isEmpty()) {
                rec.setBestEmailAddrInd("N");
            } else {
                rec.setBestEmailAddrInd("Y");
            }

            dTablesComparerRecords.add(rec);
        }
        Collections.sort(dTablesComparerRecords);

        assertEquals(dTablesComparerRecords, dvIndivEmailComparerRecords, "d_ tables do not match dv_individual_email");

    }

    private void validateMart(List<DvIndividualEmail> dvIndividualEmailRecords, Long dcrmEmailAddrId,
            Long currIndivId) {

        validateMIndividualEmail(dvIndividualEmailRecords, dcrmEmailAddrId, currIndivId);

        validateMEmailAddress(dvIndividualEmailRecords, dcrmEmailAddrId);

    }

    private void validateMIndividualEmail(List<DvIndividualEmail> dvIndividualEmailRecords, Long dcrmEmailAddrId, Long currIndivId) {
        List<MIndividualEmailComparer> dvIndividualEmailComparerRecords = new ArrayList<MIndividualEmailComparer>();
        for (DvIndividualEmail record : dvIndividualEmailRecords) {
            MIndividualEmailComparer rec = new MIndividualEmailComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setIndivId(currIndivId);
            dvIndividualEmailComparerRecords.add(rec);
        }
        Collections.sort(dvIndividualEmailComparerRecords);

        List<MIndividualEmailComparer> mIndividualEmailComparerRecords = new ArrayList<MIndividualEmailComparer>();
        List<MIndividualEmail> mIndividualEmailRecords = mIndividualEmailRepo
                .findByIndivIdAndBrandCdAndDcrmEmailAddrId(currIndivId, BRAND_CD, dcrmEmailAddrId);
        for (MIndividualEmail record : mIndividualEmailRecords) {
            MIndividualEmailComparer rec = new MIndividualEmailComparer();
            BeanUtils.copyProperties(record, rec);
            mIndividualEmailComparerRecords.add(rec);
        }
        Collections.sort(mIndividualEmailComparerRecords);

        assertEquals(dvIndividualEmailComparerRecords, mIndividualEmailComparerRecords, "dv_individual_email table does not match m_individual_email");
    }

    private void validateMEmailAddress(List<DvIndividualEmail> dvIndividualEmailRecords, Long dcrmEmailAddrId) {
        // m_email_address comparer records
        List<MEmailAddress> mEmailAddressRecords = mEmailAddressRepo.findByDcrmEmailAddrId(dcrmEmailAddrId);
        List<MEmailAddressComparer> mEmailAddressComparerRecords = new ArrayList<MEmailAddressComparer>();
        for (MEmailAddress record : mEmailAddressRecords) {
            MEmailAddressComparer rec = new MEmailAddressComparer();
            BeanUtils.copyProperties(record, rec);

            mEmailAddressComparerRecords.add(rec);
        }
        Collections.sort(mEmailAddressComparerRecords);

        List<MEmailAddressComparer> dvEmailAddressComparerRecords = new ArrayList<MEmailAddressComparer>();
        for (DvIndividualEmail record : dvIndividualEmailRecords) {
            MEmailAddressComparer rec = new MEmailAddressComparer();
            BeanUtils.copyProperties(record, rec);
            dvEmailAddressComparerRecords.add(rec);
        }
        Collections.sort(dvEmailAddressComparerRecords);

        assertEquals(mEmailAddressComparerRecords, dvEmailAddressComparerRecords, "m_email_address table does not match dv_individual_email");
    }

    private void cleanUp(Long dcrmEmailAddrId) {
        dIndividualRepo.deleteByUpdateFileId(FILE_ID);
        dIndivEmailRepo.deleteByUpdateFileId(FILE_ID);
        dEmailAddressRepo.deleteByUpdateFileId(FILE_ID);
        dIndividualGoldenProfileRepo.deleteByBrandCd(BRAND_CD);
        mIndividualEmailRepo.deleteByBrandCd(BRAND_CD);
        mEmailAddressRepo.deleteByDcrmEmailAddrId(dcrmEmailAddrId);
    }
}
