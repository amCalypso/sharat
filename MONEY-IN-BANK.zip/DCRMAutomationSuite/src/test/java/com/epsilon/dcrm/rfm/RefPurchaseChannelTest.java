package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefPurchaseChannelRepository;
import com.epsilon.dcrm.db.repository.SRefPurchaseChannelRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefPurchaseChannel;
import com.epsilon.dcrm.model.standard.StandardRefPurchaseChannel;
import com.epsilon.dcrm.objects.csv.RefPurchaseChannel;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class RefPurchaseChannelTest extends BaseTest {

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/RefPurchaseChannelAutomation.txt";
    private static final Logger logger = LoggerFactory.getLogger(RefPurchaseChannelTest.class);

    @Autowired
    private SRefPurchaseChannelRepository sRepo;

    @Autowired
    private DRefPurchaseChannelRepository dRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_PURCHASE_CHANNEL_CREATE, false);
    }

    @AfterGroups(alwaysRun = true, groups = { "RefPurchaseChannel" })
    public void afterGroup() {
        if (!CollectionUtils.isEmpty(fileIds)) {
            for (Long fileId : fileIds) {
                logger.info("FileId being used for deletion - {} ", fileId);
                sRepo.deleteByCreateFileId(fileId);
                dRepo.deleteByCreateFileId(fileId);
            }
        }

    }

    @Rollback(false)
    @Test(groups = "RefPurchaseChannel")
    public void testRefPurchaseChannel_Create() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("RefPurchaseChannelAutomation_Create_").append(testId).toString();
        try {
            List<RefPurchaseChannel> csvRecords = readTestData(filename, DATA_FILE_PATH_STANDARD_CREATE, RefPurchaseChannel.class, null);

            startProcess(filename, DATA_FILE_PATH_STANDARD_CREATE, CommonConstants.FRMS_WORKFLOW_ID_DATA_CONVERT_REF_PURCHASE_CHANNEL);
            Long fileId = pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_D_REF_PURCHASE_CHANNEL);

            // Assertions
            assertData(fileId, csvRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {

        }
    }

    private void assertData(Long fileId, List<RefPurchaseChannel> csvRecs) {

        Collections.sort(csvRecs);

        List<StandardRefPurchaseChannel> sRecs = sRepo.findByCreateFileId(fileId);
        assertNotNull(sRecs, "Null from staging RefPurchaseChannel table");
        assertNotEquals(sRecs.size(), 0, "Found 0 records in staging RefPurchaseChannel table.");

        List<RefPurchaseChannel> convertedSRecs = CopyUtil.convertRefPurchaseChannelRecs(sRecs, StandardRefPurchaseChannel.class);
        assertEquals(convertedSRecs, csvRecs, "SRecords donot match with test data for RefPurchaseChannel");

        List<DimensionRefPurchaseChannel> dRecs = dRepo.findByCreateFileId(fileId);
        assertNotNull(dRecs, "Null from dimension RefPurchaseChannel table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension RefPurchaseChannel table.");

        List<RefPurchaseChannel> convertedDRecs = CopyUtil.convertRefPurchaseChannelRecs(dRecs, DimensionRefPurchaseChannel.class);
        assertEquals(convertedDRecs, convertedSRecs, "DRecords donot match with SRecords for RefPurchaseChannel");

        assertAuditFields(fileId, dRecs);

    }

    private void assertAuditFields(Long fileId, List<DimensionRefPurchaseChannel> dRecs) {
        for (DimensionRefPurchaseChannel dRec : dRecs) {
            assertNotNull(dRec.getCreateFileId(), "Null from dimension RefPurchaseChannel table for CreateFileId");
            assertEquals(dRec.getCreateFileId(), fileId, "CreateFileId and FIleId from FRMS donot match");
            assertNotNull(dRec.getCreateTs(), "Null from dimension RefPurchaseChannel table for CreateTs");
        }
    }

}
