package com.epsilon.dcrm.employee;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DvEmployeeRepository;
import com.epsilon.dcrm.db.repository.MEmployeeRepository;
import com.epsilon.dcrm.db.repository.MLocationRepository;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.dimension.DvEmployee;
import com.epsilon.dcrm.model.mart.MEmployee;
import com.epsilon.dcrm.model.mart.MLocation;
import com.epsilon.dcrm.objects.comparer.DvEmployeeComparer;
import com.epsilon.dcrm.objects.comparer.MEmployeeComparer;
import com.epsilon.dcrm.util.FormatUtil;

@RunWith(SpringRunner.class)
public class MEmployeeTest extends BaseTest {

    private static final Long FILE_ID = 1024L;
    private static final String BRAND_CD = "MEmpTest";
    private static final Long DEFAULT_LOCATION_ID = 0L;

    @Autowired
    private DEmployeeRepository dEmployeeRepo;

    @Autowired
    private DvEmployeeRepository dvEmployeeRepo;

    @Autowired
    private MEmployeeRepository mEmployeeRepo;

    @Autowired
    private MLocationRepository mLocationRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.M_EMPLOYEE_TEST_DATA_LOAD, false);
    }

    @Rollback(false)
    @Test(groups = "M_Employee")
    public void testMEmployee() {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("MEmployeeAutomationTest_").append(testId).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_EMPLOYEE);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_EMPLOYEE);
            // Assertions
            List<DvEmployee> dvEmployeeRecords = assertEmployeeView();
            assertMEmployeeTable(dvEmployeeRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            cleanUp();
        }
    }

    private void cleanUp() {
        dEmployeeRepo.deleteByUpdateFileId(FILE_ID);
        mEmployeeRepo.deleteByBrandCd(BRAND_CD);
        mLocationRepo.deleteByBrandCd(BRAND_CD);
    }

    private List<DvEmployee> assertEmployeeView() {
        List<DimensionEmployee> dEmployeeRecords = dEmployeeRepo.findByBrandCd(BRAND_CD);
        List<DvEmployeeComparer> dEmployeeComparerRecords = new ArrayList<DvEmployeeComparer>();
        List<DvEmployeeComparer> dvEmployeeComparerRecords = new ArrayList<DvEmployeeComparer>();

        for (DimensionEmployee record : dEmployeeRecords) {
            DvEmployeeComparer rec = new DvEmployeeComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmEmployeeId(FormatUtil.convertToLong(record.getDcrmEmployeeId()));

            List<MLocation> mLocationRecords = mLocationRepo.findByLocationCd(record.getAssignedLocation1Cd());

            if (mLocationRecords.size() == 0) {
                rec.setS1AssignedDcrmLocationId(DEFAULT_LOCATION_ID);
                rec.setS2AssignedDcrmLocationId(DEFAULT_LOCATION_ID);
                rec.setS3AssignedDcrmLocationId(DEFAULT_LOCATION_ID);
            } else {
                assertEquals(mLocationRecords.size(), 1, "more than 1 record in m_location table");
                rec.setS1AssignedDcrmLocationId(mLocationRecords.get(0).getDcrmLocationId());
                rec.setS2AssignedDcrmLocationId(mLocationRecords.get(0).getDcrmLocationId());
                rec.setS3AssignedDcrmLocationId(mLocationRecords.get(0).getDcrmLocationId());
            }

            dEmployeeComparerRecords.add(rec);
        }
        Collections.sort(dEmployeeComparerRecords);

        List<DvEmployee> dvEmployeeRecords = dvEmployeeRepo.findByBrandCd(BRAND_CD);
        for (DvEmployee record : dvEmployeeRecords) {
            DvEmployeeComparer rec = new DvEmployeeComparer();
            BeanUtils.copyProperties(record, rec);
            dvEmployeeComparerRecords.add(rec);
        }
        Collections.sort(dvEmployeeComparerRecords);

        assertEquals(dvEmployeeComparerRecords, dEmployeeComparerRecords, "dv_employee records donot match with test data");
        return dvEmployeeRecords;
    }

    private void assertMEmployeeTable(List<DvEmployee> dvEmployeeRecords) throws ParseException {
        List<MEmployee> mEmployeeRecords = mEmployeeRepo.findByBrandCd(BRAND_CD);
        List<MEmployeeComparer> dvEmployeeComparerRecords = new ArrayList<MEmployeeComparer>();
        List<MEmployeeComparer> mEmployeeComparerRecords = new ArrayList<MEmployeeComparer>();

        for (DvEmployee record : dvEmployeeRecords) {
            MEmployeeComparer rec = new MEmployeeComparer();
            BeanUtils.copyProperties(record, rec);
            dvEmployeeComparerRecords.add(rec);
        }

        Collections.sort(dvEmployeeComparerRecords);
        for (MEmployee record : mEmployeeRecords) {
            MEmployeeComparer rec = new MEmployeeComparer();
            BeanUtils.copyProperties(record, rec);
            mEmployeeComparerRecords.add(rec);
        }

        Collections.sort(mEmployeeComparerRecords);

        assertEquals(mEmployeeComparerRecords, dvEmployeeComparerRecords, "m_employee records do not match with test data");
    }

}
