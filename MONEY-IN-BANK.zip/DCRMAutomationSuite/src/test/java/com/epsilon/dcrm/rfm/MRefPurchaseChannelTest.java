package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefPurchaseChannelRepository;
import com.epsilon.dcrm.db.repository.MRefPurchaseChannelRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefPurchaseChannel;
import com.epsilon.dcrm.model.mart.MRefPurchaseChannel;
import com.epsilon.dcrm.objects.csv.RefPurchaseChannel;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class MRefPurchaseChannelTest extends BaseTest {

    @Autowired
    private DRefPurchaseChannelRepository dRepo;

    @Autowired
    private MRefPurchaseChannelRepository mRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final Long CREATE_FILE_ID = (long) (Math.random() * 1000);
    private static final String PURCHASE_CHANNEL_CD = "PCT";//Refers to PurchaseChannelTest

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_PURCHASE_CHANNEL_CREATE, false);
        dRepo.insertTestData(PURCHASE_CHANNEL_CD, RAND_STRING.substring(0, 20), RAND_STRING, CREATE_FILE_ID, (long) Math.random() * 1000);
    }

    @Test
    public void testMartLoad() {
        String filename = new StringBuilder().append("MRefPurchaseChannelTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_PURCHASE_CHANNEL);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_PURCHASE_CHANNEL);
            assertData();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            dRepo.deleteByCreateFileId(CREATE_FILE_ID);
            mRepo.deleteById(PURCHASE_CHANNEL_CD);
        }
    }

    private void assertData() {
        MRefPurchaseChannel mRec = mRepo.findByPurchaseChannelCd(PURCHASE_CHANNEL_CD);
        assertNotNull(mRec, "Null from mart RefPurchaseChannel table");

        List<MRefPurchaseChannel> mRecs = new ArrayList<>();
        mRecs.add(mRec);

        List<DimensionRefPurchaseChannel> dRecs = dRepo.findByCreateFileId(CREATE_FILE_ID);
        assertNotNull(dRecs, "Null from dimension RefPurchaseChannel table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension RefPurchaseChannel table.");

        List<RefPurchaseChannel> convertedDRecs = CopyUtil.convertRefPurchaseChannelRecs(dRecs, DimensionRefPurchaseChannel.class);
        List<RefPurchaseChannel> convertedMRecs = CopyUtil.convertRefPurchaseChannelRecs(mRecs, MRefPurchaseChannel.class);

        assertEquals(convertedMRecs, convertedDRecs, "MRecords donot match with DRecords for RefPurchaseChannel");

    }
}
