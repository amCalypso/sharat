package com.epsilon.dcrm.profile;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.util.CollectionUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.util.IOUtils;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmailAddressRepository;
import com.epsilon.dcrm.db.repository.DPhoneRepository;
import com.epsilon.dcrm.db.repository.DProfileEmailRepository;
import com.epsilon.dcrm.db.repository.DProfilePhoneRepository;
import com.epsilon.dcrm.db.repository.DProfileRepository;
import com.epsilon.dcrm.db.repository.DProfileSocialRepository;
import com.epsilon.dcrm.db.repository.DSocialAccountRepository;
import com.epsilon.dcrm.db.repository.SProfileRepository;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.model.dimension.DimensionEmailAddress;
import com.epsilon.dcrm.model.dimension.DimensionPhone;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.dimension.DimensionProfileEmail;
import com.epsilon.dcrm.model.dimension.DimensionProfilePhone;
import com.epsilon.dcrm.model.dimension.DimensionProfileSocial;
import com.epsilon.dcrm.model.dimension.DimensionSocialAccount;
import com.epsilon.dcrm.model.id.ProfileEmailId;
import com.epsilon.dcrm.model.id.ProfilePhoneId;
import com.epsilon.dcrm.model.id.ProfileSocialId;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.objects.MatillionJobAttributes;
import com.epsilon.dcrm.objects.MatillionWorkflowAttributes;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.comparer.CreateUpdateFileFields;
import com.epsilon.dcrm.objects.comparer.DimensionEmailAddressComparer;
import com.epsilon.dcrm.objects.comparer.DimensionPhoneComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileEmailComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfilePhoneComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileSocialComparer;
import com.epsilon.dcrm.objects.comparer.DimensionSocialAccountComparer;
import com.epsilon.dcrm.objects.comparer.StandardProfileComparer;
import com.epsilon.dcrm.objects.csv.Profile;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.util.CSVUtil;
import com.epsilon.dcrm.util.CopyUtil;
import com.epsilon.dcrm.util.JsonUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class ProfileTest extends AbstractTransactionalTestNGSpringContextTests {
    private static final Logger logger = LoggerFactory.getLogger(ProfileTest.class);

    private static final String DATA_FILE_PATH_STANDARD_CREATE = "/files/ProfileAutomationTestStandard_Create.txt";
    private static final String DATA_FILE_PATH_STANDARD_UPDATE = "/files/ProfileAutomationTestStandard_Update.txt";
    private static final String DATA_FILE_PATH_STANDARD = "processing/inbound/ProfileAutomationTestStandard";
    private static final String DATA_FILE_PATH_STANDARD_DATA = "processing/inbound/data.Automation_Profile_Standard";
    private static final String DATA_FILE_PATH_STANDARD_SCHEMA = "processing/inbound/schema.Automation_Profile_Standard";

    private static final String MARITAL_STATUS_M = "M";
    private static final String COUNTRY_CD_GBR = "GBR";
    private static final String COUNTRY_NM_GBR = "United Kingdom";
    private static final String LANG_CD_ENG = "eng";
    private static final String SOCIAL_MEDIA_CD = "ABC";
    private static final String UNKNOWN_CD = "U";

    @Autowired
    private FrmsService testService;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private SProfileRepository standardProfileRepository;

    @Autowired
    private DProfileRepository dimensionProfileRepository;

    @Autowired
    private DSocialAccountRepository dimensionSocialAccountRepository;

    @Autowired
    private DEmailAddressRepository dimensionEmailAddressRepository;

    @Autowired
    private DProfileEmailRepository dimensionProfileEmailRepository;

    @Autowired
    private DProfileSocialRepository dimensionProfileSocialRepository;

    @Autowired
    private DProfilePhoneRepository dimensionProfilePhoneRepository;

    @Autowired
    private DPhoneRepository dimensionPhoneRepository;

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    @Autowired
    private MessagePoller messagePoller;

    private List<ProfileSocialId> profileSocialIds = new ArrayList<ProfileSocialId>();

    private List<ProfileEmailId> profileEmailIds = new ArrayList<ProfileEmailId>();

    private List<ProfilePhoneId> profilePhoneIds = new ArrayList<ProfilePhoneId>();

    private List<Long> fileIds = new ArrayList<Long>();

    private List<String> acctSrcNbrs = new ArrayList<String>();

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_PROFILE_TABLES, false);
        dimensionProfileRepository.deleteByRecSrcCd(CommonConstants.REC_SRC_CD_PROFILE);
    }

    /**
     * Clearing the test data from dimension table after the test groups are run
     */
    @AfterGroups(alwaysRun = true, groups = { "Profile_Standard" })
    public void afterGroup() {
        if (CollectionUtils.isEmpty(fileIds)) {
            if (!CollectionUtils.isEmpty(acctSrcNbrs)) {
                for (String acctSrcNbr : acctSrcNbrs) {
                    dimensionProfileRepository.deleteByAcctSrcNbr(acctSrcNbr);
                    standardProfileRepository.deleteByAcctSrcNbr(acctSrcNbr);
                }
            }
        } else {
            for (Long fileId : fileIds) {
                logger.info("FileId being used for deleteion - {} ", fileId);
                dimensionProfileRepository.deleteByCreateFileId(fileId);
                dimensionSocialAccountRepository.deleteByCreateFileId(fileId);
                dimensionEmailAddressRepository.deleteByCreateFileId(fileId);
                dimensionPhoneRepository.deleteByCreateFileId(fileId);
            }
            if (!CollectionUtils.isEmpty(profileSocialIds)) {
                for (ProfileSocialId id : profileSocialIds) {
                    dimensionProfileSocialRepository.deleteById(id);
                }
            }
            if (!CollectionUtils.isEmpty(profileEmailIds)) {
                for (ProfileEmailId id : profileEmailIds) {
                    dimensionProfileEmailRepository.deleteById(id);
                }
            }
            if (!CollectionUtils.isEmpty(profilePhoneIds)) {
                for (ProfilePhoneId id : profilePhoneIds) {
                    dimensionProfilePhoneRepository.deleteById(id);
                }
            }
        }
    }

    // TODO - This deletes all files in S3 - Check why
    //   @AfterMethod
    public void afterTestCleanup(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_DATA);
            s3Service.deleteObjectWithPrefix(s3Props.getS3BucketName(), DATA_FILE_PATH_STANDARD_SCHEMA);
        }
    }

    @Rollback(false)
    @Test(groups = "Profile_Standard")
    public void testProfileRecord_Standard_Create() {

        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("ProfileAutomationTestStandard_Create_").append(testId).toString();
        /***
         * 1. Upload file to S3
         * 2. Start the FRMS workflow
         * 3. Read the csv data (test data)
         * 4. Poll the SQS for matillion job status
         * {
            "jobName":"Refresh-PII",
            "status":"completed",
            "create_file_nm" :"ProfileAutomationTestStandard_Create_114cbfb1-d23f-41f7-a39d-5d3d844ac099",
            "create_file_ts" :"2017-09-08 18:47:14",
            "automationTestId":"114cbfb1-d23f-41f7-a39d-5d3d844ac099"
            }
         * 5. Assertions
         *   // TODO - Add rolling table assertions
         */

        try {
            uploadDataFile(filename, DATA_FILE_PATH_STANDARD_CREATE);
            testService.testEnable(CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_PROFILE);

            // Read the input data from CSV for table comparisons.
            List<Profile> csvRecords = CSVUtil.readStaticFile(Profile.class, DATA_FILE_PATH_STANDARD_CREATE, true);
            for (Profile csvRecord : csvRecords) {
                acctSrcNbrs.add(csvRecord.getAcctSrcNbr());
            }
            Collections.sort(csvRecords);

            // Poll SQS for the Success/Failure message

            Long fileId = pollForMessages(filename);

            // Assertions
            /**
             * 1. Check if standard and rolling table is populated.
             * 2. Check if "d_" table is populated
             */
            assertProfileDimAndStandardTableData(csvRecords, fileId, true);
            assertSocialAccountDimAndBrTableData(csvRecords, fileId, true);
            assertEmailAddressDimAndBrTableData(csvRecords, fileId, true);
            assertPhoneDimAndBrTableData(csvRecords, fileId, true);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.getMessage());
        } finally {
            String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
            s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
        }
    }

    @Rollback(false)
    @Test(groups = "Profile_Standard", dependsOnMethods = "testProfileRecord_Standard_Create")
    public void testProfileRecord_Standard_Update() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        String testId = UUID.randomUUID().toString();
        String filename = new StringBuilder().append("ProfileAutomationTestStandard_Update_").append(testId).toString();

        /***
         * 1. Upload file to S3
         * 2. Start the FRMS workflow
         * 3. Read the csv data (test data)
         * 4. Poll the SQS for matillion job status
         * {
            "jobName":"Refresh-PII",
            "status":"completed",
            "create_file_nm" :"ProfileAutomationTestStandard_Create_114cbfb1-d23f-41f7-a39d-5d3d844ac099",
            "create_file_ts" :"2017-09-08 18:47:14",
            "automationTestId":"114cbfb1-d23f-41f7-a39d-5d3d844ac099"
            }
         * 5. Assertions
         *  // TODO - Add rolling table assertions
         */

        try {
            uploadDataFile(filename, DATA_FILE_PATH_STANDARD_UPDATE);
            testService.testEnable(CommonConstants.FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_PROFILE);

            // Read the input data from CSV for table comparisons.
            List<Profile> csvRecords = CSVUtil.readStaticFile(Profile.class, DATA_FILE_PATH_STANDARD_UPDATE, true);
            Collections.sort(csvRecords);
            for (Profile csvRecord : csvRecords) {
                acctSrcNbrs.add(csvRecord.getAcctSrcNbr());
            }
            // Poll SQS for the Success/Failure message

            Long fileId = pollForMessages(filename);

            // Assertions
            /**
             * 1. Check if standard and rolling table is populated.
             * 2. Check if "d_" table is populated
             */
            assertProfileDimAndStandardTableData(csvRecords, fileId, false);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.getMessage());
        } finally {
            String fileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
            s3Service.deleteObject(s3Props.getS3BucketName(), fileKey);
        }

    }

    // @Test(groups = "Profile_Custom")
    public void testProfileRecord_Custom_Create() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        // TODO - Future
    }

    //  @Test(groups = "Profile_Custom", dependsOnMethods = "testProfileRecord_Custom_Create")
    public void testProfileRecord_Custom_Update() throws InstantiationException, IllegalAccessException, ApplicationException, SQLException, IOException {
        // TODO - Future
    }

    private void assertAgilityKeyingIsInvoked(MessageDetails details) throws IOException {
        assertNotNull(details.getSrcSystem(), "Matiilion message object is null");
        assertNotNull(details.getSrcSystem().getData(), "Null SRCSytem from Matillion");
        MatillionWorkflowAttributes attributes = JsonUtil.getObject(details.getSrcSystem().getData(), MatillionWorkflowAttributes.class);
        assertNotNull(attributes, "Null Workflow attributes from matillion");
        List<MatillionJobAttributes> subJobs = attributes.getSubJobs();
        assertNotNull(subJobs, "Subjobs null from matillion");
        boolean jobPresent = subJobs.stream().anyMatch(item -> CommonConstants.MATILLION_JOB_NAME_INVOKE_AGILITY_KEYING.equals(item.getJobName()));
        // The job should not be present for a Transaction Header feed when there is no PII update.
        assertTrue(jobPresent, "Matillion did not invoke Agility Keying workflow");
    }

    private void assertCreateFileFields_CreateFlow(List<CreateUpdateFileFields> dimRecords) {
        for (CreateUpdateFileFields dimRecord : dimRecords) {
            assertEquals(dimRecord.getUpdateFileId(), dimRecord.getCreateFileId(),
                    String.format("D-UpdateFileId does not match with D-CreateFileId. Actual - %s, Expected - %s", dimRecord.getUpdateFileId(), dimRecord.getCreateFileId()));
            assertEquals(dimRecord.getUpdateRecNbr(), dimRecord.getCreateRecNbr(),
                    String.format("D-UpdateRecNbr does not match with D-CreateRecNbr. Actual - %s, Expected - %s", dimRecord.getUpdateRecNbr(), dimRecord.getCreateRecNbr()));
        }
    }

    private void assertCreateFileFields_UpdateExisting(List<DimensionProfile> dimRecords) {
        for (DimensionProfile dimRecord : dimRecords) {
            assertNotEquals(dimRecord.getUpdateFileId(), dimRecord.getCreateFileId(),
                    String.format("D-UpdateFileId matches with D-CreateFileId. Actual - %s, Expected - %s", dimRecord.getUpdateFileId(), dimRecord.getCreateFileId()));
            assertNotNull(dimRecord.getUpdateRecNbr(), "UpdateRecNbr is null");
            assertNotNull(dimRecord.getCreateFileRecNbr(), "CreateFileRecNbr is null");
        }
    }

    private void assertProfileDimAndStandardTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) throws ParseException {
        assertProfileStandardTableData(csvRecords, fileId);
        assertProfileDimensionTableData(csvRecords, fileId, isCreateFlow);
    }

    private Long pollForMessages(String filename) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        Long fileId = null;
        messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_LDC, sqsUrl, 20);
        // assertEquals(pollFrmsMessageLDC.size(), 2, String.format("FRMS LDC polled message count. Expected - %s, Actual - %s", pollFrmsMessageLDC.size(), 2));
        //List<MessageDetails> pollFrmsMessageAWS = messagePoller.pollFrmsMessages(filename, CommonConstants.JOB_SRC_NAME_FRMS, CommonConstants.ENV_AWS, sqsUrl, 50);
        //assertEquals(pollFrmsMessageAWS.size(), 2, String.format("FRMS AWS polled message count. Expected - %s, Actual - %s", pollFrmsMessageAWS.size(), 2));
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_PII, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc()) && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);

            assertAgilityKeyingIsInvoked(pollMatillionMessage);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    private void assertProfileStandardTableData(List<Profile> csvRecords, Long fileId) throws ParseException {
        List<StandardProfile> dbRecords = standardProfileRepository.findByCreateFileId(fileId);
        List<Profile> convertedStandardProfileRecords = CopyUtil.convertStandardProfile(dbRecords);
        List<StandardProfileComparer> convertedStandardProfileDbRecords = new ArrayList<StandardProfileComparer>();
        List<StandardProfileComparer> convertedProfileCsvRecords = new ArrayList<StandardProfileComparer>();
        for (Profile record : convertedStandardProfileRecords) {
            StandardProfileComparer rec = new StandardProfileComparer();
            BeanUtils.copyProperties(record, rec);
            convertedStandardProfileDbRecords.add(rec);
        }
        for (Profile record : csvRecords) {
            StandardProfileComparer rec = new StandardProfileComparer();
            BeanUtils.copyProperties(record, rec);
            convertedProfileCsvRecords.add(rec);
        }

        assertEquals(convertedStandardProfileDbRecords, convertedProfileCsvRecords, "s_profile records do not match with test data");

    }

    private void assertProfileDimensionTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) throws ParseException {

        List<DimensionProfile> dimTranRecords = dimensionProfileRepository.findByUpdateFileId(fileId);
        List<DimensionProfileComparer> convertedDimensionProfileRecords = CopyUtil.convertDimensionProfile(dimTranRecords);

        List<DimensionProfileComparer> convertedProfileCsvRecords = new ArrayList<DimensionProfileComparer>();
        for (Profile record : csvRecords) {
            DimensionProfileComparer rec = new DimensionProfileComparer();
            BeanUtils.copyProperties(record, rec);
            setRefCodes(rec, record);
            convertedProfileCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the dimension table.
        assertEquals(convertedDimensionProfileRecords, convertedProfileCsvRecords, "d_profile records do not match with test data");
        assertRecSrcCd(dimTranRecords);

        if (isCreateFlow) {
            assertCreateFileFields_CreateFlow(dimTranRecords.stream().map(i -> new CreateUpdateFileFields(i.getCreateFileId(),
                    i.getCreateFileRecNbr(), i.getUpdateFileId(), i.getUpdateRecNbr())).collect(Collectors.toList()));
        } else {
            assertCreateFileFields_UpdateExisting(dimTranRecords);
        }
    }

    private void setRefCodes(DimensionProfileComparer rec, Profile csvRecords) {
        rec.setCountryCd(csvRecords.getCountryCd().equals(COUNTRY_CD_GBR) ? COUNTRY_CD_GBR : UNKNOWN_CD);
        // Changing the assertion to set null because of recent changes to profile worklflow.
        rec.setCountryNm(csvRecords.getCountryNm().equals(COUNTRY_NM_GBR) ? COUNTRY_NM_GBR : null);

        rec.setMaritalStatusCd(csvRecords.getMaritalStatusCd().equals(MARITAL_STATUS_M) ? MARITAL_STATUS_M : UNKNOWN_CD);
        rec.setLangCd(csvRecords.getLangCd().equals(LANG_CD_ENG) ? LANG_CD_ENG : UNKNOWN_CD);
        rec.setBirthDt(new StringBuffer().append(csvRecords.getBirthYr()).append("-").append(csvRecords.getBirthMth()).append("-")
                .append(csvRecords.getBirthDay()).toString());
        rec.setStateCd(UNKNOWN_CD);
    }

    private void assertSocialAccountDimAndBrTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        HashMap<String, Long> socialMap = new HashMap<String, Long>();
        socialMap = assertDimSocialTableData(csvRecords, fileId, isCreateFlow);
        assertBrSocialTableData(csvRecords, socialMap);
    }

    private void assertEmailAddressDimAndBrTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        HashMap<String, Long> emailMap = new HashMap<String, Long>();
        emailMap = assertDimEmailTableData(csvRecords, fileId, isCreateFlow);
        assertBrEmailTableData(csvRecords, emailMap);
    }

    private void assertPhoneDimAndBrTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        HashMap<String, Long> phoneMap = new HashMap<String, Long>();
        phoneMap = assertDimPhoneTableData(csvRecords, fileId, isCreateFlow);
        assertBrPhoneTableData(csvRecords, phoneMap);
    }

    private HashMap<String, Long> assertDimSocialTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        List<DimensionSocialAccount> dimSocialAcctRecords = dimensionSocialAccountRepository.findByUpdateFileId(fileId);

        List<DimensionSocialAccountComparer> convertedDSocialAccountRecords = CopyUtil.convertDimensionSocialAccount(dimSocialAcctRecords);

        List<DimensionSocialAccountComparer> convertedProfileCsvRecords = new ArrayList<DimensionSocialAccountComparer>();

        for (Profile record : csvRecords) {
            DimensionSocialAccountComparer rec = new DimensionSocialAccountComparer();
            rec.setSocialMediaAcctId(record.getSocialMediaAcct1Id());
            rec.setSocialMediaCd(record.getSocialMedia1Nm());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionSocialAccountComparer();
            rec.setSocialMediaAcctId(record.getSocialMediaAcct2Id());
            rec.setSocialMediaCd(record.getSocialMedia2Nm().equals(SOCIAL_MEDIA_CD) ? UNKNOWN_CD : record.getSocialMedia2Nm());
            convertedProfileCsvRecords.add(rec);
        }
        Collections.sort(convertedProfileCsvRecords);
        assertEquals(convertedDSocialAccountRecords, convertedProfileCsvRecords, "d_social_account records do not match with test data");

        if (isCreateFlow) {
            assertCreateFileFields_CreateFlow(dimSocialAcctRecords.stream().map(i -> new CreateUpdateFileFields(i.getCreateFileId(),
                    i.getCreateFileRecNbr(), i.getUpdateFileId(), i.getUpdateFileRecNbr())).collect(Collectors.toList()));
        }

        HashMap<String, Long> socialMap = new HashMap<String, Long>();
        for (DimensionSocialAccount record : dimSocialAcctRecords) {
            socialMap.put(record.getSocialMediaAcctId() + record.getSocialMediaCd(), record.getDcrmSocialAcctId());
        }

        return socialMap;
    }

    private void assertBrSocialTableData(List<Profile> csvRecords, HashMap<String, Long> socialMap) {
        List<DimensionProfileSocial> brSocialRecords = new ArrayList<DimensionProfileSocial>();
        for (HashMap.Entry<String, Long> entry : socialMap.entrySet()) {
            //dimProfileSocialRecords
            List<DimensionProfileSocial> dimProfileSocialRecords = dimensionProfileSocialRepository.findByDcrmSocialAcctId(entry.getValue());
            assertEquals(1, dimProfileSocialRecords.size());
            brSocialRecords.add(dimProfileSocialRecords.get(0));
        }

        List<DimensionProfileSocialComparer> convertedbrProfileSocialRecords = CopyUtil.convertDimensionProfileSocial(brSocialRecords);
        List<DimensionProfileSocialComparer> convertedProfilCsvRecords = new ArrayList<DimensionProfileSocialComparer>();
        for (Profile record : csvRecords) {
            DimensionProfileSocialComparer rec = new DimensionProfileSocialComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmSocialAcctId(socialMap.get(record.getSocialMediaAcct1Id() + record.getSocialMedia1Nm()).toString());
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfileSocialComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmSocialAcctId(socialMap.get(record.getSocialMediaAcct2Id() + (record.getSocialMedia2Nm().equals(SOCIAL_MEDIA_CD) ? UNKNOWN_CD : record.getSocialMedia2Nm())).toString());
            convertedProfilCsvRecords.add(rec);
        }
        // Confirm the records  are loaded to the d_profile_social table.
        Collections.sort(convertedProfilCsvRecords);
        assertEquals(convertedbrProfileSocialRecords, convertedProfilCsvRecords, "d_profile_social records do not match with test data");

        // Clean up d_profile_social
        for (DimensionProfileSocialComparer item : convertedbrProfileSocialRecords) {
            ProfileSocialId id = new ProfileSocialId();
            id.setDcrmSocialAcctId(new Long(item.getDcrmSocialAcctId()));
            id.setBrandCd(item.getBrandCd());
            id.setAcctSrcCd(item.getAcctSrcCd());
            id.setAcctSrcNbr(item.getAcctSrcNbr());
            profileSocialIds.add(id);
        }
    }

    private HashMap<String, Long> assertDimEmailTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        List<DimensionEmailAddress> dimEmailAddrRecords = dimensionEmailAddressRepository.findByUpdateFileId(fileId);

        List<DimensionEmailAddressComparer> convertedDEmailAddressRecords = CopyUtil.convertDimensionEmailAddress(dimEmailAddrRecords);

        List<DimensionEmailAddressComparer> convertedProfileCsvRecords = new ArrayList<DimensionEmailAddressComparer>();

        for (Profile record : csvRecords) {
            DimensionEmailAddressComparer rec = new DimensionEmailAddressComparer();
            rec.setEmailAddr(record.getEmailAddr1());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionEmailAddressComparer();
            rec.setEmailAddr(record.getEmailAddr2());
            convertedProfileCsvRecords.add(rec);
        }
        // Confirm the records in the standard table are loaded to the d_email_address table.
        Collections.sort(convertedProfileCsvRecords);

        assertEquals(convertedDEmailAddressRecords, convertedProfileCsvRecords, "d_email_address records do not match with test data");

        if (isCreateFlow) {
            assertCreateFileFields_CreateFlow(dimEmailAddrRecords.stream().map(i -> new CreateUpdateFileFields(i.getCreateFileId(),
                    i.getCreateFileRecNbr(), i.getUpdateFileId(), i.getUpdateFileRecNbr())).collect(Collectors.toList()));
        }

        HashMap<String, Long> emailMap = new HashMap<String, Long>();
        for (DimensionEmailAddress record : dimEmailAddrRecords) {
            emailMap.put(record.getEmailAddr(), record.getDcrmEmailAddrId());
        }

        return emailMap;
    }

    private void assertBrEmailTableData(List<Profile> csvRecords, HashMap<String, Long> emailMap) {
        //Verify d_profile_email bridge table
        List<DimensionProfileEmail> brEmailRecords = new ArrayList<DimensionProfileEmail>();
        for (HashMap.Entry<String, Long> entry : emailMap.entrySet()) {
            //dimProfileEmailRecords
            List<DimensionProfileEmail> dimProfileEmailRecords = dimensionProfileEmailRepository.findByDcrmEmailAddrId(entry.getValue());
            assertEquals(1, dimProfileEmailRecords.size());
            brEmailRecords.add(dimProfileEmailRecords.get(0));
        }

        List<DimensionProfileEmailComparer> convertedbrProfileEmailRecords = CopyUtil.convertDimensionProfileEmail(brEmailRecords);

        List<DimensionProfileEmailComparer> convertedProfilCsvRecords = new ArrayList<DimensionProfileEmailComparer>();
        for (Profile record : csvRecords) {
            DimensionProfileEmailComparer rec = new DimensionProfileEmailComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmEmailAddrId(emailMap.get(record.getEmailAddr1()).toString());
            rec.setPreferredInd("T");
            rec.setSrcEmailAddr(record.getEmailAddr1());
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfileEmailComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmEmailAddrId(emailMap.get(record.getEmailAddr2()).toString());
            rec.setPreferredInd("F");
            rec.setSrcEmailAddr(record.getEmailAddr2());
            convertedProfilCsvRecords.add(rec);
        }
        // Confirm the records  are loaded to the d_profile_email table.
        Collections.sort(convertedProfilCsvRecords);
        assertEquals(convertedbrProfileEmailRecords, convertedProfilCsvRecords, "d_profile_email records do not match with test data");

        // Clean up d_profile_email
        for (DimensionProfileEmailComparer item : convertedbrProfileEmailRecords) {
            ProfileEmailId id = new ProfileEmailId();
            id.setDcrmEmailAddrId(new Long(item.getDcrmEmailAddrId()));
            id.setBrandCd(item.getBrandCd());
            id.setAcctSrcCd(item.getAcctSrcCd());
            id.setAcctSrcNbr(item.getAcctSrcNbr());
            profileEmailIds.add(id);
        }
    }

    private HashMap<String, Long> assertDimPhoneTableData(List<Profile> csvRecords, Long fileId, boolean isCreateFlow) {
        List<DimensionPhone> dimPhoneRecords = dimensionPhoneRepository.findByUpdateFileId(fileId);

        List<DimensionPhoneComparer> convertedDPhoneRecords = CopyUtil.convertDimensionPhone(dimPhoneRecords);

        List<DimensionPhoneComparer> convertedProfileCsvRecords = new ArrayList<DimensionPhoneComparer>();
        for (Profile record : csvRecords) {
            DimensionPhoneComparer rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getHomePhoneNbr());
            rec.setCountryCd(record.getHomePhoneCountryCd());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getWorkPhoneNbr());
            rec.setCountryCd(record.getWorkPhoneCountryCd());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getCellPhoneNbr());
            rec.setCountryCd(record.getCellPhoneCountryCd());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getPagerPhoneNbr());
            rec.setCountryCd(record.getPagerPhoneCountryCd());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getFaxPhoneNbr());
            rec.setCountryCd(record.getFaxPhoneCountryCd());
            convertedProfileCsvRecords.add(rec);

            rec = new DimensionPhoneComparer();
            rec.setPhoneNum(record.getOtherPhoneNbr());
            rec.setCountryCd(record.getOtherPhoneCountryCd());
            convertedProfileCsvRecords.add(rec);
        }
        Collections.sort(convertedProfileCsvRecords);

        assertEquals(convertedDPhoneRecords, convertedProfileCsvRecords, "d_phone records do not match with test data");

        if (isCreateFlow) {
            assertCreateFileFields_CreateFlow(dimPhoneRecords.stream().map(i -> new CreateUpdateFileFields(i.getCreateFileId(),
                    i.getCreateFileRecNbr(), i.getUpdateFileId(), i.getUpdateFileRecNbr())).collect(Collectors.toList()));
        }

        HashMap<String, Long> phoneMap = new HashMap<String, Long>();
        for (DimensionPhone record : dimPhoneRecords) {
            phoneMap.put(record.getPhoneNum() + record.getCountryCd(), record.getDcrmPhoneId());
        }

        return phoneMap;
    }

    private void assertBrPhoneTableData(List<Profile> csvRecords, HashMap<String, Long> phoneMap) {
        List<DimensionProfilePhone> brPhoneRecords = new ArrayList<DimensionProfilePhone>();
        for (HashMap.Entry<String, Long> entry : phoneMap.entrySet()) {
            //dimProfilePhoneRecords
            List<DimensionProfilePhone> dimProfilePhoneRecords = dimensionProfilePhoneRepository.findByDcrmPhoneId(entry.getValue());
            assertEquals(1, dimProfilePhoneRecords.size());
            brPhoneRecords.add(dimProfilePhoneRecords.get(0));
        }

        List<DimensionProfilePhoneComparer> convertedbrProfilePhoneRecords = CopyUtil.convertDimensionProfilePhone(brPhoneRecords);

        List<DimensionProfilePhoneComparer> convertedProfilCsvRecords = new ArrayList<DimensionProfilePhoneComparer>();
        for (Profile record : csvRecords) {
            DimensionProfilePhoneComparer rec = new DimensionProfilePhoneComparer();

            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getHomePhoneNbr() + record.getHomePhoneCountryCd()).toString());
            rec.setPhoneTypeCd("H");
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getWorkPhoneNbr() + record.getWorkPhoneCountryCd()).toString());
            rec.setPhoneTypeCd("W");
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getCellPhoneNbr() + record.getCellPhoneCountryCd()).toString());
            rec.setPhoneTypeCd("C");
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getPagerPhoneNbr() + record.getPagerPhoneCountryCd()).toString());
            rec.setPhoneTypeCd("P");
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getFaxPhoneNbr() + record.getFaxPhoneCountryCd()).toString());

            rec.setPhoneTypeCd("F");
            convertedProfilCsvRecords.add(rec);

            rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setDcrmPhoneId(phoneMap.get(record.getOtherPhoneNbr() + record.getOtherPhoneCountryCd()).toString());
            rec.setPhoneTypeCd("O");
            convertedProfilCsvRecords.add(rec);

        }
        // Confirm the records  are loaded to the d_profile_email table.
        Collections.sort(convertedProfilCsvRecords);
        assertEquals(convertedbrProfilePhoneRecords, convertedProfilCsvRecords, "d_profile_phone records do not match with test data");

        // Clean up d_profile_phone
        for (DimensionProfilePhoneComparer item : convertedbrProfilePhoneRecords) {
            ProfilePhoneId id = new ProfilePhoneId();
            id.setDcrmPhoneId(new Long(item.getDcrmPhoneId()));
            id.setBrandCd(item.getBrandCd());
            id.setAcctSrcCd(item.getAcctSrcCd());
            id.setAcctSrcNbr(item.getAcctSrcNbr());
            profilePhoneIds.add(id);
        }
    }

    private void uploadDataFile(String filename, String path) throws IOException {
        InputStream dataStream = ProfileTest.class.getResourceAsStream(path);
        byte[] bytes = IOUtils.toByteArray(dataStream);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
    }

    private void assertRecSrcCd(List<DimensionProfile> dimProfileRecords) {
        for (DimensionProfile record : dimProfileRecords) {
            assertEquals(record.getRecSrcCd(), CommonConstants.REC_SRC_CD_PROFILE,
                    String.format("rec_src_profile value does not match with expected value. Expected - %s, Actual - %s", record.getRecSrcCd(), CommonConstants.REC_SRC_CD_PROFILE));
        }
    }
}
