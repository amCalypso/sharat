package com.epsilon.dcrm.spike;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.spike.objects.SNSMessage;
import com.epsilon.dcrm.spike.objects.SNSSubMessage;
import com.epsilon.dcrm.type.ProcessErrorCode;
import com.epsilon.dcrm.util.JsonUtil;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class SampleSNSReportingTest extends AbstractTransactionalTestNGSpringContextTests {

    private static final String WORKFLOW_ID = "118067";
    private static final String MATILLION_JOB_NAME = "SampleSNSReporting";

    private static final String MATILLION_SUCCESS_STATUS = "SUCCESS";

    @Autowired
    private FrmsService testService;

    @Autowired
    private AmazonSQS sqsClient;

    @Value("${sqs.url}")
    private String sqsUrl;

    @Test
    public void test() throws ApplicationException {
        try {
            testService.testEnable(WORKFLOW_ID);

            SNSSubMessage snsSubMessage = pollSQS();
            assertNotNull(snsSubMessage);

            assertEquals(MATILLION_SUCCESS_STATUS, snsSubMessage.getEventStatus());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    private SNSSubMessage pollSQS() throws ApplicationException {
        List<Message> messages = null;
        int maxAttempts = 30;
        try {
            while (maxAttempts > 0) {
                messages = sqsClient.receiveMessage(new ReceiveMessageRequest(sqsUrl).withWaitTimeSeconds(20)).getMessages();
                if (messages != null) {
                    for (Message msg : messages) {
                        logger.debug(JsonUtil.getPrettyJson(msg));
                        SNSMessage snsMessage = JsonUtil.getObject(msg.getBody(), SNSMessage.class);

                        if (snsMessage != null && snsMessage.getMessage() != null) {
                            SNSSubMessage snsSubMessage = JsonUtil.getObject(snsMessage.getMessage(), SNSSubMessage.class);
                            if (MATILLION_JOB_NAME.equals(snsSubMessage.getSrcSystem().getData().getJobName())) {
                                sqsClient.deleteMessage(new DeleteMessageRequest()
                                        .withQueueUrl(sqsUrl)
                                        .withReceiptHandle(msg.getReceiptHandle()));
                            }

                            logger.debug(JsonUtil.getPrettyJson(snsSubMessage));
                            return snsSubMessage;
                        }

                    }
                } else {
                    maxAttempts--;
                }
            }
        } catch (IOException e) {
            logger.error("Exception : {}" + e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        logger.error("****FAILED****  - SQS poller timed out");
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, String.format("****FAILED****  - SQS poller timed out"));
    }
}