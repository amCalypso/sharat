package com.epsilon.dcrm;

import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.util.IOUtils;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.objects.MatillionJobTriggerSQSMessage;
import com.epsilon.dcrm.objects.MatillionVariables;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.properties.S3;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.S3Service;
import com.epsilon.dcrm.service.SQSService;
import com.epsilon.dcrm.util.CSVUtil;

@ContextConfiguration(classes = AppConfig.class)
public class BaseTest extends AbstractTransactionalTestNGSpringContextTests {

    @Autowired
    private S3 s3Props;

    @Autowired
    private S3Service s3Service;

    @Autowired
    private FrmsService frmsService;

    @Autowired
    protected MessagePoller messagePoller;

    @Autowired
    private SQSService sqsService;

    @Value("${matillion.sqs.url}")
    private String matillionSqsUrl;

    @Value("${sqs.url}")
    protected String sqsUrl;

    protected List<Long> fileIds = new ArrayList<Long>();

    protected <C> List<C> readTestData(String filename, String filepath, Class<C> clazz, Comparator<C> comparator) throws IOException {
        List<C> csvRecords = CSVUtil.readStaticFile(clazz, filepath, true);
        assertNotNull(csvRecords, "Empty list of records from test csv");
        assertNotEquals(csvRecords.size(), 0, String.format("Found 0 records in test data."));

        if (comparator != null) {
            Collections.sort(csvRecords, comparator);
        }
        return csvRecords;
    }

    protected void startProcess(String filename, String filePath, String workFlowId) throws IOException {
        uploadDataFileFromClassPath(filename, filePath);
        frmsService.testEnable(workFlowId);
    }

    protected void uploadDataFileFromClassPath(String filename, String path) throws IOException {
        InputStream dataStream = this.getClass().getResourceAsStream(path);
        byte[] bytes = IOUtils.toByteArray(dataStream);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        String dataFileKey = new StringBuilder().append(s3Props.getS3Path()).append("/").append(filename).toString();
        s3Service.uploadToS3(new PutObjectRequest(s3Props.getS3BucketName(), dataFileKey, byteArrayInputStream, metadata));
    }

    protected Long pollForMessages(String filename, String jobName) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        Long fileId = null;
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMessage(filename, jobName, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        if (CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc()) && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus())) {
            fileId = new Long(pollMatillionMessage.getKeyInfo().getFileId());
            assertNotNull(fileId, "FileId parameter is null from Matillion.");
            fileIds.add(fileId);
        } else {
            assertTrue(false, "Something went wrong in Matillion.");
        }
        return fileId;
    }

    // Adding special poller for Metadata messages. This is a quick fix until we refactor the SQS handling.
    protected void pollForMetadataMessages(String tableName, String jobName) throws ParseException, ApplicationException, IOException {
        // Poll SQS for the Success/Failure message
        MessageDetails pollMatillionMessage = messagePoller.pollMatillionMetadataMessage(tableName, jobName, sqsUrl, 50);
        assertNotNull(pollMatillionMessage, "Matiilion message object is null");
        if (!(CommonConstants.ENV_AWS.equals(pollMatillionMessage.getSrcSystem().getEnvLoc())
                && CommonConstants.MATILLION_SUCCESS_EVENT_STATUS.equalsIgnoreCase(pollMatillionMessage.getEventStatus()))) {
            assertTrue(false, "Something went wrong in Matillion.");
        }
    }

    protected void triggerMatillionJob(String filename, String jobName) {
        MatillionVariables variable = MatillionVariables.builder().fileName(filename).build();
        sendMatillionStartMessage(jobName, variable);
    }

    protected void triggerMatillionJob(String jobName, MatillionVariables variables) {
        sendMatillionStartMessage(jobName, variables);
    }

    private void sendMatillionStartMessage(String jobName, MatillionVariables variables) {
        MatillionJobTriggerSQSMessage sqsMessage = MatillionJobTriggerSQSMessage.builder()
                .group("DCRM")
                .project("dcrm-main")
                .version("default")
                .job(jobName)
                .environment("Test")
                .variables(variables)
                .build();
        sqsService.postMessageToSQS(sqsMessage, matillionSqsUrl);
    }

}
