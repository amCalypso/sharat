package com.epsilon.dcrm.transaction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.config.AppConfig;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DEmployeeRepository;
import com.epsilon.dcrm.db.repository.DIndividualAddressRepository;
import com.epsilon.dcrm.db.repository.DIndividualRepository;
import com.epsilon.dcrm.db.repository.DLocationRepository;
import com.epsilon.dcrm.db.repository.DProductCatalogRepository;
import com.epsilon.dcrm.db.repository.DProfileAddressRepository;
import com.epsilon.dcrm.db.repository.DTransactionAdjustmentRepository;
import com.epsilon.dcrm.db.repository.DTransactionHeaderRepository;
import com.epsilon.dcrm.db.repository.DTransactionItemRepository;
import com.epsilon.dcrm.db.repository.DvTransactionAdjustmentRepository;
import com.epsilon.dcrm.db.repository.DvTransactionItemRepository;
import com.epsilon.dcrm.db.repository.MTransactionAdjustmentRepository;
import com.epsilon.dcrm.db.repository.MTransactionItemOrphanRepository;
import com.epsilon.dcrm.db.repository.MTransactionItemRepository;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.dimension.DimensionIndividual;
import com.epsilon.dcrm.model.dimension.DimensionIndividualAddress;
import com.epsilon.dcrm.model.dimension.DimensionLocation;
import com.epsilon.dcrm.model.dimension.DimensionProductCatalog;
import com.epsilon.dcrm.model.dimension.DimensionTransactionAdjustment;
import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.dimension.DvTransactionAdjustment;
import com.epsilon.dcrm.model.dimension.DvTransactionItem;
import com.epsilon.dcrm.model.mart.MTransactionAdjustment;
import com.epsilon.dcrm.model.mart.MTransactionItem;
import com.epsilon.dcrm.model.mart.MTransactionItemOrphan;
import com.epsilon.dcrm.objects.comparer.DvTransItemComparer;
import com.epsilon.dcrm.objects.comparer.MTransactionItemComparer;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class MTransactionItemAndAdjustmentTest extends BaseTest {

    private static final String BRAND_CD = "Titem";
    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final long FILE_ID = (long) Math.ceil(Math.random() * 10000);
    private static final long EPOCH_MILLIS = Instant.now().toEpochMilli();
    private static final String SKU = RAND_STRING.substring(0, 8);
    private static final String MATCHING_TXN_NBR = RAND_STRING;
    private static final String NON_MATCHING_TXN_NBR = UUID.randomUUID().toString();
    private static final String MATCHING_TXN_ADJ_NBR = RAND_STRING;
    private static final long MATCHING_TXN_ADJ_LINE_NBR = (long) (Math.random() * 1000);

    @Autowired
    private DTransactionItemRepository dTransItemRepo;

    @Autowired
    private DvTransactionItemRepository dvTransItemRepo;

    @Autowired
    private DIndividualRepository dIndivRepo;

    @Autowired
    private DIndividualAddressRepository dIndivAddrRepo;

    @Autowired
    private DProfileAddressRepository dProfAddrRepo;

    @Autowired
    private DProductCatalogRepository dProdCatalogRepo;

    @Autowired
    private DEmployeeRepository dEmployeeRepo;

    @Autowired
    private DLocationRepository dLocationRepo;

    @Autowired
    private DTransactionHeaderRepository dTransRepo;

    @Autowired
    private MTransactionItemRepository mTranasctionItemRepo;

    @Autowired
    private MTransactionItemOrphanRepository mTransItemOrphanRepo;

    @Autowired
    private DTransactionAdjustmentRepository dTransactionAdjustmentRepo;

    @Autowired
    private DvTransactionAdjustmentRepository dvTransactionAdjustmentRepo;

    @Autowired
    private MTransactionAdjustmentRepository mTransactionAdjustmentRepo;

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.CREATE_M_TRANSACTION_ITEM_TABLES, false);
        //Matching Individual record for transaction item and transaction views
        dIndivRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS - 100, FILE_ID);

        //Matching record in individual_address and profile_address tables for match in transaction_item and transaction views based on tri-part key
        dIndivAddrRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, "road 1", "street 1", "area 1", "Anchorage", "Alask", "75000", "0000", "USA", FILE_ID, (long) (Math.random() * 1000));

        dProfAddrRepo.insertSimpleTestRecord(EPOCH_MILLIS, EPOCH_MILLIS, BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, FILE_ID, (long) (Math.random() * 1000));

        //Matching record in product_catalog table for transaction_item view
        dProdCatalogRepo.insertSimpleTestRecord(SKU, BRAND_CD, FILE_ID, (long) (Math.random() * 1000));

        //matching record in employee table for tranaction_item view
        dEmployeeRepo.insertSimpleTestRecord(BRAND_CD, Long.toString(EPOCH_MILLIS));
        dLocationRepo.insertSimpleTestRecord(RAND_STRING.substring(0, 10), RAND_STRING, FILE_ID, (long) (Math.random() * 1000), BRAND_CD);

        //Matching record in transaction table for transaction view
        dTransRepo.insertTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING, RAND_STRING.substring(0, 5), EPOCH_MILLIS);

        // Non-orphan record for d_transaction_item
        dTransItemRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), MATCHING_TXN_NBR, MATCHING_TXN_ADJ_LINE_NBR, BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING,
                SKU, FILE_ID, (long) (Math.random() * 1000), RAND_STRING.substring(0, 10));

        // Orphan record for d_transaction_item
        dTransItemRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), NON_MATCHING_TXN_NBR, (long) (Math.random() * 1000), BRAND_CD, RAND_STRING.substring(0, 5), RAND_STRING,
                SKU, FILE_ID, (long) (Math.random() * 1000), RAND_STRING.substring(0, 10));

        // Non-orphan record for d_transaction_adjustment
        dTransactionAdjustmentRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), MATCHING_TXN_ADJ_NBR, MATCHING_TXN_ADJ_LINE_NBR, (long) (Math.random() * 1000), (long) (Math.random() * 10), RAND_STRING.substring(0, 5),
                RAND_STRING.substring(0, 5),
                FILE_ID, (long) (Math.random() * 1000));

        // Orphan record for d_transaction_adjustment
        dTransactionAdjustmentRepo.insertSimpleTestRecord(BRAND_CD, RAND_STRING.substring(0, 5), MATCHING_TXN_ADJ_NBR, MATCHING_TXN_ADJ_LINE_NBR, (long) (Math.random() * 1000), (long) (Math.random() * 10), RAND_STRING.substring(0, 5),
                RAND_STRING.substring(0, 5),
                FILE_ID, (long) (Math.random() * 1000));

    }

    @AfterGroups(alwaysRun = true, groups = { "M_TransactionItemAndAdjustment" })
    public void afterGroup() {

        dIndivRepo.deleteByUpdateFileId(FILE_ID);
        dIndivAddrRepo.deleteByUpdateFileId(FILE_ID);
        dProfAddrRepo.deleteByBrandCd(BRAND_CD);
        dProdCatalogRepo.deleteByBrandCd(BRAND_CD);
        dEmployeeRepo.deleteByBrandCd(BRAND_CD);
        dLocationRepo.deleteByBrandCd(BRAND_CD);
        dTransRepo.deleteByBrandCd(BRAND_CD);
        dTransItemRepo.deleteByCreateFileId(FILE_ID);
        mTranasctionItemRepo.deleteByBrandCd(BRAND_CD);
        mTransItemOrphanRepo.deleteByBrandCd(BRAND_CD);
        dTransactionAdjustmentRepo.deleteByBrandCd(BRAND_CD);
        mTransactionAdjustmentRepo.deleteByBrandCd(BRAND_CD);
    }

    @Rollback(false)
    @Test(groups = "M_TransactionItemAndAdjustment")
    public void testMTransactionItem() {
        String filename = new StringBuilder().append("M_TransactionItemAutomationTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTIONITEM);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTIONITEM);
            // Assertions  
            List<DvTransactionItem> dvTransactionItemRecords = assertTransactionItemView();

            assertMTranasactionItemTable(dvTransactionItemRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        }
    }

    @Rollback(false)
    @Test(groups = "M_TransactionItemAndAdjustment", dependsOnMethods = "testMTransactionItem")
    public void testMTransactionAdjustment() {
        String filename = new StringBuilder().append("M_TransactionAdjustmentAutomationTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_ADJUSTMENT);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_ADJUSTMENT);
            // Assertions  
            List<DvTransactionAdjustment> dvTransactionAdjustmentRecords = assertTransactionAdjustmentView();

            assertMTranasactionAdjustmentTable(dvTransactionAdjustmentRecords);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        }
    }

    private List<DvTransactionAdjustment> assertTransactionAdjustmentView() {
        List<DvTransactionAdjustment> actualRecords = dvTransactionAdjustmentRepo.findByBrandCd(BRAND_CD);
        List<DimensionTransactionAdjustment> dimTxnAdjust = dTransactionAdjustmentRepo.findByBrandCd(BRAND_CD);

        List<DvTransactionAdjustment> expectedRecords = new ArrayList<DvTransactionAdjustment>();

        for (DimensionTransactionAdjustment record : dimTxnAdjust) {
            DvTransactionAdjustment rec = new DvTransactionAdjustment();
            List<DvTransactionItem> dvTransItemRecords = dvTransItemRepo.findByBrandAndTxnElements(record.getBrandCd(), record.getTxnSrcCd(), record.getTxnNbr(), record.getTxnLineNbr());
            assertEquals(dvTransItemRecords.size(), 1, "number of matching records in dv_transaction_item table is not equal to 1");
            BeanUtils.copyProperties(dvTransItemRecords.get(0), rec);
            BeanUtils.copyProperties(record, rec);

            rec.setTxnItemNbr(record.getTxnLineNbr());
            expectedRecords.add(rec);
        }

        Collections.sort(actualRecords);
        Collections.sort(expectedRecords);

        assertEquals(actualRecords, expectedRecords, "dv_transaction_adjustment records do not match with test data");

        return actualRecords;
    }

    private void assertMTranasactionAdjustmentTable(List<DvTransactionAdjustment> dvTransactionAdjustmentRecords) {
        List<MTransactionAdjustment> actualRecords = mTransactionAdjustmentRepo.findByBrandCd(BRAND_CD);
        List<MTransactionAdjustment> expectedRecords = new ArrayList<MTransactionAdjustment>();

        for (DvTransactionAdjustment record : dvTransactionAdjustmentRecords) {
            MTransactionAdjustment rec = new MTransactionAdjustment();
            BeanUtils.copyProperties(record, rec);
            expectedRecords.add(rec);
        }

        Collections.sort(actualRecords);
        Collections.sort(expectedRecords);
        assertEquals(actualRecords, expectedRecords, "m_transaction_adjustment records do not match with test data");
    }

    private void assertMTranasactionItemTable(List<DvTransactionItem> dvTransactionItemRecords) {

        List<MTransactionItem> mtransactionItemRecords = mTranasctionItemRepo.findByBrandCd(BRAND_CD);
        List<MTransactionItemOrphan> mtransItemOrphanRecords = mTransItemOrphanRepo.findByBrandCd(BRAND_CD);

        List<MTransactionItemComparer> mTransItemComparerExpectedRecords = new ArrayList<MTransactionItemComparer>();
        List<MTransactionItemComparer> mTransItemComparerActualRecords = new ArrayList<MTransactionItemComparer>();

        List<MTransactionItemComparer> mTransItemOrphanComparerExpectedRecords = new ArrayList<MTransactionItemComparer>();
        List<MTransactionItemComparer> mTransItemOrphanComparerActualRecords = new ArrayList<MTransactionItemComparer>();

        //Get m_transaction_item records    
        for (MTransactionItem mTransItemRecord : mtransactionItemRecords) {
            MTransactionItemComparer rec = new MTransactionItemComparer();
            BeanUtils.copyProperties(mTransItemRecord, rec);
            mTransItemComparerActualRecords.add(rec);
        }
        //Get m_transaction_item_orphan records  
        for (MTransactionItemOrphan mtransItemOrphanRecord : mtransItemOrphanRecords) {
            MTransactionItemComparer rec = new MTransactionItemComparer();
            BeanUtils.copyProperties(mtransItemOrphanRecord, rec);
            mTransItemOrphanComparerActualRecords.add(rec);
        }
        //Get dv_transaction_item records (both regular and orphan)
        for (DvTransactionItem dvTransactionItemRecord : dvTransactionItemRecords) {
            MTransactionItemComparer rec = new MTransactionItemComparer();
            BeanUtils.copyProperties(dvTransactionItemRecord, rec);
            if (rec.getDcrmTxnId() != 0) {
                mTransItemComparerExpectedRecords.add(rec);
            } else {
                mTransItemOrphanComparerExpectedRecords.add(rec);
            }

        }
        Collections.sort(mTransItemComparerExpectedRecords);
        Collections.sort(mTransItemComparerActualRecords);
        Collections.sort(mTransItemOrphanComparerExpectedRecords);
        Collections.sort(mTransItemOrphanComparerActualRecords);

        assertEquals(mTransItemComparerActualRecords.size(), 1, "1 record is expected in m_transaction_item table");

        assertEquals(mTransItemOrphanComparerActualRecords.size(), 1, "1 record is expected in m_transaction_item_orphan table");

        assertEquals(mTransItemComparerActualRecords, mTransItemComparerExpectedRecords, "Records in m_transaction_item do not match with expected records");

        assertEquals(mTransItemOrphanComparerActualRecords, mTransItemOrphanComparerExpectedRecords, "Records in m_transaction_item_orphan do not match with expected records");

    }

    private List<DvTransactionItem> assertTransactionItemView() {
        List<DimensionTransactionItem> dTransactionItemRecords = dTransItemRepo.findByBrandCd(BRAND_CD);

        List<DvTransItemComparer> dTransItemComparerRecords = new ArrayList<DvTransItemComparer>();
        List<DvTransItemComparer> dvTransItemComparerRecords = new ArrayList<DvTransItemComparer>();

        for (DimensionTransactionItem record : dTransactionItemRecords) {
            DvTransItemComparer rec = new DvTransItemComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setTxnItemNbr(record.getTxnLineNbr());

            List<DimensionIndividualAddress> dIndividualAddressRecords = dIndivAddrRepo.findByIndivId(EPOCH_MILLIS);
            assertEquals(dIndividualAddressRecords.size(), 1, "more than 1 matching record in d_individual_address table");
            DimensionIndividualAddress dIndividualAddressRecord = dIndividualAddressRecords.get(0);
            rec.setShiptoHholdId(dIndividualAddressRecord.getHholdId());

            List<DimensionIndividual> dIndividualRecords = dIndivRepo.findByIndivId(dIndividualAddressRecord.getIndivId());
            assertEquals(dIndividualRecords.size(), 1, "more than 1 matching record in d_individual table");
            rec.setShiptoIndivId(dIndividualRecords.get(0).getCurrIndiv_id());

            List<DimensionProductCatalog> dProdRecords = dProdCatalogRepo.findBySku(record.getSku());
            assertEquals(dProdRecords.size(), 1, "more than 1 matching record in d_product_catalog table");
            DimensionProductCatalog dProdRecord = dProdRecords.get(0);
            rec.setDcrmProdId(dProdRecord.getDcrmProdCatalogId());

            List<DimensionLocation> dLocationRecords = dLocationRepo.findByLocationCd(record.getFulfillLocationCd());
            assertEquals(dLocationRecords.size(), 1, "more than 1 matching record in d_location table");
            DimensionLocation dLocationRecord = dLocationRecords.get(0);
            rec.setFullfillDcrmLocationId(dLocationRecord.getDcrmLocationId());

            if (record.getTxnNbr().equals(MATCHING_TXN_NBR)) {

                List<DimensionEmployee> dEmployeeRecords = dEmployeeRepo.findByBrandCd(BRAND_CD);
                //there is a match in d_trnasction table for non-orphan record
                assertEquals(dEmployeeRecords.size(), 1, "more than 1 matching record in d_employee table");
                rec.setShiptoDcrmEmployeeId(dEmployeeRecords.get(0).getDcrmEmployeeId());
                rec.setHholdId(dIndividualAddressRecord.getHholdId());
                rec.setIndivId(dIndividualRecords.get(0).getCurrIndiv_id());

            } else {
                rec.setIndivId(0L);
                rec.setHholdId(0L);
            }

            if (rec.getIndivId() == null) {
                rec.setIndivId(0L);
            }
            if (rec.getHholdId() == null) {
                rec.setHholdId(0L);
            }

            dTransItemComparerRecords.add(rec);
        }

        Collections.sort(dTransItemComparerRecords);

        List<DvTransactionItem> dvTransItemRecords = dvTransItemRepo.findByBrandCd(BRAND_CD);

        for (DvTransactionItem record : dvTransItemRecords) {
            DvTransItemComparer rec = new DvTransItemComparer();
            BeanUtils.copyProperties(record, rec);
            dvTransItemComparerRecords.add(rec);
        }
        Collections.sort(dvTransItemComparerRecords);

        assertEquals(dvTransItemComparerRecords, dTransItemComparerRecords, "dv_transaction_item records donot match with test data");

        return dvTransItemRecords;
    }

}
