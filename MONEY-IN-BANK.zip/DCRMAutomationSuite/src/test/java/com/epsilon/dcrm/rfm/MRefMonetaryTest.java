package com.epsilon.dcrm.rfm;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.epsilon.dcrm.BaseTest;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.db.repository.DRefMonetaryRepository;
import com.epsilon.dcrm.db.repository.MRefMonetaryRepository;
import com.epsilon.dcrm.model.dimension.DimensionRefMonetary;
import com.epsilon.dcrm.model.mart.MRefMonetary;
import com.epsilon.dcrm.objects.csv.RefMonetary;
import com.epsilon.dcrm.util.CopyUtil;

@RunWith(SpringRunner.class)
public class MRefMonetaryTest extends BaseTest {

    @Autowired
    private DRefMonetaryRepository dRepo;

    @Autowired
    private MRefMonetaryRepository mRepo;

    private static final String RAND_STRING = UUID.randomUUID().toString();
    private static final Long CREATE_FILE_ID = (long) (Math.random() * 1000);
    private static final String MONETARY_CD = "RMT";//Refers to RefMonetaryTest

    @BeforeClass
    public void setup() {
        executeSqlScript(CommonConstants.REF_MONETARY_CREATE, false);
        dRepo.insertTestData(MONETARY_CD, RAND_STRING.substring(0, 20), RAND_STRING, 0.01, 25.0, CREATE_FILE_ID, (long) Math.random() * 1000);
    }

    @Test
    public void testMartLoad() {
        String filename = new StringBuilder().append("MRefMonetaryTest_").append(RAND_STRING).toString();
        try {
            triggerMatillionJob(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_MONETARY);
            pollForMessages(filename, CommonConstants.MATILLION_JOB_NAME_REFRESH_M_REF_MONETARY);
            assertData();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false, e.toString());
        } finally {
            dRepo.deleteByCreateFileId(CREATE_FILE_ID);
            mRepo.deleteById(MONETARY_CD);
        }
    }

    private void assertData() {
        MRefMonetary mRec = mRepo.findByMonetaryCd(MONETARY_CD);
        assertNotNull(mRec, "Null from mart refmonetary table");

        List<MRefMonetary> mRecs = new ArrayList<>();
        mRecs.add(mRec);
        
        List<DimensionRefMonetary> dRecs = dRepo.findByCreateFileId(CREATE_FILE_ID);
        assertNotNull(dRecs, "Null from dimension refmonetary table");
        assertNotEquals(dRecs.size(), 0, "Found 0 records in dimension refmonetary table.");

        List<RefMonetary> convertedDRecs = CopyUtil.convertRefMonetaryDRecs(dRecs);
        List<RefMonetary> convertedMRecs = CopyUtil.convertRefMonetaryMRecs(mRecs);

        assertEquals(convertedMRecs, convertedDRecs, "MRecords donot match with DRecords for RefMonetary");

    }
}
