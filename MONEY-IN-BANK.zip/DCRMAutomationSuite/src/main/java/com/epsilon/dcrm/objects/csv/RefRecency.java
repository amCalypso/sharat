package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the RefRecency feed
 * 
 * @author gwalia
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefRecency implements Comparable<RefRecency> {
    private String recencyCd;
    private String recencyNm;
    private String recencyDsc;
    private String rangeMinVal;
    private String rangeMaxVal;

    @Override
    public int compareTo(RefRecency arg) {
        return recencyCd.compareTo(arg.getRecencyCd());
    }

}
