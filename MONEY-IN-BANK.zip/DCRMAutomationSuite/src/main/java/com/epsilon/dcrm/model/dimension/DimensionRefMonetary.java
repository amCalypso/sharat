package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.RefMonetaryId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_ref_monetary table.
 * @author dvelayudhannair
 *
 */
@Entity
@IdClass(RefMonetaryId.class)
@Table(name = "d_ref_monetary", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionRefMonetary {

    @Id
    @Column(name = "monetary_cd")
    private String monetaryCd;

    @Column(name = "monetary_nm")
    private String monetaryNm;

    @Column(name = "monetary_dsc")
    private String monetaryDsc;

    @Column(name = "range_min_val")
    private Double rangeMinVal;

    @Column(name = "range_max_val")
    private Double rangeMaxVal;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
