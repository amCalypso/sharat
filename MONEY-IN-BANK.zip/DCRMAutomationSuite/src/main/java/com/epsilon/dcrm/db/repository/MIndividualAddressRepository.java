package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MIndividualAddress;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MIndividualAddressRepository extends BaseRepository<MIndividualAddress, Long> {

    List<MIndividualAddress> findByDcrmIndivAddrId(Long dcrmIndivAddrId);

    void deleteByDcrmIndivAddrId(Long dcrmIndivAddrId);

}
