package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionCertificate standard feed
 *
 * @author kkapoor
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionCertificate implements Comparable<TransactionCertificate> {
    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnTs;
    private String certNbr;
    private String certStatusCd;
    private String activityTs;

    @Override
    public int compareTo(TransactionCertificate o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(certNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getCertNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
