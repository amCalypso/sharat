package com.epsilon.dcrm.objects.comparer;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class DvIndivEmailComparer implements Comparable<DvIndivEmailComparer> {
    private Long indivId;
    private String emailAddr;
    private String brandCd;
    private String validInd;
    private Long currIndivId;
    private String bestEmailAddrInd;
    private Long dcrmEmailAddrId;
    private Timestamp updateTs;

    @Override
    public int compareTo(DvIndivEmailComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(emailAddr)
                .append(indivId)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getEmailAddr())
                .append(o.getIndivId())
                .toString();
        return o1Key.compareToIgnoreCase(o2Key);
    }
}
