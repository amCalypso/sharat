package com.epsilon.dcrm.objects;

import java.util.List;

import com.epsilon.dcrm.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FrmsWorkflowResponse {

    private long pid;
    private String name;
    private long folderId;
    private String status;
    private List<ScheduleResponse> schedules;

    @Override
    public String toString() {
        return JsonUtil.getJson(this);
    }

    @Data
    public static class ScheduleResponse {
        @JsonProperty("Flag")
        private boolean active;
    }
}
