package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvTransactionItemId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_transaction_item view.
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvTransactionItemId.class)
@Table(name = "dv_transaction_item", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvTransactionItem {

    @Id
    @Column(name = "txn_item_nbr")
    private String txnItemNbr;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "fullfill_dcrm_location_id")
    private Long fullfillDcrmLocationId;

    @Column(name = "dcrm_prod_id")
    private Long dcrmProdId;

    @Column(name = "shipto_brand_cd")
    private String shiptoBrandCd;

    @Column(name = "dcrm_txn_id")
    private Long dcrmTxnId;

    @Column(name = "hhold_id")
    private Long hholdId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "shipto_dcrm_employee_id")
    private String shiptoDcrmEmployeeId;

    @Column(name = "shipto_hhold_id")
    private Long shiptoHholdId;

    @Column(name = "shipto_indiv_id")
    private Long shiptoIndivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

}
