package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_transaction_item table.
 * @author dvelayudhannair
 *
 */
@Data
public class TransactionItemId implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String txnNbr;

    private String txnLineNbr;

    private String txnSrcCd;

    private String brandCd;

    private Long createFileId;

    private Long createFileRecNbr;

}
