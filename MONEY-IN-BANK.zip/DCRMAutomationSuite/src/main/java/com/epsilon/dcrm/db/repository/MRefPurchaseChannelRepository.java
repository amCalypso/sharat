package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MRefPurchaseChannel;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MRefPurchaseChannelRepository extends BaseRepository<MRefPurchaseChannel, String> {
    MRefPurchaseChannel findByPurchaseChannelCd(String purchaseChannelCd);
}