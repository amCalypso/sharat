package com.epsilon.dcrm.objects;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;
import javax.validation.constraints.Size;

import com.epsilon.dcrm.util.JsonUtil;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DcrmWorkflowParams {
    @NotNull
    private String cdsOrg;

    @NotNull
    private String cdsSubOrg;

    @Size(min = 36, max = 36)
    private String cdsEventTableId;

    @Size(min = 36, max = 36)
    private String cdsProfileTableId;

    @NotNull
    private String frmsClientCode;
    private String paxataTenantId;
    private String paxataServiceAccount;
    private String paxataServiceAccountPassword;

    @NotNull
    private String s3AccessKeyId;

    @NotNull
    private String s3SecretAccessKey;

    @NotNull
    private String s3Region;

    @NotNull
    private String s3BucketName;

    @Pattern(message = "The S3 path should not include s3://", regexp = "^(?!s3:\\/\\/).*$", flags = Flag.CASE_INSENSITIVE)
    private String s3Path;

    @Pattern(message = "Should match pattern jdbc:redshift://.+:\\d+\\/.+", regexp = "^jdbc:redshift:\\/\\/.+:\\d+\\/.+")
    private String dbJdbcUrl;

    @NotNull
    private String dbUsername;

    @NotNull
    private String dbPassword;

    @Override
    public String toString() {
        return JsonUtil.getJson(this);
    }
}
