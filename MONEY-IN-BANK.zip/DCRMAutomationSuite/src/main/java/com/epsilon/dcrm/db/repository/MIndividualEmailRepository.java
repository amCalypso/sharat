package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MIndividualEmail;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MIndividualEmailRepository extends BaseRepository<MIndividualEmail, String> {

    List<MIndividualEmail> findByIndivIdAndBrandCdAndDcrmEmailAddrId(Long indivId, String brandCd, Long dcrmEmailAddrId);
    List<MIndividualEmail> findByDcrmEmailAddrId(Long dcrmEmailAddrId);
    Long deleteByDcrmEmailAddrId(Long dcrmEmailAddrId);

    List<MIndividualEmail> findByBrandCd(String brandCd);
    Long deleteByBrandCd(String brandCd);
}
