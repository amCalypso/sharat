package com.epsilon.dcrm.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FormatUtil {

    private static final Logger logger = LoggerFactory.getLogger(FormatUtil.class);

    public static String convertToString(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.toString();
    }

    public static String convertDate(Timestamp timestamp, String format) {
        if (timestamp == null) {
            return "";
        }
        Date date = new Date();
        date.setTime(timestamp.getTime());
        String formattedDate = new SimpleDateFormat(format).format(date);
        return formattedDate;
    }

    public static String convertDate(Date timestamp, String format) {
        if (timestamp == null) {
            return "";
        }
        Date date = new Date();
        date.setTime(timestamp.getTime());
        String formattedDate = new SimpleDateFormat(format).format(date);
        return formattedDate;
    }

    public static Timestamp getTimestampFromString(String dateStr, String format) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        Date parsedDate = dateFormat.parse(dateStr);
        Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
        return timestamp;
    }

    public static Long convertToLong(String obj) {

        return Long.parseLong(obj);
    }

}
