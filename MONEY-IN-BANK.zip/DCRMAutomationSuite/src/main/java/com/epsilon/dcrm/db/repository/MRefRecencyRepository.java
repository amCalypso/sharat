package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MRefRecency;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)

public interface MRefRecencyRepository extends BaseRepository<MRefRecency, String> {

    MRefRecency findByRecencyCd(String recencyCd);

}
