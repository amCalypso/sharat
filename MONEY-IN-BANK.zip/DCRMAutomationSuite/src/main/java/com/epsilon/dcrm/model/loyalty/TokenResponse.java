package com.epsilon.dcrm.model.loyalty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenResponse {
    private String username;
    private String accessToken;
    private String refreshToken;
    private String accessTokenExpiration;
    private String refreshTokenExpiration;
    private boolean success;
    private boolean requireSsl;
    private boolean isPasswordExpired;
    private String tenantId;
    private String tenantName;
}
