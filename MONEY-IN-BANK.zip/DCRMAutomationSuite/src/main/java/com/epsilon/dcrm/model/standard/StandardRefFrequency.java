package com.epsilon.dcrm.model.standard;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.RefFrequencyId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_ref_frequency table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(RefFrequencyId.class)
@Table(name = "s_ref_frequency", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardRefFrequency {

    @Id
    @Column(name = "frequency_cd")
    private String frequencyCd;;

    @Column(name = "frequency_nm")
    private String frequencyNm;

    @Column(name = "frequency_dsc")
    private String frequencyDsc;

    @Column(name = "range_min_val")
    private Integer rangeMinVal;

    @Column(name = "range_max_val")
    private Integer rangeMaxVal;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

}
