package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionTender standard feed
 * 
 * @author gwalia
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileAddressChange implements Comparable<ProfileAddressChange> {
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private String origUnparsedNm;
    private String origFirstNm;
    private String origMiddleNm;
    private String origLastNm;
    private String origAddrLine1;
    private String origAddrLine2;
    private String origAddrLine3;
    private String origAddrLine4;
    private String origCityNm;
    private String origStateCd;
    private String origPostalCd;
    private String origCountry;
    private String origIsoCountryCd;
    private String newUnparsedNm;
    private String newFirstNm;
    private String newMiddleNm;
    private String newLastNm;
    private String newAddrLine1;
    private String newAddrLine2;
    private String newAddrLine3;
    private String newAddrLine4;
    private String newCityNm;
    private String newStateCd;
    private String newPostalCd;
    private String newCountry;
    private String newIsoCountryCd;
    private String changeSubmitDt;

    @Override
    public int compareTo(ProfileAddressChange o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getAcctSrcCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
