package com.epsilon.dcrm.model.id;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

/**
 * This is the ID class for d_ref_tender
 * @author dvelayudhannair
 *
 */
@Data
public class DRefTenderId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String tenderSubTypeCd;
    private String tenderTypeCd;
    private Timestamp createTs;
}
