package com.epsilon.dcrm.util;

import java.text.MessageFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RedshiftQuery {
    private static final Logger logger = LoggerFactory.getLogger(RedshiftQuery.class);

    public static final String VERIFY_COPY_COMMIT = "SELECT exists (select * from stl_utilitytext where rtrim(\"text\")=''COMMIT'' and xid in (select xid from STL_QUERY where query = {0})) as \"commit\"";

    public static final String FILENAME_FORMAT = "s3://{0}/{1}";

    public static final String GET_STL_LOAD_ERRORS = "select query as \"queryId\", starttime as StartTime, trim(filename) as filename, line_number as lineNumber, trim(colname) as colName, trim(type) as type, col_length as colLength, position, trim(raw_field_value) as rawFieldValue, err_code as errCode, trim(err_reason) as errReason from stl_load_errors where filename like ''%"
            .concat("{0}").concat("%'' and TIMESTAMP_CMP(''{1}'', starttime) <= 0;");

    /*
     * {0} --> schemaname
     * {1} --> tablename
     * {2} --> where/any clause (Optional)
     */
    public static final String SELECT_QUERY = "select * from {0}.{1} {2}";

    /*
     * {0} --> schemaname
     * {1} --> tablename
     * {2} --> where clause
     */
    public static final String DELETE_QUERY = "delete from {0}.{1} {2}";

    public static final String TRUNCATE_QUERY = "truncate {0}.{1}";

    public static final String getFilenameFormat(String bucketName, String path) {
        logger.debug(MessageFormat.format(FILENAME_FORMAT, bucketName, path));
        return MessageFormat.format(FILENAME_FORMAT, bucketName, path);
    }

    public static String verifyCopyCommit(String queryId) {
        logger.debug(MessageFormat.format(VERIFY_COPY_COMMIT, queryId));
        return MessageFormat.format(VERIFY_COPY_COMMIT, queryId);
    }

    public static String getSTLLoadErrors(String filePrefix, String copyStartTimeInSQSMessage) {
        logger.debug(MessageFormat.format(GET_STL_LOAD_ERRORS, filePrefix, copyStartTimeInSQSMessage));
        return MessageFormat.format(GET_STL_LOAD_ERRORS, filePrefix, copyStartTimeInSQSMessage);
    }

    public static String getSelectQuery(String schema, String table, String optionalClause) {
        return MessageFormat.format(SELECT_QUERY, schema, table, optionalClause);
    }

    public static String getDeleteQuery(String schema, String table, String optionalClause) {
        return MessageFormat.format(DELETE_QUERY, schema, table, optionalClause);
    }

    public static String truncateTable(String schema, String table) {
        return MessageFormat.format(TRUNCATE_QUERY, schema, table);
    }
}
