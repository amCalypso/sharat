package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionEmailAddress;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DEmailAddressRepository extends DimensionRepository<DimensionEmailAddress, String> {
    List<DimensionEmailAddress> findByEmailAddr(String emailAddr);

    Long deleteByEmailAddr(String emailAddr);
    Long deleteByDcrmEmailAddrId(Long dcrmEmailAddrId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_email_address"
           + "(email_addr, update_file_id, update_ts)"
           + "VALUES(?1, ?2, getdate())", nativeQuery = true)
    void insertSimpleTestRecord(String emailAddr, Long updateFileId);

}
