package com.epsilon.dcrm.model.mart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_ref_recency table.
 * @author gwalia
 *
 */
@Entity
@Table(name = "m_ref_recency", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MRefRecency {

    @Id
    @Column(name = "recency_cd")
    private String recencyCd;

    @Column(name = "recency_nm")
    private String recencyNm;

    @Column(name = "recency_dsc")
    private String recencyDsc;

    @Column(name = "range_min_val")
    private Long rangeMinVal;

    @Column(name = "range_max_val")
    private Long rangeMaxVal;

}
