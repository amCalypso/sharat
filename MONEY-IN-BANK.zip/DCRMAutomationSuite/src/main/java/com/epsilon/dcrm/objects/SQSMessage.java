package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = Include.NON_NULL)
public class SQSMessage {
    @JsonProperty(value = "Type")
    private String type;
    @JsonProperty(value = "MessageId")
    private String messageId;
    @JsonProperty(value = "TopicArn")
    private String topicArn;
    @JsonProperty(value = "Message")
    private String message;
    @JsonProperty(value = "Timestamp")
    private String timestamp;
    @JsonProperty(value = "SignatureVersion")
    private String signatureVersion;
    @JsonProperty(value = "Signature")
    private String signature;
    @JsonProperty(value = "SigningCertURL")
    private String signingCertURL;
    @JsonProperty(value = "UnsubscribeURL")
    private String unsubscribeURL;
}
