package com.epsilon.dcrm.model.mart;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.MHouseholdSummaryId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_household_summary table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(MHouseholdSummaryId.class)
@Table(name = "m_household_summary", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HouseholdSummary {

    @Id
    @Column(name = "hhold_id")
    private Long hHoldId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "name_prefix")
    private String namePrefix;

    @Column(name = "first_nm")
    private String firstNm;

    @Column(name = "middle_nm")
    private String middleNm;

    @Column(name = "last_nm")
    private String lastNm;

    @Column(name = "name_suffix")
    private String nameSuffix;

    @Column(name = "marital_status_cd")
    private String maritalStatusCd;

    @Column(name = "gender_cd")
    private String genderCd;

    @Column(name = "birth_dt")
    private Date birthDt;

    @Column(name = "birth_day")
    private Integer birthDay;

    @Column(name = "birth_mth")
    private Integer birthMth;

    @Column(name = "birth_yr")
    private Integer birthYr;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "zip4")
    private String zip4;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "best_phone_nbr")
    private String phoneNbr;

    @Column(name = "indiv_id")
    private Integer indivId;

    @Column(name = "dcrm_indiv_addr_id")
    private Integer dcrmIndivAddrId;

}
