package com.epsilon.dcrm.spike.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SNSSrcSystem {
    private String env;

    @JsonProperty("env_loc")
    private String envLoc;
    
    private String name;
    
    private SNSData data;
}
