package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the ID class for d_ref_frequency
 * @author adomakonda
 *
 */
@Data
public class RefFrequencyId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String frequencyCd;
    private Long createFileId;
    private Long createRecNbr;
}
