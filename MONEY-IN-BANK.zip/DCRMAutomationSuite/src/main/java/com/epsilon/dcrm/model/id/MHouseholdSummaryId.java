package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_household_summary table.
 * @author Mohan
 *
 */
@Data
public class MHouseholdSummaryId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long hHoldId;

    private String brandCd;

}
