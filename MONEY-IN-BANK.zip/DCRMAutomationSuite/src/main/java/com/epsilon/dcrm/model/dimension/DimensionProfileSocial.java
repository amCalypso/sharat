package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfileSocialId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile_social table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(ProfileSocialId.class)
@Table(name = "d_profile_social", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfileSocial {
    @Id
    @Column(name = "dcrm_social_acct_id")
    private Long dcrmSocialAcctId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "src_acct_nbr")
    private String acctSrcNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
