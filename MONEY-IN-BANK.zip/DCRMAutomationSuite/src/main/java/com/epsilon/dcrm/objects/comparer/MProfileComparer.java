package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class MProfileComparer implements Comparable<MProfileComparer> {
    private Long dcrmProfileId;
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private Long indivId;
    private String genderCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String unparsedNm;
    private String busnNm;
    private String title;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String addrLine4;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String countryCd;
    private String countryNm;
    private Date birthDt;
    private Integer birthDay;
    private Integer birthMth;
    private Integer birthYr;
    private String langCd;
    private String maritalStatusCd;
    private String preferredChannelCd;
    private String doNotPromoteInd;
    private String doNotCallInd;
    private String doNotMailInd;
    private String doNotSmsInd;
    private String doNotEmailInd;
    private String doNotRentInd;
    private String hardkey1;
    private String hardkey2;
    private String hardkey3;
    private String hardkey4;
    private String hardkey5;
    private String hardkey6;
    private String hardkey7;
    private String hardkey8;
    private String hardkey9;
    private String hardkey10;
    private Timestamp activityTs;
    private String recStatusCd;
    private Date recStatusChangeDt;
    private String recSrcCd;
    private Long gaId;
    private String aceStatusCd;
    private String geoMatchCd;
    private String aceGeoBlk;
    private String aceAgeoMcd;
    private String aceCgeoCbsa;
    private String aceCgeoMsa;
    private Integer latitude;
    private Integer longitude;
    private String fipsPlaceCd;
    private String dsfBusnInd;
    private String dsfDropInd;
    private String dsfThrowbackInd;
    private String dsfSeasonalInd;
    private String dsfVacantInd;
    private String dsfDeliveryTypeCd;
    private String dsfCurbInd;
    private String dsfNdcbuInd;
    private String dsfCentralInd;
    private String dsfDoorSlotInd;
    private String dsfDropCnt;
    private String dsfLacsInd;
    private String dsfNostatInd;
    private String dsfEducationalInd;
    private String dsfRecTypeCd;
    private String mailabilityCd;
    private String occupancyCd;
    private String dwellingTypeCd;
    private String canDoNotMailInd;
    private String canDoNotCallInd;
    private String canDoNotFaxInd;
    private String prisonInd;
    private String nursingHomeInd;
    private String deceasedInd;
    private Date deceasedDob;
    private Date deceasedDod;
    private Date recProcessDt;
    private String aceApLacsInd;

    @Override
    public int compareTo(MProfileComparer o) {
        return dcrmProfileId.compareTo(o.getDcrmProfileId());
    }
}
