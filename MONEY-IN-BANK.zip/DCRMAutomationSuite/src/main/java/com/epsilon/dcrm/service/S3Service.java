package com.epsilon.dcrm.service;

import com.amazonaws.services.s3.model.PutObjectRequest;

public interface S3Service {
    void uploadToS3(PutObjectRequest putObjectRequest);

    void deleteObject(String bucketName, String keyName);

    void deleteObjectWithPrefix(String bucketName, String prefix);
}
