package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the d_household_golden_profile table.
 * @author Mohan
 *
 */
@Data
public class DHouseholdGoldenProfileId implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Long hHoldId;

    private String brandCd;

}
