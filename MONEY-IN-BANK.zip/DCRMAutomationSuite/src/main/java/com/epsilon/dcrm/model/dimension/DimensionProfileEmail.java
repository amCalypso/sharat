package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfileEmailId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile_email table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(ProfileEmailId.class)
@Table(name = "d_profile_email", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfileEmail {
    @Id
    @Column(name = "dcrm_email_addr_id")
    private Long dcrmEmailAddrId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "src_acct_nbr")
    private String acctSrcNbr;

    @Column(name = "preferred_ind")
    private String preferredInd;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;
    
    @Column(name = "src_email_addr")
    private String srcEmailAddr;
}
