package com.epsilon.dcrm.service.impl;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestOperations;

import com.epsilon.dcrm.model.loyalty.AggregationDetail;
import com.epsilon.dcrm.model.loyalty.TableDetail;
import com.epsilon.dcrm.model.loyalty.TokenResponse;
import com.epsilon.dcrm.properties.LoyaltyApiProperties;
import com.epsilon.dcrm.properties.LoyaltyOauthProperties;
import com.epsilon.dcrm.service.LoyaltyService;
import com.epsilon.dcrm.util.LoyaltyApiUtil;

@Service
public class LoyaltyServiceImpl implements LoyaltyService {

    private static Logger logger = LoggerFactory.getLogger(LoyaltyServiceImpl.class);

    @Autowired
    @Qualifier("basicRestTemplate")
    private RestOperations restTemplate;

    @Autowired
    private LoyaltyApiProperties loyaltyApiProperties;

    @Autowired
    private LoyaltyOauthProperties loyaltyOauthProperties;

    @Autowired
    private ApplicationContext context;

    /* 
     * Using the proxy service with the PostConstruct below so that the Loyalty tokens
     * will be cached on the first request.
     */
    private LoyaltyService proxyService;

    @PostConstruct
    private void init() {
        proxyService = context.getBean(LoyaltyService.class);
    }

    @Override
    public TableDetail createTable(TableDetail tableDetail) {
        HttpEntity<TableDetail> request = new HttpEntity<>(tableDetail, setHeaders());
        return restTemplate.postForObject(
                loyaltyApiProperties.getBaseUrl().concat(loyaltyApiProperties.getEndpoint().getTables()),
                request,
                TableDetail.class);
    }

    @Override
    public void deleteTable(String tableId) {
        restTemplate.exchange(
                loyaltyApiProperties.getBaseUrl().concat(loyaltyApiProperties.getEndpoint().getTableById()),
                HttpMethod.DELETE,
                new HttpEntity<>(setHeaders()),
                String.class,
                tableId);
        logger.debug("Delete Table Id = {}", tableId);
    }

    @Override
    public AggregationDetail createAggregation(AggregationDetail aggregationDetail) {
        HttpEntity<AggregationDetail> request = new HttpEntity<>(aggregationDetail, setHeaders());
        return restTemplate.postForObject(
                loyaltyApiProperties.getBaseUrl().concat(loyaltyApiProperties.getEndpoint().getAggregations()),
                request,
                AggregationDetail.class);
    }

    @Override
    public void deleteAggregation(String aggregationId) {
        restTemplate.exchange(
                loyaltyApiProperties.getBaseUrl().concat(loyaltyApiProperties.getEndpoint().getAggregationById()),
                HttpMethod.DELETE,
                new HttpEntity<>(setHeaders()),
                String.class,
                aggregationId);
        logger.debug("Delete Aggregate Id = {}", aggregationId);
    }

    @Override
    @Cacheable(value = "LoyaltyToken")
    public TokenResponse getLoyaltyToken() {
        MultiValueMap<String, String> headers = LoyaltyApiUtil.getHeadersForLoyaltyOAuth(loyaltyOauthProperties.getClientId(), loyaltyOauthProperties.getClientSecret());
        HttpEntity<String> request = new HttpEntity<>(getBodyForToken(), headers);

        return restTemplate.postForObject(
                loyaltyOauthProperties.getTokenUrl(),
                request,
                TokenResponse.class);
    }

    private MultiValueMap<String, String> setHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Authorization", "Bearer " + proxyService.getLoyaltyToken().getAccessToken());
        headers.add("Accept-Language", "en-US");
        headers.add("content-type", "application/json");
        return headers;
    }

    private String getBodyForToken() {
        return new StringBuilder()
                .append("grant_type=")
                .append(loyaltyOauthProperties.getGrantType())
                .append("&username=")
                .append(loyaltyOauthProperties.getUserName())
                .append("&password=")
                .append(loyaltyOauthProperties.getPassword())
                .append("&response_type=")
                .append(loyaltyOauthProperties.getResponseType())
                .toString();
    }
}
