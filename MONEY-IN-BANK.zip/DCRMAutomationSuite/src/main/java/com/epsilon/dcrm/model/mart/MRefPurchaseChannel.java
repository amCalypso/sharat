package com.epsilon.dcrm.model.mart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_ref_purchase_channel table.
 * @author dvelayudhannair
 *
 */
@Entity
@Table(name = "m_ref_purchase_channel", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MRefPurchaseChannel {

    @Id
    @Column(name = "purch_channel_cd")
    private String purchaseChannelCd;

    @Column(name = "purch_channel_nm")
    private String purchaseChannelNm;

    @Column(name = "purch_channel_dsc")
    private String purchaseChannelDsc;
}
