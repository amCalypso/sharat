package com.epsilon.dcrm.objects;

import com.epsilon.dcrm.objects.FrmsWorkflowResponse.ScheduleResponse;
import com.epsilon.dcrm.type.FrmsEnvironment;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DcrmWorkflowResponse {
    private long workflowId;
    private FrmsEnvironment frmsEnv;
    private String workflowName;
    private Long folderId;
    private String workflowStatus;
    private String scheduleStatus;

    public DcrmWorkflowResponse(FrmsWorkflowResponse frmsWorkflowResponse) {
        this.workflowId = frmsWorkflowResponse.getPid();
        this.workflowName = frmsWorkflowResponse.getName();
        this.folderId = frmsWorkflowResponse.getFolderId();
        this.workflowStatus = frmsWorkflowResponse.getStatus();
        this.scheduleStatus = frmsWorkflowResponse.getSchedules().stream().anyMatch(ScheduleResponse::isActive) ? "Enabled" : "Disabled";
    }

    public DcrmWorkflowResponse(FrmsWorkflowResponse frmsWorkflowResponse, FrmsEnvironment frmsEnv) {
        this(frmsWorkflowResponse);
        this.frmsEnv = frmsEnv;
    }

}
