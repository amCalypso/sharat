package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile_address_standard view.
 * @author adomakonda
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_profile_address_standard", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfileAddressStandard {

    @Id
    @Column(name = "dcrm_profile_id")
    private Long dcrmProfileId;

    @Column(name = "ga_id")
    private String gaId;

    @Column(name = "ace_status_cd")
    private String aceStatusCd;

    @Column(name = "geo_match_cd")
    private String geoMatchCd;

    @Column(name = "ace_geo_blk")
    private String aceGeoBlk;

    @Column(name = "ace_ageo_mcd")
    private String aceAgeoMcd;

    @Column(name = "ace_cgeo_cbsa")
    private String aceCgeoCbsa;

    @Column(name = "ace_cgeo_msa")
    private String aceCgeoMsa;

    @Column(name = "latitude")
    private Integer latitude;

    @Column(name = "longitude")
    private Integer longitude;

    @Column(name = "fips_place_cd")
    private String fipsPlaceCd;

    @Column(name = "dsf_busn_ind")
    private String dsfBusnInd;

    @Column(name = "dsf_drop_ind")
    private String dsfDropInd;

    @Column(name = "dsf_throwback_ind")
    private String dsfThrowbackInd;

    @Column(name = "dsf_seasonal_ind")
    private String dsfSeasonalInd;

    @Column(name = "dsf_vacant_ind")
    private String dsfVacantInd;

    @Column(name = "dsf_delivery_type_cd")
    private String dsfDeliveryTypeCd;

    @Column(name = "dsf_curb_ind")
    private String dsfCurbInd;

    @Column(name = "dsf_ndcbu_ind")
    private String dsfNdcbuInd;

    @Column(name = "dsf_central_ind")
    private String dsfCentralInd;

    @Column(name = "dsf_door_slot_ind")
    private String dsfDoorSlotInd;

    @Column(name = "dsf_drop_cnt")
    private String dsfDropCnt;

    @Column(name = "dsf_lacs_ind")
    private String dsfLacsInd;

    @Column(name = "dsf_nostat_ind")
    private String dsfNostatInd;

    @Column(name = "dsf_educational_ind")
    private String dsfEducationalInd;

    @Column(name = "dsf_rec_type_cd")
    private String dsfRecTypeCd;

    @Column(name = "mailability_cd")
    private String mailabilityCd;

    @Column(name = "occupancy_cd")
    private String occupancyCd;

    @Column(name = "dwelling_type_cd")
    private String dwellingTypeCd;

    @Column(name = "can_do_not_mail_ind")
    private String canDoNotMailInd;

    @Column(name = "can_do_not_call_ind")
    private String canDoNotCallInd;

    @Column(name = "can_do_not_fax_ind")
    private String canDoNotFaxInd;

    @Column(name = "prison_ind")
    private String prisonInd;

    @Column(name = "nursing_home_ind")
    private String nursingHomeInd;

    @Column(name = "deceased_ind")
    private String deceasedInd;

    @Column(name = "deceased_dob")
    private Date deceasedDob;

    @Column(name = "deceased_dod")
    private Date deceasedDod;

    @Column(name = "rec_process_dt")
    private Date recProcessDt;

    @Column(name = "ace_ap_lacs_ind")
    private String aceApLacsInd;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "update_file_id")
    private Long updateFileId;

}
