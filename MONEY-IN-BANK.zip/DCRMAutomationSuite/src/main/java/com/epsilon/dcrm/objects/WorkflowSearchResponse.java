package com.epsilon.dcrm.objects;

import com.epsilon.dcrm.type.FrmsExecutionStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkflowSearchResponse {
    @JsonProperty("WorkflowId")
    private String workflowId;
    
    @JsonProperty("JobId")
    private String jobId;
    
    @JsonProperty("ClientName")
    private String clientName;
    
    @JsonProperty("WorkflowExecId")
    private String workflowExecId;
    
    @JsonProperty("ExecStatus")
    private FrmsExecutionStatus execStatus;
    
    @JsonProperty("FolderName")
    private String folderName;
    
    @JsonProperty("WorkflowName")
    private String workflowName;
    
    @JsonProperty("StartDate")
    private String startDate;
    
    @JsonProperty("EndDate")
    private String endDate;
    
    @JsonProperty("ClientId")
    private String clientId;
}