package com.epsilon.dcrm.model.loyalty;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Builder
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TableDetail extends BaseModel {
    private String tableId;
    private String sqlName;
    private String schema;
    private String subjectArea;

    @JsonProperty("IsView")
    private boolean view;

    private String ddl;
    private List<TableColumn> columns;
}
