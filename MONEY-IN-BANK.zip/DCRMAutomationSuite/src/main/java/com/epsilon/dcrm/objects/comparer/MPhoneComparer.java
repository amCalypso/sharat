package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class MPhoneComparer implements Comparable<MPhoneComparer> {
    private String brandCd;
    private String phoneTypeCd;
    private Long dcrmPhoneId;

    @Override
    public int compareTo(MPhoneComparer o) {
        return dcrmPhoneId.compareTo(o.getDcrmPhoneId());

    }

}
