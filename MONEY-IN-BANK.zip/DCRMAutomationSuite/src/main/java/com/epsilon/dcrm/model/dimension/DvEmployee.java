package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvEmployeeId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_employee view.
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvEmployeeId.class)
@Table(name = "dv_employee", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvEmployee {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "src_gender_cd")
    private String srcGenderCd;

    @Column(name = "src_name_prefix")
    private String srcNamePrefix;

    @Column(name = "src_first_nm")
    private String srcFirstNm;

    @Column(name = "src_middle_nm")
    private String srcMiddleNm;

    @Column(name = "src_last_nm")
    private String srcLastNm;

    @Column(name = "src_name_suffix")
    private String srcNameSuffix;

    @Column(name = "src_unparsed_nm")
    private String srcUnparsedNm;

    @Column(name = "home_addr_line_1")
    private String homeAddrLine1;

    @Column(name = "home_addr_line_2")
    private String homeAddrLine2;

    @Column(name = "home_addr_line_3")
    private String homeAddrLine3;

    @Column(name = "home_addr_line_4")
    private String homeAddrLine4;

    @Column(name = "home_city_nm")
    private String homeCityNm;

    @Column(name = "home_state_cd")
    private String homeStateCd;

    @Column(name = "home_postal_cd")
    private String homePostalCd;

    @Column(name = "home_country_cd")
    private String homeCountryCd;

    @Column(name = "assigned_location1_cd")
    private String assignedLocation1Cd;

    @Id
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "assigned_location2_cd")
    private String assignedLocation2Cd;

    @Column(name = "assigned_location3_cd")
    private String assignedLocation3Cd;

    @Column(name = "employment_start_dt")
    private Date employmentStartDt;

    @Column(name = "employment_end_dt")
    private Date employmentEndDt;

    @Column(name = "employment_status_cd")
    private String employmentStatusCd;

    @Column(name = "role_nm")
    private String roleNm;

    @Column(name = "dcrm_employee_id")
    private Long dcrmEmployeeId;

    @Column(name = "home_country_nm")
    private String homeCountryNm;

    @Column(name = "s1_assigned_dcrm_location_id")
    private Long s1AssignedDcrmLocationId;

    @Column(name = "s2_assigned_dcrm_location_id")
    private Long s2AssignedDcrmLocationId;

    @Column(name = "s3_assigned_dcrm_location_id")
    private Long s3AssignedDcrmLocationId;

}
