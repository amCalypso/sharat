package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_individual_address view.
 * @author gwalia
 *
 */
@Data
public class DvIndividualAddressId implements Serializable {

    private static final long serialVersionUID = 6540745122202292776L;
    private String brandCd;
    private Long dcrmIndivAddrId;

}
