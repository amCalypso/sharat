package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_location table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_location", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionLocation {

    @Id
    @Column(name = "dcrm_location_id")
    private Long dcrmLocationId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "location_cd")
    private String locationCd;

    @Column(name = "location_nm")
    private String locationNm;

    @Column(name = "location_type_dsc")
    private String locationTypeDsc;

    @Column(name = "franchise_cd")
    private String franchiseCd;

    @Column(name = "franchise_nm")
    private String franchiseNm;

    @Column(name = "parent_location_cd")
    private String parentLocationCd;

    @Column(name = "parent_location_nm")
    private String parentLocationNm;

    @Column(name = "division_cd")
    private String divisionCd;

    @Column(name = "manager_first_nm")
    private String managerFirstNm;

    @Column(name = "manager_middle_initial")
    private String managerMiddleInitial;

    @Column(name = "manager_last_nm")
    private String managerLastNm;

    @Column(name = "manager_email_addr")
    private String managerEmailAddr;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "urbanization_nm")
    private String urbanizationNm;

    @Column(name = "latitude")
    private String latitude;

    @Column(name = "longitude")
    private String longitude;

    @Column(name = "geofence_radius")
    private String geofenceRadius;

    @Column(name = "status")
    private String status;

    @Column(name = "active_rec_ind")
    private String activeRecInd;

    @Column(name = "create_ts")
    private String createTs;

    @Column(name = "effect_start_dt")
    private String effectStartDt;

    @Column(name = "effect_end_dt")
    private String effectEndDt;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

}