package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "d_individual", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionIndividual {

    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "curr_indiv_id")
    private Long currIndiv_id;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;

}
