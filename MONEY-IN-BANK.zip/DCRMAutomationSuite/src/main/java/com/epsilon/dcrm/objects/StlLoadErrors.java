package com.epsilon.dcrm.objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StlLoadErrors {
    private int queryId;
    private String startTime;
    private String filename;
    private int lineNumber;
    private String colName;
    private String type;
    private int colLength;
    private int position;
    private String rawFieldValue;
    private String errCode;
    private String errReason;
}
