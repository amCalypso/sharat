package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_store table.
 * @author jblasingame
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_store", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionStore {

    @Column(name = "store_cd")
    private String storeCd;

    @Column(name = "store_nm")
    private String storeNm;

    @Column(name = "store_type_cd")
    private String storeTypeCd;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "store_status_cd")
    private String storeStatusCd;

    @Column(name = "store_open_dt")
    private String storeOpenDt;

    @Column(name = "store_close_dt")
    private String storeCloseDt;

    @Id
    @Column(name = "dcrm_store_id")
    private Long dcrmStoreId;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private String createTs;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "addr_line_4")
    private String addrLine4;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "store_phone_nbr")
    private String storePhoneNbr;

    @Column(name = "store_hours_txt")
    private String storeHoursTxt;

    @Column(name = "store_region_1_nm")
    private String storeRegion1Nm;

    @Column(name = "store_region_2_nm")
    private String storeRegion2Nm;

    @Column(name = "store_region_3_nm")
    private String storeRegion3Nm;

    @Column(name = "store_region_4_nm")
    private String storeRegion4Nm;

    @Column(name = "store_config_dsc")
    private String storeConfigDsc;

    @Column(name = "store_comp_ind")
    private String storeCompInd;

    @Column(name = "comp_start_dt")
    private String compStartDt;

    @Column(name = "comp_end_dt")
    private String compEndDt;

    @Column(name = "store_size_band_nm")
    private String storeSizeBandNm;

    @Column(name = "store_remodel_dt")
    private String storeRemodelDt;

    @Column(name = "store_sq_ft_qty")
    private String storeSqFtQty;
}
