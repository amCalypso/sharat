package com.epsilon.dcrm.type;

public enum ProcessErrorCode {
    APPLICATION_ERROR("Application error"),
    DATA_FILE_ERROR("Data file Error");

    String description;

    ProcessErrorCode(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
