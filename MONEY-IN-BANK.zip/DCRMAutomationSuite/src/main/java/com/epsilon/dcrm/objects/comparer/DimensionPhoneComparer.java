package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionPhoneComparer implements Comparable<DimensionPhoneComparer> {
    private String phoneNum;
    private String countryCd;

    @Override
    public int compareTo(DimensionPhoneComparer o) {
        String o1Key = new StringBuilder()
                .append(phoneNum)
                .append(countryCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getPhoneNum())
                .append(o.getCountryCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
