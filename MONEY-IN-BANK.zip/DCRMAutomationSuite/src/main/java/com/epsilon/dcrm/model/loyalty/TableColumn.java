package com.epsilon.dcrm.model.loyalty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TableColumn {

    private String columnId;
    private String name;
    private String description;
    private String sqlName;
    private String dataType;

    @JsonProperty("IsPrimaryKey")
    private boolean primaryKey;

    @JsonProperty("IsIdentity")
    private boolean identity;

    @JsonProperty("IsNullable")
    private boolean nullable;
}
