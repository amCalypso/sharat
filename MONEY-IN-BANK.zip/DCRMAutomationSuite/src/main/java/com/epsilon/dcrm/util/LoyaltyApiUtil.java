package com.epsilon.dcrm.util;

import org.springframework.security.crypto.codec.Base64;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

public class LoyaltyApiUtil {

    private LoyaltyApiUtil() {

    }

    public static String getAuthHeader(final String username, final String password) {
        return "Basic " + encodeCreds(username, password);
    }

    public static String encodeCreds(final String username, final String password) {
        String auth = username + ":" + password;
        return encode(auth);
    }

    public static String encode(final String text) {
        byte[] encodedAuth = Base64.encode(text.getBytes());
        return new String(encodedAuth);
    }

    public static String decode(final String encodedtext) {
        byte[] decodedAuth = Base64.decode(encodedtext.getBytes());
        return new String(decodedAuth);
    }

    public static String getAuthToken(final String token) {
        return "OAuth " + token;
    }

    public static MultiValueMap<String, String> getHeadersForLoyaltyOAuth(final String username, final String password) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.set("Authorization", getAuthHeader(username, password));
        params.set("Accept-Language", "en-US");
        params.set("Content-Type", "application/x-www-form-urlencoded");
        return params;
    }
}