package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvIndividualSummaryId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_individual_summary view.
 * @author adomakonda
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvIndividualSummaryId.class)
@Table(name = "dv_individual_summary", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvIndividualSummary {

    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "name_prefix")
    private String namePrefix;

    @Column(name = "first_nm")
    private String firstNm;

    @Column(name = "middle_nm")
    private String middleNm;

    @Column(name = "last_nm")
    private String lastNm;

    @Column(name = "name_suffix")
    private String nameSuffix;

    @Column(name = "marital_status_cd")
    private String maritalStatusCd;

    @Column(name = "gender_cd")
    private String genderCd;

    @Column(name = "birth_dt")
    private Date birthDt;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "zip4")
    private String zip4;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "best_phone_nbr")
    private String phoneNbr;

    @Column(name = "m12_frequency_cnt")
    private Long m12FrequencyCnt;

    @Column(name = "m13_24_frequency_cnt")
    private Long m1324FrequencyCnt;

    @Column(name = "lifetime_frequency_cnt")
    private Long lifeTimeFrequencyCnt;

    @Column(name = "orig_txn_dt")
    private Date origTxnDt;

}
