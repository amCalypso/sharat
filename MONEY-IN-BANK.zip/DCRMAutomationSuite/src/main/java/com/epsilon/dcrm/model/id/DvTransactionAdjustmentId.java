package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_transaction_adjustment view.
 * @author adomakonda
 *
 */
@Data
public class DvTransactionAdjustmentId implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long dcrmTxnId;
    private String txnItemNbr;
    private Long adjustSeqNbr;

}
