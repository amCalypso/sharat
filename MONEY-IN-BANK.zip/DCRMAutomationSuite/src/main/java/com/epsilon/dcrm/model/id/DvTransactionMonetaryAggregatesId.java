package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_transaction_monetary_aggregates view.
 * @author dmitri
 *
 */
@Data
public class DvTransactionMonetaryAggregatesId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long indivId;

    private String brandCd;

}
