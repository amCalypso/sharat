package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class MEmailAddressComparer implements Comparable<MEmailAddressComparer> {
    private String emailAddr;
    private String validInd;
    private Long dcrmEmailAddrId;

    @Override
    public int compareTo(MEmailAddressComparer o) {
        return dcrmEmailAddrId.compareTo(o.getDcrmEmailAddrId());

    }

}
