package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = Include.NON_NULL)
public class MessageDetails {
    private String topic;
    @JsonProperty(value = "key_info")
    private KeyInfo keyInfo;
    @JsonProperty(value = "event_ts_epoch")
    private String eventTsEpoch;
    @JsonProperty(value = "event_type")
    private String eventType;
    @JsonProperty(value = "event_status")
    private String eventStatus;
    @JsonProperty(value = "src_system")
    private SrcSystem srcSystem;
    private String[] tags;
}
