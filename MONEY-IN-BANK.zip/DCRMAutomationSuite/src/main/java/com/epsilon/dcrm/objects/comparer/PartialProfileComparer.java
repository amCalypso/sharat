package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
/**
 * Not using countryNm for comparison as it comes in from the reference table. 
 * @author dvelayudhannair
 *
 */
public class PartialProfileComparer {
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;

    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String unparsedNm;
    private String busnNm;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String addrLine4;
    private String cityNm;
    // Commenting out stateCd until QMI team changes are finalized for this column
    // private String stateCd;
    private String postalCd;
    private String countryCd;
    private String activityTs;

    private String recSrcCd;

}
