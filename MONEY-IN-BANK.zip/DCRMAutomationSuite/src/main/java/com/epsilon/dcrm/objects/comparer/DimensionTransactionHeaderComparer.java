package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionTransactionHeaderComparer implements Comparable<DimensionTransactionHeaderComparer> {
    private String brandCd;
    private String txnSrcCd;
    private String txnNbr;
    private String txnTs;
    private String billBrandCd;
    private String billAcctSrcCd;
    private String billAcctSrcNbr;
    private String locationBrandCd;
    private String salesLocationCd; // represents location_cd in the table
    private String txnCompleteDt;
    private String txnChannelCd;
    private String mobileInd;
    private String clientellingInd;
    private String employeePurchInd;
    private String registerNbr;
    private String employeeId;
    private String txnSeqNbr;
    private String txnBusnDt;
    private String loyaltyAcctSrcCd;
    private String loyaltyAcctNbr;
    private String loginId;
    private String ipAddr;
    private String srcKeycode;
    private String emailAddr;
    private String phoneNbr;
    private String receiptDeliveryMethodCd;
    private String emailCaptureTypeCd;
    private String ereceiptEmailAddr;
    private String emailCaptureInd;
    private String txnTypeCd;
    private String txnSubtypeCd;
    private String relatedTxnNbr;
    private String relatedTxnTs;
    private String purchTxnAmt;
    private String purchTaxAmt;
    private String purchShipAmt;
    private String purchDiscountAmt;
    private String cancelTxnAmt;
    private String cancelTaxAmt;
    private String cancelShipAmt;
    private String cancelDiscountAmt;
    private String returnTxnAmt;
    private String returnTaxAmt;
    private String returnShipAmt;
    private String returnDiscountAmt;
    private String currencyCd;
    private String foreignInd;
    private String buyerTypeCd;
    private String txnVoidInd;
    private String txnStatusCd;
    private String txnRemarkTxt;
    private String itemPriceOverrideInd;
    private String shipPriceOverrideInd;
    private String returnReasonCd;
    private String activityTs;

    @Override
    public int compareTo(DimensionTransactionHeaderComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnNbr())
                .toString();
        return o1Key.compareToIgnoreCase(o2Key);
    }
}
