package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvHouseholdSummary;
import com.epsilon.dcrm.model.id.DvHouseholdSummaryId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvHouseholdSummaryRepository extends BaseRepository<DvHouseholdSummary, DvHouseholdSummaryId> {
    List<DvHouseholdSummary> findByBrandCd(String brandCd);

    Long deleteByBrandCd(String brandCd);
}
