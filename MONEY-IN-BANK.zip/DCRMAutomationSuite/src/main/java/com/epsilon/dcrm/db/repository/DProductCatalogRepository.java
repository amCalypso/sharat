package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProductCatalog;
import com.epsilon.dcrm.model.id.ProductCatalogId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProductCatalogRepository extends StandardRepository<DimensionProductCatalog, ProductCatalogId> {

    Long deleteByBrandCd(String brandCd);

    List<DimensionProductCatalog> findByBrandCd(String brandCd);

    List<DimensionProductCatalog> findBySku(String sku);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_product_catalog"
            + "(sku, brand_cd, activity_ts, create_file_id, create_rec_nbr)"
            + "VALUES(?1, ?2, getdate(), ?3,?4);", nativeQuery = true)
    void insertSimpleTestRecord(String sku, String brand_cd, Long createfile_id, Long create_file_id);

    Long deleteBySku(String sku);

}
