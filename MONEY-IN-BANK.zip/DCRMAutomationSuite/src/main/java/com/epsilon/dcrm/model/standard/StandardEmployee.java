package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.EmployeeId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_employee table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(EmployeeId.class)
@Table(name = "s_employee", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardEmployee {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "src_gender_cd")
    private String srcGenderCd;

    @Column(name = "src_name_prefix")
    private String srcNamePrefix;

    @Column(name = "src_first_nm")
    private String srcFirstNm;

    @Column(name = "src_middle_nm")
    private String srcMiddleNm;

    @Column(name = "src_last_nm")
    private String srcLastNm;

    @Column(name = "src_name_suffix")
    private String srcNameSuffix;

    @Column(name = "src_unparsed_nm")
    private String srcUnparsedNm;

    @Column(name = "home_addr_line_1")
    private String homeAddrLine1;

    @Column(name = "home_addr_line_2")
    private String homeAddrLine2;

    @Column(name = "home_addr_line_3")
    private String homeAddrLine3;

    @Column(name = "home_addr_line_4")
    private String homeAddrLine4;

    @Column(name = "home_city_nm")
    private String homeCityNm;

    @Column(name = "home_state_cd")
    private String homeStateCd;

    @Column(name = "home_postal_cd")
    private String homePostalCd;

    @Column(name = "home_country_cd")
    private String homeCountryCd;

    @Column(name = "home_country_nm")
    private String homeCountryNm;

    @Column(name = "assigned_location1_cd")
    private String assignedLocation1Cd;

    @Column(name = "assigned_location2_cd")
    private String assignedLocation2Cd;

    @Column(name = "assigned_location3_cd")
    private String assignedLocation3Cd;

    @Column(name = "employment_start_dt")
    private Date employmentStartDt;

    @Column(name = "employment_end_dt")
    private Date employmentEndDt;

    @Column(name = "employment_status_cd")
    private String employmentStatusCd;

    @Column(name = "role_nm")
    private String roleNm;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createFileRecNbr;

}
