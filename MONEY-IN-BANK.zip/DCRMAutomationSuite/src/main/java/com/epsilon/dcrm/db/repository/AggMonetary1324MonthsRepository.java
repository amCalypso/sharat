package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.AggMonetary1324Months;
import com.epsilon.dcrm.model.id.AggMonetaryId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface AggMonetary1324MonthsRepository extends BaseRepository<AggMonetary1324Months, AggMonetaryId> {
    List<AggMonetary1324Months> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);

    List<AggMonetary1324Months> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.agg_monetary_13_24_months"
            + "(indiv_id, brand_cd, m13_24_frequency_cnt, m13_24_gross_amt, m13_24_discount_amt, m13_24_return_amt, m13_24_cancel_amt)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7)", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String brandCd,
            Long m1324FrequencyCnt, Double m1324GrossAmt,
            Double m1324DiscountAmt, Double m1324ReturnAmt,
            Double m1324CancelAmt);

}
