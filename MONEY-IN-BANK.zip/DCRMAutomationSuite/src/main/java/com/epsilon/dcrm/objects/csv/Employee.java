package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the Employee standard feed
 *
 * @author adomakonda
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Employee implements Comparable<Employee> {
    private String employeeId;
    private String brandCd;
    private String srcGenderCd;
    private String srcNamePrefix;
    private String srcFirstNm;
    private String srcMiddleNm;
    private String srcLastNm;
    private String srcNameSuffix;
    private String srcUnparsedNm;
    private String homeAddrLine1;
    private String homeAddrLine2;
    private String homeAddrLine3;
    private String homeAddrLine4;
    private String homeCityNm;
    private String homeStateCd;
    private String homePostalCd;
    private String homeCountryNm;
    private String homeCountryCd;
    private String employmentStartDt;
    private String employmentEndDt;
    private String roleNm;
    private String assignedLocation1Cd;
    private String assignedLocation2Cd;
    private String assignedLocation3Cd;
    private String employmentStatusCd;
    private String activityTs;

    @Override
    public int compareTo(Employee o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(employeeId)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getEmployeeId())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }

}
