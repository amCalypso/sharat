package com.epsilon.dcrm.model.dimension;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvTransactionAdjustmentId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_transaction_adjustment view.
 * @author adomakonda
 *
 */
@Entity
@IdClass(DvTransactionAdjustmentId.class)
@Table(name = "dv_transaction_adjustment", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvTransactionAdjustment implements Comparable<DvTransactionAdjustment> {

    @Id
    @Column(name = "adjust_seq_nbr")
    private Long adjustSeqNbr;

    @Column(name = "adjust_dt")
    private Date adjustDt;

    @Column(name = "adjust_amt")
    private Double adjustAmt;

    @Column(name = "adjust_type_cd")
    private String adjustTypeCd;

    @Column(name = "adjust_subtype_cd")
    private String adjustSubtypeCd;

    @Column(name = "discount_cd")
    private String discountCd;

    @Column(name = "coupon_cd")
    private String couponCd;

    @Column(name = "barcode")
    private String barcode;

    @Column(name = "ring_cd")
    private String ringCd;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Id
    @Column(name = "txn_item_nbr")
    private String txnItemNbr;

    @Column(name = "shipto_billto_ind")
    private String shiptoBilltoInd;

    @Column(name = "shipto_hhold_id")
    private Long shiptoHholdId;

    @Column(name = "shipto_indiv_id")
    private Long shiptoIndivId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "hhold_id")
    private Long hholdId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "dcrm_txn_id")
    private Long dcrmTxnId;

    @Override
    public int compareTo(DvTransactionAdjustment o) {
        String thisKey = new StringBuilder().append(dcrmTxnId)
                .append(txnItemNbr).append(adjustSeqNbr).toString();
        String oKey = new StringBuilder().append(o.getDcrmTxnId())
                .append(o.getTxnItemNbr()).append(o.getAdjustSeqNbr()).toString();

        return thisKey.compareToIgnoreCase(oKey);
    }
}
