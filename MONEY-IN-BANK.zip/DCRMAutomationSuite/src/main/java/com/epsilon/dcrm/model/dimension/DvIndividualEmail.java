package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.epsilon.dcrm.model.id.DvIndividualEmailId;

/**
 * This is the entity class for the dv_individual_email view.
 * @author dmitri
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvIndividualEmailId.class)
@Table(name = "dv_individual_email", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvIndividualEmail {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Id
    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "dcrm_email_addr_id")
    private Long dcrmEmailAddrId;

    @Column(name = "curr_indiv_id")
    private Long currIndivId;

    @Column(name = "valid_ind")
    private String validInd;

    @Column(name = "best_email_addr_ind")
    private String bestEmailAddrInd;

    @Column(name = "update_ts")
    private Timestamp updateTs;

}
