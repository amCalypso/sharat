package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DHouseholdGoldenProfileId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_household_golden_profile table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DHouseholdGoldenProfileId.class)
@Table(name = "d_household_golden_profile", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionHouseholdGoldenProfile {

    @Id
    @Column(name = "hhold_id")
    private Long hHoldId;

    @Id
    @Column(name = "hoh_indiv_id")
    private Long hohIndivId;
    
    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "name_prefix")
    private String namePrefix;

    @Column(name = "first_nm")
    private String firstNm;

    @Column(name = "middle_nm")
    private String middleNm;

    @Column(name = "last_nm")
    private String lastNm;

    @Column(name = "name_suffix")
    private String nameSuffix;

    @Column(name = "marital_status_cd")
    private String maritalStatusCd;

    @Column(name = "gender_cd")
    private String genderCd;

    @Column(name = "birth_dt")
    private Date birthDt;

    @Column(name = "dcrm_indiv_addr_id")
    private Long dcrmIndivAddrId;

    @Column(name = "dcrm_indiv_email_id")
    private Long dcrmIndivEmailId;

    @Column(name = "dcrm_indiv_phone_id")
    private Long dcrmIndivPhoneId;

}
