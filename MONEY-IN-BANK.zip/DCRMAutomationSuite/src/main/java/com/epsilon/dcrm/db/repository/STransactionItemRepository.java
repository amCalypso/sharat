package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.TransactionItemId;
import com.epsilon.dcrm.model.standard.StandardTransactionItem;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface STransactionItemRepository extends StandardRepository<StandardTransactionItem, TransactionItemId> {
    Long deleteByTxnNbr(String txnNbr);
}
