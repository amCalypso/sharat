package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionIndividualAddress;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DIndividualAddressRepository extends DimensionRepository<DimensionIndividualAddress, Long> {
    List<DimensionIndividualAddress> findByDcrmIndivAddrId(Long dcrmIndivAddrId);

    List<DimensionIndividualAddress> findByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_individual_address"
            + "(indiv_id, ga_id, addr_line_1, addr_line_2, addr_line_3, city_nm, state_nm, postal_cd, "
            + "zip4, country_cd, create_file_id, create_rec_nbr, create_ts, update_file_id, update_rec_nbr, "
            + "update_ts, addr_type_cd)"
            + "VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, getdate(), ?11, ?12, getdate(),'F');", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, Long gaId, String addrLine1, String addrLine2, String addrLine3,
            String city, String state, String postalCd, String zip4, String countryCd, Long fileId, Long recNbr);       
}
