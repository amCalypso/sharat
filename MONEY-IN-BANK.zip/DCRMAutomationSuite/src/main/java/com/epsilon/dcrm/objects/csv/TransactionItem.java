package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionItem standard feed
 * 
 * @author dvelayudhannair
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionItem implements Comparable<TransactionItem> {
    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnLineNbr;
    private String txnTs;
    private String shipToAcctSrcCd;
    private String shipToAcctSrcNbr;
    private String shipToBillToInd;
    private String shipToFirstNm;
    private String shipToMiddleNm;
    private String shipToLastNm;
    private String shipToUnparsedNm;
    private String shipToBusinessNm;
    private String shipToAddrLine1;
    private String shipToAddrLine2;
    private String shipToAddrLine3;
    private String shipToAddrLine4;
    private String shipToCity;
    private String shipToState;
    private String shipToPostalCd;
    private String shipToCountry;
    private String shipToCountryCd;
    private String shipToEmailAddr;
    private String shipToPhoneNbr;
    private String qty;
    private String uom;
    private String firstShipDt;
    private String lastShipDt;
    private String shipQty;
    private String shipUom;
    private String sku;
    private String upc;
    private String sizeCd;
    private String colorDesc;
    private String stdColorCd;
    private String fulfillLocationCd;
    private String fulfillGroupNbr;
    private String itemFulfillmentTypeCd;
    private String itemTypeCd;
    private String listPriceAmt;
    private String offerPriceAmt;
    private String soldPriceAmt;
    private String cogsAmt;
    private String extOfferAmt;
    private String extItemAmt;
    private String extDiscAmt;
    private String extShipAmt;
    private String itemStatusCd;
    private String backorderQty;
    private String backorderDt;
    private String backorderExpectedFulfillDt;
    private String backorderActualFulfillDt;
    private String itemGiftInd;
    private String gwpInd;
    private String bogoInd;
    private String giftWrapInd;
    private String markdownInd;
    private String returnDt;
    private String returnReasonCd;
    private String cancelDt;
    private String cancelReasonCd;
    private String taxRt;
    private String extTaxAmt;
    private String currencyCd;
    private String exchangeRt;
    private String surchargeAmt;
    private String surchargeReasonCd;
    private String activityTs;

    @Override
    public int compareTo(TransactionItem o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnLineNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnLineNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
