package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_individual_email view.
 * @author dmitri
 *
 */
@Data
public class DvIndividualEmailId implements Serializable {

    private static final long serialVersionUID = 1L;

    private String brandCd;
    private Long indivId;
    private String emailAddr;

}
