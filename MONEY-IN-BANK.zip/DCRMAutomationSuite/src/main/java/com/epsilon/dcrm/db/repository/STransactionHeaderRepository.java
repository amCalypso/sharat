package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.TransactionHeaderId;
import com.epsilon.dcrm.model.standard.StandardTransactionHeader;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface STransactionHeaderRepository extends StandardRepository<StandardTransactionHeader, TransactionHeaderId> {
    Long deleteByTxnNbr(String txnNbr);
}
