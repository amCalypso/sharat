package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "m_store", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class MStore {

    @Id
    @Column(name = "store_cd")
    private String storeCd;

    @Column(name = "store_nm")
    private String storeNm;

    @Column(name = "store_type_cd")
    private String storeTypeCd;

    @Column(name = "parent_store_cd")
    private String parentStoreCD;

    @Column(name = "parent_store_nm")
    private String parentStoreNm;

    @Column(name = "franchise_cd")
    private String franchiseCd;

    @Column(name = "franchise_nm")
    private String franchiseNm;

    @Column(name = "chain_nm")
    private String chainNm;

    @Column(name = "chain_priority_seq")
    private String chainPrioritySeq;

    @Column(name = "division_cd")
    private String divisionCd;

    @Column(name = "manager_first_nm")
    private String managerFirstNm;

    @Column(name = "manager_middle_initial")
    private String managerMiddleIntial;

    @Column(name = "manager_last_nm")
    private String managerLastNm;

    @Column(name = "manager_email_addr")
    private String managerEmailAddr;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_nm")
    private String stateCd;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "urbanization_nm")
    private String urbanizationNm;

    @Column(name = "latitude")
    private String latitude;

    @Column(name = "longitude")
    private String longitude;

    @Column(name = "geofenceradius")
    private String geofenceradius;

    @Column(name = "store_status_cd")
    private String storeStatusCd;

    @Column(name = "dcrm_store_id")
    private Long dcrmStoreId;

    @Column(name = "brand_cd")
    private String brandCd;

}
