package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_transaction_adjustment table.
 * @author adomakonda
 *
 */
@Data
public class MTransactionAdjustmentId implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long dcrmTxnId;
    private String txnItemNbr;
    private Long adjustSeqNbr;

}
