package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvTransactionItem;
import com.epsilon.dcrm.model.id.DvTransactionItemId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvTransactionItemRepository extends BaseRepository<DvTransactionItem, DvTransactionItemId> {

    List<DvTransactionItem> findByBrandCd(String brandCd);

    @Query(value = "SELECT * FROM test_crm_warehouse.dv_transaction_item where brand_cd = (?1)" +
            " AND txn_src_cd = (?2) AND txn_nbr = (?3) AND txn_item_nbr = (?4);", nativeQuery = true)
    List<DvTransactionItem> findByBrandAndTxnElements(String brandCd, String txnSrcCd, String txnNbr, String txnItemNbr);

}
