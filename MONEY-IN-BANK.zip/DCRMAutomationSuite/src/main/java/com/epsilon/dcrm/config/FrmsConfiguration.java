package com.epsilon.dcrm.config;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.RestTemplate;

import com.epsilon.dcrm.controller.hook.FrmsClientHttpRequestInterceptor;

@Configuration
public class FrmsConfiguration {
    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder
                .additionalInterceptors(frmsInterceptor())
                .build();
    }

    @Bean
    public ClientHttpRequestInterceptor frmsInterceptor() {
        return new FrmsClientHttpRequestInterceptor();
    }
}
