package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("dcrm.automation.object")
@PropertySource("classpath:automation.properties")
public class Redshift {
	private String dbJdbcUrl;
	private String dbUsername;
	private String dbPassword;
}
