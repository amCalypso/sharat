package com.epsilon.dcrm.type;

public enum FrmsEnvironment {
    HOSTED,
    AWS
}
