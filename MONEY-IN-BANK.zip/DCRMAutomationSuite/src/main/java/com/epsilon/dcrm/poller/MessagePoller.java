package com.epsilon.dcrm.poller;

import java.util.List;

import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.objects.MessageDetails;

public interface MessagePoller {

    List<MessageDetails> pollFrmsMessages(String fileName, String jobName, String env, String queueUrl, int maxAttempts) throws ApplicationException;

    MessageDetails pollMatillionMessage(String fileName, String jobName, String queueUrl, int maxAttempts) throws ApplicationException;

    MessageDetails pollMatillionMetadataMessage(String tableName, String jobName, String queueUrl, int maxAttempts) throws ApplicationException;

}