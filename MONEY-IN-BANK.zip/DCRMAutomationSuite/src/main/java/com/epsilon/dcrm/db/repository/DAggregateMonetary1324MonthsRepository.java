package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionAggMonetary1324Months;
import com.epsilon.dcrm.model.id.AggMonetary1324MonthsId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DAggregateMonetary1324MonthsRepository extends BaseRepository<DimensionAggMonetary1324Months, AggMonetary1324MonthsId> {

    Long deleteByBrandCd(String brandCd);

    List<DimensionAggMonetary1324Months> findByBrandCd(String brandCd);

    List<DimensionAggMonetary1324Months> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.agg_monetary_13_24_months"
            + "(indiv_id, brand_cd, m13_24_frequency_cnt, m13_24_gross_amt, m13_24_discount_amt, m13_24_return_amt, m13_24_cancel_amt)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7)", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String brand_cd, Long m13_24_frequency_cnt,
            Double m1324GrossAmt, Double m1324DiscountAmt, Double m1324ReturnAmt,
            Double m1324CancelAmt);
}