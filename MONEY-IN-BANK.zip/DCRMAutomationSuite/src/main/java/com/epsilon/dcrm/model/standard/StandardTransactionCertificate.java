package com.epsilon.dcrm.model.standard;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionCertificateId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_transaction_certificate table.
 * @author kkapoor
 *
 */
@Entity
@IdClass(TransactionCertificateId.class)
@Table(name = "s_transaction_certificate", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardTransactionCertificate {
    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "cert_nbr")
    private String certNbr;

    @Column(name = "cert_status_cd")
    private String status;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
