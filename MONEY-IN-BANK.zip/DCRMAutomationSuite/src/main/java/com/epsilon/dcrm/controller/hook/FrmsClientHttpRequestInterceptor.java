package com.epsilon.dcrm.controller.hook;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import com.epsilon.dcrm.properties.FrmsApiProperties;

public class FrmsClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(FrmsClientHttpRequestInterceptor.class);

    private static final Set<HttpStatus> HTTP_OK_CODES = EnumSet.of(HttpStatus.OK,
            HttpStatus.CREATED, HttpStatus.ACCEPTED, HttpStatus.NO_CONTENT);

    private static final String AUTH_HEADER_NAME = "Authorization";

    @Autowired
    private FrmsApiProperties props;

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        HttpHeaders headers = request.getHeaders();
        headers.add(AUTH_HEADER_NAME, props.getAuthToken());
        if (log.isDebugEnabled()) {
            log.debug("Authorization = {} \nContent-Type = {} \nURI = {} \nMETHOD = {} \nNew Body : {}",
                    headers.get("Authorization"),
                    headers.get("Content-Type"),
                    request.getURI().toString(),
                    request.getMethod().toString(),
                    new String(body));
        }
        try {
            ClientHttpResponse response = execution.execute(request, body);
            if (log.isDebugEnabled()) {
                log.debug("Response Code : {}", response.getStatusCode());
            }
            if (hasError(response)) {
                log.error("API Error:" + "URI = {} \nMETHOD = {} \nRequest Body : {}\n ReasonPhrase:{}",
                        request.getURI().toString(),
                        request.getMethod().toString(),
                        new String(body),
                        response.getStatusCode().getReasonPhrase());
            }
            return response;
        } catch (Exception ex) {
            log.error("Exception calling service:" + "URI = {} \nMETHOD = {} \nRequest Body : {}\n Exception:{}",
                    request.getURI().toString(),
                    request.getMethod().toString(),
                    new String(body),
                    ex.getMessage());
            throw ex;
        }
    }

    public boolean hasError(ClientHttpResponse response) throws IOException {
        return !HTTP_OK_CODES.contains(response.getStatusCode());
    }
}
