package com.epsilon.dcrm.db.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@NoRepositoryBean
@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface StandardRepository<B, I extends Serializable> extends BaseRepository<B, I> {
    List<B> findByCreateFileId(Long createFileId);

    Long deleteByCreateFileId(Long createFileId);
}
