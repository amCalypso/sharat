package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_employee  and d_ employee table.
 * @author adomakonda
 */
@Data
public class EmployeeId implements Serializable {

    private static final long serialVersionUID = 2563323859922410491L;

    private String brandCd;

    private String employeeId;

    private Long createFileId;

    private Long createFileRecNbr;
}
