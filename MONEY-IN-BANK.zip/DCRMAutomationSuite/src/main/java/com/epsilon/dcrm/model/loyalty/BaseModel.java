package com.epsilon.dcrm.model.loyalty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseModel {
    private String name;
    private String description;
    private String status;
    private String createUser;
    private String createDate;
    private String updateUser;
    private String updateDate;
}
