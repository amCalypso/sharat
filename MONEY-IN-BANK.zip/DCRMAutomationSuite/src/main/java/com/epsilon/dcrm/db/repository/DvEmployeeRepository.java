package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvEmployee;
import com.epsilon.dcrm.model.id.DvEmployeeId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvEmployeeRepository extends BaseRepository<DvEmployee, DvEmployeeId> {

    List<DvEmployee> findByBrandCd(String brandCd);

}
