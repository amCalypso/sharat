package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("frms.api")
public class FrmsApiProperties {
    private String authToken;
    private String baseUri;
    private String baseUriAws;
    private Retry retry;
    private Endpoint endpoint;

    @Data
    public static class Retry {
        private int maxAttempts;
        private long backOffDelay;
    }

    @Data
    public static class Endpoint {
        private String dcrmImport;
        private String dcrmExport;
        private String startWorkflow;
        private String workflowExecutionStatus;
        private String workflowExecutionStatusSearch;
    }
}
