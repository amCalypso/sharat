package com.epsilon.dcrm.objects.comparer;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class CreateUpdateFileFields {
    private Long createFileId;
    private Long createRecNbr;
    private Long updateFileId;
    private Long UpdateRecNbr;
}
