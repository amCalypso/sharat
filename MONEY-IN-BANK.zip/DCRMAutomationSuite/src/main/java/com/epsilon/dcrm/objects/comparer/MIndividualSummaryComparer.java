package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;

import lombok.Data;

@Data
public class MIndividualSummaryComparer implements Comparable<MIndividualSummaryComparer> {
    private Long indivId;
    private String brandCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String maritalStatusCd;
    private String genderCd;
    private Date birthDt;
    private Integer birthDay;
    private Integer birthMth;
    private Integer birthYr;
    private String homeAddrLine1;
    private String homeAddrLine2;
    private String homeAddrLine3;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String zip4;
    private String countryCd;
    private String emailAddr;
    private String phoneNbr;

    private Long m12FrequencyCnt;
    private Long m12GrossAmt;
    private Long m12DiscountAmt;
    private Long m12ReturnAmt;
    private Long m12CancelAmt;
    private Long m12NetAmt;
    private String m12FrequencyCd;
    private String m12MonetaryCd;
    private Long m1324FrequencyCnt;
    private Long m1324GrossAmt;
    private Long m1324DiscountAmt;
    private Long m1324ReturnAmt;
    private Long m1324CancelAmt;
    private Long m1324NetAmt;
    private String m1324FrequencyCd;
    private String m1324MonetaryCd;
    private Long lifetimeFrequencyCnt;
    private Long lifetimeGrossAmt;
    private Long lifetimeDiscountAmt;
    private Long lifetimeReturnAmt;
    private Long lifetimeCancelAmt;
    private Long lifetimeNetAmt;
    private String lifetimeFrequencyCd;
    private String lifetimeMonetaryCd;
    private String recencyCd;
    private Date origTxnDt;
    private Date lastTxnDt;
    private String custLifeCycleCd;

    @Override
    public int compareTo(MIndividualSummaryComparer o) {
        String o1 = new StringBuilder()
                .append(indivId)
                .append(brandCd)
                .toString();
        String o2 = new StringBuilder()
                .append(o.getIndivId())
                .append(o.getBrandCd())
                .toString();
        return o1.compareToIgnoreCase(o2);
    }

}
