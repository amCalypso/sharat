package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the agg_monetary_.. tables.
 * @author dmitri
 *
 */
@Data
public class AggMonetaryId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long indivId;

    private String brandCd;

}
