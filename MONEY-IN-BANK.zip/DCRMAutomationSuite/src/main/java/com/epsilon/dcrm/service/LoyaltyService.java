package com.epsilon.dcrm.service;

import com.epsilon.dcrm.model.loyalty.AggregationDetail;
import com.epsilon.dcrm.model.loyalty.TableDetail;
import com.epsilon.dcrm.model.loyalty.TokenResponse;

public interface LoyaltyService {

    TokenResponse getLoyaltyToken();

    TableDetail createTable(TableDetail tableDetail);

    void deleteTable(String tableId);

    AggregationDetail createAggregation(AggregationDetail aggregationDetail);

    void deleteAggregation(String aggregationId);

}
