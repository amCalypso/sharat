package com.epsilon.dcrm.db.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionRefRecency;
import com.epsilon.dcrm.model.id.RefRecencyId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DRefRecencyRepository extends StandardRepository<DimensionRefRecency, RefRecencyId> {

    Long deleteByRecencyCdAndCreateFileId(String recencyCd, Long createFileId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_ref_recency"
            + "(recency_cd, recency_nm, recency_dsc, range_min_val, range_max_val, create_ts, create_file_id, create_rec_nbr)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, getdate(), ?6, ?7);", nativeQuery = true)
    void insertTestData(String recencyCd, String recencyNm, String recencyDsc, Long rangeMinVal, Long rangeMaxVal, Long createFileId, Long createRecNbr);

    @Query(value = "select * from test_crm_warehouse.d_ref_recency where ROUND(MONTHS_BETWEEN(CURRENT_DATE, ?1)) BETWEEN NVL(range_min_val,0) AND NVL(range_max_val,999)", nativeQuery = true)
    List<DimensionRefRecency> findByValue(Date value);

}
