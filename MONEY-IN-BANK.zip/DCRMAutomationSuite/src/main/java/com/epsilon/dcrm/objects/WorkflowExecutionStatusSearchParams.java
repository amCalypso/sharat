package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkflowExecutionStatusSearchParams {
    private FrmsWorkflowFilter filter;
    private Long recordsCount;
    private Boolean includeInactive;
    private String sortingOrder;
    private String sortingName;
    private Integer pageIndex;
    private Integer pagesCount;
}