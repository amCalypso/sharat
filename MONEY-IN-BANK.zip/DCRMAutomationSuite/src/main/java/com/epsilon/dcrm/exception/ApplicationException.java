package com.epsilon.dcrm.exception;

import com.epsilon.dcrm.type.ProcessErrorCode;

public class ApplicationException extends Exception {
    private static final long serialVersionUID = 1L;
    private ProcessErrorCode errorCode;

    public ApplicationException(String error) {
        super(error);
    }

    public ApplicationException(ProcessErrorCode e) {
        super(e.getDescription());
        this.errorCode = e;
    }

    public ApplicationException(ProcessErrorCode e, String error) {
        super(error);
        this.errorCode = e;
    }

    public ProcessErrorCode getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(ProcessErrorCode errorCode) {
        this.errorCode = errorCode;
    }
}
