package com.epsilon.dcrm.model;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_profile_hash table.
 * @author dvelayudhannair
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "m_profile_hash", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileHash {

    @Id
    @Column(name = "profile_hash_id")
    private Integer profileHashId;

    @Column(name = "src_brand_cd")
    private String srcBrandCd;

    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Column(name = "src_acct_nbr")
    private String srcAcctNbr;

    @Column(name = "tri_part_hash_val")
    private String triPartHashVal;

    @Column(name = "pii_hash_val")
    private String piiHashVal;

    @Column(name = "activity_ts")
    private Timestamp activityts;

}
