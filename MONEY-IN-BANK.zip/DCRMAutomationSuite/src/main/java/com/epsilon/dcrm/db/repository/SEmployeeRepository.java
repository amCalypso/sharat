package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.EmployeeId;
import com.epsilon.dcrm.model.standard.StandardEmployee;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface SEmployeeRepository extends StandardRepository<StandardEmployee, EmployeeId> {
    Long deleteByEmployeeId(String employeeId);
}
