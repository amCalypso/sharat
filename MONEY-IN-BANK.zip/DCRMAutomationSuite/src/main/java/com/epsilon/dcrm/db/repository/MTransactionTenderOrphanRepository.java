package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.MTransactionTenderId;
import com.epsilon.dcrm.model.mart.MTransactionTenderOrphan;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MTransactionTenderOrphanRepository extends BaseRepository<MTransactionTenderOrphan, MTransactionTenderId> {

    Long deleteByBrandCd(String brandCd);

    List<MTransactionTenderOrphan> findByBrandCd(String brandCd);

}
