package com.epsilon.dcrm.model.dimension;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProductCatalogId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_product_catalog table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(ProductCatalogId.class)
@Table(name = "d_product_catalog", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProductCatalog {

    @Column(name = "dcrm_prod_catalog_id")
    private Long dcrmProdCatalogId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "sku")
    private String sku;

    @Column(name = "prod_catalog_start_dt")
    private Date prodCatalogStartDt;

    @Column(name = "prod_catalog_end_dt")
    private Date prodCatalogEndDt;
    
    @Column(name = "sku_nm")
    private String skuNm;

    @Column(name = "sku_dsc")
    private String skuDsc;

    @Column(name = "alt_sku")
    private String altSku;

    @Column(name = "base_prod_cd")
    private String baseProdCd;

    @Column(name = "base_prod_nm")
    private String baseProdNm;

    @Column(name = "prod_option1")
    private String prodOption1;

    @Column(name = "prod_option2")
    private String prodOption2;

    @Column(name = "prod_option3")
    private String prodOption3;

    @Column(name = "size_cd")
    private String sizeCd;

    @Column(name = "uom_nm")
    private String uomNm;

    @Column(name = "color_cd")
    private String colorCd;

    @Column(name = "active_ind")
    private String activeInd;

    @Column(name = "prod_start_dt")
    private Date prodStartDt;

    @Column(name = "prod_end_dt")
    private Date prodEndDt;

    @Column(name = "list_price_amt")
    private Long listPriceAmt;

    @Column(name = "vendor_cd")
    private String vendorCd;

    @Column(name = "vendor_nm")
    private String vendorNm;

    @Column(name = "brand_nm")
    private String brandNm;

    @Column(name = "prod_comment_txt")
    private String prodCommentTxt;
    
    @Column(name = "prod1_txt")
    private String prod1Txt;

    @Column(name = "prod2_txt")
    private String prod2Txt;
    
    @Column(name = "prod3_txt")
    private String prod3Txt;
    
    @Column(name = "prod4_txt")
    private String prod4Txt;
    
    @Column(name = "prod5_txt")
    private String prod5Txt;
    
    @Column(name = "prod6_txt")
    private String prod6Txt;
    
    @Column(name = "prod7_txt")
    private String prod7Txt;
    
    @Column(name = "prod8_txt")
    private String prod8Txt;
    
    @Column(name = "prod1_dt")
    private Date prod1Dt;
    
    @Column(name = "prod2_dt")
    private Date prod2Dt;
    
    @Column(name = "prod3_dt")
    private Date prod3Dt;
    
    @Column(name = "prod4_dt")
    private Date prod4Dt;
    
    @Column(name = "prod1_amt")
    private Long prod1Amt;
    
    @Column(name = "prod2_amt")
    private Long prod2Amt;
    
    @Column(name = "prod3_amt")
    private Long prod3Amt;
    
    @Column(name = "prod4_amt")
    private Long prod4Amt;
    
    @Column(name = "prod1_qty")
    private Long prod1Qty;
    
    @Column(name = "prod2_qty")
    private Long prod2Qty;
    
    @Column(name = "prod3_qty")
    private Long prod3Qty;
    
    @Column(name = "prod4_qty")
    private Long prod4Qty;
    
    @Column(name = "active_rec_ind")
    private String activeRecInd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_file_nm")
    private String createFileNm;
    
    @Column(name = "create_file_ts")
    private Timestamp createFileTs;
    
    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;
    
}