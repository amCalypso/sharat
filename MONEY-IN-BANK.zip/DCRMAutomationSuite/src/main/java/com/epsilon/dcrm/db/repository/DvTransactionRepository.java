package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvTransaction;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvTransactionRepository extends BaseRepository<DvTransaction, String> {

    Long deleteByBrandCd(String brandCd);

    List<DvTransaction> findByBrandCd(String brandCd);

    List<DvTransaction> findByTxnNbr(String txnNbr);

}
