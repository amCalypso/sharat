package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvIndividualPhoneId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_individual_phone view.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvIndividualPhoneId.class)
@Table(name = "dv_individual_phone", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvIndividualPhone {

    @Id
    @Column(name = "dcrm_phone_id")
    private Long dcrmPhoneId;

    @Column(name = "phone_nbr")
    private String phoneNbr;

    @Column(name = "phone_type_cd")
    private String phoneTypeCd;

    @Column(name = "best_phone_ind")
    private String bestPhoneInd;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "curr_indiv_id")
    private Long currIndivId;
    
    @Id
    @Column(name = "brand_cd")
    private String brandCd;
}
