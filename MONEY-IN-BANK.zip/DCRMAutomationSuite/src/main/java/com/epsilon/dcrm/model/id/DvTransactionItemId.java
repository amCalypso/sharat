package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_transaction_item view.
 * @author gwalia
 *
 */
@Data
public class DvTransactionItemId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String brandCd;
    private String txnItemNbr;

}
