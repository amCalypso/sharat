package com.epsilon.dcrm.db.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@NoRepositoryBean
@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DimensionRepository<B, I extends Serializable> extends StandardRepository<B, I> {
    List<B> findByUpdateFileId(Long updateFileId);

    Long deleteByUpdateFileId(Long updateFileId);
}
