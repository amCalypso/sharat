package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvIndividualAddressId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_individual_address view.
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvIndividualAddressId.class)
@Table(name = "dv_individual_address", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvIndividualAddress {

    @Id
    @Column(name = "dcrm_indiv_addr_id")
    private Long dcrmIndivAddrId;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_nm")
    private String stateNm;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "zip4")
    private String zip4;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "ga_id")
    private Long gaId;

    @Column(name = "indiv_id")
    private Integer indivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;
}
