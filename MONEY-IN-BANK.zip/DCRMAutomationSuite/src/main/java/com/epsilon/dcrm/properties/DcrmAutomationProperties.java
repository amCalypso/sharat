package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("dcrm.automation.object")
public class DcrmAutomationProperties {
    private String cdsOrg;
    private String cdsSubOrg;
    private String cdsEventTableId;
    private String cdsProfileTableId;
    private String frmsClientCode;
    private String paxataTenantId;
    private String paxataServiceAccount;
    private String paxataServiceAccountPassword;
    private String s3AccessKeyId;
    private String s3SecretAccessKey;
    private String s3Region;
    private String s3BucketName;
    private String s3Path;
    private String dbJdbcUrl;
    private String dbUsername;
    private String dbPassword;
}
