package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionHeader standard feed
 * 
 * @author jblasingame
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionHeader implements Comparable<TransactionHeader> {
    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnTs;
    private String txnCompleteDt;
    private String txnChannelCd;
    private String mobileInd;
    private String clientellingInd;
    private String employeePurchInd;
    private String salesLocationCd; // represents location_cd in the table
    private String registerNbr;
    private String employeeId;
    private String txnSeqNbr;
    private String txnBusnDt;
    private String billAcctSrcCd;
    private String billAcctSrcNbr;
    private String loyaltyAcctSrcCd;
    private String loyaltyAcctNbr;
    private String loginId;
    private String ipAddr;
    private String srcKeycode;
    private String srcFirstNm;
    private String srcMiddleNm;
    private String srcLastNm;
    private String srcUnparsedNm;
    private String srcBusinessNm;
    private String srcAddrLine1;
    private String srcAddrLine2;
    private String srcAddrLine3;
    private String srcAddrLine4;
    private String srcCity;
    private String srcState;
    private String postalCd;
    private String srcCountry;
    private String srcCountryCd;
    private String emailAddr;
    private String phoneNbr;
    private String receiptDeliveryMethodCd;
    private String ereceiptEmailAddr;
    private String emailCaptureTypeCd;
    private String emailCaptureInd;
    private String txnTypeCd;
    private String txnSubtypeCd;
    private String relatedTxnNbr;
    private String relatedTxnTs;
    private String purchTxnAmt;
    private String purchTaxAmt;
    private String purchShipAmt;
    private String purchDiscountAmt;
    private String cancelTxnAmt;
    private String cancelTaxAmt;
    private String cancelShipAmt;
    private String cancelDiscountAmt;
    private String returnTxnAmt;
    private String returnTaxAmt;
    private String returnShipAmt;
    private String returnDiscountAmt;
    private String currencyCd;
    private String foreignInd;
    private String buyerTypeCd;
    private String txnVoidInd;
    private String txnStatusCd;
    private String txnRemarkTxt;
    private String itemPriceOverrideInd;
    private String shipPriceOverrideInd;
    private String returnReasonCd;
    private String activityTs;

    @Override
    public int compareTo(TransactionHeader o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnNbr())
                .toString();
        return o1Key.compareToIgnoreCase(o2Key);
    }
}
