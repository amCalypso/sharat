package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the ref_cust_lifecycle standard feed
 * 
 * @author Mohan
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefCustLifeCycle implements Comparable<RefCustLifeCycle> {
    private String custLifeCycleCd;
    private String custLifeCycleNm;
    private String custLifeCycleDsc;

    @Override
    public int compareTo(RefCustLifeCycle arg) {
        return custLifeCycleCd.compareTo(arg.getCustLifeCycleCd());
    }
}