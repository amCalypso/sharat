package com.epsilon.dcrm.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.epsilon.dcrm.model.dimension.DimensionEmailAddress;
import com.epsilon.dcrm.model.dimension.DimensionEmployee;
import com.epsilon.dcrm.model.dimension.DimensionPhone;
import com.epsilon.dcrm.model.dimension.DimensionProfile;
import com.epsilon.dcrm.model.dimension.DimensionProfileEmail;
import com.epsilon.dcrm.model.dimension.DimensionProfilePhone;
import com.epsilon.dcrm.model.dimension.DimensionProfileSocial;
import com.epsilon.dcrm.model.dimension.DimensionRefFrequency;
import com.epsilon.dcrm.model.dimension.DimensionRefMonetary;
import com.epsilon.dcrm.model.dimension.DimensionRefRecency;
import com.epsilon.dcrm.model.dimension.DimensionSocialAccount;
import com.epsilon.dcrm.model.dimension.DimensionTransactionAdjustment;
import com.epsilon.dcrm.model.dimension.DimensionTransactionCertificate;
import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;
import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.dimension.DimensionTransactionTender;
import com.epsilon.dcrm.model.mart.MRefFrequency;
import com.epsilon.dcrm.model.mart.MRefMonetary;
import com.epsilon.dcrm.model.mart.MRefRecency;
import com.epsilon.dcrm.model.standard.StandardEmployee;
import com.epsilon.dcrm.model.standard.StandardProfile;
import com.epsilon.dcrm.model.standard.StandardProfileAddressChange;
import com.epsilon.dcrm.model.standard.StandardRefFrequency;
import com.epsilon.dcrm.model.standard.StandardRefMonetary;
import com.epsilon.dcrm.model.standard.StandardRefRecency;
import com.epsilon.dcrm.model.standard.StandardTransactionAdjustment;
import com.epsilon.dcrm.model.standard.StandardTransactionCertificate;
import com.epsilon.dcrm.model.standard.StandardTransactionHeader;
import com.epsilon.dcrm.model.standard.StandardTransactionItem;
import com.epsilon.dcrm.model.standard.StandardTransactionTender;
import com.epsilon.dcrm.objects.comparer.DimensionCPCOAProfileComparer;
import com.epsilon.dcrm.objects.comparer.DimensionEmailAddressComparer;
import com.epsilon.dcrm.objects.comparer.DimensionEmployeeComparer;
import com.epsilon.dcrm.objects.comparer.DimensionPhoneComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileEmailComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfilePhoneComparer;
import com.epsilon.dcrm.objects.comparer.DimensionProfileSocialComparer;
import com.epsilon.dcrm.objects.comparer.DimensionSocialAccountComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionAdjustmentComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionCertificateComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionHeaderComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionItemComparer;
import com.epsilon.dcrm.objects.comparer.DimensionTransactionTenderComparer;
import com.epsilon.dcrm.objects.comparer.EmployeeToProfilePartialComparer;
import com.epsilon.dcrm.objects.comparer.PartialProfileComparer;
import com.epsilon.dcrm.objects.comparer.StandardCPCOAProfileComparer;
import com.epsilon.dcrm.objects.csv.Employee;
import com.epsilon.dcrm.objects.csv.Profile;
import com.epsilon.dcrm.objects.csv.ProfileAddressChange;
import com.epsilon.dcrm.objects.csv.RefCustLifeCycle;
import com.epsilon.dcrm.objects.csv.RefFrequency;
import com.epsilon.dcrm.objects.csv.RefMonetary;
import com.epsilon.dcrm.objects.csv.RefPurchaseChannel;
import com.epsilon.dcrm.objects.csv.RefRecency;
import com.epsilon.dcrm.objects.csv.TransactionAdjustment;
import com.epsilon.dcrm.objects.csv.TransactionCertificate;
import com.epsilon.dcrm.objects.csv.TransactionHeader;
import com.epsilon.dcrm.objects.csv.TransactionItem;
import com.epsilon.dcrm.objects.csv.TransactionTender;

public class CopyUtil {

    private static final String dateFormat = "yyyy-MM-dd";
    private static final String timestampFormat = "yyyy-MM-dd HH:mm:ss";

    public static List<TransactionItem> convertStandardTransactionItem(List<StandardTransactionItem> dbRecords) {
        List<TransactionItem> convertedDbRecords = new ArrayList<>();

        for (StandardTransactionItem dbRecord : dbRecords) {
            TransactionItem rec = new TransactionItem();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setCogsAmt(FormatUtil.convertToString(dbRecord.getCogsAmt()));
            rec.setExchangeRt(FormatUtil.convertToString(dbRecord.getExchangeRt()));
            rec.setExtDiscAmt(FormatUtil.convertToString(dbRecord.getExtDiscAmt()));
            rec.setExtItemAmt(FormatUtil.convertToString(dbRecord.getExtItemAmt()));
            rec.setExtOfferAmt(FormatUtil.convertToString(dbRecord.getExtOfferAmt()));
            rec.setExtShipAmt(FormatUtil.convertToString(dbRecord.getExtShipAmt()));
            rec.setExtTaxAmt(FormatUtil.convertToString(dbRecord.getExtTaxAmt()));
            rec.setListPriceAmt(FormatUtil.convertToString(dbRecord.getListPriceAmt()));
            rec.setOfferPriceAmt(FormatUtil.convertToString(dbRecord.getOfferPriceAmt()));
            rec.setSoldPriceAmt(FormatUtil.convertToString(dbRecord.getSoldPriceAmt()));
            rec.setSurchargeAmt(FormatUtil.convertToString(dbRecord.getSurchargeAmt()));
            rec.setTaxRt(FormatUtil.convertToString(dbRecord.getTaxRt()));

            rec.setQty(FormatUtil.convertToString(dbRecord.getQty()));
            rec.setUom(FormatUtil.convertToString(dbRecord.getUom()));
            rec.setShipQty(FormatUtil.convertToString(dbRecord.getShipQty()));
            rec.setShipUom(FormatUtil.convertToString(dbRecord.getShipUom()));

            rec.setBackorderQty(FormatUtil.convertToString(dbRecord.getBackorderQty()));
            rec.setFulfillGroupNbr(FormatUtil.convertToString(dbRecord.getFulfillGroupNbr()));

            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));
            rec.setBackorderDt(FormatUtil.convertDate(dbRecord.getBackorderDt(), dateFormat));
            rec.setBackorderActualFulfillDt(FormatUtil.convertDate(dbRecord.getBackorderActualFulfillDt(), dateFormat));
            rec.setBackorderExpectedFulfillDt(FormatUtil.convertDate(dbRecord.getBackorderExpectedFulfillDt(), dateFormat));
            rec.setCancelDt(FormatUtil.convertDate(dbRecord.getCancelDt(), dateFormat));
            rec.setFirstShipDt(FormatUtil.convertDate(dbRecord.getFirstShipDt(), dateFormat));
            rec.setLastShipDt(FormatUtil.convertDate(dbRecord.getLastShipDt(), dateFormat));
            rec.setReturnDt(FormatUtil.convertDate(dbRecord.getReturnDt(), dateFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionTransactionItemComparer> convertDimensionTransactionItem(List<DimensionTransactionItem> dbRecords) {
        List<DimensionTransactionItemComparer> convertedDbRecords = new ArrayList<DimensionTransactionItemComparer>();

        for (DimensionTransactionItem dbRecord : dbRecords) {
            DimensionTransactionItemComparer rec = new DimensionTransactionItemComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setCogsAmt(FormatUtil.convertToString(dbRecord.getCogsAmt()));
            rec.setExchangeRt(FormatUtil.convertToString(dbRecord.getExchangeRt()));
            rec.setExtDiscAmt(FormatUtil.convertToString(dbRecord.getExtDiscAmt()));
            rec.setExtItemAmt(FormatUtil.convertToString(dbRecord.getExtItemAmt()));
            rec.setExtOfferAmt(FormatUtil.convertToString(dbRecord.getExtOfferAmt()));
            rec.setExtShipAmt(FormatUtil.convertToString(dbRecord.getExtShipAmt()));
            rec.setExtTaxAmt(FormatUtil.convertToString(dbRecord.getExtTaxAmt()));
            rec.setListPriceAmt(FormatUtil.convertToString(dbRecord.getListPriceAmt()));
            rec.setOfferPriceAmt(FormatUtil.convertToString(dbRecord.getOfferPriceAmt()));
            rec.setSoldPriceAmt(FormatUtil.convertToString(dbRecord.getSoldPriceAmt()));
            rec.setSurchargeAmt(FormatUtil.convertToString(dbRecord.getSurchargeAmt()));
            rec.setTaxRt(FormatUtil.convertToString(dbRecord.getTaxRt()));

            rec.setQty(FormatUtil.convertToString(dbRecord.getQty()));
            rec.setUom(FormatUtil.convertToString(dbRecord.getUom()));
            rec.setShipQty(FormatUtil.convertToString(dbRecord.getShipQty()));
            rec.setShipUom(FormatUtil.convertToString(dbRecord.getShipUom()));

            rec.setBackorderQty(FormatUtil.convertToString(dbRecord.getBackorderQty()));
            rec.setFulfillGroupNbr(FormatUtil.convertToString(dbRecord.getFulfillGroupNbr()));

            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setBackorderDt(FormatUtil.convertDate(dbRecord.getBackorderDt(), dateFormat));
            rec.setBackorderActualFulfillDt(FormatUtil.convertDate(dbRecord.getBackorderActualFulfillDt(), dateFormat));
            rec.setBackorderExpectedFulfillDt(FormatUtil.convertDate(dbRecord.getBackorderExpectedFulfillDt(), dateFormat));
            rec.setCancelDt(FormatUtil.convertDate(dbRecord.getCancelDt(), dateFormat));
            rec.setFirstShipDt(FormatUtil.convertDate(dbRecord.getFirstShipDt(), dateFormat));
            rec.setLastShipDt(FormatUtil.convertDate(dbRecord.getLastShipDt(), dateFormat));
            rec.setReturnDt(FormatUtil.convertDate(dbRecord.getReturnDt(), dateFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<TransactionTender> convertStandardTransactionTender(List<StandardTransactionTender> dbRecords) {
        List<TransactionTender> convertedDbRecords = new ArrayList<>();

        for (StandardTransactionTender dbRecord : dbRecords) {
            TransactionTender rec = new TransactionTender();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setTenderAmt(FormatUtil.convertToString(dbRecord.getTenderAmt()));
            rec.setTenderDt(FormatUtil.convertDate(dbRecord.getTenderDt(), dateFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));
            rec.setActivityDt(FormatUtil.convertDate(dbRecord.getActivityDt(), timestampFormat));
            rec.setTenderSeqNbr(FormatUtil.convertToString(dbRecord.getTenderSeqNbr()));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<ProfileAddressChange> convertStandardProfileAddressChange(List<StandardProfileAddressChange> dbRecords) {
        List<ProfileAddressChange> convertedDbRecords = new ArrayList<>();

        for (StandardProfileAddressChange dbRecord : dbRecords) {
            ProfileAddressChange rec = new ProfileAddressChange();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setChangeSubmitDt(FormatUtil.convertDate(dbRecord.getChangeSubmitDt(), dateFormat));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionTransactionTenderComparer> convertDimensionTransactionTender(List<DimensionTransactionTender> dbRecords) {
        List<DimensionTransactionTenderComparer> convertedDbRecords = new ArrayList<>();

        for (DimensionTransactionTender dbRecord : dbRecords) {
            DimensionTransactionTenderComparer rec = new DimensionTransactionTenderComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setTenderAmt(FormatUtil.convertToString(dbRecord.getTenderAmt()));
            rec.setTenderDt(FormatUtil.convertDate(dbRecord.getTenderDt(), dateFormat));
            rec.setActivityDt(FormatUtil.convertDate(dbRecord.getActivityDt(), timestampFormat));
            rec.setTenderSeqNbr(FormatUtil.convertToString(dbRecord.getTenderSeqNbr()));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<TransactionCertificate> convertStandardTransactionCertificate(List<StandardTransactionCertificate> dbRecords) {
        List<TransactionCertificate> convertedDbRecords = new ArrayList<>();

        for (StandardTransactionCertificate dbRecord : dbRecords) {
            TransactionCertificate rec = new TransactionCertificate();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setCertStatusCd(dbRecord.getStatus());
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionTransactionCertificateComparer> convertDimensionTransactionCertificate(List<DimensionTransactionCertificate> dbRecords) {
        List<DimensionTransactionCertificateComparer> convertedDbRecords = new ArrayList<DimensionTransactionCertificateComparer>();

        for (DimensionTransactionCertificate dbRecord : dbRecords) {
            DimensionTransactionCertificateComparer rec = new DimensionTransactionCertificateComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<TransactionAdjustment> convertStandardTransactionAdjustment(List<StandardTransactionAdjustment> dbRecords) {
        List<TransactionAdjustment> convertedDbRecords = new ArrayList<>();

        for (StandardTransactionAdjustment dbRecord : dbRecords) {
            TransactionAdjustment rec = new TransactionAdjustment();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setAdjustSeqNbr(FormatUtil.convertToString(dbRecord.getAdjustSeqNbr()));
            rec.setTxnDt(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));
            rec.setAdjustDt(FormatUtil.convertDate(dbRecord.getAdjustDt(), dateFormat));
            rec.setAdjustAmt(FormatUtil.convertToString(dbRecord.getAdjustAmt()));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }
        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionTransactionAdjustmentComparer> convertDimensionTransactionAdjustment(List<DimensionTransactionAdjustment> dbRecords) {
        List<DimensionTransactionAdjustmentComparer> convertedDbRecords = new ArrayList<DimensionTransactionAdjustmentComparer>();

        for (DimensionTransactionAdjustment dbRecord : dbRecords) {
            DimensionTransactionAdjustmentComparer rec = new DimensionTransactionAdjustmentComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setAdjustSeqNbr(FormatUtil.convertToString(dbRecord.getAdjustSeqNbr()));
            rec.setAdjustDt(FormatUtil.convertDate(dbRecord.getAdjustDt(), dateFormat));
            rec.setAdjustAmt(FormatUtil.convertToString(dbRecord.getAdjustAmt()));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<TransactionHeader> convertStandardTransactionHeader(List<StandardTransactionHeader> dbRecords) {
        List<TransactionHeader> convertedDbRecords = new ArrayList<>();

        for (StandardTransactionHeader dbRecord : dbRecords) {
            TransactionHeader rec = new TransactionHeader();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));

            rec.setRelatedTxnTs(FormatUtil.convertDate(dbRecord.getRelatedTxnTs(), dateFormat));
            rec.setTxnCompleteDt(FormatUtil.convertDate(dbRecord.getTxnCompleteDt(), dateFormat));
            rec.setTxnBusnDt(FormatUtil.convertDate(dbRecord.getTxnBusnDt(), dateFormat));

            rec.setCancelDiscountAmt(FormatUtil.convertToString(dbRecord.getCancelDiscountAmt()));
            rec.setCancelShipAmt(FormatUtil.convertToString(dbRecord.getCancelShipAmt()));
            rec.setCancelTaxAmt(FormatUtil.convertToString(dbRecord.getCancelTaxAmt()));
            rec.setCancelTxnAmt(FormatUtil.convertToString(dbRecord.getCancelTxnAmt()));
            rec.setCancelShipAmt(FormatUtil.convertToString(dbRecord.getCancelShipAmt()));
            rec.setPurchDiscountAmt(FormatUtil.convertToString(dbRecord.getPurchDiscountAmt()));
            rec.setPurchShipAmt(FormatUtil.convertToString(dbRecord.getPurchShipAmt()));
            rec.setPurchTaxAmt(FormatUtil.convertToString(dbRecord.getPurchTaxAmt()));
            rec.setPurchTxnAmt(FormatUtil.convertToString(dbRecord.getPurchTxnAmt()));
            rec.setReturnDiscountAmt(FormatUtil.convertToString(dbRecord.getReturnDiscountAmt()));
            rec.setReturnShipAmt(FormatUtil.convertToString(dbRecord.getReturnShipAmt()));
            rec.setReturnTaxAmt(FormatUtil.convertToString(dbRecord.getReturnTaxAmt()));
            rec.setReturnTxnAmt(FormatUtil.convertToString(dbRecord.getReturnTxnAmt()));
            rec.setClientellingInd(FormatUtil.convertToString(dbRecord.getClientellingInd()));
            rec.setEmailCaptureInd(FormatUtil.convertToString(dbRecord.getEmailCaptureInd()));
            rec.setEmployeePurchInd(FormatUtil.convertToString(dbRecord.getEmployeePurchInd()));
            rec.setForeignInd(FormatUtil.convertToString(dbRecord.getForeignInd()));
            rec.setItemPriceOverrideInd(FormatUtil.convertToString(dbRecord.getItemPriceOverrideInd()));
            rec.setMobileInd(FormatUtil.convertToString(dbRecord.getMobileInd()));
            rec.setRegisterNbr(FormatUtil.convertToString(dbRecord.getRegisterNbr()));
            rec.setShipPriceOverrideInd(FormatUtil.convertToString(dbRecord.getShipPriceOverrideInd()));
            rec.setTxnVoidInd(FormatUtil.convertToString(dbRecord.getTxnVoidInd()));
            rec.setTxnSeqNbr(FormatUtil.convertToString(dbRecord.getTxnSeqNbr()));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionTransactionHeaderComparer> convertDimensionTransactionHeader(List<DimensionTransactionHeader> dbRecords) {
        List<DimensionTransactionHeaderComparer> convertedDbRecords = new ArrayList<>();

        for (DimensionTransactionHeader dbRecord : dbRecords) {
            DimensionTransactionHeaderComparer rec = new DimensionTransactionHeaderComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setTxnTs(FormatUtil.convertDate(dbRecord.getTxnTs(), timestampFormat));

            rec.setTxnBusnDt(FormatUtil.convertDate(dbRecord.getTxnBusnDt(), dateFormat));
            rec.setTxnCompleteDt(FormatUtil.convertDate(dbRecord.getTxnCompleteDt(), dateFormat));
            rec.setRelatedTxnTs(FormatUtil.convertDate(dbRecord.getRelatedTxnTs(), dateFormat));

            rec.setCancelDiscountAmt(FormatUtil.convertToString(dbRecord.getCancelDiscountAmt()));
            rec.setCancelShipAmt(FormatUtil.convertToString(dbRecord.getCancelShipAmt()));
            rec.setCancelTaxAmt(FormatUtil.convertToString(dbRecord.getCancelTaxAmt()));
            rec.setCancelTxnAmt(FormatUtil.convertToString(dbRecord.getCancelTxnAmt()));
            rec.setPurchDiscountAmt(FormatUtil.convertToString(dbRecord.getPurchDiscountAmt()));
            rec.setPurchShipAmt(FormatUtil.convertToString(dbRecord.getPurchShipAmt()));
            rec.setPurchTaxAmt(FormatUtil.convertToString(dbRecord.getPurchTaxAmt()));
            rec.setPurchTxnAmt(FormatUtil.convertToString(dbRecord.getPurchTxnAmt()));
            rec.setReturnDiscountAmt(FormatUtil.convertToString(dbRecord.getReturnDiscountAmt()));
            rec.setReturnShipAmt(FormatUtil.convertToString(dbRecord.getReturnShipAmt()));
            rec.setReturnTaxAmt(FormatUtil.convertToString(dbRecord.getReturnTaxAmt()));
            rec.setReturnTxnAmt(FormatUtil.convertToString(dbRecord.getReturnTxnAmt()));
            rec.setRegisterNbr(FormatUtil.convertToString(dbRecord.getRegisterNbr()));
            rec.setTxnSeqNbr(FormatUtil.convertToString(dbRecord.getTxnSeqNbr()));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<Profile> convertStandardProfile(List<StandardProfile> dbRecords) {
        List<Profile> convertedDbRecords = new ArrayList<>();

        for (StandardProfile dbRecord : dbRecords) {
            Profile rec = new Profile();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setBirthDay(FormatUtil.convertToString(dbRecord.getBirthDay()));
            rec.setBirthMth(FormatUtil.convertToString(dbRecord.getBirthMth()));
            rec.setBirthYr(FormatUtil.convertToString(dbRecord.getBirthYr()));
            rec.setRecStatusChangeDt(FormatUtil.convertDate(dbRecord.getRecStatusChangeDt(), dateFormat));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setRecSrcOrigTs(FormatUtil.convertDate(dbRecord.getRecSrcOrigTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }
        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<StandardCPCOAProfileComparer> convertStandardCPCOAProfile(List<StandardProfile> dbRecords) {

        List<StandardCPCOAProfileComparer> convertedStandardProfileDbRecords = new ArrayList<StandardCPCOAProfileComparer>();

        for (StandardProfile record : dbRecords) {
            StandardCPCOAProfileComparer rec = new StandardCPCOAProfileComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setActivityTs(FormatUtil.convertDate(record.getActivityTs(), timestampFormat));
            convertedStandardProfileDbRecords.add(rec);
        }
        Collections.sort(convertedStandardProfileDbRecords);
        return convertedStandardProfileDbRecords;
    }

    public static List<StandardCPCOAProfileComparer> convertCPCOAProfileCvs(List<ProfileAddressChange> csvRecords) throws ParseException {

        List<StandardCPCOAProfileComparer> convertedPartialProfileCsvRecords = new ArrayList<StandardCPCOAProfileComparer>();

        for (ProfileAddressChange record : csvRecords) {
            StandardCPCOAProfileComparer recOld = new StandardCPCOAProfileComparer();
            StandardCPCOAProfileComparer recNew = new StandardCPCOAProfileComparer();
            BeanUtils.copyProperties(record, recOld);

            recOld.setUnparsedNm(record.getOrigUnparsedNm());
            recOld.setFirstNm(record.getOrigFirstNm());
            recOld.setMiddleNm(record.getOrigMiddleNm());
            recOld.setLastNm(record.getOrigLastNm());
            recOld.setAddrLine1(record.getOrigAddrLine1());
            recOld.setAddrLine2(record.getOrigAddrLine2());
            recOld.setAddrLine3(record.getOrigAddrLine3());
            recOld.setAddrLine4(record.getOrigAddrLine4());
            recOld.setCityNm(record.getOrigCityNm());
            recOld.setStateCd(record.getOrigStateCd());
            recOld.setCountryNm(record.getOrigCountry());
            recOld.setCountryCd(record.getOrigIsoCountryCd());
            recOld.setPostalCd(record.getOrigPostalCd());
            recOld.setActivityTs(FormatUtil.convertDate(FormatUtil.getTimestampFromString(record.getChangeSubmitDt(), dateFormat), timestampFormat));
            convertedPartialProfileCsvRecords.add(recOld);

            BeanUtils.copyProperties(record, recNew);
            recNew.setUnparsedNm(record.getNewUnparsedNm());
            recNew.setFirstNm(record.getNewFirstNm());
            recNew.setMiddleNm(record.getNewMiddleNm());
            recNew.setLastNm(record.getNewLastNm());
            recNew.setAddrLine1(record.getNewAddrLine1());
            recNew.setAddrLine2(record.getNewAddrLine2());
            recNew.setAddrLine3(record.getNewAddrLine3());
            recNew.setAddrLine4(record.getNewAddrLine4());
            recNew.setCityNm(record.getNewCityNm());
            recNew.setStateCd(record.getNewStateCd());
            recNew.setCountryNm(record.getNewCountry());
            recNew.setCountryCd(record.getNewIsoCountryCd());
            recNew.setPostalCd(record.getNewPostalCd());

            Timestamp oldChangeSubmitDt = FormatUtil.getTimestampFromString(record.getChangeSubmitDt(), dateFormat);
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(oldChangeSubmitDt.getTime());
            cal.add(Calendar.SECOND, 1);
            Timestamp newChangeSubmitDt = new Timestamp(cal.getTime().getTime());

            recNew.setActivityTs(FormatUtil.convertDate(newChangeSubmitDt, timestampFormat));

            convertedPartialProfileCsvRecords.add(recNew);

        }
        Collections.sort(convertedPartialProfileCsvRecords);
        return convertedPartialProfileCsvRecords;
    }

    public static List<DimensionCPCOAProfileComparer> convertDimensionCPCOAProfile(List<DimensionProfile> dbRecords) {
        List<DimensionCPCOAProfileComparer> convertedDbRecords = new ArrayList<DimensionCPCOAProfileComparer>();

        for (DimensionProfile dbRecord : dbRecords) {
            DimensionCPCOAProfileComparer rec = new DimensionCPCOAProfileComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionCPCOAProfileComparer> convertCPCOADimProfileCvs(List<ProfileAddressChange> csvRecords) throws ParseException {

        List<DimensionCPCOAProfileComparer> convertedPartialProfileCsvRecords = new ArrayList<DimensionCPCOAProfileComparer>();

        for (ProfileAddressChange record : csvRecords) {
            DimensionCPCOAProfileComparer rec = new DimensionCPCOAProfileComparer();

            BeanUtils.copyProperties(record, rec);

            rec.setUnparsedNm(record.getNewUnparsedNm());
            rec.setFirstNm(record.getNewFirstNm());
            rec.setMiddleNm(record.getNewMiddleNm());
            rec.setLastNm(record.getNewLastNm());
            rec.setAddrLine1(record.getNewAddrLine1());
            rec.setAddrLine2(record.getNewAddrLine2());
            rec.setAddrLine3(record.getNewAddrLine3());
            rec.setAddrLine4(record.getNewAddrLine4());
            rec.setCityNm(record.getNewCityNm());
            rec.setStateCd(record.getNewStateCd());
            rec.setCountryNm(record.getNewCountry());
            rec.setCountryCd(record.getNewIsoCountryCd());
            rec.setPostalCd(record.getNewPostalCd());

            Timestamp oldChangeSubmitDt = FormatUtil.getTimestampFromString(record.getChangeSubmitDt(), dateFormat);
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(oldChangeSubmitDt.getTime());
            cal.add(Calendar.SECOND, 1);
            Timestamp newChangeSubmitDt = new Timestamp(cal.getTime().getTime());

            rec.setActivityTs(FormatUtil.convertDate(newChangeSubmitDt, timestampFormat));

            convertedPartialProfileCsvRecords.add(rec);

        }
        Collections.sort(convertedPartialProfileCsvRecords);
        return convertedPartialProfileCsvRecords;
    }

    public static List<DimensionProfileComparer> convertDimensionProfile(List<DimensionProfile> dbRecords) {
        List<DimensionProfileComparer> convertedDbRecords = new ArrayList<DimensionProfileComparer>();

        for (DimensionProfile dbRecord : dbRecords) {
            DimensionProfileComparer rec = new DimensionProfileComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            rec.setBirthDt(FormatUtil.convertToString(dbRecord.getBirthDt()));
            rec.setBirthDay(FormatUtil.convertToString(dbRecord.getBirthDay()));
            rec.setBirthMth(FormatUtil.convertToString(dbRecord.getBirthMth()));
            rec.setBirthYr(FormatUtil.convertToString(dbRecord.getBirthYr()));
            rec.setRecStatusChangeDt(FormatUtil.convertDate(dbRecord.getRecStatusChangeDt(), dateFormat));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            rec.setRecSrcOrigTs(FormatUtil.convertDate(dbRecord.getRecSrcOrigTs(), timestampFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<PartialProfileComparer> partialConvertDProfile(List<DimensionProfile> dbRecords) {
        List<PartialProfileComparer> convertedDbRecords = new ArrayList<PartialProfileComparer>();

        for (DimensionProfile dbRecord : dbRecords) {
            PartialProfileComparer rec = new PartialProfileComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }
        return convertedDbRecords;

    }

    public static List<PartialProfileComparer> partialConvertSProfile(List<StandardProfile> dbRecords) {
        List<PartialProfileComparer> convertedDbRecords = new ArrayList<PartialProfileComparer>();

        for (StandardProfile dbRecord : dbRecords) {
            PartialProfileComparer rec = new PartialProfileComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }
        return convertedDbRecords;

    }

    public static List<DimensionSocialAccountComparer> convertDimensionSocialAccount(List<DimensionSocialAccount> dbRecords) {
        List<DimensionSocialAccountComparer> convertedDbRecords = new ArrayList<DimensionSocialAccountComparer>();

        for (DimensionSocialAccount dbRecord : dbRecords) {
            DimensionSocialAccountComparer rec = new DimensionSocialAccountComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionProfileSocialComparer> convertDimensionProfileSocial(List<DimensionProfileSocial> dbRecords) {
        List<DimensionProfileSocialComparer> convertedDbRecords = new ArrayList<DimensionProfileSocialComparer>();

        for (DimensionProfileSocial dbRecord : dbRecords) {
            DimensionProfileSocialComparer rec = new DimensionProfileSocialComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setDcrmSocialAcctId(FormatUtil.convertToString(dbRecord.getDcrmSocialAcctId()));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionEmailAddressComparer> convertDimensionEmailAddress(List<DimensionEmailAddress> dbRecords) {
        List<DimensionEmailAddressComparer> convertedDbRecords = new ArrayList<DimensionEmailAddressComparer>();

        for (DimensionEmailAddress dbRecord : dbRecords) {
            DimensionEmailAddressComparer rec = new DimensionEmailAddressComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionProfileEmailComparer> convertDimensionProfileEmail(List<DimensionProfileEmail> dbRecords) {
        List<DimensionProfileEmailComparer> convertedDbRecords = new ArrayList<DimensionProfileEmailComparer>();

        for (DimensionProfileEmail dbRecord : dbRecords) {
            DimensionProfileEmailComparer rec = new DimensionProfileEmailComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setDcrmEmailAddrId(FormatUtil.convertToString(dbRecord.getDcrmEmailAddrId()));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionPhoneComparer> convertDimensionPhone(List<DimensionPhone> dbRecords) {
        List<DimensionPhoneComparer> convertedDbRecords = new ArrayList<DimensionPhoneComparer>();

        for (DimensionPhone dbRecord : dbRecords) {
            DimensionPhoneComparer rec = new DimensionPhoneComparer();
            BeanUtils.copyProperties(dbRecord, rec);

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionProfilePhoneComparer> convertDimensionProfilePhone(List<DimensionProfilePhone> dbRecords) {
        List<DimensionProfilePhoneComparer> convertedDbRecords = new ArrayList<DimensionProfilePhoneComparer>();

        for (DimensionProfilePhone dbRecord : dbRecords) {
            DimensionProfilePhoneComparer rec = new DimensionProfilePhoneComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setDcrmPhoneId(FormatUtil.convertToString(dbRecord.getDcrmPhoneId()));
            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<Employee> convertStandardEmployee(List<StandardEmployee> dbRecords) {
        List<Employee> convertedDbRecords = new ArrayList<>();

        for (StandardEmployee dbRecord : dbRecords) {
            Employee rec = new Employee();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setEmploymentStartDt(FormatUtil.convertDate(dbRecord.getEmploymentStartDt(), dateFormat));
            rec.setEmploymentEndDt(FormatUtil.convertDate(dbRecord.getEmploymentEndDt(), dateFormat));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));
            convertedDbRecords.add(rec);
        }
        Collections.sort(convertedDbRecords);
        return convertedDbRecords;
    }

    public static List<DimensionEmployeeComparer> convertDimensionEmployee(List<DimensionEmployee> dbRecords) {
        List<DimensionEmployeeComparer> convertedDbRecords = new ArrayList<DimensionEmployeeComparer>();

        for (DimensionEmployee dbRecord : dbRecords) {
            DimensionEmployeeComparer rec = new DimensionEmployeeComparer();
            BeanUtils.copyProperties(dbRecord, rec);
            rec.setEmploymentStartDt(FormatUtil.convertDate(dbRecord.getEmploymentStartDt(), dateFormat));
            rec.setEmploymentEndDt(FormatUtil.convertDate(dbRecord.getEmploymentEndDt(), dateFormat));
            rec.setActivityTs(FormatUtil.convertDate(dbRecord.getActivityTs(), timestampFormat));

            convertedDbRecords.add(rec);
        }

        Collections.sort(convertedDbRecords);

        return convertedDbRecords;
    }

    public static List<EmployeeToProfilePartialComparer> convertSEmployeeToEmployeePartialProfile(List<StandardEmployee> SEmployeeRecords) {
        List<EmployeeToProfilePartialComparer> convertedSEmployeeRecords = new ArrayList<EmployeeToProfilePartialComparer>();

        for (StandardEmployee record : SEmployeeRecords) {
            EmployeeToProfilePartialComparer rec = new EmployeeToProfilePartialComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setAcctSrcNbr(record.getEmployeeId());
            rec.setGenderCd(record.getSrcGenderCd());
            rec.setNamePrefix(record.getSrcNamePrefix());
            rec.setFirstNm(record.getSrcFirstNm());
            rec.setMiddleNm(record.getSrcMiddleNm());
            rec.setLastNm(record.getSrcLastNm());
            rec.setNameSuffix(record.getSrcNameSuffix());
            rec.setUnparsedNm(record.getSrcUnparsedNm());
            rec.setAddrLine1(record.getHomeAddrLine1());
            rec.setAddrLine2(record.getHomeAddrLine2());
            rec.setAddrLine3(record.getHomeAddrLine3());
            rec.setAddrLine4(record.getHomeAddrLine4());
            rec.setCityNm(record.getHomeCityNm());
            rec.setStateCd(record.getHomeStateCd());
            rec.setPostalCd(record.getHomePostalCd());
            rec.setCountryCd(record.getHomeCountryCd());
            rec.setCountryNm(record.getHomeCountryNm());
            rec.setActivityTs(FormatUtil.convertDate(record.getActivityTs(), timestampFormat));
            convertedSEmployeeRecords.add(rec);
        }

        Collections.sort(convertedSEmployeeRecords);

        return convertedSEmployeeRecords;
    }

    public static List<EmployeeToProfilePartialComparer> convertSProfileToEmployeePartialProfile(List<StandardProfile> sProfileRecords) {

        List<EmployeeToProfilePartialComparer> convertedSProfileRecords = new ArrayList<EmployeeToProfilePartialComparer>();

        for (StandardProfile record : sProfileRecords) {
            EmployeeToProfilePartialComparer rec = new EmployeeToProfilePartialComparer();
            BeanUtils.copyProperties(record, rec);
            rec.setActivityTs(FormatUtil.convertDate(record.getActivityTs(), timestampFormat));
            convertedSProfileRecords.add(rec);
        }
        Collections.sort(convertedSProfileRecords);

        return convertedSProfileRecords;
    }

    public static List<RefMonetary> convertRefMonetarySRecs(List<StandardRefMonetary> sRecs) {
        List<RefMonetary> convertedRecs = new ArrayList<RefMonetary>();

        for (StandardRefMonetary sRec : sRecs) {
            RefMonetary rec = new RefMonetary();
            BeanUtils.copyProperties(sRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(sRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(sRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefMonetary> convertRefMonetaryDRecs(List<DimensionRefMonetary> dRecs) {
        List<RefMonetary> convertedRecs = new ArrayList<RefMonetary>();

        for (DimensionRefMonetary dRec : dRecs) {
            RefMonetary rec = new RefMonetary();
            BeanUtils.copyProperties(dRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(dRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(dRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefMonetary> convertRefMonetaryMRecs(List<MRefMonetary> mRecs) {
        List<RefMonetary> convertedRecs = new ArrayList<RefMonetary>();

        for (MRefMonetary mRec : mRecs) {
            RefMonetary rec = new RefMonetary();
            BeanUtils.copyProperties(mRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(mRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(mRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefFrequency> convertRefFrequencySRecs(List<StandardRefFrequency> sRecs) {
        List<RefFrequency> convertedRecs = new ArrayList<RefFrequency>();

        for (StandardRefFrequency sRec : sRecs) {
            RefFrequency rec = new RefFrequency();
            BeanUtils.copyProperties(sRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(sRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(sRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefFrequency> convertRefFrequencyDRecs(List<DimensionRefFrequency> dRecs) {
        List<RefFrequency> convertedRecs = new ArrayList<RefFrequency>();

        for (DimensionRefFrequency dRec : dRecs) {
            RefFrequency rec = new RefFrequency();
            BeanUtils.copyProperties(dRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(dRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(dRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefFrequency> convertRefFrequencyMRecs(List<MRefFrequency> mRecs) {
        List<RefFrequency> convertedRecs = new ArrayList<RefFrequency>();

        for (MRefFrequency mRec : mRecs) {
            RefFrequency rec = new RefFrequency();
            BeanUtils.copyProperties(mRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(mRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(mRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static <T> List<RefPurchaseChannel> convertRefPurchaseChannelRecs(List<T> sRecs, Class<T> clazz) {
        List<RefPurchaseChannel> convertedRecs = new ArrayList<RefPurchaseChannel>();

        for (T sRec : sRecs) {
            RefPurchaseChannel rec = new RefPurchaseChannel();
            BeanUtils.copyProperties(sRec, rec);

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static <T> List<RefCustLifeCycle> convertRefCustLifeCycleRecs(List<T> sRecs, Class<T> clazz) {
        List<RefCustLifeCycle> convertedRecs = new ArrayList<RefCustLifeCycle>();

        for (T sRec : sRecs) {
            RefCustLifeCycle rec = new RefCustLifeCycle();
            BeanUtils.copyProperties(sRec, rec);

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefRecency> convertRefRecencySRecs(List<StandardRefRecency> sRecs) {
        List<RefRecency> convertedRecs = new ArrayList<RefRecency>();

        for (StandardRefRecency sRec : sRecs) {
            RefRecency rec = new RefRecency();
            BeanUtils.copyProperties(sRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(sRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(sRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefRecency> convertRefRecencyDRecs(List<DimensionRefRecency> dRecs) {
        List<RefRecency> convertedRecs = new ArrayList<RefRecency>();

        for (DimensionRefRecency dRec : dRecs) {
            RefRecency rec = new RefRecency();
            BeanUtils.copyProperties(dRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(dRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(dRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

    public static List<RefRecency> convertRefRecencyMRecs(List<MRefRecency> mRecs) {
        List<RefRecency> convertedRecs = new ArrayList<RefRecency>();

        for (MRefRecency mRec : mRecs) {
            RefRecency rec = new RefRecency();
            BeanUtils.copyProperties(mRec, rec);

            rec.setRangeMinVal(FormatUtil.convertToString(mRec.getRangeMinVal()));
            rec.setRangeMaxVal(FormatUtil.convertToString(mRec.getRangeMaxVal()));

            convertedRecs.add(rec);
        }
        Collections.sort(convertedRecs);
        return convertedRecs;
    }

}
