package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionProfileEmailComparer implements Comparable<DimensionProfileEmailComparer> {
    private String dcrmEmailAddrId;
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private String preferredInd;
    private String srcEmailAddr;

    @Override
    public int compareTo(DimensionProfileEmailComparer o) {
        String o1Key = new StringBuilder()
                .append(dcrmEmailAddrId)
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getDcrmEmailAddrId())
                .append(o.getBrandCd())
                .append(o.getAcctSrcCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
