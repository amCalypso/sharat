package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;

import lombok.Data;

@Data
public class DvIndividualSummaryComparer implements Comparable<DvIndividualSummaryComparer> {
    private Long indivId;
    private String brandCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String maritalStatusCd;
    private String genderCd;
    private Date birthDt;
    private String AddrLine1;
    private String AddrLine2;
    private String AddrLine3;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String zip4;
    private String countryCd;
    private String emailAddr;
    private String phoneNbr;

    @Override
    public int compareTo(DvIndividualSummaryComparer o) {
        String o1Key = new StringBuilder()
                .append(indivId)
                .append(brandCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getIndivId())
                .append(o.getBrandCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }

}
