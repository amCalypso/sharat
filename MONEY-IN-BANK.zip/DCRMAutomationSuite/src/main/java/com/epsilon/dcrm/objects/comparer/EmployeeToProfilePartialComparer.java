package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
/**
 * @author adomakonda
 */
public class EmployeeToProfilePartialComparer implements Comparable<EmployeeToProfilePartialComparer> {
    private String brandCd;
    private String acctSrcNbr;
    private String genderCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String unparsedNm;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String addrLine4;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String countryCd;
    private String countryNm;
    private String activityTs;

    @Override
    public int compareTo(EmployeeToProfilePartialComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
