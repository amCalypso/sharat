package com.epsilon.dcrm.objects;

import java.time.ZonedDateTime;

import com.epsilon.dcrm.type.FrmsExecutionStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FrmsWorkflowFilter {
    private String workflowId;
    private String jobId;
    private String clientName;
    private String workflowExecId;
    private FrmsExecutionStatus execStatus;
    private String folderName;
    private String workflowName;
    private ZonedDateTime startDate;
    private ZonedDateTime endDate;
    private String fileName;
}