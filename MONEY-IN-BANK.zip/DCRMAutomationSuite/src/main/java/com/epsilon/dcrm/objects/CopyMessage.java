package com.epsilon.dcrm.objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CopyMessage {
    private String jobName;
    private String status;
    private String startTime;
    private String endTime;
    private String lastCopyQueryId;
}
