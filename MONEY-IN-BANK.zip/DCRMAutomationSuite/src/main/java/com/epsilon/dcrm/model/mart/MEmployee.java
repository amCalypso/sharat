package com.epsilon.dcrm.model.mart;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.MEmployeeId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@IdClass(MEmployeeId.class)
@Table(name = "m_employee", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MEmployee {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "src_gender_cd")
    private String srcGenderCd;

    @Column(name = "src_name_prefix")
    private String srcNamePrefix;

    @Column(name = "src_first_nm")
    private String srcFirstNm;

    @Column(name = "src_middle_nm")
    private String srcMiddleNm;

    @Column(name = "src_last_nm")
    private String srcLastNm;

    @Column(name = "src_name_suffix")
    private String srcNameSuffix;

    @Column(name = "src_unparsed_nm")
    private String srcUnparsedNm;

    @Column(name = "home_addr_line_1")
    private String homeAddrLine1;

    @Column(name = "home_addr_line_2")
    private String homeAddrLine2;

    @Column(name = "home_addr_line_3")
    private String homeAddrLine3;

    @Column(name = "home_addr_line_4")
    private String homeAddrLine4;

    @Column(name = "home_city_nm")
    private String homeCityNm;

    @Column(name = "home_state_cd")
    private String homeStateCd;

    @Column(name = "home_postal_cd")
    private String homePostalCd;

    @Column(name = "home_country_cd")
    private String homeCountryCd;

    @Id
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employment_start_dt")
    private Date employmentStartDt;

    @Column(name = "employment_end_dt")
    private Date employmentEndDt;

    @Column(name = "employment_status_cd")
    private String employmentStatusCd;

    @Column(name = "role_nm")
    private String roleNm;

    @Column(name = "dcrm_employee_id")
    private Long dcrmEmployeeId;

    @Column(name = "assigned_dcrm_location1_id")
    private Long s1AssignedDcrmLocationId;

    @Column(name = "assigned_dcrm_location2_id")
    private Long s2AssignedDcrmLocationId;

    @Column(name = "assigned_dcrm_location3_id")
    private Long s3AssignedDcrmLocationId;

}
