package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionAdjustmentId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_transaction_Adjustment table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(TransactionAdjustmentId.class)
@Table(name = "s_transaction_adjustment", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardTransactionAdjustment {

    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "txn_line_nbr")
    private String txnLineNbr;

    @Id
    @Column(name = "adjust_seq_nbr")
    private Long adjustSeqNbr;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "adjust_dt")
    private Date adjustDt;

    @Column(name = "adjust_amt")
    private Double adjustAmt;

    @Column(name = "adjust_type_cd")
    private String adjustTypeCd;

    @Column(name = "adjust_subtype_cd")
    private String adjustSubtypeCd;

    @Column(name = "discount_cd")
    private String discountCd;

    @Column(name = "barcode")
    private String barcode;

    @Column(name = "ring_cd")
    private String ringCd;

    @Column(name = "coupon_cd")
    private String couponCd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;
}
