package com.epsilon.dcrm.spike.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SNSData {

    @JsonProperty("job_name")
    private String jobName;
    
    @JsonProperty("rows_inserted")
    private int rowsInserted;
    
    @JsonProperty("rows_updated")
    private int rowsUpdated;
    
    @JsonProperty("test_id")
    private String testId;
    
    @JsonProperty("start_time")
    private String startTime;
    
    @JsonProperty("end_time")
    private String endTime;
    
    private String duration;
}
