package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.AggMonetaryLast12Months;
import com.epsilon.dcrm.model.id.AggMonetaryId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface AggMonetaryLast12MonthsRepository extends BaseRepository<AggMonetaryLast12Months, AggMonetaryId> {
    List<AggMonetaryLast12Months> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);

    List<AggMonetaryLast12Months> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.agg_monetary_last_12_months"
            + "(indiv_id, brand_cd, m12_frequency_cnt, m12_gross_amt, m12_discount_amt, m12_return_amt, m12_cancel_amt)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7)", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String brandCd,
            Long m12FrequencyCnt, Double m12GrossAmt,
            Double m12DiscountAmt, Double m12ReturnAmt,
            Double m12CancelAmt);

}
