package com.epsilon.dcrm.util;

import java.io.File;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.type.ProcessErrorCode;

public class TestUtil {
    private static final Logger logger = LoggerFactory.getLogger(TestUtil.class);

    public static void deleteFile(String filePath) {
        File f = new File(filePath);
        if (f.exists()) {
            logger.info("File {} exists. Deleting ", filePath);
            logger.info("Deleted file flag : {} ", f.delete());
        }
    }

    public static String generateMd5Hashvalue(String... values) throws NoSuchAlgorithmException {
        if (null == values) {
            return null;
        }
        MessageDigest m = MessageDigest.getInstance("MD5");
        StringBuilder strToHashBuilder = new StringBuilder();

        for (String value : values) {
            strToHashBuilder.append(processForMD5Hash(value));
        }
        m.update(strToHashBuilder.toString().getBytes(), 0, strToHashBuilder.toString().length());
        String hashVal = new BigInteger(1, m.digest()).toString(16);

        logger.info("Hash value for the input string {}  is {}", strToHashBuilder.toString(), hashVal);
        return hashVal;
    }

    public static String processForMD5Hash(String value) {
        return (StringUtils.isBlank(value) ? "" : value.trim());
    }

    public static void sleep(int timeInMilliseconds) throws ApplicationException {
        try {
            Thread.sleep(timeInMilliseconds);
        } catch (InterruptedException e) {
            logger.error("Exception : {}", e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
    }
}
