package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the ID class for d_ref_monetary
 * @author dvelayudhannair
 *
 */
@Data
public class RefMonetaryId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String monetaryCd;
    private Long createFileId;
    private Long createRecNbr;
}
