package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfileAddressChangeId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_profile_address_change table.
 * @author gwalia
 *
 */
@Entity
@IdClass(ProfileAddressChangeId.class)
@Table(name = "s_profile_address_change", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardProfileAddressChange {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "acct_src_nbr")
    private String acctSrcNbr;

    @Column(name = "orig_unparsed_nm")
    private String origUnparsedNm;

    @Column(name = "orig_first_nm")
    private String origFirstNm;

    @Column(name = "orig_middle_nm")
    private String origMiddleNm;

    @Column(name = "orig_last_nm")
    private String origLastNm;

    @Column(name = "orig_addr_line_1")
    private String origAddrLine1;

    @Column(name = "orig_addr_line_2")
    private String origAddrLine2;

    @Column(name = "orig_addr_line_3")
    private String origAddrLine3;

    @Column(name = "orig_addr_line_4")
    private String origAddrLine4;

    @Column(name = "orig_city_nm")
    private String origCityNm;

    @Column(name = "orig_state_cd")
    private String origStateCd;

    @Column(name = "orig_postal_cd")
    private String origPostalCd;

    @Column(name = "orig_country")
    private String origCountry;

    @Column(name = "orig_iso_country_cd")
    private String origIsoCountryCd;

    @Column(name = "new_unparsed_nm")
    private String newUnparsedNm;

    @Column(name = "new_first_nm")
    private String newFirstNm;

    @Column(name = "new_middle_nm")
    private String newMiddleNm;

    @Column(name = "new_last_nm")
    private String newLastNm;

    @Column(name = "new_addr_line_1")
    private String newAddrLine1;

    @Column(name = "new_addr_line_2")
    private String newAddrLine2;

    @Column(name = "new_addr_line_3")
    private String newAddrLine3;

    @Column(name = "new_addr_line_4")
    private String newAddrLine4;

    @Column(name = "new_city_nm")
    private String newCityNm;

    @Column(name = "new_state_cd")
    private String newStateCd;

    @Column(name = "new_postal_cd")
    private String newPostalCd;

    @Column(name = "new_country")
    private String newCountry;

    @Column(name = "new_iso_country_cd")
    private String newIsoCountryCd;

    @Column(name = "change_submit_dt")
    private Date changeSubmitDt;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_file_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;
}
