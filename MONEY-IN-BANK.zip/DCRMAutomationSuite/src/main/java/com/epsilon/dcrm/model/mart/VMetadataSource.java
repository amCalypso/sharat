package com.epsilon.dcrm.model.mart;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This represents the source view used for all Metadata Aggregate requests.
 * @author jblasingame
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "v_metadata_source", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VMetadataSource implements Comparable<VMetadataSource> {

    @Column(name = "txn_yyyymm")
    private String txnMonth;

    @Id
    @Column(name = "row_id")
    private String rowId;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "purch_txn_amt")
    private Double purchTxnAmt;

    @Override
    public int compareTo(VMetadataSource o) {
        return rowId.compareTo(o.getRowId());
    }
}
