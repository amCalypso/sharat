package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "m_phone", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MPhone {

    @Id
    @Column(name = "dcrm_phone_id")
    private Long dcrmPhoneId;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "phone_nbr")
    private String phoneNbr;

    @Column(name = "valid_ind")
    private String validInd;

}
