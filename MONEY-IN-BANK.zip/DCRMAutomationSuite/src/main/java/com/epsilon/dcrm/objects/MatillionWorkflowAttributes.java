package com.epsilon.dcrm.objects;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MatillionWorkflowAttributes {

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("test_id")
    private String testId;

    @JsonProperty("start_time")
    private String startTime;

    @JsonProperty("end_time")
    private String endTime;

    private String duration;
    
    @JsonProperty("sub_jobs")
    private List<MatillionJobAttributes> subJobs;
}
