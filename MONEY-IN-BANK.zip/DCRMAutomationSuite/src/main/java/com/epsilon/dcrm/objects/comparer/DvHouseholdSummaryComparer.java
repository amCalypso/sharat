package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;

import lombok.Data;

@Data
public class DvHouseholdSummaryComparer implements Comparable<DvHouseholdSummaryComparer> {
    private Long hHoldId;
    private Long hohIndivId;
    private String brandCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String maritalStatusCd;
    private String genderCd;
    private Date birthDt;
    private String AddrLine1;
    private String AddrLine2;
    private String AddrLine3;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String zip4;
    private String countryCd;
    private String emailAddr;
    private String phoneNbr;

    @Override
    public int compareTo(DvHouseholdSummaryComparer o) {
        String o1Key = new StringBuilder()
                .append(hHoldId)
                .append(brandCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getHHoldId())
                .append(o.getBrandCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }

}
