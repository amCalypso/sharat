package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_individual_phone table.
 * @author adomakonda
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_individual_phone", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionIndividualPhone implements Comparable<DimensionIndividualPhone>{

    @Id
    @Column(name = "dcrm_indiv_phone_id")
    private Long dcrmIndivPhoneId;

    @Column(name = "indiv_id")
    private Long indivId;
    
    @Column(name = "brand_cd")
    private String brandCd;
    
    @Column(name = "phone_nbr")
    private String phoneNbr;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Override
    public int compareTo(DimensionIndividualPhone o) {
        return dcrmIndivPhoneId.compareTo(o.getDcrmIndivPhoneId());
    }
}
