package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionTransactionCertificate;
import com.epsilon.dcrm.model.id.TransactionCertificateId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DTransantionCertificateRepository extends DimensionRepository<DimensionTransactionCertificate, TransactionCertificateId> {
    Long deleteByTxnNbr(String txnNbr);
}
