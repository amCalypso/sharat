package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfileId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_profile table.
 * @author dvelayudhannair
 *
 */
@Entity
@IdClass(ProfileId.class)
@Table(name = "s_profile", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardProfile {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "acct_src_nbr")
    private String acctSrcNbr;

    @Column(name = "gender_cd")
    private String genderCd;

    @Column(name = "name_prefix")
    private String namePrefix;

    @Column(name = "first_nm")
    private String firstNm;

    @Column(name = "middle_nm")
    private String middleNm;

    @Column(name = "last_nm")
    private String lastNm;

    @Column(name = "name_suffix")
    private String nameSuffix;

    @Column(name = "unparsed_nm")
    private String unparsedNm;

    @Column(name = "busn_nm")
    private String busnNm;

    @Column(name = "title")
    private String title;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "addr_line_4")
    private String addrLine4;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "country_nm")
    private String countryNm;

    @Column(name = "birth_day")
    private Integer birthDay;

    @Column(name = "birth_mth")
    private Integer birthMth;

    @Column(name = "birth_yr")
    private Integer birthYr;

    @Column(name = "lang_cd")
    private String langCd;

    @Column(name = "marital_status_cd")
    private String maritalStatusCd;

    @Column(name = "preferred_channel_cd")
    private String preferredChannelCd;

    @Column(name = "do_not_promote_ind")
    private String doNotPromoteInd;

    @Column(name = "do_not_call_ind")
    private String doNotCallInd;

    @Column(name = "do_not_mail_ind")
    private String doNotMailInd;

    @Column(name = "do_not_sms_ind")
    private String doNotSmsInd;

    @Column(name = "do_not_email_ind")
    private String doNotEmailInd;

    @Column(name = "do_not_rent_ind")
    private String doNotRentInd;

    @Column(name = "hardkey_1")
    private String hardkey1;

    @Column(name = "hardkey_2")
    private String hardkey2;

    @Column(name = "hardkey_3")
    private String hardkey3;

    @Column(name = "hardkey_4")
    private String hardkey4;

    @Column(name = "hardkey_5")
    private String hardkey5;

    @Column(name = "hardkey_6")
    private String hardkey6;

    @Column(name = "hardkey_7")
    private String hardkey7;

    @Column(name = "hardkey_8")
    private String hardkey8;

    @Column(name = "hardkey_9")
    private String hardkey9;

    @Column(name = "hardkey_10")
    private String hardkey10;

    @Column(name = "email_addr_1")
    private String emailAddr1;

    @Column(name = "email_addr_2")
    private String emailAddr2;

    @Column(name = "home_phone_nbr")
    private String homePhoneNbr;

    @Column(name = "home_phone_country_cd")
    private String homePhoneCountryCd;

    @Column(name = "work_phone_nbr")
    private String workPhoneNbr;

    @Column(name = "work_phone_country_cd")
    private String workPhoneCountryCd;

    @Column(name = "cell_phone_nbr")
    private String cellPhoneNbr;

    @Column(name = "cell_phone_country_cd")
    private String cellPhoneCountryCd;

    @Column(name = "pager_phone_nbr")
    private String pagerPhoneNbr;

    @Column(name = "pager_phone_country_cd")
    private String pagerPhoneCountryCd;

    @Column(name = "fax_phone_nbr")
    private String faxPhoneNbr;

    @Column(name = "fax_phone_country_cd")
    private String faxPhoneCountryCd;

    @Column(name = "other_phone_nbr")
    private String otherPhoneNbr;

    @Column(name = "other_phone_country_cd")
    private String otherPhoneCountryCd;

    @Column(name = "social_media_1_nm")
    private String socialMedia1Nm;

    @Column(name = "social_media_acct_1_id")
    private String socialMediaAcct1Id;

    @Column(name = "social_media_2_nm")
    private String socialMedia2Nm;

    @Column(name = "social_media_acct_2_id")
    private String socialMediaAcct2Id;

    @Column(name = "rec_src_cd")
    private String recSrcCd;

    @Id
    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Column(name = "rec_status_cd")
    private String recStatusCd;

    @Column(name = "rec_status_change_dt")
    private Date recStatusChangeDt;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "rec_src_orig_ts")
    private Timestamp recSrcOrigTs;

}
