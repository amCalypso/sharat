package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProfileAddressStandard;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProfileAddressStandardRepository extends DimensionRepository<DimensionProfileAddressStandard, Long> {

    List<DimensionProfileAddressStandard> findByDcrmProfileId(Long dcrmProfileId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_profile_address_standard " +
            "(rec_process_dt, name_prefix, first_nm, middle_nm, last_nm, name_suffix, prof_suffix, gender_cd, busn_nm, profanity_ind, " +
            "fname_lname_match_ind, possible_busn_ind, lacs_ind, llk_new_addr_cd, llk_return_cd, ncoa_move_dt, ncoa_move_type_cd, " +
            "ncoa_link_footnote_cd, pcoa_move_dt, pac_action_cd, pac_footnote_cd, ga_id, hhold_id, indiv_id, busn_id, site_id, " +
            "addr_line_1, addr_line_2, city_nm, state_nm, postal_cd, zip4, dpbc_cd, checkdigit_ind, country_cd, carrier_route_nbr, " +
            "lot_nbr, lot_seq, ace_rec_type_cd, ace_remainder_txt, dpv_cmra_cd, dpv_footnote_cd, dpv_false_positive_ind, " +
            "dpv_no_stats_ind, dpv_status_cd, dpv_vacant_ind, foreign_addr_cd, match_5_ind, match_9_ind, unsuitable_match_ind, " +
            "zip_move_ind, zip_type_cd, congress_district_nbr, county_cd, county_nm, facility_type_cd, fips_cd, ace_error_cd, " +
            "ace_status_cd, geo_match_cd, latitude, longitude, fips_place_cd, ace_geo_blk, ace_ageo_mcd, ace_cgeo_cbsa, ace_cgeo_msa, " +
            "ace_ap_lacs_ind, dsf_busn_ind, dsf_drop_ind, dsf_throwback_ind, dsf_seasonal_ind, dsf_vacant_ind, dsf_delivery_type_cd, " +
            "dsf_curb_ind, dsf_ndcbu_ind, dsf_central_ind, dsf_door_slot_ind, dsf_drop_cnt, dsf_lacs_ind, dsf_nostat_ind, " +
            "dsf_educational_ind, dsf_rec_type_cd, mailability_cd, occupancy_cd, dwelling_type_cd, deceased_ind, can_do_not_mail_ind, " +
            "can_do_not_call_ind, can_do_not_fax_ind, prison_ind, nursing_home_ind, deceased_dob, deceased_dod, create_file_id, " +
            "create_rec_nbr, update_ts, update_file_id, update_rec_nbr, create_ts, addr_line_3, dcrm_profile_id) " +
            "VALUES('2018-01-07', 'MR', 'JOHN-28', 'dude', 'DOE-28', 'Jr', 'ab', 'U', 'JOHN-28 DOE-28', 'N', 'N', 'N', 'N', 'N', " +
            "'cd', NULL, 'a', 'bc', NULL, 'jk', 'xy', '27364872346873', '2000000009772', 1000000008222, '3000000106572'," +
            "'4000000106572', 'DR SUITE 100 - 1506051773532 - 28', 'SUITE 100 - 1506051773532 - 28', 'IRVING', 'TX', '70000', '600', " +
            "NULL, NULL, 'USA', NULL, NULL, NULL, 'F', NULL, NULL, 'A1M1', NULL, NULL, NULL, NULL, 'N', 'F', 'F', 'F', 'F', NULL, " +
            "NULL, NULL, NULL, NULL, NULL, 'E420', 'S00000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, " +
            "NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', NULL, NULL, NULL, '8', '9', 'M', '1', '0', '1', '0', 'N', 'N', " +
            "'2018-01-4', '2018-01-5', NULL, NULL, '2017-09-25 09:53:35.000', 1645, NULL, NULL, 'apt', ?1);", nativeQuery = true)
    void insertTestRecord(Long dcrmProfileId);

}
