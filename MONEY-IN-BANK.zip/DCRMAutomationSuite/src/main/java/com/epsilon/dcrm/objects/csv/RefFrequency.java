package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the ref_frequency standard feed
 * 
 * @author adomakonda
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefFrequency implements Comparable<RefFrequency> {
    private String frequencyCd;
    private String frequencyNm;
    private String frequencyDsc;
    private String rangeMinVal;
    private String rangeMaxVal;

    @Override
    public int compareTo(RefFrequency arg) {
        return frequencyCd.compareTo(arg.getFrequencyCd());
    }
}
