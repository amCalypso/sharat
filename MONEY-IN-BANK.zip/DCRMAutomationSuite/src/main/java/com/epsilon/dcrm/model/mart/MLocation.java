package com.epsilon.dcrm.model.mart;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "m_location", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class MLocation {

    @Id
    @Column(name = "dcrm_location_id")
    private Long dcrmLocationId;

    @Column(name = "parent_dcrm_location_id")
    private Long parentDcrmLocationId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "location_cd")
    private String locationCd;

    @Column(name = "location_nm")
    private String locationNm;

    @Column(name = "location_type_dsc")
    private String locationTypeDsc;

    @Column(name = "division_cd")
    private String divisionCd;

    @Column(name = "manager_first_nm")
    private String managerFirstNm;

    @Column(name = "manager_middle_initial")
    private String managerMiddleIntial;

    @Column(name = "manager_last_nm")
    private String managerLastNm;

    @Column(name = "manager_email_addr")
    private String managerEmailAddr;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_cd")
    private String stateCd;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "urbanization_nm")
    private String urbanizationNm;

    @Column(name = "latitude")
    private Long latitude;

    @Column(name = "longitude")
    private Long longitude;

    @Column(name = "geofence_radius")
    private Long geoFenceRadius;

    @Column(name = "active_rec_ind")
    private String activeRecInd;

    @Column(name = "dcrm_franchise_id")
    private Long dcrmFranchiseId;

    @Column(name = "effect_start_dt")
    private Date effectStartDate;

    @Column(name = "effect_end_dt")
    private Date effectEndDate;

}
