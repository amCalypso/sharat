package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "m_email_address", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MEmailAddress {

    @Id
    @Column(name = "dcrm_email_addr_id")
    private Long dcrmEmailAddrId;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "valid_ind")
    private String validInd;

}
