package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionHeaderId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_transaction_header table.
 * @author jblasingame
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(TransactionHeaderId.class)
@Table(name = "s_transaction_header", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardTransactionHeader {
    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "txn_complete_dt")
    private Date txnCompleteDt;

    @Column(name = "txn_channel_cd")
    private String txnChannelCd;

    @Column(name = "mobile_ind")
    private String mobileInd;

    @Column(name = "clienteling_ind")
    private String clientellingInd;

    @Column(name = "employee_purch_ind")
    private String employeePurchInd;

    @Column(name = "sales_location_cd")
    private String salesLocationCd;

    @Column(name = "register_nbr")
    private Long registerNbr;

    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "txn_seq_nbr")
    private Long txnSeqNbr;

    @Column(name = "txn_busn_dt")
    private Date txnBusnDt;

    @Column(name = "bill_acct_src_cd")
    private String billAcctSrcCd;

    @Column(name = "bill_acct_src_nbr")
    private String billAcctSrcNbr;

    @Column(name = "loyalty_acct_src_cd")
    private String loyaltyAcctSrcCd;

    @Column(name = "loyalty_acct_nbr")
    private String loyaltyAcctNbr;

    @Column(name = "login_id")
    private String loginId;

    @Column(name = "ip_address")
    private String ipAddr;

    @Column(name = "src_keycode")
    private String srcKeycode;

    @Column(name = "src_first_nm")
    private String srcFirstNm;

    @Column(name = "src_middle_nm")
    private String srcMiddleNm;

    @Column(name = "src_last_nm")
    private String srcLastNm;

    @Column(name = "src_unparsed_nm")
    private String srcUnparsedNm;

    @Column(name = "src_busn_nm")
    private String srcBusinessNm;

    @Column(name = "src_addr_line_1")
    private String srcAddrLine1;

    @Column(name = "src_addr_line_2")
    private String srcAddrLine2;

    @Column(name = "src_addr_line_3")
    private String srcAddrLine3;

    @Column(name = "src_addr_line_4")
    private String srcAddrLine4;

    @Column(name = "src_city_nm")
    private String srcCity;

    @Column(name = "src_state_cd")
    private String srcState;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "src_country_nm")
    private String srcCountry;

    @Column(name = "src_country_cd")
    private String srcCountryCd;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "phone_nbr")
    private String phoneNbr;

    @Column(name = "receipt_delivery_method_cd")
    private String receiptDeliveryMethodCd;

    @Column(name = "ereceipt_email_addr")
    private String ereceiptEmailAddr;

    @Column(name = "email_capture_type_cd")
    private String emailCaptureTypeCd;

    @Column(name = "email_capture_ind")
    private String emailCaptureInd;

    @Column(name = "txn_type_cd")
    private String txnTypeCd;

    @Column(name = "txn_subtype_cd")
    private String txnSubtypeCd;

    @Column(name = "related_txn_nbr")
    private String relatedTxnNbr;

    @Column(name = "related_txn_ts")
    private Timestamp relatedTxnTs;

    @Column(name = "purch_txn_amt")
    private Double purchTxnAmt;

    @Column(name = "purch_tax_amt")
    private Double purchTaxAmt;

    @Column(name = "purch_ship_amt")
    private Double purchShipAmt;

    @Column(name = "purch_discount_amt")
    private Double purchDiscountAmt;

    @Column(name = "cancel_txn_amt")
    private Double cancelTxnAmt;

    @Column(name = "cancel_tax_amt")
    private Double cancelTaxAmt;

    @Column(name = "cancel_ship_amt")
    private Double cancelShipAmt;

    @Column(name = "cancel_discount_amt")
    private Double cancelDiscountAmt;

    @Column(name = "return_txn_amt")
    private Double returnTxnAmt;

    @Column(name = "return_tax_amt")
    private Double returnTaxAmt;

    @Column(name = "return_ship_amt")
    private Double returnShipAmt;

    @Column(name = "return_discount_amt")
    private Double returnDiscountAmt;

    @Column(name = "currency_cd")
    private String currencyCd;

    @Column(name = "foreign_ind")
    private String foreignInd;

    @Column(name = "buyer_type_cd")
    private String buyerTypeCd;

    @Column(name = "txn_void_ind")
    private String txnVoidInd;

    @Column(name = "txn_status_cd")
    private String txnStatusCd;

    @Column(name = "txn_remark_txt")
    private String txnRemarkTxt;

    @Column(name = "item_price_override_ind")
    private String itemPriceOverrideInd;

    @Column(name = "ship_price_override_ind")
    private String shipPriceOverrideInd;

    @Column(name = "return_reason_cd")
    private String returnReasonCd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
