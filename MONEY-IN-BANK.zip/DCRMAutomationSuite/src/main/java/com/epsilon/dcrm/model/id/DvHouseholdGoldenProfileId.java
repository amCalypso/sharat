package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_household_golden_profile view.
 * @author Mohan 
 *
 */
@Data
public class DvHouseholdGoldenProfileId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long hHoldId;

    private String brandCd;

}