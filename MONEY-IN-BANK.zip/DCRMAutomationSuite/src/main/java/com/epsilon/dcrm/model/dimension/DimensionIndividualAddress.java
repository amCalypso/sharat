package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_individual_address table.
 * @author adomakonda
 * 
 * Update by :
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_individual_address", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionIndividualAddress implements Comparable<DimensionIndividualAddress> {

    @Id
    @Column(name = "dcrm_indiv_addr_id")
    private Long dcrmIndivAddrId;

    @Column(name = "addr_line_1")
    private String addrLine1;

    @Column(name = "addr_line_2")
    private String addrLine2;

    @Column(name = "addr_line_3")
    private String addrLine3;

    @Column(name = "city_nm")
    private String cityNm;

    @Column(name = "state_nm")
    private String stateNm;

    @Column(name = "postal_cd")
    private String postalCd;

    @Column(name = "zip4")
    private String zip4;

    @Column(name = "country_cd")
    private String countryCd;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "ga_id")
    private Long gaId;

    @Column(name = "hhold_id")
    private Long hholdId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;

    @Override
    public int compareTo(DimensionIndividualAddress o) {
        return updateTs.compareTo(o.getUpdateTs());
    }

}
