package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionTransactionTender;
import com.epsilon.dcrm.model.id.TransactionTenderId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DTransactionTenderRepository extends DimensionRepository<DimensionTransactionTender, TransactionTenderId> {
    Long deleteByTxnNbr(String txnNbr);

    Long deleteByBrandCd(String brandCd);

    List<DimensionTransactionTender> findByBrandCd(String brandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_transaction_tender"
            + "(txn_brand_cd, txn_src_cd, txn_nbr, tender_seq_nbr, txn_ts, "
            + "tender_dt, tender_type_cd, tender_subtype_cd, tender_amt, "
            + "surrogate_nbr, swipe_first_nm, swipe_last_nm, activity_ts, "
            + "create_file_id, create_rec_nbr)"
            + "VALUES(?1, ?2, ?3, ?4, getdate(), getdate(), ?5, ?6, ?7, ?8, ?9, ?10, getdate(), "
            + "?11, ?12);", nativeQuery = true)
    void insertSimpleTestRecord(String brandCd, String txnSrcCd, String txnNbr, Long tenderSeqNbr,
            String tenderTypeCd, String tenderSubtypeCd, Double tenderAmt, String surrogateNbr, String swipeFirstNm, String swipeLastNm, Long createFileId, Long createFileRecNbr);

}