package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionTransactionCertificateComparer implements Comparable<DimensionTransactionCertificateComparer> {
    private String txnNbr;
    private String certNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnTs;
    private String certStatusCd;
    private String activityTs;

    @Override
    public int compareTo(DimensionTransactionCertificateComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(certNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getCertNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
