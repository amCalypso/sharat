package com.epsilon.dcrm.objects.comparer;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class DvTransItemComparer implements Comparable<DvTransItemComparer> {
    private String txnItemNbr;
    private Timestamp txnTs;
    private String brandCd;
    private Long shiptoHholdId;
    private Long shiptoIndivId;
    private Long hholdId;
    private Long IndivId;
    private Long dcrmProdId;
    private Long fullfillDcrmLocationId;
    private String shiptoDcrmEmployeeId;

    @Override
    public int compareTo(DvTransItemComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnTs)
                .append(txnItemNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnTs())
                .append(o.getTxnItemNbr())
                .toString();
        return o1Key.compareToIgnoreCase(o2Key);
    }
}
