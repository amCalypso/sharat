package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.AggMonetary12MonthsId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the agg_monetary_last_12_months table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(AggMonetary12MonthsId.class)
@Table(name = "agg_monetary_last_12_months", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionAggMonetary12Months {

    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "m12_frequency_cnt")
    private Long m12FrequencyCnt;

    @Column(name = "m12_gross_amt")
    private Long m12GrossAmt;

    @Column(name = "m12_discount_amt")
    private Long m12DiscountAmt;

    @Column(name = "m12_return_amt")
    private Long m12ReturnAmt;

    @Column(name = "m12_cancel_amt")
    private Long m12CancelAmt;

}
