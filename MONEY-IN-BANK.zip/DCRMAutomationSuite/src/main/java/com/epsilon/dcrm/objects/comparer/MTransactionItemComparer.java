package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class MTransactionItemComparer implements Comparable<MTransactionItemComparer> {

    private String txnItemNbr;
    private String shiptoBilltoInd;
    private Long soldQty;
    private Date firstShipDt;
    private Date lastShipDt;
    private Long shipQty;
    private String fulfillTypeCd;
    private String itemTypeCd;
    private Long listPriceAmt;
    private Long offerPriceAmt;
    private Long soldPriceAmt;
    private Long cogsAmt;
    private Long extendedOfferAmt;
    private Long extendedItemAmt;
    private Long extendedDiscountAmt;
    private Long extendedShipAmt;
    private String itemStatusCd;
    private Long backorderQty;
    private Date backorderDt;
    private Date backorderExpectedFulfillDt;
    private Date backorderActualFulfillDt;
    private String itemGiftInd;
    private String gwpInd;
    private String bogoInd;
    private String giftWrapInd;
    private String markdownInd;
    private String returnReasonCd;
    private String cancelReasonCd;
    private Long taxRt;
    private Long extendedTaxAmt;
    private String currencyCd;
    private Long exchangeRt;
    private Long surchargeAmt;
    private String surchargeReasonCd;
    private Long fulfillGroupNbr;
    private String upc;
    private Timestamp txnTs;
    private Long dcrmTxnId;
    private Long shiptoHholdId;
    private Long fullfillDcrmStoreId;
    private Long dcrmProdId;
    private Date cancelDt;
    private Date returnDt;
    private String shiptoBrandCd;
    private Long hholdId;
    private Long shiptoDcrmEmployeeId;
    private Long shiptoIndivId;
    private Long indivId;
    private String brandCd;

    @Override
    public int compareTo(MTransactionItemComparer o) {
        String o1Key = new StringBuilder()
                .append(dcrmTxnId)
                .append(txnItemNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getDcrmTxnId())
                .append(o.getTxnItemNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }

}
