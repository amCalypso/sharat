package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionPhone;
import com.epsilon.dcrm.model.id.PhoneId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DPhoneRepository extends DimensionRepository<DimensionPhone, PhoneId> {
	Long deleteByPhoneNum(String phoneNum);
}

