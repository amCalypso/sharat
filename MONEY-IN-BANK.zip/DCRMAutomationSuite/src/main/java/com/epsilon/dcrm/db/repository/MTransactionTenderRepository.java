package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.MTransactionTenderId;
import com.epsilon.dcrm.model.mart.MTransactionTender;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MTransactionTenderRepository extends BaseRepository<MTransactionTender, MTransactionTenderId> {

    Long deleteByBrandCd(String brandCd);

    List<MTransactionTender> findByBrandCd(String brandCd);

}
