package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionTransactionItemComparer implements Comparable<DimensionTransactionItemComparer> {
    private String txnNbr;
    private String txnLineNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnTs;
    private String shipToBrandCd;
    private String shipToAcctSrcCd;
    private String shipToAcctSrcNbr;
    private String shipToBillToInd;
    private String shipToEmailAddr;
    private String shipToPhoneNbr;
    private String prodCatalogBrandCd;
    private String sku;
    private String upc;
    private String qty;
    private String uom;
    private String firstShipDt;
    private String lastShipDt;
    private String shipQty;
    private String shipUom;
    private String sizeCd;
    private String colorDesc;
    private String stdColorCd;
    private String fulfillLocationCd;
    private String fulfillGroupNbr;
    private String itemFulfillmentTypeCd;
    private String itemTypeCd;
    private String listPriceAmt;
    private String offerPriceAmt;
    private String soldPriceAmt;
    private String cogsAmt;
    private String extOfferAmt;
    private String extItemAmt;
    private String extDiscAmt;
    private String extShipAmt;
    private String itemStatusCd;
    private String backorderQty;
    private String backorderDt;
    private String backorderExpectedFulfillDt;
    private String backorderActualFulfillDt;
    private String itemGiftInd;
    private String gwpInd;
    private String bogoInd;
    private String giftWrapInd;
    private String markdownInd;
    private String returnDt;
    private String returnReasonCd;
    private String cancelDt;
    private String cancelReasonCd;
    private String taxRt;
    private String extTaxAmt;
    private String currencyCd;
    private String exchangeRt;
    private String surchargeAmt;
    private String surchargeReasonCd;
    private String activityTs;

    @Override
    public int compareTo(DimensionTransactionItemComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnLineNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnLineNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
