package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_individual_phone view.
 * @author Mohan
 *
 */
@Data
public class DvIndividualPhoneId implements Serializable {

    private static final long serialVersionUID = 6540745122202292776L;
    private String brandCd;
    private Long dcrmPhoneId;

}
