package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionTransactionAdjustment;
import com.epsilon.dcrm.model.id.TransactionAdjustmentId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DTransactionAdjustmentRepository extends DimensionRepository<DimensionTransactionAdjustment, TransactionAdjustmentId> {
    Long deleteByTxnNbr(String txnNbr);

    Long deleteByBrandCd(String brandCd);

    List<DimensionTransactionAdjustment> findByBrandCd(String BrandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_transaction_adjustment"
            + "(txn_brand_cd, txn_src_cd, txn_nbr, txn_item_nbr, "
            + "adjust_seq_nbr, adjust_dt, adjust_amt, adjust_type_cd, adjust_subtype_cd,activity_ts,"
            + "create_file_id, create_rec_nbr, create_ts, update_file_id, update_rec_nbr, update_ts, txn_ts)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, getdate(),?6,?7,?8,getdate(), ?9, ?10, getdate(), ?9, ?10, getdate(), getdate());", nativeQuery = true)
    void insertSimpleTestRecord(String brandCd, String txnSrcCd, String txnNbr, Long txnItemnbr, Long adjustSeqNbr, Long adjustAmt, String adjustTypeCd, String adjustSubtypeCd,
            Long FileId, Long FileRecNbr);

}