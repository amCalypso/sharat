package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.MIndividualSummaryId;
import com.epsilon.dcrm.model.mart.IndividualSummary;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MIndividualSummaryRepository extends BaseRepository<IndividualSummary, MIndividualSummaryId> {
    List<IndividualSummary> findByBrandCd(String brandCd);

    List<IndividualSummary> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByBrandCd(String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);

    List<IndividualSummary> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);
}
