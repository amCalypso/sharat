package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_email_address table.
 * @author adomakonda
 *
 */
@Entity
@Table(name = "d_email_address", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionEmailAddress {

    @Id
    @Column(name = "dcrm_email_addr_id")
    private Long dcrmEmailAddrId;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateFileRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
