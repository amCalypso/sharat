package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_transaction_tender table.
 * @author jblasingame
 *
 */
@Data
public class TransactionTenderId implements Serializable {
    private static final long serialVersionUID = 8872593856464040203L;

    private String brandCd;
    private String txnSrcCd;
    private String txnNbr;
    private Long tenderSeqNbr;
    private Long createFileId;
    private Long createFileRecNbr;
}
