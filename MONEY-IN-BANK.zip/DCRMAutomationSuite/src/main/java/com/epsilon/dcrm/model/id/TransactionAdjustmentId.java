package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_transaction_Adjustment table.
 * @author adomakonda
 *
 */
@Data
public class TransactionAdjustmentId implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String txnNbr;

    private String txnSrcCd;

    private String brandCd;

    private String txnLineNbr;

    private Long adjustSeqNbr;

    private Long createFileId;

    private Long createRecNbr;
}
