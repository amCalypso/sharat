package com.epsilon.dcrm.objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MatillionJobTriggerSQSMessage {
    private String group;
    private String project;
    private String version;
    private String job;
    private String environment;
    private MatillionVariables variables;
}
