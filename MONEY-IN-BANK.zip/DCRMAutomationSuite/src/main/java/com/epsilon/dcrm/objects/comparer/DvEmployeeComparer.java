package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;

import lombok.Data;

@Data
public class DvEmployeeComparer implements Comparable<DvEmployeeComparer> {

    private String employeeId;
    private String brandCd;
    private String srcGenderCd;
    private String srcNamePrefix;
    private String srcFirstNm;
    private String srcMiddleNm;
    private String srcLastNm;
    private String srcNameSuffix;
    private String srcUnparsedNm;
    private String homeAddrLine1;
    private String homeAddrLine2;
    private String homeAddrLine3;
    private String homeAddrLine4;
    private String homeCityNm;
    private String homeStateCd;
    private String homePostalCd;
    private String homeCountryCd;
    private String assignedLocation1Cd;
    private String assignedLocation2Cd;
    private String assignedLocation3Cd;
    private Date employmentStartDt;
    private Date employmentEndDt;
    private String employmentStatusCd;
    private String roleNm;
    private Long dcrmEmployeeId;
    private String homeCountryNm;
    private Long s1AssignedDcrmLocationId;
    private Long s2AssignedDcrmLocationId;
    private Long s3AssignedDcrmLocationId;

    @Override
    public int compareTo(DvEmployeeComparer o) {
        String o1Key = new StringBuilder()
                .append(employeeId)
                .append(brandCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getEmployeeId())
                .append(o.getBrandCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
