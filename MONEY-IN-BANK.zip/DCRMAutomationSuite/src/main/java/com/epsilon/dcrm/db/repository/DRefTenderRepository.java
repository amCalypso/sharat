package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DRefTender;
import com.epsilon.dcrm.model.id.DRefTenderId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DRefTenderRepository extends BaseRepository<DRefTender, DRefTenderId> {
    List<DRefTender> findByTenderSubTypeCdAndTenderTypeCdOrderByCreateTsDesc(String tenderSubtypeCd, String tenderTypeCd);
    
    Long deleteByTenderSubTypeCdAndTenderTypeCd(String tenderSubtypeCd, String tenderTypeCd);
}