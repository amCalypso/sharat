package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvIndividualSummary;
import com.epsilon.dcrm.model.id.DvIndividualSummaryId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvIndividualSummaryRepository extends BaseRepository<DvIndividualSummary, DvIndividualSummaryId> {
    List<DvIndividualSummary> findByBrandCd(String brandCd);

    Long deleteByBrandCd(String brandCd);

    List<DvIndividualSummary> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    List<DvIndividualSummary> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);
}
