package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionTransactionHeader;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DTransactionHeaderRepository extends DimensionRepository<DimensionTransactionHeader, String> {

    Long deleteByTxnNbr(String txnNbr);

    List<DimensionTransactionHeader> findByLocationBrandCdAndSalesLocationCd(String locationBrandCd, String salesLocationCd);

    Long deleteByBrandCd(String brandCd);

    List<DimensionTransactionHeader> findByBrandCd(String brandCd);

    List<DimensionTransactionHeader> findByTxnNbr(String txnNbr);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_transaction"
            + "(txn_brand_cd, txn_src_cd, txn_nbr,txn_ts, bill_brand_cd, bill_acct_src_cd,"
            + " bill_src_acct_nbr, location_brand_cd, location_cd, employee_id, activity_ts)"
            + "VALUES(?1, ?2, ?3, getdate(), ?1, ?2, ?3, ?1, ?4, ?5, getdate());", nativeQuery = true)
    void insertSimpleTestRecord(String brandCd, String acctSrcCd, String srcAcctNbr, String locationCd, long employeeId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_transaction"
            + "(txn_brand_cd, txn_src_cd, txn_nbr,txn_ts, bill_brand_cd, bill_acct_src_cd,"
            + " bill_src_acct_nbr, location_brand_cd, location_cd, employee_id, activity_ts)"
            + "VALUES(?1, ?2, ?3, getdate(), ?4, ?5, ?6, ?1, ?7, ?8, getdate());", nativeQuery = true)
    void insertTestRecord(String brandCd, String acctSrcCd, String srcAcctNbr, String billBrandCd, String billAcctSrcCd, String billAcctSrcNbr, String locationCd, long employeeId);

}