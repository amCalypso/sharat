package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionProfileComparer implements Comparable<DimensionProfileComparer> {
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private String genderCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String unparsedNm;
    private String busnNm;
    private String title;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String addrLine4;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String countryCd;
    private String countryNm;
    private String birthDt;
    private String birthDay;
    private String birthMth;
    private String birthYr;
    private String langCd;
    private String maritalStatusCd;
    private String preferredChannelCd;
    private String doNotPromoteInd;
    private String doNotCallInd;
    private String doNotMailInd;
    private String doNotSmsInd;
    private String doNotEmailInd;
    private String doNotRentInd;
    private String hardkey1;
    private String hardkey2;
    private String hardkey3;
    private String hardkey4;
    private String hardkey5;
    private String hardkey6;
    private String hardkey7;
    private String hardkey8;
    private String hardkey9;
    private String hardkey10;
    private String activityTs;
    private String recStatusCd;
    private String recStatusChangeDt;
    private String recSrcOrigTs;

    @Override
    public int compareTo(DimensionProfileComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getAcctSrcCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
