package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionRefFrequency;
import com.epsilon.dcrm.model.id.RefFrequencyId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DRefFrequencyRepository extends StandardRepository<DimensionRefFrequency, RefFrequencyId> {

    Long deleteByFrequencyCdAndCreateFileId(String frequencyCd, Long createFileId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_ref_frequency"
            + "(frequency_cd, frequency_nm, frequency_dsc, range_min_val, range_max_val, create_ts, create_file_id, create_rec_nbr)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, getdate(), ?6, ?7);", nativeQuery = true)
    void insertTestData(String frequencyCd, String frequencyNm, String frequencyDsc, Integer rangeMinVal, Integer rangeMaxVal, Long createFileId, Long createRecNbr);

    @Query(value = "select * from test_crm_warehouse.d_ref_frequency where ?1 BETWEEN NVL(range_min_val,0) AND NVL(range_max_val,999)", nativeQuery = true)
    List<DimensionRefFrequency> findByValue(Long value);

}
