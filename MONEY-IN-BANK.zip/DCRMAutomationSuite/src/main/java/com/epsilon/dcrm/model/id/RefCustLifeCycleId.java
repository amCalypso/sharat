package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the ID class for d_ref_customer_lifecycle
 * @author Mohan
 *
 */
@Data
public class RefCustLifeCycleId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String custLifeCycleCd;
    private Long createFileId;
    private Long createRecNbr;
}
