package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProfilePhone;
import com.epsilon.dcrm.model.id.ProfilePhoneId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProfilePhoneRepository extends BaseRepository<DimensionProfilePhone, ProfilePhoneId> {
    List<DimensionProfilePhone> findByDcrmPhoneId(Long dcrmPhoneId);
}