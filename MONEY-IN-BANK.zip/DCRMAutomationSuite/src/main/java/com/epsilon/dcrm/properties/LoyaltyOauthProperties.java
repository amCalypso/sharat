package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("loyalty.oauth")
public class LoyaltyOauthProperties {
    private String tokenUrl;
    private String clientId;
    private String clientSecret;
    private String userName;
    private String password;
    private String responseType;
    private String grantType;
}
