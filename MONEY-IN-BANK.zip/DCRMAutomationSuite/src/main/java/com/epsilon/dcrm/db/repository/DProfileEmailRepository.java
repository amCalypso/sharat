package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProfileEmail;
import com.epsilon.dcrm.model.id.ProfileEmailId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProfileEmailRepository extends BaseRepository<DimensionProfileEmail, ProfileEmailId> {
    List<DimensionProfileEmail> findByDcrmEmailAddrId(Long dcrmEmailAddrId);
}
