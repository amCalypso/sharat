package com.epsilon.dcrm.model.mart;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.MTransactionItemOrphanId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_transaction_item_orphan table.
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(MTransactionItemOrphanId.class)
@Table(name = "m_transaction_item_orphan", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MTransactionItemOrphan {

    @Id
    @Column(name = "txn_item_nbr")
    private String txnItemNbr;

    @Column(name = "shipto_billto_ind")
    private String shiptoBilltoInd;

    @Column(name = "sold_qty")
    private Long soldQty;

    @Column(name = "first_ship_dt")
    private Date firstShipDt;

    @Column(name = "last_ship_dt")
    private Date lastShipDt;

    @Column(name = "ship_qty")
    private Long shipQty;

    @Column(name = "fulfill_type_cd")
    private String fulfillTypeCd;

    @Column(name = "item_type_cd")
    private String itemTypeCd;

    @Column(name = "list_price_amt")
    private Long listPriceAmt;

    @Column(name = "offer_price_amt")
    private Long offerPriceAmt;

    @Column(name = "sold_price_amt")
    private Long soldPriceAmt;

    @Column(name = "cogs_amt")
    private Long cogsAmt;

    @Column(name = "extended_offer_amt")
    private Long extendedOfferAmt;

    @Column(name = "extended_item_amt")
    private Long extendedItemAmt;

    @Column(name = "extended_discount_amt")
    private Long extendedDiscountAmt;

    @Column(name = "extended_ship_amt")
    private Long extendedShipAmt;

    @Column(name = "item_status_cd")
    private String itemStatusCd;

    @Column(name = "backorder_qty")
    private Long backorderQty;

    @Column(name = "backorder_dt")
    private Date backorderDt;

    @Column(name = "backorder_expected_fulfill_dt")
    private Date backorderExpectedFulfillDt;

    @Column(name = "backorder_actual_fulfill_dt")
    private Date backorderActualFulfillDt;

    @Column(name = "item_gift_ind")
    private String itemGiftInd;

    @Column(name = "gwp_ind")
    private String gwpInd;

    @Column(name = "bogo_ind")
    private String bogoInd;

    @Column(name = "gift_wrap_ind")
    private String giftWrapInd;

    @Column(name = "markdown_ind")
    private String markdownInd;

    @Column(name = "return_reason_cd")
    private String returnReasonCd;

    @Column(name = "cancel_reason_cd")
    private String cancelReasonCd;

    @Column(name = "tax_rt")
    private Long taxRt;

    @Column(name = "extended_tax_amt")
    private Long extendedTaxAmt;

    @Column(name = "currency_cd")
    private String currencyCd;

    @Column(name = "exchange_rt")
    private Long exchangeRt;

    @Column(name = "surcharge_amt")
    private Long surchargeAmt;

    @Column(name = "surcharge_reason_cd")
    private String surchargeReasonCd;

    @Column(name = "fulfill_group_nbr")
    private Long fulfillGroupNbr;

    @Column(name = "upc")
    private String upc;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Id
    @Column(name = "dcrm_txn_id")
    private Long dcrmTxnId;

    @Column(name = "shipto_hhold_id")
    private Long shiptoHholdId;

    @Column(name = "fullfill_dcrm_Location_id")
    private Long fullfillDcrmLocationId;

    @Column(name = "dcrm_prod_id")
    private Long dcrmProdId;

    @Column(name = "cancel_dt")
    private Date cancelDt;

    @Column(name = "return_dt")
    private Date returnDt;

    @Column(name = "shipto_brand_cd")
    private String shiptoBrandCd;

    @Column(name = "hhold_id")
    private Long hholdId;

    @Column(name = "shipto_dcrm_employee_id")
    private Long shiptoDcrmEmployeeId;

    @Column(name = "shipto_indiv_id")
    private Long shiptoIndivId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "brand_cd")
    private String brandCd;

}
