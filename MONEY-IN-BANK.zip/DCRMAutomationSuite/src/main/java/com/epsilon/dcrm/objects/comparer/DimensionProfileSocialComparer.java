package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionProfileSocialComparer implements Comparable<DimensionProfileSocialComparer> {
    private String dcrmSocialAcctId;
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;

    @Override
    public int compareTo(DimensionProfileSocialComparer o) {
        String o1Key = new StringBuilder()
                .append(dcrmSocialAcctId)
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getDcrmSocialAcctId())
                .append(o.getBrandCd())
                .append(o.getAcctSrcCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
