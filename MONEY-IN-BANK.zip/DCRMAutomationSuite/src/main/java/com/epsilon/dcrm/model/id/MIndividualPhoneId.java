package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_individual_phone table.
 * @author Mohan
 *
 */
@Data
public class MIndividualPhoneId implements Serializable {

    private static final long serialVersionUID = -8903490955376337323L;
    private Long dcrmPhoneId;
    private String phoneTypeCd;
    private Long indivId;
    private String brandCd;

}
