package com.epsilon.dcrm.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.epsilon.dcrm.properties.S3;

@Configuration
public class AWSConfig {

    @Autowired
    private S3 s3Props;

    @Bean
    public BasicAWSCredentials basicAWSCredentials() {
        return new BasicAWSCredentials(s3Props.getS3AccessKeyId(), s3Props.getS3SecretAccessKey());
    }

    @Bean
    public AmazonSQS sqsConnection() {
        return AmazonSQSClientBuilder
                .standard()
                .withRegion(s3Props.getS3Region())
                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials()))
                .build();
    }

    @Bean
    public AmazonS3 s3Connection() {
        return AmazonS3ClientBuilder
                .standard()
                .withRegion(s3Props.getS3Region())
                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials()))
                .build();
    }

}
