package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.TransactionCertificateId;
import com.epsilon.dcrm.model.standard.StandardTransactionCertificate;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface STransactionCertificateRepository extends StandardRepository<StandardTransactionCertificate, TransactionCertificateId> {
    Long deleteByTxnNbr(String txnNbr);
}
