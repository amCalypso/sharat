package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_transaction_item_orphan table.
 * @author gwalia
 *
 */
@Data
public class MTransactionItemOrphanId implements Serializable {

    private static final long serialVersionUID = 6482595413919034270L;
    private Long dcrmTxnId;
    private String txnItemNbr;

}
