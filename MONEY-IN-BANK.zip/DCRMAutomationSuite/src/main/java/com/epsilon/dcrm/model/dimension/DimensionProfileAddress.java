package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile_address table.
 * @author gwalia
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_profile_address", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfileAddress {

    @Id
    @Column(name = "dcrm_profile_addr_id")
    private Long dcrmIndivAddrId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "ga_id")
    private Long gaId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Column(name = "src_acct_nbr")
    private String srcAcctNbr;

    @Column(name = "undeliverable_ind")
    private String undeliverableInd;

    @Column(name = "active_addr_ind")
    private String activeAddrInd;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
