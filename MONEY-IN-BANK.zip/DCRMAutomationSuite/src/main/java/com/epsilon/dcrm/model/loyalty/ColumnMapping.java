package com.epsilon.dcrm.model.loyalty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ColumnMapping extends BaseModel {
    private String mappingId;
    private String businessRuleDescription;
    private String sourceTableId;
    private String sourceColumnSqlName;
    private String targetTableId;
    private String targetColumnSqlName;

    @JsonProperty("IsDistinct")
    private boolean distinct;
}
