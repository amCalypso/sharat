package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class MIndividualPhoneComparer implements Comparable<MIndividualPhoneComparer> {
    private String brandCd;
    private String phoneTypeCd;
    private Long dcrmPhoneId;

    @Override
    public int compareTo(MIndividualPhoneComparer o) {
        return dcrmPhoneId.compareTo(o.getDcrmPhoneId());
    }

}
