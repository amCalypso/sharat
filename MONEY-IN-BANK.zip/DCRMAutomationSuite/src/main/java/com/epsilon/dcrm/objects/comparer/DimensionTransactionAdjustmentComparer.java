package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionTransactionAdjustmentComparer implements Comparable<DimensionTransactionAdjustmentComparer> {
    private String brandCd;
    private String txnSrcCd;
    private String txnNbr;
    private String txnLineNbr;
    private String adjustSeqNbr;
    private String adjustDt;
    private String adjustAmt;
    private String adjustTypeCd;
    private String adjustSubtypeCd;
    private String discountCd;
    private String couponCd;
    private String barcode;
    private String ringCd;
    private String activityTs;

    @Override
    public int compareTo(DimensionTransactionAdjustmentComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnNbr)
                .append(txnLineNbr)
                .append(adjustSeqNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnNbr())
                .append(o.getTxnLineNbr())
                .append(o.getAdjustSeqNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
