package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MatillionVariables {
    @JsonProperty("STD_SQS_CREATE_FILE_NAME")
    private String fileName;

    @JsonProperty("STD_SQS_SOURCE_SCHEMA_NAME")
    private String sourceSchemaName;

    @JsonProperty("STD_SQS_SOURCE_TABLE_NAME")
    private String sourceTableName;

    @JsonProperty("STD_SQS_TARGET_SCHEMA_NAME")
    private String targetSchemaName;

    @JsonProperty("STD_SQS_TARGET_TABLE_NAME")
    private String targetTableName;

    @JsonProperty("STD_SQS_AGGREGATE_FLAG")
    private String metadataAggregateFlag;

    @JsonProperty("STD_SQS_SOURCE_WHERE_COLUMN_NAME")
    private String whereColumnName;

    @JsonProperty("STD_SQS_SOURCE_WHERE_COLUMN_VALUE")
    private String whereColumnValue;

    @JsonProperty("STD_SQS_SOURCE_RECENCY_COLUMN_NAME")
    private String recencyColumnName;

    @JsonProperty("STD_SQS_SOURCE_ORDER_BY_COLUMN_NAME")
    private String orderByColumnName;

    @JsonProperty("STD_SQS_SOURCE_TO_TARGET_UPDATE_FLAG")
    private String sourceToTargetUpdateFlag;

}
