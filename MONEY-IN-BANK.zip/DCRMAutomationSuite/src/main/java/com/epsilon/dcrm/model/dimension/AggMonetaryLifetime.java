package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.AggMonetaryId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the agg_monetary_lifetime table.
 * @author dmitri
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(AggMonetaryId.class)
@Table(name = "agg_monetary_lifetime", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AggMonetaryLifetime {
    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "lifetime_frequency_cnt")
    private Long lifetimeFrequencyCnt;

    @Column(name = "lifetime_gross_amt")
    private Double lifetimeGrossAmt;

    @Column(name = "lifetime_discount_amt")
    private Double lifetimeDiscountAmt;

    @Column(name = "lifetime_return_amt")
    private Double lifetimeReturnAmt;

    @Column(name = "lifetime_cancel_amt")
    private Double lifetimeCancelAmt;

    @Column(name = "orig_txn_dt")
    private Date origTxnDt;

    @Column(name = "last_txn_dt")
    private Date lastTxnDt;

}
