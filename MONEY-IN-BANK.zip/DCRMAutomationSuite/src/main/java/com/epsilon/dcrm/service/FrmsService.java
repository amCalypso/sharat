package com.epsilon.dcrm.service;

import java.util.List;

import com.epsilon.dcrm.objects.DcrmWorkflowParams;
import com.epsilon.dcrm.objects.WorkflowExecutionStatusSearchResponse;
import com.epsilon.dcrm.objects.WorkflowSearchResponse;

public interface FrmsService {

    List<Long> scheduleTest(DcrmWorkflowParams dcrmWorkflowParams);

    void testEnable(String workflowId);

    WorkflowExecutionStatusSearchResponse searchWorkflowExec(String workflowId);

    WorkflowSearchResponse workflowExecStatus(String workflowId);
}
