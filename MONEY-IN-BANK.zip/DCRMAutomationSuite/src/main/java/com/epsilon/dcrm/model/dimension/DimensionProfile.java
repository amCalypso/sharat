package com.epsilon.dcrm.model.dimension;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfileId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile table.
 * @author dvelayudhannair
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(ProfileId.class)
@Table(name = "d_profile", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfile {
    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "src_acct_nbr")
    private String acctSrcNbr;

    @Column(name = "dcrm_profile_id")
    private Long dcrmProfileId;

    @Column(name = "src_gender_cd")
    private String genderCd;

    @Column(name = "src_name_prefix")
    private String namePrefix;

    @Column(name = "src_first_nm")
    private String firstNm;

    @Column(name = "src_middle_nm")
    private String middleNm;

    @Column(name = "src_last_nm")
    private String lastNm;

    @Column(name = "src_name_suffix")
    private String nameSuffix;

    @Column(name = "src_unparsed_nm")
    private String unparsedNm;

    @Column(name = "src_busn_nm")
    private String busnNm;

    @Column(name = "src_title")
    private String title;

    @Column(name = "src_addr_line_1")
    private String addrLine1;

    @Column(name = "src_addr_line_2")
    private String addrLine2;

    @Column(name = "src_addr_line_3")
    private String addrLine3;

    @Column(name = "src_addr_line_4")
    private String addrLine4;

    @Column(name = "src_city_nm")
    private String cityNm;

    @Column(name = "src_state_cd")
    private String stateCd;

    @Column(name = "src_postal_cd")
    private String postalCd;

    @Column(name = "src_country_cd")
    private String countryCd;

    @Column(name = "src_country_nm")
    private String countryNm;

    @Column(name = "src_birth_dt")
    private Date birthDt;

    @Column(name = "src_birth_day")
    private Integer birthDay;

    @Column(name = "src_birth_mth")
    private Integer birthMth;

    @Column(name = "src_birth_yr")
    private Integer birthYr;

    @Column(name = "lang_cd")
    private String langCd;

    @Column(name = "marital_status_cd")
    private String maritalStatusCd;

    @Column(name = "preferred_channel_cd")
    private String preferredChannelCd;

    @Column(name = "do_not_promote_ind")
    private String doNotPromoteInd;

    @Column(name = "do_not_call_ind")
    private String doNotCallInd;

    @Column(name = "do_not_mail_ind")
    private String doNotMailInd;

    @Column(name = "do_not_sms_ind")
    private String doNotSmsInd;

    @Column(name = "do_not_email_ind")
    private String doNotEmailInd;

    @Column(name = "do_not_rent_ind")
    private String doNotRentInd;

    @Column(name = "hardkey_1")
    private String hardkey1;

    @Column(name = "hardkey_2")
    private String hardkey2;

    @Column(name = "hardkey_3")
    private String hardkey3;

    @Column(name = "hardkey_4")
    private String hardkey4;

    @Column(name = "hardkey_5")
    private String hardkey5;

    @Column(name = "hardkey_6")
    private String hardkey6;

    @Column(name = "hardkey_7")
    private String hardkey7;

    @Column(name = "hardkey_8")
    private String hardkey8;

    @Column(name = "hardkey_9")
    private String hardkey9;

    @Column(name = "hardkey_10")
    private String hardkey10;

    @Column(name = "rec_src_cd")
    private String recSrcCd;

    @Column(name = "src_activity_ts")
    private Timestamp activityTs;

    @Column(name = "src_rec_status_cd")
    private String recStatusCd;

    @Column(name = "src_rec_change_dt")
    private Date recStatusChangeDt;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;

    @Column(name = "rec_src_orig_ts")
    private Timestamp recSrcOrigTs;
}
