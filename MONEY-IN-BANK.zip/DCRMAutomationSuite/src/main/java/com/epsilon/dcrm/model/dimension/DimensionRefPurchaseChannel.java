package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.RefPurchaseChannelId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_ref_purchase_channel table.
 * @author dvelayudhannair
 *
 */
@Entity
@IdClass(RefPurchaseChannelId.class)
@Table(name = "d_ref_purchase_channel", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionRefPurchaseChannel {

    @Id
    @Column(name = "purch_channel_cd")
    private String purchaseChannelCd;

    @Column(name = "purch_channel_nm")
    private String purchaseChannelNm;

    @Column(name = "purch_channel_dsc")
    private String purchaseChannelDsc;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
