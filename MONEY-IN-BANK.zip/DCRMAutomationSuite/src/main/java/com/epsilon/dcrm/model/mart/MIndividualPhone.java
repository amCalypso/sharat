package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.MIndividualPhoneId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@IdClass(MIndividualPhoneId.class)
@Table(name = "m_individual_phone", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MIndividualPhone {

    @Id
    @Column(name = "dcrm_phone_id")
    private Long dcrmPhoneId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "best_phone_nbr_ind")
    private String bestPhoneNbrInd;

    @Column(name = "phone_type_cd")
    private String phoneTypeCd;

    @Column(name = "phone_rank")
    private String phoneRank;

    @Column(name = "indiv_id")
    private Long indivId;

}
