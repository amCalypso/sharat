package com.epsilon.dcrm.model.standard;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionTenderId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_transaction_tender table.
 * @author jblasingame
 *
 */
@Entity
@IdClass(TransactionTenderId.class)
@Table(name = "s_transaction_tender", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardTransactionTender {

    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "tender_seq_nbr")
    private Long tenderSeqNbr;

    @Column(name = "txn_tS")
    private Timestamp txnTs;

    @Column(name = "tender_dt")
    private Date tenderDt;

    @Column(name = "tender_type_cd")
    private String tenderTypeCd;

    @Column(name = "tender_subtype_cd")
    private String tenderSubTypeCd;

    @Column(name = "tender_amt")
    private Double tenderAmt;

    @Column(name = "surrogate_nbr")
    private String surrogateNbr;

    @Column(name = "swipe_first_nm")
    private String swipeFirstNm;

    @Column(name = "swipe_last_nm")
    private String swipeLastNm;

    @Column(name = "activity_ts")
    private Timestamp activityDt;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_file_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
