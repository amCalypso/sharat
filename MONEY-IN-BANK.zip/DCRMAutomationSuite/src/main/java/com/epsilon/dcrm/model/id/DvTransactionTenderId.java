package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_transaction_tender view.
 * @author dvelayudhannair
 *
 */
@Data
public class DvTransactionTenderId implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -7442290201253692050L;

    private String brandCd;

    private Long tenderSeqNbr;

}
