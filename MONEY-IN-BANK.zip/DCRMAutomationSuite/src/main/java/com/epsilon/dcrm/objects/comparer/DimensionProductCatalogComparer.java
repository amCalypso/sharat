package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionProductCatalogComparer implements Comparable<DimensionProductCatalogComparer> {
    private String brandCd;
    private String sku;
    private String prodCatalogStartDt;
    private String prodCatalogEndDt;
    private String skuNm;
    private String skuDsc;
    private String altSku;
    private String baseProdCd;
    private String baseProdNm;
    private String prodOption1;
    private String prodOption2;
    private String prodOption3;
    private String sizeCd;
    private String uomNm;
    private String colorCd;
    private String activeInd;
    private String prodStartDt;
    private String prodEndDt;
    private String listPriceAmt;
    private String vendorCd;
    private String vendorNm;
    private String brandNm;
    private String prodCommentTxt;
    private String prod1Txt;
    private String prod2Txt;
    private String prod3Txt;
    private String prod4Txt;
    private String prod5Txt;
    private String prod6Txt;
    private String prod7Txt;
    private String prod8Txt;
    private String prod1Dt;
    private String prod2Dt;
    private String prod3Dt;
    private String prod4Dt;
    private String prod1Amt;
    private String prod2Amt;
    private String prod3Amt;
    private String prod4Amt;
    private String prod1Qty;
    private String prod2Qty;
    private String prod3Qty;
    private String prod4Qty;
    private String activityTs;

    @Override
    public int compareTo(DimensionProductCatalogComparer o) {
        return sku.compareToIgnoreCase(o.getSku());

    }
}