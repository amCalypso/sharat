package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionTransactionItem;
import com.epsilon.dcrm.model.id.TransactionItemId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DTransactionItemRepository extends DimensionRepository<DimensionTransactionItem, TransactionItemId> {
    Long deleteByTxnNbr(String txnNbr);

    List<DimensionTransactionItem> findByBrandCd(String brandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_transaction_item"
            + "(txn_brand_cd, txn_src_cd, txn_nbr, txn_item_nbr, "
            + "shipto_brand_cd, shipto_acct_src_cd, shipto_acct_src_nbr,"
            + "sku, activity_ts, create_file_id, create_rec_nbr,create_ts,"
            + "update_file_id, update_rec_nbr, update_ts, txn_ts, "
            + "fulfill_location_cd,prod_catalog_brand_cd) "
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, getdate(), ?9, ?10, getdate(), ?9, ?10, getdate(), getdate(), ?11,?1);", nativeQuery = true)
    void insertSimpleTestRecord(String brandCd, String txnSrcCd, String txnNbr, Long txnItemnbr, String shipToBrandCd, String shipToAcctSrcCd, String shipToAcctSrcNbr,
            String sku, Long FileId, Long FileRecNbr, String fullfillLocationCd);
}
