package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_ref_customer_lifecycle table.
 * @author Mohan
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "m_ref_customer_lifecycle", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MRefCustLifeCycle {

    @Id
    @Column(name = "cust_lifecycle_cd")
    private String custLifeCycleCd;;

    @Column(name = "cust_lifecycle_nm")
    private String custLifeCycleNm;

    @Column(name = "cust_lifecycle_dsc")
    private String custLifeCycleDsc;

}
