package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class MIndividualEmailComparer implements Comparable<MIndividualEmailComparer> {
    private Long indivId;
    private String validInd;
    private String brandCd;
    private String bestEmailAddrInd;
    private Long dcrmEmailAddrId;

    @Override
    public int compareTo(MIndividualEmailComparer o) {
        String o1Key = new StringBuilder()
                .append(indivId)
                .append(brandCd)
                .append(dcrmEmailAddrId)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getIndivId())
                .append(o.getBrandCd())
                .append(o.getDcrmEmailAddrId())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }

}
