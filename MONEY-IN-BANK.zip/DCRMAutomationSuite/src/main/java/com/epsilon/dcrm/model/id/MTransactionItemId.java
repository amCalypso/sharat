package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_transaction_item table.
 * @author gwalia
 *
 */
@Data
public class MTransactionItemId implements Serializable {

    private static final long serialVersionUID = -7649378233440003653L;
    private Long dcrmTxnId;
    private String txnItemNbr;
}
