package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.ProfilePhoneId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_profile_phone table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(ProfilePhoneId.class)
@Table(name = "d_profile_phone", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionProfilePhone {
    @Id
    @Column(name = "dcrm_phone_id")
    private Long dcrmPhoneId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Id
    @Column(name = "src_acct_nbr")
    private String acctSrcNbr;

    @Column(name = "phone_type_cd")
    private String phoneTypeCd;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
