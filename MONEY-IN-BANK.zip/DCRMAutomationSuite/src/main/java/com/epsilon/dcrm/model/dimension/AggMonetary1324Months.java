package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.AggMonetaryId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the agg_monetary_13_24_months table.
 * @author dmitri
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(AggMonetaryId.class)
@Table(name = "agg_monetary_13_24_months", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AggMonetary1324Months {
    @Id
    @Column(name = "indiv_id")
    private Long indivId;

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "m13_24_frequency_cnt")
    private Long m1324FrequencyCnt;

    @Column(name = "m13_24_gross_amt")
    private Double m1324GrossAmt;

    @Column(name = "m13_24_discount_amt")
    private Double m1324DiscountAmt;

    @Column(name = "m13_24_return_amt")
    private Double m1324ReturnAmt;

    @Column(name = "m13_24_cancel_amt")
    private Double m1324CancelAmt;

}
