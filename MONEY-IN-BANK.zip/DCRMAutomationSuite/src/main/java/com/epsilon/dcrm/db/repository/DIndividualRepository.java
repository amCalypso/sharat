package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionIndividual;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DIndividualRepository extends DimensionRepository<DimensionIndividual, Long> {

    List<DimensionIndividual> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_individual"
            + "(indiv_id, curr_indiv_id, update_file_id, update_ts)"
            + "VALUES(?1, ?2, ?3, getdate())", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, Long currentIndivId, Long updateFileId);

}
