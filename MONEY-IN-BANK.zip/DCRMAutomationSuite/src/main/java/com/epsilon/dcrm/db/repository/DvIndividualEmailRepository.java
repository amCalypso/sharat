package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvIndividualEmail;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvIndividualEmailRepository extends BaseRepository<DvIndividualEmail, String> {

    List<DvIndividualEmail> findByIndivIdAndBrandCdAndEmailAddrOrderByUpdateTsDesc (Long indivId, String brandCd, String emailAddr);

}
