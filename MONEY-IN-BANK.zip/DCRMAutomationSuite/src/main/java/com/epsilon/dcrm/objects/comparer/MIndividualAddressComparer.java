package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class MIndividualAddressComparer implements Comparable<MIndividualAddressComparer> {

    private Long dcrmIndivAddrId;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String cityNm;
    private String stateNm;
    private String postalCd;
    private String zip4;
    private String countryCd;
    private Long gaId;
    private Integer indivId;

    @Override
    public int compareTo(MIndividualAddressComparer o) {
        return dcrmIndivAddrId.compareTo(o.getDcrmIndivAddrId());

    }

}
