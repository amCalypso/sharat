package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_individual_summary view.
 * @author dmitri
 *
 */
@Data
public class MIndividualSummaryId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long indivId;

    private String brandCd;

}
