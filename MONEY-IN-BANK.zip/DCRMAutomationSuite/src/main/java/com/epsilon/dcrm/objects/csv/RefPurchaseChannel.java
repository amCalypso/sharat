package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the RefPurchaseChannel feed
 * 
 * @author dvelayudhannair
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefPurchaseChannel implements Comparable<RefPurchaseChannel> {
    private String purchaseChannelCd;
    private String purchaseChannelNm;
    private String purchaseChannelDsc;

    @Override
    public int compareTo(RefPurchaseChannel arg) {
        return purchaseChannelCd.compareTo(arg.getPurchaseChannelCd());
    }

}
