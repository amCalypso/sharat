package com.epsilon.dcrm.model.dimension;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionAdjustmentId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_transaction_adjustment table.
 * @author adomakonda
 *
 */
@Entity
@IdClass(TransactionAdjustmentId.class)
@Table(name = "d_transaction_adjustment", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionTransactionAdjustment {

    @Id
    @Column(name = "txn_brand_cd")
    private String brandCd;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_item_nbr")
    private String txnLineNbr;

    @Id
    @Column(name = "adjust_seq_nbr")
    private Long adjustSeqNbr;

    @Column(name = "adjust_dt")
    private Date adjustDt;

    @Column(name = "adjust_amt")
    private Double adjustAmt;

    @Column(name = "adjust_type_cd")
    private String adjustTypeCd;

    @Column(name = "adjust_subtype_cd")
    private String adjustSubtypeCd;

    @Column(name = "discount_cd")
    private String discountCd;

    @Column(name = "coupon_cd")
    private String couponCd;

    @Column(name = "barcode")
    private String barcode;

    @Column(name = "ring_cd")
    private String ringCd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Column(name = "create_file_id")
    @Id
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;

    @Column(name = "txn_ts")
    private Timestamp txnTs;
}
