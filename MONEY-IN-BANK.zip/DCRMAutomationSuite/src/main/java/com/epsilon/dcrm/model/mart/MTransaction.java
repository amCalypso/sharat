package com.epsilon.dcrm.model.mart;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_transaction table.
 * @author jblasingame
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "m_transaction", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MTransaction implements Comparable<MTransaction> {

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "mobile_ind")
    private String mobileInd;

    @Column(name = "clienteling_ind")
    private String clientellingInd;

    @Column(name = "employee_purch_ind")
    private String employeePurchInd;

    @Column(name = "register_nbr")
    private Long registerNbr;

    @Column(name = "txn_seq_nbr")
    private Long txnSeqNbr;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "receipt_delivery_method_cd")
    private String receiptDeliveryMethodCd;

    @Column(name = "email_capture_type_cd")
    private String emailCaptureTypeCd;

    @Column(name = "email_capture_ind")
    private String emailCaptureInd;

    @Column(name = "txn_type_cd")
    private String txnTypeCd;

    @Column(name = "txn_subtype_cd")
    private String txnSubtypeCd;

    @Column(name = "related_txn_nbr")
    private String relatedTxnNbr;

    @Column(name = "related_txn_ts")
    private Timestamp relatedTxnTs;

    @Column(name = "purch_txn_amt")
    private Double purchTxnAmt;

    @Column(name = "purch_tax_amt")
    private Double purchTaxAmt;

    @Column(name = "purch_ship_amt")
    private Double purchShipAmt;

    @Column(name = "purch_discount_amt")
    private Double purchDiscountAmt;

    @Column(name = "cancel_txn_amt")
    private Double cancelTxnAmt;

    @Column(name = "cancel_tax_amt")
    private Double cancelTaxAmt;

    @Column(name = "cancel_ship_amt")
    private Double cancelShipAmt;

    @Column(name = "cancel_discount_amt")
    private Double cancelDiscountAmt;

    @Column(name = "return_txn_amt")
    private Double returnTxnAmt;

    @Column(name = "return_tax_amt")
    private Double returnTaxAmt;

    @Column(name = "return_ship_amt")
    private Double returnShipAmt;

    @Column(name = "return_discount_amt")
    private Double returnDiscountAmt;

    @Column(name = "currency_cd")
    private String currencyCd;

    @Column(name = "foreign_ind")
    private String foreignInd;

    @Column(name = "buyer_type_cd")
    private String buyerTypeCd;

    @Column(name = "txn_void_ind")
    private String txnVoidInd;

    @Column(name = "txn_status_cd")
    private String txnStatusCd;

    @Column(name = "item_price_override_ind")
    private String itemPriceOverrideInd;

    @Column(name = "ship_price_override_ind")
    private String shipPriceOverrideInd;

    @Column(name = "return_reason_cd")
    private String returnReasonCd;

    @Id
    @Column(name = "dcrm_txn_id")
    private Long dcrmTxnId;

    @Column(name = "dcrm_location_id")
    private Long dcrmLocationId;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "hhold_id")
    private Long hholdId;

    @Column(name = "dcrm_employee_id")
    private Long dcrmEmployeeId;

    @Column(name = "txn_channel_cd")
    private String txnChannelCd;

    @Column(name = "txn_complete_dt")
    private Date txnCompleteDt;

    @Column(name = "txn_busn_dt")
    private Date txnBusnDt;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "txn_nbr")
    private String txnNbr;

    @Override
    public int compareTo(MTransaction o) {
        return dcrmTxnId.compareTo(o.getDcrmTxnId());
    }
}
