package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionStore;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DStoreRepository extends JpaRepository<DimensionStore, String> {

    Long deleteByStoreNm(String storeNm);

    Long deleteByStoreCd(String storeCd);

    Long deleteByBrandCd(String brandCd);

    Long deleteByBrandCdAndStoreCd(String brandCd, String storeCd);

    List<DimensionStore> findByBrandCd(String brandCd);

    List<DimensionStore> findByStoreCd(String storeCd);

    List<DimensionStore> findByBrandCdAndStoreCd(String brandCd, String storeCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_store"
            + "(store_cd, store_nm, store_type_cd, store_status_cd, brand_cd)"
            + "VALUES(?1, ?2, 'AA', 'BB', ?3);", nativeQuery = true)
    void insertSimpleTestRecord(String storeCd, String storeNm, String brandCd);

    Long deleteByCreateFileId(Long fileId);

}
