package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("dcrm.automation.object")
@PropertySource("classpath:automation.properties")

public class S3 {

	private String s3AccessKeyId;
    private String s3SecretAccessKey;
    private String s3Region;
    private String s3BucketName;
    private String s3Path;
}
