package com.epsilon.dcrm.model.mart;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Cacheable(value = false)
@Table(name = "m_individual_email", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MIndividualEmail {

    @Id
    @Column(name = "dcrm_email_addr_id")
    private Long dcrmEmailAddrId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "best_email_addr_ind")
    private String bestEmailAddrInd;

    @Column(name = "valid_ind")
    private String validInd;

    @Column(name = "indiv_id")
    private Long indivId;

}
