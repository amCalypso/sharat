package com.epsilon.dcrm.model.dimension;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionItemId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_transaction_item table.
 * @author dvelayudhannair
 *
 */
@Entity
@IdClass(TransactionItemId.class)
@Table(name = "d_transaction_item", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionTransactionItem {

    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;
    @Id
    @Column(name = "txn_item_nbr")
    private String txnLineNbr;
    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;
    @Id
    @Column(name = "txn_brand_cd")
    private String brandCd;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "shipto_brand_cd")
    private String shipToBrandCd;

    @Column(name = "shipto_acct_src_cd")
    private String shipToAcctSrcCd;

    @Column(name = "shipto_acct_src_nbr")
    private String shipToAcctSrcNbr;

    @Column(name = "shipto_billto_ind")
    private String shipToBillToInd;

    @Column(name = "shipto_email_addr")
    private String shipToEmailAddr;

    @Column(name = "shipto_phone_nbr")
    private String shipToPhoneNbr;

    @Column(name = "prod_catalog_brand_cd")
    private String prodCatalogBrandCd;

    private String sku;

    private String upc;

    @Column(name = "sold_qty")
    private Integer qty;

    @Column(name = "uom_nm")
    private Integer uom;

    @Column(name = "first_ship_dt")
    private Date firstShipDt;

    @Column(name = "last_ship_dt")
    private Date lastShipDt;

    @Column(name = "ship_qty")
    private Integer shipQty;

    @Column(name = "ship_uom_nm")
    private Integer shipUom;

    @Column(name = "sku_size_cd")
    private String sizeCd;

    @Column(name = "sku_color_dsc")
    private String colorDesc;

    @Column(name = "sku_color_cd")
    private String stdColorCd;

    @Column(name = "fulfill_location_cd")
    private String fulfillLocationCd;

    @Column(name = "fulfill_group_nbr")
    private Integer fulfillGroupNbr;

    @Column(name = "fulfill_type_cd")
    private String itemFulfillmentTypeCd;

    @Column(name = "item_type_cd")
    private String itemTypeCd;

    @Column(name = "list_price_amt")
    private Double listPriceAmt;

    @Column(name = "offer_price_amt")
    private Double offerPriceAmt;

    @Column(name = "sold_price_amt")
    private Double soldPriceAmt;

    @Column(name = "cogs_amt")
    private Double cogsAmt;

    @Column(name = "extended_offer_amt")
    private Double extOfferAmt;

    @Column(name = "extended_item_amt")
    private Double extItemAmt;

    @Column(name = "extended_discount_amt")
    private Double extDiscAmt;

    @Column(name = "extended_ship_amt")
    private Double extShipAmt;

    @Column(name = "item_status_cd")
    private String itemStatusCd;

    @Column(name = "backorder_qty")
    private Integer backorderQty;

    @Column(name = "backorder_dt")
    private Date backorderDt;

    @Column(name = "backorder_expected_fulfill_dt")
    private Date backorderExpectedFulfillDt;

    @Column(name = "backorder_actual_fulfill_dt")
    private Date backorderActualFulfillDt;

    @Column(name = "item_gift_ind")
    private String itemGiftInd;

    @Column(name = "gwp_ind")
    private String gwpInd;

    @Column(name = "bogo_ind")
    private String bogoInd;

    @Column(name = "gift_wrap_ind")
    private String giftWrapInd;

    @Column(name = "markdown_ind")
    private String markdownInd;

    @Column(name = "return_dt")
    private Date returnDt;

    @Column(name = "return_reason_cd")
    private String returnReasonCd;

    @Column(name = "cancel_dt")
    private Date cancelDt;

    @Column(name = "cancel_reason_cd")
    private String cancelReasonCd;

    @Column(name = "tax_rt")
    private Double taxRt;

    @Column(name = "extended_tax_amt")
    private Double extTaxAmt;

    @Column(name = "currency_cd")
    private String currencyCd;

    @Column(name = "exchange_rt")
    private Double exchangeRt;

    @Column(name = "surcharge_amt")
    private Double surchargeAmt;

    @Column(name = "surcharge_reason_cd")
    private String surchargeReasonCd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateFileRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
