package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionProfilePhoneComparer implements Comparable<DimensionProfilePhoneComparer> {
    private String dcrmPhoneId;
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private String phoneTypeCd;

    @Override
    public int compareTo(DimensionProfilePhoneComparer o) {
        String o1Key = new StringBuilder()
                .append(dcrmPhoneId)
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getDcrmPhoneId())
                .append(o.getBrandCd())
                .append(o.getAcctSrcCd())
                .append(o.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
