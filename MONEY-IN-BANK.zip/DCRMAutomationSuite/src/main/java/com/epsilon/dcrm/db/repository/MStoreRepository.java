package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MStore;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MStoreRepository extends BaseRepository<MStore, Long> {
    Long deleteByBrandCd(String brandCd);

    List<MStore> findByStoreCd(String storeCd);

}
