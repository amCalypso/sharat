package com.epsilon.dcrm.model.mart;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.MTransactionTenderId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_transaction_tender_orphan.
 * @author dvelayudhannair
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(MTransactionTenderId.class)
@Table(name = "m_transaction_tender_orphan", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MTransactionTenderOrphan {

    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Id
    @Column(name = "dcrm_txn_id")
    private Long dcrmTxnId;

    @Id
    @Column(name = "tender_seq_nbr")
    private Long tenderSeqNbr;

    @Column(name = "tender_dt")
    private Date tenderDt;

    @Column(name = "tender_type_cd")
    private String tenderTypeCd;

    @Column(name = "tender_subtype_cd")
    private String tenderSubTypeCd;

    @Column(name = "tender_amt")
    private Double tenderAmt;

    @Column(name = "surrogate_nbr")
    private String surrogateNbr;

    @Column(name = "swipe_first_nm")
    private String swipeFirstNm;

    @Column(name = "swipe_last_nm")
    private String swipeLastNm;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "hhold_id")
    private Long hHoldId;

    @Column(name = "indiv_id")
    private Long indivId;

}
