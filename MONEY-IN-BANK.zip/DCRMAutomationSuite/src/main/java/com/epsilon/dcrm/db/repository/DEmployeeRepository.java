package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionEmployee;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DEmployeeRepository extends DimensionRepository<DimensionEmployee, String> {

    Long deleteByEmployeeId(String employeeId);

    Long deleteByBrandCd(String brandCd);

    List<DimensionEmployee> findByBrandCd(String branchCd);

    List<DimensionEmployee> findByEmployeeId(String employeeId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_employee"
            + "(brand_cd, employee_id, activity_ts)"
            + "VALUES(?1, ?2, getdate());", nativeQuery = true)
    void insertSimpleTestRecord(String brandCd, String employeeId);
}
