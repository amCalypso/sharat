package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionIndividualPhone;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DIndividualPhoneRepository extends DimensionRepository<DimensionIndividualPhone, Long> {
    List<DimensionIndividualPhone> findByDcrmIndivPhoneId(Long dcrmIndivPhoneId);

    Long findByBrandCd(String brandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_individual_phone"
            + "(phone_nbr, update_file_id)"
            + "VALUES(?1, ?2)", nativeQuery = true)
    void insertSimpleTestRecord(String phoneNumber, Long updateFileId);

}
