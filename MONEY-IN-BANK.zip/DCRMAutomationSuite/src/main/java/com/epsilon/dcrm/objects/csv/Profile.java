package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the Profile standard feed
 *
 * @author adomakonda
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Profile implements Comparable<Profile> {
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private String recStatusCd;
    private String recStatusChangeDt;
    private String preferredChannelCd;
    private String genderCd;
    private String namePrefix;
    private String firstNm;
    private String middleNm;
    private String lastNm;
    private String nameSuffix;
    private String unparsedNm;
    private String busnNm;
    private String title;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String addrLine4;
    private String cityNm;
    private String stateCd;
    private String postalCd;
    private String countryNm;
    private String countryCd;
    private String birthDay;
    private String birthMth;
    private String birthYr;
    private String langCd;
    private String maritalStatusCd;
    private String emailAddr1;
    private String emailAddr2;
    private String homePhoneNbr;
    private String homePhoneCountryCd;
    private String workPhoneNbr;
    private String workPhoneCountryCd;
    private String cellPhoneNbr;
    private String cellPhoneCountryCd;
    private String pagerPhoneNbr;
    private String pagerPhoneCountryCd;
    private String faxPhoneNbr;
    private String faxPhoneCountryCd;
    private String otherPhoneNbr;
    private String otherPhoneCountryCd;
    private String socialMedia1Nm;
    private String socialMediaAcct1Id;
    private String socialMedia2Nm;
    private String socialMediaAcct2Id;
    private String hardkey1;
    private String hardkey2;
    private String hardkey3;
    private String hardkey4;
    private String hardkey5;
    private String hardkey6;
    private String hardkey7;
    private String hardkey8;
    private String hardkey9;
    private String hardkey10;
    private String doNotPromoteInd;
    private String doNotCallInd;
    private String doNotMailInd;
    private String doNotSmsInd;
    private String doNotEmailInd;
    private String doNotRentInd;
    private String recSrcOrigTs;
    private String activityTs;

    @Override
    public int compareTo(Profile arg) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(acctSrcCd)
                .append(acctSrcNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(arg.getBrandCd())
                .append(arg.getAcctSrcCd())
                .append(arg.getAcctSrcNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
