package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LookupTestParameters {
    private String trigger;
    private String prefix;
    private String dataFilePath;
    private String dataFileHeader;
    private String jobName;
    private String tableName;
    @JsonProperty("class")
    private String className;

    @Override
    public String toString() {
        return "JobName: " + jobName;
    }
}
