package com.epsilon.dcrm.db.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionHouseholdGoldenProfile;
import com.epsilon.dcrm.model.id.DvHouseholdGoldenProfileId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DHouseholdGoldenProfileRepository extends BaseRepository<DimensionHouseholdGoldenProfile, DvHouseholdGoldenProfileId> {
    List<DimensionHouseholdGoldenProfile> findByBrandCd(String brandCd);

    Long deleteByBrandCd(String brandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_household_golden_profile" +
            "(hhold_id, hoh_indiv_id, brand_cd, name_prefix, first_nm, middle_nm, last_nm, " +
            "birth_dt, dcrm_indiv_addr_id, dcrm_indiv_email_id, dcrm_indiv_phone_id, dcrm_profile_id)" +
            "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12);", nativeQuery = true)
    void insertTestRecordToHouseHoldGoldenProfile(Long hHoldId, Long hoh_indiv_id, String brandCd, String namePrefix, String firstNm, String middleNm, String lastNm,
            Date birthDt, Long dcrmIndivAddrId, Long dcrmIndivEmailId, Long dcrmIndivPhoneId, Long dcrmProfileId);
}

