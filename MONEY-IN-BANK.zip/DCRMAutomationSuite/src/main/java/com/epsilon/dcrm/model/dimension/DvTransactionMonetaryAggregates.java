package com.epsilon.dcrm.model.dimension;

import java.sql.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DvTransactionMonetaryAggregatesId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the dv_transaction_monetary_aggregates view.
 * @author dmitri
 *
 */
@Entity
@Cacheable(value = false)
@IdClass(DvTransactionMonetaryAggregatesId.class)
@Table(name = "dv_transaction_monetary_aggregates", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DvTransactionMonetaryAggregates {
    @Id
    @Column(name = "indiv_id")
    private Long indivId;
    @Id
    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "hhold_head_ind")
    private Long hholdHeadInd;

    @Column(name = "m12_frequency_cnt")
    private Long m12FrequencyCnt;

    @Column(name = "m12_gross_amt")
    private Long m12GrossAmt;

    @Column(name = "m12_discount_amt")
    private Long m12DiscountAmt;

    @Column(name = "m12_return_amt")
    private Long m12ReturnAmt;

    @Column(name = "m12_cancel_amt")
    private Long m12CancelAmt;

    @Column(name = "m12_net_amt")
    private Long m12NetAmt;

    @Column(name = "m12_frequency_cd")
    private String m12FrequencyCd;

    @Column(name = "m12_monetary_cd")
    private String m12MonetaryCd;

    @Column(name = "m13_24_frequency_cnt")
    private Long m1324FrequencyCnt;

    @Column(name = "m13_24_gross_amt")
    private Long m1324GrossAmt;

    @Column(name = "m13_24_discount_amt")
    private Long m1324DiscountAmt;

    @Column(name = "m13_24_return_amt")
    private Long m1324ReturnAmt;

    @Column(name = "m13_24_cancel_amt")
    private Long m1324CancelAmt;

    @Column(name = "m13_24_net_amt")
    private Long m1324NetAmt;

    @Column(name = "m13_24_frequency_cd")
    private String m1324FrequencyCd;

    @Column(name = "m13_24_monetary_cd")
    private String m1324MonetaryCd;

    @Column(name = "lifetime_frequency_cnt")
    private Long lifetimeFrequencyCnt;

    @Column(name = "lifetime_gross_amt")
    private Long lifetimeGrossAmt;

    @Column(name = "lifetime_discount_amt")
    private Long lifetimeDiscountAmt;

    @Column(name = "lifetime_return_amt")
    private Long lifetimeReturnAmt;

    @Column(name = "lifetime_cancel_amt")
    private Long lifetimeCancelAmt;

    @Column(name = "lifetime_net_amt")
    private Long lifetimeNetAmt;

    @Column(name = "lifetime_frequency_cd")
    private String lifetimeFrequencyCd;

    @Column(name = "lifetime_monetary_cd")
    private String lifetimeMonetaryCd;

    @Column(name = "lifetime_recency_cd")
    private String lifetimeRecencyCd;

    @Column(name = "orig_txn_dt")
    private Date origTxnDt;

    @Column(name = "last_txn_dt")
    private Date lastTxnDt;

}
