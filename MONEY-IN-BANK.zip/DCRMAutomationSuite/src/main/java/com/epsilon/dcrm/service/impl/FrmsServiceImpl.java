package com.epsilon.dcrm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestOperations;

import com.epsilon.dcrm.objects.DcrmWorkflowParams;
import com.epsilon.dcrm.objects.DcrmWorkflowResponse;
import com.epsilon.dcrm.objects.FrmsWorkflowFilter;
import com.epsilon.dcrm.objects.WorkflowExecutionStatusSearchParams;
import com.epsilon.dcrm.objects.WorkflowExecutionStatusSearchResponse;
import com.epsilon.dcrm.objects.WorkflowSearchResponse;
import com.epsilon.dcrm.properties.DcrmProperties;
import com.epsilon.dcrm.properties.FrmsApiProperties;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.type.FrmsExecutionStatus;

@Service
public class FrmsServiceImpl implements FrmsService {

    @Autowired
    private RestOperations restTemplate;

    @Autowired
    private DcrmProperties props;

    @Autowired
    private FrmsApiProperties frmsProps;

    private static final Logger log = LoggerFactory.getLogger(FrmsServiceImpl.class);

    @Override
    public List<Long> scheduleTest(DcrmWorkflowParams dcrmWorkflowParams) {
        log.debug("incoming test object", dcrmWorkflowParams);
        List<Long> workflowIdList = new ArrayList<Long>();
        DcrmWorkflowResponse[] response = restTemplate.postForObject(
                props.getDcrmUri().concat(props.getEndpoint().getEnable()),
                dcrmWorkflowParams,
                DcrmWorkflowResponse[].class);
        for (DcrmWorkflowResponse dcrmWorkflowResponse : response) {
            workflowIdList.add(dcrmWorkflowResponse.getWorkflowId());
        }
        log.debug("list of workflows", workflowIdList.toArray().toString());
        return workflowIdList;
    }

    @Override
    public void testEnable(String workflowId) {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("id", workflowId);
        restTemplate.put(frmsProps.getBaseUri().concat(frmsProps.getEndpoint().getStartWorkflow()), null, params);
    }

    @Override
    public WorkflowExecutionStatusSearchResponse searchWorkflowExec(String workflowId) {
        FrmsWorkflowFilter filter = new FrmsWorkflowFilter();
        filter.setWorkflowId(workflowId);
        filter.setExecStatus(FrmsExecutionStatus.Completed);

        WorkflowExecutionStatusSearchParams params = new WorkflowExecutionStatusSearchParams();
        params.setFilter(filter);
        params.setSortingName("StartDate");
        params.setSortingOrder("Desc");
        params.setRecordsCount(0L);

        HttpEntity<WorkflowExecutionStatusSearchParams> request = new HttpEntity<>(params);

        return restTemplate.postForObject(
                frmsProps.getBaseUri().concat(frmsProps.getEndpoint().getWorkflowExecutionStatusSearch()),
                request,
                WorkflowExecutionStatusSearchResponse.class);
    }

    @Override
    public WorkflowSearchResponse workflowExecStatus(String workflowId) {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("id", workflowId);
        return restTemplate.getForObject(frmsProps.getBaseUri().concat(frmsProps.getEndpoint().getWorkflowExecutionStatus()), WorkflowSearchResponse.class, params);
    }
}
