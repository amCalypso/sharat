package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DvIndivPhoneComparer implements Comparable<DvIndivPhoneComparer> {
    private String phoneNbr;
    private String brandCd;
    private Long indivId;

    @Override
    public int compareTo(DvIndivPhoneComparer o) {
        return phoneNbr.compareToIgnoreCase(o.getPhoneNbr());

    }
}
