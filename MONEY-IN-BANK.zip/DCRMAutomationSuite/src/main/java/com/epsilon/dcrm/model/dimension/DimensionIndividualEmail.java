package com.epsilon.dcrm.model.dimension;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_individual_email table.
 * @author adomakonda
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "d_individual_email", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionIndividualEmail {

    @Id
    @Column(name = "dcrm_indiv_email_id")
    private Long dcrmIndivEmailId;

    @Column(name = "email_addr")
    private String emailAddr;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "acct_src_cd")
    private String acctSrcCd;

    @Column(name = "valid_ind")
    private String validInd;

    @Column(name = "create_file_id")
    private Long createFileId;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;

    @Column(name = "indiv_id")
    private Long indivId;

}
