package com.epsilon.dcrm.objects.comparer;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class DvTransactionTenderComparer implements Comparable<DvTransactionTenderComparer> {
    private String brandCd;

    private Long dcrmTxnId;

    private Long tenderSeqNbr;

    private Date tenderDt;

    private String tenderTypeCd;

    private String tenderSubTypeCd;

    private Double tenderAmt;

    private String surrogateNbr;

    private String swipeFirstNm;

    private String swipeLastNm;

    private Timestamp txnTs;

    private Long hHoldId;

    private Long indivId;

    @Override
    public int compareTo(DvTransactionTenderComparer o) {
        String o1Key = new StringBuilder()
                .append(tenderSeqNbr)
                .append(brandCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getTenderSeqNbr())
                .append(o.getBrandCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
