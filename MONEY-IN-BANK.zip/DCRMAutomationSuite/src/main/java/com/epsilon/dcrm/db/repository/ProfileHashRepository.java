package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.ProfileHash;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface ProfileHashRepository extends BaseRepository<ProfileHash, Integer> {

    ProfileHash findBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(String srcBrandCd, String acctSrcCd, String srcAcctNbr);

    ProfileHash findBySrcBrandCdAndAcctSrcCdAndPiiHashVal(String srcBrandCd, String acctSrcCd, String piiHashVal);

    Long deleteByPiiHashVal(String piiHashVal);
    
    Long deleteBySrcBrandCdAndAcctSrcCdAndSrcAcctNbr(String srcBrandCd, String acctSrcCd, String srcAcctNbr);
}
