package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionLocation;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DLocationRepository extends JpaRepository<DimensionLocation, String> {

    List<DimensionLocation> findByBrandCd(String brandCd);

    List<DimensionLocation> findByBrandCdAndLocationCd(String brandCd, String locationCd);

    Long deleteByBrandCdAndLocationCd(String brandCd, String locationCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_location"
            + "(location_cd, location_nm, location_type_dsc, create_file_id, create_rec_nbr, create_ts,brand_cd)"
            + "VALUES(?1, ?2, 'AA',?3,?4,getdate(),?5);", nativeQuery = true)
    void insertSimpleTestRecord(String locationCd, String locationNm, Long createFileID, Long createRecNbr, String brandCd);

    Long deleteByBrandCd(String brandCd);

    List<DimensionLocation> findByLocationCd(String fulfillLocationNbr);

}