package com.epsilon.dcrm.model.standard;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.RefRecencyId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_ref_recency table.
 * @author gwalia
 *
 */
@Entity
@IdClass(RefRecencyId.class)
@Table(name = "s_ref_recency", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardRefRecency {

    @Id
    @Column(name = "recency_cd")
    private String recencyCd;

    @Column(name = "recency_nm")
    private String recencyNm;

    @Column(name = "recency_dsc")
    private String recencyDsc;

    @Column(name = "range_min_val")
    private Long rangeMinVal;

    @Column(name = "range_max_val")
    private Long rangeMaxVal;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

}
