package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.RefCustLifeCycleId;
import com.epsilon.dcrm.model.standard.StandardRefCustLifeCycle;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface SRefCustLifeCycleRepository extends StandardRepository<StandardRefCustLifeCycle, RefCustLifeCycleId> {

}
