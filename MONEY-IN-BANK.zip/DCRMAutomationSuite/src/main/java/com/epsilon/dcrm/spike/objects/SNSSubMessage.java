package com.epsilon.dcrm.spike.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SNSSubMessage {

    @JsonProperty("Type")
    private String topic;

    @JsonProperty("key_info")
    private SNSKeyInfo keyInfo;

    @JsonProperty("event_ts_epoch")
    private long eventTsEpoch;

    @JsonProperty("event_type")
    private String eventType;

    @JsonProperty("event_status")
    private String eventStatus;

    private String[] tags;

    @JsonProperty("src_system")
    private SNSSrcSystem srcSystem;

}
