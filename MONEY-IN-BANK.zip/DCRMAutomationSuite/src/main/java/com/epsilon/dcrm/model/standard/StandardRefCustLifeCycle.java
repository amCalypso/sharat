package com.epsilon.dcrm.model.standard;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.RefCustLifeCycleId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the s_ref_cust_lifecycle table.
 * @author Mohan
 *
 */
@Entity
@IdClass(RefCustLifeCycleId.class)
@Table(name = "s_ref_customer_lifecycle", schema = "test_pre_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardRefCustLifeCycle {

    @Id
    @Column(name = "cust_lifecycle_cd")
    private String custLifeCycleCd;;

    @Column(name = "cust_lifecycle_nm")
    private String custLifeCycleNm;

    @Column(name = "cust_lifecycle_dsc")
    private String custLifeCycleDsc;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createRecNbr;

}
