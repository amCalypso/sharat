package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = Include.NON_NULL)
public class KeyInfo {
    @JsonProperty(value = "file_name")
    private String fileName;
    @JsonProperty(value = "file_ts")
    private String fileTs;
    @JsonProperty(value = "file_id")
    private String fileId;
    @JsonProperty(value = "targetTable")
    private String targetTable;
}
