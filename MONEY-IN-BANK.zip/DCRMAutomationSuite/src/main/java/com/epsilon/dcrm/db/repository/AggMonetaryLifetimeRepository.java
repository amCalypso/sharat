package com.epsilon.dcrm.db.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.AggMonetaryLifetime;
import com.epsilon.dcrm.model.id.AggMonetaryId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface AggMonetaryLifetimeRepository extends BaseRepository<AggMonetaryLifetime, AggMonetaryId> {
    List<AggMonetaryLifetime> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);

    List<AggMonetaryLifetime> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.agg_monetary_lifetime"
            + "(indiv_id, brand_cd, lifetime_frequency_cnt, lifetime_gross_amt, lifetime_discount_amt, lifetime_return_amt, lifetime_cancel_amt,  orig_txn_dt, last_txn_dt)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String brandCd,
            Long lifetimeFrequencyCnt, Double lifetimeGrossAmt,
            Double lifetimeDiscountAmt, Double lifetimeReturnAmt,
            Double lifetimeCancelAmt, Date origTxnDt, Date lastTxnDt);

}
