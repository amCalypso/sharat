package com.epsilon.dcrm.model.loyalty;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AggregationDetail extends BaseModel {
    private String aggregationId;
    private String sourceTableId;
    private String targetSchema;
    private String targetSqlTableName;
    private List<Aggregate> aggregates;
    private List<GroupByColumn> groupByColumns;
}
