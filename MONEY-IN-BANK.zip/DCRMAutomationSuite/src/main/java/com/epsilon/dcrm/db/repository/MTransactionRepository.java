package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MTransaction;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MTransactionRepository extends BaseRepository<MTransaction, String> {

    Long deleteByBrandCd(String brandCd);

    Long deleteByTxnNbr(String txnNbr);

    List<MTransaction> findByBrandCd(String brandCd);

    List<MTransaction> findByTxnNbr(String txnNbr);
}
