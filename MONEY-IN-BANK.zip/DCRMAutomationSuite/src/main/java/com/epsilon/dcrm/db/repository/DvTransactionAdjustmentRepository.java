package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DvTransactionAdjustment;
import com.epsilon.dcrm.model.id.DvTransactionAdjustmentId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DvTransactionAdjustmentRepository extends BaseRepository<DvTransactionAdjustment, DvTransactionAdjustmentId> {
    List<DvTransactionAdjustment> findByBrandCd(String brandCd);

    Long deleteByBrandCd(String brandCd);
}
