package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.mart.MetadataSource;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface MetadataSourceRepository extends JpaRepository<MetadataSource, String> {

    List<MetadataSource> findByBrandCd(String brandCd);

    List<MetadataSource> findByIndivId(String indivId);

    List<MetadataSource> findByRowIdIn(List<String> rowIds);

}
