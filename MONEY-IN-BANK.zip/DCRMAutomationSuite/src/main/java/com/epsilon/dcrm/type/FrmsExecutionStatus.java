package com.epsilon.dcrm.type;

public enum FrmsExecutionStatus {
    Running,
    Completed,
    Failed,
    Pending,
    Cancelled
}