package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.RefPurchaseChannelId;
import com.epsilon.dcrm.model.standard.StandardRefPurchaseChannel;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface SRefPurchaseChannelRepository extends StandardRepository<StandardRefPurchaseChannel, RefPurchaseChannelId> {

}
