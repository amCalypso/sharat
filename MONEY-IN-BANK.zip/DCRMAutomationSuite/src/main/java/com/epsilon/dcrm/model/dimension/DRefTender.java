package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.DRefTenderId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_ref_tender table.
 * @author dvelayudhannair
 *
 */
@Entity
@IdClass(DRefTenderId.class)
@Table(name = "d_ref_tender", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DRefTender {

    @Id
    @Column(name = "tender_subtype_cd")
    private String tenderSubTypeCd;

    @Column(name = "tender_subtype_dsc")
    private String tenderSubTypeDsc;

    @Id
    @Column(name = "tender_type_cd")
    private String tenderTypeCd;

    @Column(name = "tender_type_dsc")
    private String tenderTypeDsc;

    @Id
    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_ts")
    private Timestamp updateTs;

}
