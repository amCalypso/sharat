package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.id.ProfileId;
import com.epsilon.dcrm.model.standard.StandardProfile;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface SProfileRepository extends StandardRepository<StandardProfile, ProfileId> {
    Long deleteByAcctSrcNbr(String acctSrcNbr);
}
