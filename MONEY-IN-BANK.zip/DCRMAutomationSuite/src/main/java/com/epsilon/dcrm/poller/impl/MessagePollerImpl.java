package com.epsilon.dcrm.poller.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.model.Message;
import com.epsilon.dcrm.constants.CommonConstants;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.objects.FrmsWorkflowAttributes;
import com.epsilon.dcrm.objects.MatillionWorkflowAttributes;
import com.epsilon.dcrm.objects.MessageDetails;
import com.epsilon.dcrm.objects.SQSMessage;
import com.epsilon.dcrm.objects.WorkflowSearchResponse;
import com.epsilon.dcrm.poller.MessagePoller;
import com.epsilon.dcrm.service.FrmsService;
import com.epsilon.dcrm.service.SQSService;
import com.epsilon.dcrm.type.ProcessErrorCode;
import com.epsilon.dcrm.util.JsonUtil;
import com.epsilon.dcrm.util.TestUtil;

@Service
public class MessagePollerImpl implements MessagePoller {

    private static final Logger logger = LoggerFactory.getLogger(MessagePollerImpl.class);

    @Autowired
    private FrmsService frmsService;

    @Autowired
    private SQSService sqsService;

    @Value("${transaction.polling.time}")
    private int pollingTime;

    private static final String EVENT_TYPE_COMPLETE = "COMPLETE";
    private static final int SLEEP_TIME = 15000;

    @Override
    public List<MessageDetails> pollFrmsMessages(String fileName, String jobName, String env, String queueUrl, int maxAttempts) throws ApplicationException {
        int waitTimeBetweenPolls = 0;
        List<MessageDetails> messageDetails = new ArrayList<MessageDetails>();
        List<Message> messages = null;
        String lastEventType = null;
        String lastWorkflowId = null;
        long startTime = System.currentTimeMillis();
        try {
            while (maxAttempts > 0) {
                messages = sqsService.pollSQSMessages(queueUrl, waitTimeBetweenPolls);
                if (messages != null) {
                    for (Message msg : messages) {
                        SQSMessage sqsMessage = (SQSMessage) JsonUtil.getObject(msg.getBody(), SQSMessage.class);
                        if (sqsMessage != null && sqsMessage.getMessage() != null) {
                            MessageDetails msgDetails = (MessageDetails) JsonUtil.getObject(sqsMessage.getMessage(), MessageDetails.class);
                            if (msgDetails != null && fileName.equals(msgDetails.getKeyInfo().getFileName()) && jobName.equals(msgDetails.getSrcSystem().getName()) && env.equals(msgDetails.getSrcSystem().getEnvLoc())) {
                                messageDetails.add(msgDetails);
                                FrmsWorkflowAttributes frmsAttribute = (FrmsWorkflowAttributes) JsonUtil.getObject(msgDetails.getSrcSystem().getData(), FrmsWorkflowAttributes.class);
                                lastEventType = msgDetails.getEventType();
                                lastWorkflowId = frmsAttribute.getWorkflowExecId();
                                startTime = System.currentTimeMillis();
                                sqsService.deleteSqsMsg(queueUrl, msg);
                                if (EVENT_TYPE_COMPLETE.equals(lastEventType)) {
                                    return messageDetails;
                                }
                            }
                        }
                    }
                }
                maxAttempts--;

                if ((maxAttempts == 0 || (System.currentTimeMillis() - startTime) >= pollingTime) && null != lastWorkflowId) {
                    if (!CommonConstants.ENV_AWS.equals(env)) { // TODO - Remove once the AWS APIs can be invoked locally
                        boolean resetAttempts = false;
                        WorkflowSearchResponse res = frmsService.workflowExecStatus(lastWorkflowId);
                        logger.info("FRMS workflow response - {} for filename -{}, workflowId - {}, lasteventType - %s", JsonUtil.getJson(res), fileName, lastWorkflowId, lastEventType);
                        if (res == null || res.getExecStatus() == null) {
                            resetAttempts = true;
                        } else {
                            switch (res.getExecStatus()) {
                                case Completed:
                                    if (EVENT_TYPE_COMPLETE.equals(lastEventType)) {
                                        return messageDetails;
                                    }
                                    resetAttempts = true;
                                    break;
                                case Pending:
                                case Running:
                                    resetAttempts = true;
                                    break;
                                default:
                                    String errorMesssage = String.format("***FAILED*** FRMS workflow failed for filename -%s, env - %s, workflowname - %s, workflowExecId = %s", fileName, env, res.getWorkflowName(), res.getWorkflowExecId());
                                    logger.error(errorMesssage);
                                    throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, errorMesssage);
                            }
                        }
                        if (resetAttempts) {
                            maxAttempts = 5;
                            //    startTime = System.currentTimeMillis();
                        }
                    }
                }
                if (maxAttempts > 0) {
                    TestUtil.sleep(SLEEP_TIME);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Exception : {}", e.toString());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        String errorMesssage = String.format("***FAILED*** SQS poller timed out for filename -%s, env - %s, jobname - %s", fileName, env, jobName);
        logger.error(errorMesssage);
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, errorMesssage);
    }

    @Override
    public MessageDetails pollMatillionMessage(String fileName, String jobName, String queueUrl, int maxAttempts) throws ApplicationException {
        int waitTimeBetweenPolls = 0;
        List<Message> messages = null;
        try {
            while (maxAttempts > 0) {
                messages = sqsService.pollSQSMessages(queueUrl, waitTimeBetweenPolls);
                if (messages != null) {
                    for (Message msg : messages) {
                        SQSMessage sqsMessage = (SQSMessage) JsonUtil.getObject(msg.getBody(), SQSMessage.class);
                        if (sqsMessage != null && sqsMessage.getMessage() != null) {
                            MessageDetails msgDetails = (MessageDetails) JsonUtil.getObject(sqsMessage.getMessage(), MessageDetails.class);
                            if (msgDetails != null && fileName.equals(msgDetails.getKeyInfo().getFileName())) {
                                MatillionWorkflowAttributes attributes = JsonUtil.getObject(msgDetails.getSrcSystem().getData(), MatillionWorkflowAttributes.class);
                                if (attributes != null && jobName.equals(attributes.getJobName())) {
                                    sqsService.deleteSqsMsg(queueUrl, msg);
                                    return msgDetails;
                                }
                            }
                        }
                    }
                }
                maxAttempts--;
                TestUtil.sleep(SLEEP_TIME);
            }
        } catch (Exception e) {
            logger.error("Exception : {}", e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        logger.error("****FAILED****  - SQS poller timed out");
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, String.format("****FAILED****  - SQS poller timed out"));
    }

    // Adding special poller for Metadata messages. This is a quick fix until we refactor the SQS handling.
    @Override
    public MessageDetails pollMatillionMetadataMessage(String tableName, String jobName, String queueUrl, int maxAttempts) throws ApplicationException {
        int waitTimeBetweenPolls = 0;
        List<Message> messages = null;
        try {
            while (maxAttempts > 0) {
                messages = sqsService.pollSQSMessages(queueUrl, waitTimeBetweenPolls);
                if (messages != null) {
                    for (Message msg : messages) {
                        SQSMessage sqsMessage = (SQSMessage) JsonUtil.getObject(msg.getBody(), SQSMessage.class);
                        if (sqsMessage != null && sqsMessage.getMessage() != null) {
                            MessageDetails msgDetails = (MessageDetails) JsonUtil.getObject(sqsMessage.getMessage(), MessageDetails.class);
                            if (msgDetails != null && tableName.equals(msgDetails.getKeyInfo().getTargetTable())) {
                                MatillionWorkflowAttributes attributes = JsonUtil.getObject(msgDetails.getSrcSystem().getData(), MatillionWorkflowAttributes.class);
                                if (attributes != null && jobName.equals(attributes.getJobName())) {
                                    sqsService.deleteSqsMsg(queueUrl, msg);
                                    return msgDetails;
                                }
                            }
                        }
                    }
                }
                maxAttempts--;
                TestUtil.sleep(SLEEP_TIME);
            }
        } catch (Exception e) {
            logger.error("Exception : {}", e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        logger.error("****FAILED****  - SQS poller timed out");
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, String.format("****FAILED****  - SQS poller timed out"));
    }

}