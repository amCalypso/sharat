package com.epsilon.dcrm.db.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionRefCustLifeCycle;
import com.epsilon.dcrm.model.id.RefCustLifeCycleId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DRefCustLifeCycleRepository extends StandardRepository<DimensionRefCustLifeCycle, RefCustLifeCycleId> {

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_ref_customer_lifecycle"
            + "(cust_lifecycle_cd, cust_lifecycle_nm, cust_lifecycle_dsc, create_ts, create_file_id, create_rec_nbr)"
            + "VALUES(?1, ?2, ?3, getdate(), ?4, ?5);", nativeQuery = true)
    void insertTestData(String custLifeCycleCd, String custLifeCycleNm, String custLifeCycleDsc, Long createFileId, Long createRecNbr);

}