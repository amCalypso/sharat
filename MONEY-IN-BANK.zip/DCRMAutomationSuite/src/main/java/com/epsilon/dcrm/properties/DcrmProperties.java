package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("dcrm.api")
public class DcrmProperties {
    private String dcrmUri;
    private String s3Path;
    private Endpoint endpoint;

    @Data
    public static class Endpoint {
        private String enable;
        private String disable;
    }
}
