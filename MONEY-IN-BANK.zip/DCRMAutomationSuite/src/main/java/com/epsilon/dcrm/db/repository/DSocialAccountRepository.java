package com.epsilon.dcrm.db.repository;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionSocialAccount;
import com.epsilon.dcrm.model.id.SocialAccountId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DSocialAccountRepository extends DimensionRepository<DimensionSocialAccount, SocialAccountId> {
    Long deleteBySocialMediaAcctId(String socialMediaAcctId);
}
