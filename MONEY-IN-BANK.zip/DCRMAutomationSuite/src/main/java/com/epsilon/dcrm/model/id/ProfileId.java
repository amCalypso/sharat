package com.epsilon.dcrm.model.id;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

/**
 * This is the IDClass for the s_  and d_ profile table.
 * @author dvelayudhannair
 * Adding create_file_* columns to ID. This is because JPA enforces primary keys and Redshift doesnot.
 * Also, the s_profile tables can have duplicate data for brand/acctSrcCd/acctSrcNbr combo. Hence to 
 * UNIQUELY identify a record using JPA, adding these fields as part of ID.
 * Thus solving issues we face while deleting. Many a times we get exception when multiple
 * records are found for same key combo.
 */
@Data
public class ProfileId implements Serializable {

    private static final long serialVersionUID = -9074937427420567374L;
    private String brandCd;
    private String acctSrcCd;
    private String acctSrcNbr;
    private Timestamp activityTs;
    private Long createFileId;
    private Long createFileRecNbr;
}
