package com.epsilon.dcrm.model.dimension;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.epsilon.dcrm.model.id.TransactionCertificateId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the d_transaction_certificate table.
 * @author kkapoor
 *
 */
@Entity
@IdClass(TransactionCertificateId.class)
@Table(name = "d_transaction_certificate", schema = "test_crm_warehouse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionTransactionCertificate {

    @Id
    @Column(name = "txn_brand_cd")
    private String brandCd;

    @Id
    @Column(name = "txn_nbr")
    private String txnNbr;

    @Id
    @Column(name = "txn_src_cd")
    private String txnSrcCd;

    @Id
    @Column(name = "cert_nbr")
    private String certNbr;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "cert_status_cd")
    private String certStatusCd;

    @Column(name = "activity_ts")
    private Timestamp activityTs;

    @Id
    @Column(name = "create_file_id")
    private Long createFileId;

    @Id
    @Column(name = "create_rec_nbr")
    private Long createFileRecNbr;

    @Column(name = "create_ts")
    private Timestamp createTs;

    @Column(name = "update_file_id")
    private Long updateFileId;

    @Column(name = "update_rec_nbr")
    private Long updateFileRecNbr;

    @Column(name = "update_ts")
    private Timestamp updateTs;
}
