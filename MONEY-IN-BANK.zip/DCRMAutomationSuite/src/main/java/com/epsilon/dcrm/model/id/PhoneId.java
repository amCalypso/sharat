package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the d_phone table.
 * @author adomakonda
 *
 */
@Data
public class PhoneId implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String phoneNum;

    private String countryCd;
    
    private Long createFileId;

    private Long createFileRecNbr;

}
