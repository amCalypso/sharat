package com.epsilon.dcrm.service;

import java.util.List;

import com.amazonaws.services.sqs.model.Message;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.objects.CopyMessage;

public interface SQSService {
    CopyMessage pollSQS(String jobName) throws ApplicationException;

    <T> void postMessageToSQS(T sqsMessage, String queueUrl);

    void deleteSqsMsg(String queueUrl, Message msg);

    List<Message> pollSQSMessages(String queueUrl, int waitTimeBetweenPolls);

    <T> T pollSQS(Class<T> beanClazz, String jobName, String taskId, String queueUrl, int maxAttempts, int waitTimeBetweenPolls) throws ApplicationException;
}
