package com.epsilon.dcrm.util;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;

@Component
public class CSVUtil {

    private static final Logger logger = LoggerFactory.getLogger(CSVUtil.class);

    public static <T> List<T> readStaticFile(Class<T> tClazz, String filePath, boolean firstLineHeader) throws IOException {

        // Build reader instance
        // Read data.csv
        // Default seperator is comma
        // Default quote character is double quote
        // Start reading from line number 2 (line numbers start from zero)
        int lineStartNum = firstLineHeader == true ? 1 : 0;
        CSVReader reader = new CSVReader(new InputStreamReader(CSVUtil.class.getResourceAsStream(filePath)), ',',
                '"', lineStartNum);

        Field[] fields = tClazz.getDeclaredFields();
        String[] columns = new String[fields.length];
        for (int index = 0; index < fields.length; index++) {
            columns[index] = fields[index].getName();
        }

        ColumnPositionMappingStrategy<T> strat = new ColumnPositionMappingStrategy<T>();
        strat.setColumnMapping(columns);
        strat.setType(tClazz);
        CsvToBean<T> csv = new CsvToBean<T>();
        List<T> list = csv.parse(strat, reader);
        reader.close();
        return list;
    }

    public static <T> List<T> readDynamicFile(Class<T> tClazz, String filePath, boolean firstLineHeader) throws IOException {

        // Build reader instance
        // Read data.csv
        // Default seperator is comma
        // Default quote character is double quote
        // Start reading from line number 2 (line numbers start from zero)
        int lineStartNum = firstLineHeader == true ? 1 : 0;
        CSVReader reader = new CSVReader(new FileReader(filePath), ',',
                '"', lineStartNum);

        Field[] fields = tClazz.getDeclaredFields();
        String[] columns = new String[fields.length];
        for (int index = 0; index < fields.length; index++) {
            columns[index] = fields[index].getName();
        }

        ColumnPositionMappingStrategy<T> strat = new ColumnPositionMappingStrategy<T>();
        strat.setColumnMapping(columns);
        strat.setType(tClazz);
        CsvToBean<T> csv = new CsvToBean<T>();
        List<T> list = csv.parse(strat, reader);
        reader.close();
        return list;
    }

    public static void writeFile(String header, String filename, String... records) throws IOException {
        CSVWriter writer = new CSVWriter(new FileWriter(filename));

        if (StringUtils.isNotBlank(header)) {
            writer.writeNext(header.split(","));
        }
        for (String record : records) {
            //Write the record to file
            writer.writeNext(record.split(","));
        }
        //close the writer
        writer.close();
    }

    public static CsvMapper getMapper() {
        CsvMapper mapper = new CsvMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, false);
        return mapper;
    }

    public static <T> String getCsv(List<T> object) {
        CsvMapper mapper = getMapper();
        CsvSchema schema = mapper.schemaFor(object.get(0).getClass()).withHeader();
        String csv = null;
        try {
            csv = mapper.writer(schema).writeValueAsString(object);
        } catch (Exception e) {
            logger.error("Failed to convert Object to String.", e);
        }
        return csv;
    }

    public static <T> T getObject(String csvString, Class<T> clazz) throws IOException {
        CsvMapper mapper = getMapper();
        CsvSchema schema = mapper.schemaFor(clazz);
        return mapper.readerFor(clazz).with(schema).readValue(csvString);
    }

}

/**
 * {
            protected Object convertValue(String value, PropertyDescriptor prop) throws InstantiationException, IllegalAccessException {
                if (StringUtils.isEmpty(value)) {
                    value = null;
                }
                return super.convertValue(value, prop);
            }
        }
 */
