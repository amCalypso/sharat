package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionEmployeeComparer implements Comparable<DimensionEmployeeComparer> {
    private String employeeId;
    private String brandCd;
    private String srcGenderCd;
    private String srcNamePrefix;
    private String srcFirstNm;
    private String srcMiddleNm;
    private String srcLastNm;
    private String srcNameSuffix;
    private String srcUnparsedNm;
    private String homeAddrLine1;
    private String homeAddrLine2;
    private String homeAddrLine3;
    private String homeAddrLine4;
    private String homeCityNm;
    private String homeStateCd;
    private String homePostalCd;
    private String homeCountry;
    private String homeIsoCountryNm;
    private String employmentStartDt;
    private String employmentEndDt;
    private String roleNm;
    private String assignedLocation1Cd;
    private String assignedLocation2Cd;
    private String assignedLocation3Cd;
    private String employmentStatusCd;
    private String activityTs;

    @Override
    public int compareTo(DimensionEmployeeComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(employeeId)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getEmployeeId())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
