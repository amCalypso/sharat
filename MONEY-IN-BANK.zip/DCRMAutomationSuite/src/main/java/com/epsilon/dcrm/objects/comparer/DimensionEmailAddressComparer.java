package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionEmailAddressComparer implements Comparable<DimensionEmailAddressComparer> {
    private String emailAddr;

    @Override
    public int compareTo(DimensionEmailAddressComparer o) {
        return emailAddr.compareToIgnoreCase(o.getEmailAddr());
    }
}
