package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the d_individual_golden_profile table.
 * @author adomakonda
 *
 */
@Data
public class IndividualGoldenProfileId implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Long indivId;

    private String brandCd;

}
