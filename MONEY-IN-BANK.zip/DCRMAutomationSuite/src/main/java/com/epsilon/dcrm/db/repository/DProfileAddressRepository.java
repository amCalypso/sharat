package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProfileAddress;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProfileAddressRepository extends DimensionRepository<DimensionProfileAddress, Long> {

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_profile_address"
            + "(indiv_id, ga_id,brand_cd,acct_src_cd, src_acct_nbr,active_addr_ind,create_file_id, create_rec_nbr,create_ts,update_file_id,update_rec_nbr,update_ts)"
            + "VALUES(?1, ?2, ?3, ?4,?5,'Y',?6,?7,getdate(),?6,?7,getdate());", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, Long gaId, String brandCd, String acctSrcCd, String srcAcctNbr, Long fileId, Long recNbr);

    Long deleteByBrandCd(String brandCd);

    List<DimensionProfileAddress> findByIndivId(long indivId);

    @Query(value = "SELECT * FROM test_crm_warehouse.d_profile_address where brand_cd = (?2)"
            + " AND acct_src_cd = (?3) AND src_acct_nbr = (?4) AND active_addr_ind = (?1);", nativeQuery = true)
    List<DimensionProfileAddress> selectActiveProfileAddressRecords(String activeAddrInd, String brandCd, String acctSrcCd, String acctSrcNbr);

}
