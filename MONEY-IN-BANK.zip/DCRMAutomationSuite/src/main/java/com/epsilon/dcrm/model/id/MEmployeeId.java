package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the m_employee table.
 * @author gwalia
 *
 */
@Data
public class MEmployeeId implements Serializable {
    private static final long serialVersionUID = 1L;
    private String brandCd;
    private String employeeId;

}
