package com.epsilon.dcrm.model.mart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This is the entity class for the m_ref_monetary table.
 * @author dvelayudhannair
 *
 */
@Entity
@Table(name = "m_ref_monetary", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MRefMonetary {

    @Id
    @Column(name = "monetary_cd")
    private String monetaryCd;

    @Column(name = "monetary_nm")
    private String monetaryNm;

    @Column(name = "monetary_dsc")
    private String monetaryDsc;

    @Column(name = "range_min_val")
    private Double rangeMinVal;

    @Column(name = "range_max_val")
    private Double rangeMaxVal;

}
