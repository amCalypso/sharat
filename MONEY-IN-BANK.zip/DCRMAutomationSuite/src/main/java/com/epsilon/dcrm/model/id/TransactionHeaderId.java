package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_transaction_header table.
 * @author jblasingame
 * Adding create_file_* columns to ID. This is because JPA enforces primary keys and Redshift doesnot.
 * Also, the s_profile tables can have duplicate data for brand/acctSrcCd/acctSrcNbr combo. Hence to 
 * UNIQUELY identify a record using JPA, adding these fields as part of ID.
 * Thus solving issues we face while deleting. Many a times we get exception when multiple
 * records are found for same key combo.
 */
@Data
public class TransactionHeaderId implements Serializable {
    private static final long serialVersionUID = -203914156853051960L;

    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private Long createFileId;
    private Long createRecNbr;
}
