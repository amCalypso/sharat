package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DvIndivAddrComparer implements Comparable<DvIndivAddrComparer> {
    private Long dcrmIndivAddrId;
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String cityNm;
    private String stateNm;
    private String postalCd;
    private String zip4;
    private String countryCd;
    private Long gaId;
    private Long indivId;
    private String brandCd;

    @Override
    public int compareTo(DvIndivAddrComparer o) {
        String o1Key = new StringBuilder()
                .append(dcrmIndivAddrId)
                .append(brandCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getDcrmIndivAddrId())
                .append(o.getBrandCd())
                .toString();
        return o1Key.compareToIgnoreCase(o2Key);
    }
}
