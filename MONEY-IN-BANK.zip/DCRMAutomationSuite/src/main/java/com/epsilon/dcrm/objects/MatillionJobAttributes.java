package com.epsilon.dcrm.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MatillionJobAttributes {

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("rows_inserted")
    private int rowsInserted;

    @JsonProperty("rows_updated")
    private int rowsUpdated;

    @JsonProperty("start_time")
    private String startTime;

    @JsonProperty("end_time")
    private String endTime;

    private String duration;
}
