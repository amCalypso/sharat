package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionAdjustment standard feed
 * 
 * @author adomakonda
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionAdjustment implements Comparable<TransactionAdjustment> {
    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnLineNbr;
    private String adjustSeqNbr;
    private String txnDt;
    private String adjustDt;
    private String adjustAmt;
    private String adjustTypeCd;
    private String adjustSubtypeCd;
    private String discountCd;
    private String barcode;
    private String ringCd;
    private String couponCd;
    private String activityTs;

    @Override
    public int compareTo(TransactionAdjustment o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(txnNbr)
                .append(txnLineNbr)
                .append(adjustSeqNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTxnNbr())
                .append(o.getTxnLineNbr())
                .append(o.getAdjustSeqNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
