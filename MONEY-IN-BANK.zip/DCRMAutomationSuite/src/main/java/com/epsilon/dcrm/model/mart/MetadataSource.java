package com.epsilon.dcrm.model.mart;

import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This represents the source table used for all Metadata Aggregate requests.
 * @author jblasingame
 *
 */
@Entity
@Cacheable(value = false)
@Table(name = "metadata_source", schema = "test_crm_mart_passive")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MetadataSource implements Comparable<MetadataSource> {

    @Id
    @Column(name = "row_id")
    private String rowId;

    @Column(name = "txn_ts")
    private Timestamp txnTs;

    @Column(name = "indiv_id")
    private Long indivId;

    @Column(name = "brand_cd")
    private String brandCd;

    @Column(name = "purch_txn_amt")
    private Double purchTxnAmt;

    @Override
    public int compareTo(MetadataSource o) {
        return rowId.compareTo(o.getRowId());
    }
}
