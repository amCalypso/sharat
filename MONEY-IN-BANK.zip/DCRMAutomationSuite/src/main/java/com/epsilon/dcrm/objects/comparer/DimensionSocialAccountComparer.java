package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionSocialAccountComparer implements Comparable<DimensionSocialAccountComparer> {
    private String socialMediaAcctId;
    private String socialMediaCd;

    @Override
    public int compareTo(DimensionSocialAccountComparer o) {
        String o1Key = new StringBuilder()
                .append(socialMediaAcctId)
                .append(socialMediaCd)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getSocialMediaAcctId())
                .append(o.getSocialMediaCd())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
