package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionIndividualEmail;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DIndividualEmailRepository extends DimensionRepository<DimensionIndividualEmail, String> {
    List<DimensionIndividualEmail> findByDcrmIndivEmailId(Long dcrmIndivEmailId);

    Long deleteByDcrmIndivEmailId(Long dcrmIndivEmailId);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_individual_email"
            + "(indiv_id, email_addr, valid_ind, active_addr_ind, brand_cd, acct_src_cd, update_file_id, update_ts)"
            + "VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, getdate())", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String emailAddr,
            String validInd, String activeAddrInd, String brandCd,
            String acctSrcCd, Long updateFileId);

}
