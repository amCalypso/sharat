package com.epsilon.dcrm.objects.csv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The property order should match the order in the csv data file.
 * This serves the TransactionTender standard feed
 * 
 * @author jblasingame
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionTender implements Comparable<TransactionTender> {
    private String txnNbr;
    private String txnSrcCd;
    private String brandCd;
    private String txnTs;
    private String tenderSeqNbr;
    private String tenderDt;
    private String tenderTypeCd;
    private String tenderSubTypeCd;
    private String tenderAmt;
    private String surrogateNbr;
    private String swipeFirstNm;
    private String swipeLastNm;
    private String activityDt;

    @Override
    public int compareTo(TransactionTender o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(tenderSeqNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTenderSeqNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
