package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the d_ product_catalog table.
 * @author Mohan
 */
@Data
public class ProductCatalogId implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sku;

    private Long createFileId;

    private Long createRecNbr;
}
