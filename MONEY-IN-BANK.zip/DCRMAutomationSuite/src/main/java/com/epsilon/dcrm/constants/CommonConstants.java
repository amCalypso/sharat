package com.epsilon.dcrm.constants;

public class CommonConstants {

    public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String MATILLION_SUCCESS_STATUS = "SUCCESS";
    public static final String MATILLION_SUCCESS_EVENT_STATUS = "COMPLETED";
    public static final String JOB_SRC_NAME_MATILLION = "MATILLION";
    public static final String JOB_SRC_NAME_FRMS = "FRMS";
    public static final String ENV_AWS = "AWS";
    public static final String ENV_LDC = "LDC";

    // Loyalty
    public static final String LOYALTY_ACTIVE_STATUS = "A";

    // FRMS workflow IDs
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_HEADER_WITH_PII = "119081";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_HEADER_WITHOUT_PII_UPDATE = "118264";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ITEM_WITH_PII = "119082";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ITEM_WITHOUT_PII_UPDATE = "117849";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_PROFILE = "118472";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_TENDER = "118146";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_ADJUSTMENT = "117967";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_TRANS_CERTIFICATE = "118018";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_PROFILE_ADDRESS_CHANGE = "119908";
    public static final String FRMS_WORKFLOW_ID_STANDARD_DATA_CONVERT_EMPLOYEE = "119851";
    public static final String FRMS_WORKFLOW_ID_DATA_CONVERT_REF_MONETARY = "122894";
    public static final String FRMS_WORKFLOW_ID_DATA_CONVERT_REF_RECENCY = "122897";
    public static final String FRMS_WORKFLOW_ID_DATA_CONVERT_REF_PURCHASE_CHANNEL = "122908";
    public static final String FRMS_WORKFLOW_ID_DATA_CONVERT_REF_FREQUENCY = "122895";
    public static final String FRMS_WORKFLOW_ID_DATA_CONVERT_REF_CUST_LIFECYCLE = "122955";

    public static final String WORKFLOW_STATUS_COMPLETED = "Completed";

    // Matillion Job Names
    public static final String MATILLION_JOB_NAME_REFRESH_TRANSACTION = "Refresh-D_TRANSACTION";
    public static final String MATILLION_JOB_NAME_REFRESH_PII = "Refresh-PII";
    public static final String MATILLION_JOB_NAME_REFRESH_TRANSACTION_ITEM = "Refresh-D_TRANSACTION_ITEM";
    public static final String MATILLION_JOB_NAME_LOAD_S_TRANSHDR_AND_S_PROFILE = "Load-S_TRANSACTION_HEADER-and-S_PROFILE";
    public static final String MATILLION_JOB_NAME_LOAD_S_TRANSITM_AND_S_PROFILE = "Load-S_TRANSACTION_ITEM-and-S_PROFILE";
    public static final String MATILLION_JOB_NAME_REFRESH_TRANSACTION_ADJUSTMENT = "Refresh-D_TRANSACTION_ADJUSTMENT";
    public static final String MATILLION_JOB_NAME_REFRESH_TRANSACTION_TENDER = "Refresh-D_TRANSACTION_TENDER";
    public static final String MATILLION_JOB_NAME_REFRESH_TRANSACTION_CERTIFICATE = "Refresh-D_TRANSACTION_CERTIFICATE";
    public static final String MATILLION_JOB_NAME_INVOKE_AGILITY_KEYING = "Invoke Agility Keying";
    public static final String MATILLION_JOB_NAME_REFRESH_PROFILE_ADDRESS_CHANGE = "Refresh-Profile-from-CPCOA";
    public static final String MATILLION_JOB_NAME_REFRESH_EMPLOYEE = "Refresh-D_EMPLOYEE";
    public static final String MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_SUMMARY = "Refresh-M_INDIVIDUAL_SUMMARY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_HOUSEHOLD_SUMMARY = "Refresh-M_HOUSEHOLD_SUMMARY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_EMPLOYEE = "Refresh-M_EMPLOYEE";
    public static final String MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_ADDRESS = "Refresh-M_INDIVIDUAL_ADDRESS";
    public static final String MATILLION_JOB_NAME_REFRESH_M_EMAIL = "Refresh-M_EMAIL";
    public static final String MATILLION_JOB_NAME_REFRESH_M_INDIVIDUAL_PHONE = "Refresh-M_PHONE";
    public static final String MATILLION_JOB_NAME_REFRESH_M_PROFILE = "Refresh-M_PROFILE";
    public static final String MATILLION_JOB_NAME_REFRESH_M_TRANSACTIONITEM = "Refresh-M_TRANSACTION_ITEM";
    public static final String MATILLION_JOB_NAME_REFRESH_M_TRANSACTION = "Refresh-M_TRANSACTION";
    public static final String MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_TENDER = "Refresh-M_TRANSACTION_TENDER";
    public static final String MATILLION_JOB_NAME_REFRESH_D_REF_MONETARY = "Refresh-D_REF_MONETARY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_TRANSACTION_ADJUSTMENT = "Refresh-M_TRANSACTION_ADJUSTMENT";
    public static final String MATILLION_JOB_NAME_REFRESH_M_REF_MONETARY = "Refresh-M_REF_MONETARY";
    public static final String MATILLION_JOB_NAME_REFRESH_D_REF_RECENCY = "Refresh-D_REF_RECENCY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_REF_RECENCY = "Refresh-M_REF_RECENCY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_REF_PURCHASE_CHANNEL = "Refresh-M_REF_PURCHASE_CHANNEL";
    public static final String MATILLION_JOB_NAME_REFRESH_D_REF_PURCHASE_CHANNEL = "Refresh-D_REF_PURCHASE_CHANNEL";
    public static final String MATILLION_JOB_NAME_REFRESH_D_REF_FREQUENCY = "Refresh-D_REF_FREQUENCY";
    public static final String MATILLION_JOB_NAME_REFRESH_M_REF_FREQUENCY = "Refresh-M_REF_FREQUENCY";
    public static final String MATILLION_JOB_NAME_METADATA_PROCESSOR = "Dataload-from-source-to-target";
    public static final String MATILLION_JOB_NAME_REFRESH_D_REF_CUSTOMER_LIFECYCLE = "Refresh-D_REF_CUSTOMER_LIFECYCLE";
    public static final String MATILLION_JOB_NAME_REFRESH_M_REF_CUSTOMER_LIFECYCLE = "Refresh-M_REF_CUSTOMER_LIFECYCLE";

    // DDL paths
    public static final String CREATE_TRANSACTION_HEADER_TABLE = "/dbScripts/TransactionHeader.ddl";
    public static final String CREATE_PROFILE_TABLES = "/dbScripts/ProfileAssociatedTables.ddl";
    public static final String CREATE_REFERENCE_TABLES = "/dbScripts/ReferenceTables.ddl";
    public static final String CREATE_HASH_TABLE = "/dbScripts/HashTable.ddl";
    public static final String REF_TABLE_DATA_LOAD = "/dbScripts/RefTableDataLoad.ddl";
    public static final String CREATE_TRANSACTION_ITEM_TABLES = "/dbScripts/TransactionItem.ddl";
    public static final String CREATE_TRANSACTION_TENDER_TABLES = "/dbScripts/TransactionTender.ddl";
    public static final String CREATE_TRANSACTION_ADJUSTMENT_TABLES = "/dbScripts/TransactionAdjustment.ddl";
    public static final String CREATE_TRANSACTION_CERTIFICATE_TABLES = "/dbScripts/TransactionCertificate.ddl";
    public static final String CREATE_PROFILE_ADDRESS_CHANGE_TABLES = "/dbScripts/ProfileAddressChange.ddl";
    public static final String CREATE_EMPLOYEE_TABLES = "/dbScripts/Employee.ddl";
    public static final String INDIVIDUAL_SUMMARY_TEST_DATA_LOAD = "/dbScripts/MIndividualSummaryTestDataLoad.ddl";
    public static final String CREATE_INDIVIDUAL_SUMMARY_TABLES = "/dbScripts/IndividualSummary.ddl";
    public static final String CREATE_D_INDIVIDUAL_TABLES = "/dbScripts/DIndivTables.ddl";
    public static final String HOUSEHOLD_SUMMARY_TEST_DATA_LOAD = "/dbScripts/MHouseholdSummaryTestDataLoad.ddl";
    public static final String CREATE_HOUSEHOLD_SUMMARY_TABLES = "/dbScripts/HouseholdSummary.ddl";
    public static final String M_EMPLOYEE_TEST_DATA_LOAD = "/dbScripts/MEmployeeTestDataLoad.ddl";
    public static final String INDIVIDUAL_ADDRESS_TEST_DATA_LOAD = "/dbScripts/MindividualAddressTestDataLoad.ddl";
    public static final String TRANSACTION_FEED_NEW_EMPLOYEE_TEST_DATA_LOAD = "/dbScripts/TransactionFeedNewEmployeeTestDataLoad.ddl";
    public static final String CREATE_PRODUCTCATALOG_TABLES = "/dbScripts/ProductCatalog.ddl";
    public static final String TRANSACTION_FEED_NEW_PRODCATALOG_SKU_TEST_DATA_LOAD = "/dbScripts/TransactionFeedNewProdCatalogSkuTestDataLoad.ddl";
    public static final String INDIVIDUAL_PHONE_TEST_DATA_LOAD = "/dbScripts/MindividualPhoneTestDataLoad.ddl";
    public static final String M_PROFILE_TEST_DATA_LOAD = "/dbScripts/MProfileTestDataLoad.ddl";
    public static final String M_TRANACTION_ITEM_AND_ADJUSTMENT_TEST_DATA_LOAD = "/dbScripts/MTransactionItemAndAdjustmentTestDataLoad.ddl";
    public static final String CREATE_M_TRANSACTION_ITEM_TABLES = "/dbScripts/MTransactionItemTable.ddl";
    public static final String MART_TRANSACTION_TABLES_CREATE = "/dbScripts/TransactionMartTablesCreate.ddl";
    public static final String REF_MONETARY_CREATE = "/dbScripts/RefMonetary.ddl";
    public static final String REF_RECENCY_CREATE = "/dbScripts/RefRecency.ddl";
    public static final String REF_PURCHASE_CHANNEL_CREATE = "/dbScripts/RefPurchaseChannel.ddl";
    public static final String REF_FREQUENCY_CREATE = "/dbScripts/RefFrequency.ddl";
    public static final String REF_CUST_LIFECYCLE_CREATE = "/dbScripts/RefCustLifeCycle.ddl";
    public static final String CREATE_AGG_MONETARY_LAST_12_MONTHS_TABLE = "/dbScripts/AggMonetaryLast12Months.ddl";
    public static final String CREATE_AGG_MONETARY_13_24_MONTHS_TABLE = "/dbScripts/AggMonetary1324Months.ddl";
    public static final String CREATE_AGG_MONETARY_LIFETIME_TABLE = "/dbScripts/AggMonetaryLifetime.ddl";

    // CSV Headers
    public static final String CSV_HEADER_LINE_TRANS_HEADER = "TXN_NBR,TXN_SRC_CD,BRAND_CD,TXN_DT,TXN_COMPLETE_DT,TXN_CHANNEL_CD,MOBILE_IND,CLIENTELLING_IND,EMPLOYEE_PUR_IND,SALES_LOCATION_NBR,REGISTER_NBR,EMPLOYEE_ID,TXN_SEQ_NBR,TXN_BUSINESS_DT,BILL_ACCT_SRC_CD,BILL_ACCT_SRC_NBR,LOYALTY_ACCT_SRC_CD,LOYALTY_ACCT_NBR,LOGIN_ID,IP_ADDRESS,SRC_KEYCODE,SRC_FIRST_NM,SRC_MIDDLE_NM,SRC_LAST_NM,SRC_UNPARSED_NM,SRC_BUSINESS_NM,SRC_ADDR_LINE_1,SRC_ADDR_LINE_2,SRC_ADDR_LINE_3,SRC_ADDR_LINE_4,SRC_CITY,SRC_STATE,POSTAL_CD,src_country,src_iso_country,EMAIL_ADDR,PHONE_NBR,RECEIPT_DELIVERY_METHOD_CD,ERECEIPT_EMAIL_ADDR,EMAIL_CAPTURE_TYPE_CD,EMAIL_CAPTURE_IND,TXN_TYPE_CD,TXN_SUBTYPE_CD,RELATED_TXN_NBR,RELATED_TXN_DT,PUR_TXN_AMT,PUR_TAX_AMT,PUR_SH_AMT,PUR_DISC_AMT,CNCL_TXN_AMT,CNCL_TAX_AMT,CNCL_SH_AMT,CNCL_DISC_AMT,RTN_TXN_AMT,RTN_TAX_AMT,RTN_SH_AMT,RTN_DISC_AMT,CURRENCY_CD,FOREIGN_IND,BUYER_TYPE_CD,TRANSACTION_VOID_IND,TRANSACTION_STATUS_CD,TRANSACTION_REMARK,ITEM_PRICE_OVERRIDE_IND,SHIP_PRICE_OVERRIDE_IND,RTN_REASON_CD,ACTIVITY_DT";
    public static final String CSV_HEADER_LINE_TRANS_ITEM = "TXN_NBR,TXN_SRC_CD,BRAND_CD,TXN_LINE_NBR,TXN_DT,SHIPTO_ACCT_SRC_CD,SHIPTO_ACCT_SRC_NBR,SHIPTO_BILLTO_IND,SHIPTO_FIRST_NM,SHIPTO_MIDDLE_NM,SHIPTO_LAST_NM,SHIPTO_UNPARSED_NM,SHIPTO_BUSINESS_NM,SHIPTO_ADDR_LINE_1,SHIPTO_ADDR_LINE_2,SHIPTO_ADDR_LINE_3,SHIPTO_ADDR_LINE_4,SHIPTO_CITY,SHIPTO_STATE,SHIPTO_POSTAL_CD,SHIPTO_COUNTRY,ISO_COUNTRY_CD,SHIPTO_EMAIL_ADDR,SHIPTO_PHONE_NBR,QTY,UOM,FIRST_SHIP_DT,LAST_SHIP_DT,SHIP_QTY,SHIP_UOM,SKU,UPC,SIZE_CD,COLOR_DESC,STD_COLOR_CD,FULFILL_STORE_NBR,FULFILL_GROUP_NBR,ITEM_FULFILLMENT_TYPE_CD,ITEM_TYPE_CD,LIST_PRICE_AMT,OFFER_PRICE_AMT,SOLD_PRICE_AMT,COGS_AMT,EXT_OFFER_AMT,EXT_ITEM_AMT,EXT_DISC_AMT,EXT_SH_AMT,ITEM_STATUS_CD,BACKORDER_QTY,BACKORDER_DT,BACKORDER_EXP_FULFILL_DT,BACKORDER_ACT_FULFILL_DT,ITEM_GIFT_IND,GWP_IND,BOGO_IND,GIFT_WRAP_IND,MARKDOWN_IND,RETURN_DT,RETURN_REASON_CD,CANCEL_DT,CANCEL_REASON_CD,TAX_RT,EXT_TXN_AMT,CURRENCY_CD,EXCHANGE_RT,SURCHARGE_AMT,SURCHARGE_REASON_CD,ACTIVITY_DT";

    // File Prefixes
    public static final String FILE_PREFIX_TRANS_HEADER_LINKPROF = "TransactionHeaderAutomationTestStandard_LinkProf_";
    public static final String FILE_PREFIX_TRANS_ITEM_LINKPROF = "TransactionItemAutomationTestStandard_LinkProf_";

    public static final String REC_SRC_CD_BILLTO = "BILLTO";
    public static final String REC_SRC_CD_SHIPTO = "SHIPTO";
    public static final String REC_SRC_CD_PROFILE = "PROFILE";
    public static final String REC_SRC_CD_EMPLOYEE = "CEMP";

    public static final String DEFAULT_RECORD_BRAND_CD = "Enterprise";

}
