package com.epsilon.dcrm.objects.comparer;

import lombok.Data;

@Data
public class DimensionTransactionTenderComparer implements Comparable<DimensionTransactionTenderComparer> {
    private String brandCd;
    private String txnSrcCd;
    private String txnNbr;
    private String tenderSeqNbr;
    private String tenderDt;
    private String tenderTypeCd;
    private String tenderSubTypeCd;
    private String tenderAmt;
    private String surrogateNbr;
    private String swipeFirstNm;
    private String swipeLastNm;
    private String activityDt;

    @Override
    public int compareTo(DimensionTransactionTenderComparer o) {
        String o1Key = new StringBuilder()
                .append(brandCd)
                .append(txnSrcCd)
                .append(tenderSeqNbr)
                .append(txnNbr)
                .toString();
        String o2Key = new StringBuilder()
                .append(o.getBrandCd())
                .append(o.getTxnSrcCd())
                .append(o.getTenderSeqNbr())
                .append(o.getTxnNbr())
                .toString();

        return o1Key.compareToIgnoreCase(o2Key);
    }
}
