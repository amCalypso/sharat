package com.epsilon.dcrm.service.impl;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.epsilon.dcrm.exception.ApplicationException;
import com.epsilon.dcrm.objects.CopyMessage;
import com.epsilon.dcrm.objects.TransformationRunSQSMessage;
import com.epsilon.dcrm.service.SQSService;
import com.epsilon.dcrm.type.ProcessErrorCode;
import com.epsilon.dcrm.util.JsonUtil;

@Service
public class SQSServiceImpl implements SQSService {
    private static final Logger logger = LoggerFactory.getLogger(SQSServiceImpl.class);

    @Value("${sqs.url}")
    private String sqsUrl;

    @Autowired
    private AmazonSQS sqsClient;

    @Override
    public CopyMessage pollSQS(String jobName) throws ApplicationException {
        List<Message> messages = null;
        int maxAttempts = 30;
        try {
            while (maxAttempts > 0) {
                messages = sqsClient.receiveMessage(new ReceiveMessageRequest(sqsUrl).withWaitTimeSeconds(20)).getMessages();
                if (messages != null) {
                    for (Message msg : messages) {
                        CopyMessage sqsCopyMessage = JsonUtil.getObject(msg.getBody(), CopyMessage.class);
                        if (sqsCopyMessage.getJobName().equals(jobName)) {
                            sqsClient.deleteMessage(new DeleteMessageRequest()
                                    .withQueueUrl(sqsUrl)
                                    .withReceiptHandle(msg.getReceiptHandle()));
                            return sqsCopyMessage;
                        }
                    }
                } else {
                    maxAttempts--;
                }
            }
        } catch (IOException e) {
            logger.error("Exception : {}", e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        logger.error("****FAILED****  - SQS poller timed out");
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, String.format("****FAILED****  - SQS poller timed out"));
    }

    @Override
    public <T> void postMessageToSQS(T sqsMessage, String queueUrl) {
        sqsClient.sendMessage(new SendMessageRequest().withQueueUrl(queueUrl).withMessageBody(JsonUtil.getJson(sqsMessage)));
    }

    @Override
    public List<Message> pollSQSMessages(String queueUrl, int waitTimeBetweenPolls) {
        return sqsClient.receiveMessage(new ReceiveMessageRequest(queueUrl).withWaitTimeSeconds(waitTimeBetweenPolls)).getMessages();
    }

    @Override
    public <T> T pollSQS(Class<T> beanClazz, String jobName, String taskId, String queueUrl, int maxAttempts, int waitTimeBetweenPolls) throws ApplicationException {
        List<Message> messages = null;
        waitTimeBetweenPolls = 0;
        try {
            while (maxAttempts > 0) {
                messages = sqsClient.receiveMessage(new ReceiveMessageRequest(queueUrl).withWaitTimeSeconds(waitTimeBetweenPolls)).getMessages();
                if (messages != null) {
                    for (Message msg : messages) {
                        if (beanClazz.equals(TransformationRunSQSMessage.class)) {
                            TransformationRunSQSMessage sqsMessage = (TransformationRunSQSMessage) JsonUtil.getObject(msg.getBody(), TransformationRunSQSMessage.class);
                            if (sqsMessage != null && jobName.equals(sqsMessage.getJobName()) && taskId.equals(sqsMessage.getAutomationTestId())) {
                                deleteSqsMsg(queueUrl, msg);
                                return beanClazz.cast(sqsMessage);
                            }
                        }
                    }
                }
                try {
                    Thread.sleep(15000);
                } catch (Exception e) {

                }
                maxAttempts--;
            }
        } catch (IOException e) {
            logger.error("Exception : {}", e.getMessage());
            throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, e.getMessage());
        }
        logger.error("****FAILED****  - SQS poller timed out for job {} , taskId - {}", jobName, taskId);
        throw new ApplicationException(ProcessErrorCode.APPLICATION_ERROR, String.format("****FAILED****  - SQS poller timed out"));
    }

    @Override
    public void deleteSqsMsg(String queueUrl, Message msg) {
        sqsClient.deleteMessage(new DeleteMessageRequest()
                .withQueueUrl(queueUrl)
                .withReceiptHandle(msg.getReceiptHandle()));
    }
}
