package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the s_transaction_certificate table.
 * @author kkapoor
 *
 */
@Data
public class TransactionCertificateId implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String txnNbr;

    private String txnSrcCd;

    private String brandCd;

    private String certNbr;

    private Long createFileRecNbr;

    private Long createFileId;
}
