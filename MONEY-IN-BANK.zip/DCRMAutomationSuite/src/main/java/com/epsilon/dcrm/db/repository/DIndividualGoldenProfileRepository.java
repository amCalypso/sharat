package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionIndividualGoldenProfile;
import com.epsilon.dcrm.model.id.DimensionIndividualGoldenProfileId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DIndividualGoldenProfileRepository extends BaseRepository<DimensionIndividualGoldenProfile, DimensionIndividualGoldenProfileId> {

    List<DimensionIndividualGoldenProfile> findByBrandCd(String brandCd);

    Long deleteByBrandCd(String brandCd);

    List<DimensionIndividualGoldenProfile> findByIndivId(Long indivId);

    Long deleteByIndivId(Long indivId);

    List<DimensionIndividualGoldenProfile> findByDcrmIndivEmailId(Long dcrmIndivEmailId);

    List<DimensionIndividualGoldenProfile> findByIndivIdAndBrandCd(Long indivId, String brandCd);

    Long deleteByIndivIdAndBrandCd(Long indivId, String brandCd);

    @Modifying
    @Query(value = "INSERT INTO test_crm_warehouse.d_individual_golden_profile" +
            "(indiv_id, brand_cd, name_prefix, first_nm, middle_nm, last_nm, name_suffix, marital_status_cd, gender_cd," +
            "birth_dt, dcrm_indiv_addr_id, dcrm_indiv_email_id, dcrm_indiv_phone_id, dcrm_profile_id)" +
            "VALUES(?1, ?2, 'Mr', 'bruce', 'bat', 'wayne', 'I', 'S','M', '1980-12-14', ?3, ?4, ?5, 2);", nativeQuery = true)
    void insertSimpleTestRecord(Long indivId, String brandCd, Long dcrmIndivAddrId, Long dcrmIndivEmailId, Long dcrmIndivPhoneId);
}
