package com.epsilon.dcrm.model.id;

import java.io.Serializable;

import lombok.Data;

/**
 * This is the IDClass for the dv_individual_summary view.
 * @author adomakonda
 *
 */
@Data
public class DvIndividualSummaryId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long indivId;

    private String brandCd;

}
