package com.epsilon.dcrm.db.repository;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.epsilon.dcrm.model.dimension.DimensionProfileSocial;
import com.epsilon.dcrm.model.id.ProfileSocialId;

@Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRES_NEW)
public interface DProfileSocialRepository extends BaseRepository<DimensionProfileSocial, ProfileSocialId> {
    List<DimensionProfileSocial> findByDcrmSocialAcctId(Long dcrmSocialAcctId);
}
