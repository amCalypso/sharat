package com.epsilon.dcrm.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties("loyalty.api")
public class LoyaltyApiProperties {
    private String baseUrl;
    private Endpoint endpoint;

    @Data
    public static class Endpoint {
        private String tables;
        private String tableById;
        private String mappings;
        private String mappingById;
        private String aggregations;
        private String aggregationById;
    }
}
